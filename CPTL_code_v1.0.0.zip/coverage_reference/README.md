# Historical coverage/control implementation

This is a separate snapshot of the CPTL control pipeline. Its `coollink_sg` package has the same name as the primary package but different routing implementation. Install and run it in a separate environment with this folder as the working directory.

Copy the processed-data archive's `data/` and `outputs/` into this folder before running data-dependent controls. Raw external acquisition data are not bundled. The satellite RS-CPTL/RS-PTL models and their figure utilities are excluded. One external raw-index integration test is skipped with an explicit reason if its input is absent.
