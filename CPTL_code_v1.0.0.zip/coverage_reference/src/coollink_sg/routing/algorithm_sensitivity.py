"""One-factor-at-a-time sensitivity of the dynamic CPTL routing algorithm."""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any

import geopandas as gpd
import pandas as pd
import yaml

from coollink_sg.config import DynamicCPTLConfig, load_dynamic_cptl_config
from coollink_sg.heat.dynamic_utci import TimeVaryingUTCI
from coollink_sg.routing.multi_od_cptl import _routing_graph
from coollink_sg.routing.time_dependent_cptl import compute_time_dependent_cptl_routes

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class AlgorithmSensitivityConfig:
    """Validated inputs for an OFAT routing-algorithm sensitivity run."""

    analysis_id: str
    design: str
    base_dynamic_cptl_config: str
    od_sample: str
    output_stem: str
    detour_limits: tuple[float, ...]
    time_bins_seconds: tuple[int, ...]
    walking_speeds_m_s: tuple[float, ...]
    primary_thresholds_deg_c: tuple[float, ...]
    baseline_time_bin_seconds: int
    baseline_walking_speed_m_s: float
    baseline_primary_threshold_deg_c: float


@dataclass(frozen=True)
class AlgorithmVariant:
    """One baseline or single-parameter routing variant."""

    variant_id: str
    varied_parameter: str
    varied_value: float
    time_bin_seconds: int
    walking_speed_m_s: float
    primary_threshold_deg_c: float


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    if key not in mapping:
        raise ValueError(f"Missing required field {section}.{key}")
    return mapping[key]


def load_algorithm_sensitivity_config(path: Path) -> AlgorithmSensitivityConfig:
    """Load and validate the OFAT routing sensitivity configuration."""

    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Algorithm sensitivity configuration must be a YAML mapping")
    analysis = _required(payload, "routing_algorithm_sensitivity", "root")
    parameters = _required(payload, "parameters", "root")
    baseline = _required(payload, "baseline", "root")
    design = str(_required(analysis, "design", "routing_algorithm_sensitivity"))
    if design != "one_factor_at_a_time":
        raise ValueError("Only one_factor_at_a_time sensitivity is supported")

    limits = tuple(float(value) for value in _required(parameters, "detour_limits", "parameters"))
    bins = tuple(int(value) for value in _required(parameters, "time_bin_seconds", "parameters"))
    speeds = tuple(
        float(value) for value in _required(parameters, "walking_speed_m_s", "parameters")
    )
    thresholds = tuple(
        float(value)
        for value in _required(parameters, "primary_cptl_threshold_deg_c", "parameters")
    )
    if limits != tuple(sorted(set(limits))) or not limits or limits[0] != 0:
        raise ValueError("detour_limits must be unique, increasing, and start at zero")
    if any(value <= 0 for value in bins) or len(set(bins)) != len(bins):
        raise ValueError("time_bin_seconds must contain unique positive values")
    if any(value <= 0 for value in speeds) or len(set(speeds)) != len(speeds):
        raise ValueError("walking_speed_m_s must contain unique positive values")
    if len(set(thresholds)) != len(thresholds):
        raise ValueError("primary thresholds must be unique")
    baseline_bin = int(_required(baseline, "time_bin_seconds", "baseline"))
    baseline_speed = float(_required(baseline, "walking_speed_m_s", "baseline"))
    baseline_threshold = float(_required(baseline, "primary_cptl_threshold_deg_c", "baseline"))
    if (
        baseline_bin not in bins
        or baseline_speed not in speeds
        or baseline_threshold not in thresholds
    ):
        raise ValueError("Every baseline value must be included in its sensitivity values")
    output_stem = str(_required(analysis, "output_stem", "routing_algorithm_sensitivity"))
    if not output_stem or Path(output_stem).name != output_stem:
        raise ValueError("output_stem must be a filename stem")
    return AlgorithmSensitivityConfig(
        analysis_id=str(_required(analysis, "analysis_id", "routing_algorithm_sensitivity")),
        design=design,
        base_dynamic_cptl_config=str(
            _required(analysis, "base_dynamic_cptl_config", "routing_algorithm_sensitivity")
        ),
        od_sample=str(_required(analysis, "od_sample", "routing_algorithm_sensitivity")),
        output_stem=output_stem,
        detour_limits=limits,
        time_bins_seconds=bins,
        walking_speeds_m_s=speeds,
        primary_thresholds_deg_c=thresholds,
        baseline_time_bin_seconds=baseline_bin,
        baseline_walking_speed_m_s=baseline_speed,
        baseline_primary_threshold_deg_c=baseline_threshold,
    )


def build_algorithm_variants(config: AlgorithmSensitivityConfig) -> tuple[AlgorithmVariant, ...]:
    """Return the baseline once and every non-baseline OFAT variant."""

    variants = [
        AlgorithmVariant(
            variant_id="baseline",
            varied_parameter="baseline",
            varied_value=0.0,
            time_bin_seconds=config.baseline_time_bin_seconds,
            walking_speed_m_s=config.baseline_walking_speed_m_s,
            primary_threshold_deg_c=config.baseline_primary_threshold_deg_c,
        )
    ]
    for value in config.time_bins_seconds:
        if value != config.baseline_time_bin_seconds:
            variants.append(
                AlgorithmVariant(
                    variant_id=f"time_bin_{value}s",
                    varied_parameter="time_bin_seconds",
                    varied_value=float(value),
                    time_bin_seconds=value,
                    walking_speed_m_s=config.baseline_walking_speed_m_s,
                    primary_threshold_deg_c=config.baseline_primary_threshold_deg_c,
                )
            )
    for value in config.walking_speeds_m_s:
        if value != config.baseline_walking_speed_m_s:
            text = f"{value:g}".replace(".", "p")
            variants.append(
                AlgorithmVariant(
                    variant_id=f"walking_speed_{text}mps",
                    varied_parameter="walking_speed_m_s",
                    varied_value=value,
                    time_bin_seconds=config.baseline_time_bin_seconds,
                    walking_speed_m_s=value,
                    primary_threshold_deg_c=config.baseline_primary_threshold_deg_c,
                )
            )
    for value in config.primary_thresholds_deg_c:
        if value != config.baseline_primary_threshold_deg_c:
            text = f"{value:g}".replace(".", "p")
            variants.append(
                AlgorithmVariant(
                    variant_id=f"primary_threshold_{text}c",
                    varied_parameter="primary_threshold_deg_c",
                    varied_value=value,
                    time_bin_seconds=config.baseline_time_bin_seconds,
                    walking_speed_m_s=config.baseline_walking_speed_m_s,
                    primary_threshold_deg_c=value,
                )
            )
    return tuple(variants)


def summarize_algorithm_sensitivity(routes: pd.DataFrame) -> pd.DataFrame:
    """Summarize route benefit across OD and departure cases for every variant."""

    rows: list[dict[str, Any]] = []
    for (variant_id, cap), frame in routes.groupby(
        ["variant_id", "detour_limit_fraction"], sort=False
    ):
        reductions = frame["primary_cptl_reduction_vs_shortest_percent"]
        rows.append(
            {
                "variant_id": variant_id,
                "varied_parameter": frame["varied_parameter"].iloc[0],
                "varied_value": float(frame["varied_value"].iloc[0]),
                "time_bin_seconds": int(frame["time_bin_seconds"].iloc[0]),
                "walking_speed_m_s": float(frame["walking_speed_m_s"].iloc[0]),
                "primary_threshold_deg_c": float(frame["primary_threshold_deg_c"].iloc[0]),
                "detour_limit_fraction": float(cap),
                "case_count": len(frame),
                "median_cptl_reduction_percent": float(reductions.median()),
                "mean_cptl_reduction_percent": float(reductions.mean()),
                "q25_cptl_reduction_percent": float(reductions.quantile(0.25)),
                "q75_cptl_reduction_percent": float(reductions.quantile(0.75)),
                "positive_reduction_share_percent": float(100 * reductions.gt(1e-9).mean()),
                "median_distance_increase_percent": float(
                    100 * (frame["distance_ratio_to_shortest"].median() - 1)
                ),
            }
        )
    return pd.DataFrame(rows)


def run_algorithm_sensitivity(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Run all routing variants on the fixed canopy thermal field and OD sample."""

    sensitivity = load_algorithm_sensitivity_config(config_path)
    base = load_dynamic_cptl_config(project_root / sensitivity.base_dynamic_cptl_config)
    if not base.is_solweig_dynamic_result or "canopy" not in base.thermal_source_status:
        raise ValueError("Algorithm sensitivity must use the SOLWEIG canopy thermal field")
    if not set(sensitivity.primary_thresholds_deg_c).issubset(base.sensitivity_thresholds_deg_c):
        raise ValueError("All optimized thresholds must be available as evaluation thresholds")
    network_path = project_root / base.network_path
    nodes = gpd.read_file(network_path, layer=base.nodes_layer)
    edges = gpd.read_file(network_path, layer=base.edges_layer)
    graph = _routing_graph(nodes, edges, base.output_crs)
    thermal = TimeVaryingUTCI(
        pd.read_csv(project_root / base.dynamic_thermal_path),
        base.primary_height_scenario,
        base.thermal_source_status,
    )
    od_sample = pd.read_csv(project_root / sensitivity.od_sample)
    required_od = {"od_id", "origin_node", "destination_node", "distance_band_rank"}
    missing_od = required_od.difference(od_sample.columns)
    if missing_od or od_sample["od_id"].duplicated().any():
        raise ValueError(f"OD sample is invalid; missing fields: {sorted(missing_od)}")

    route_frames: list[gpd.GeoDataFrame] = []
    variants = build_algorithm_variants(sensitivity)
    for variant_index, variant in enumerate(variants, start=1):
        run_config: DynamicCPTLConfig = replace(
            base,
            analysis_id=f"{sensitivity.analysis_id}|{variant.variant_id}",
            detour_limits=sensitivity.detour_limits,
            time_bin_seconds=variant.time_bin_seconds,
            walking_speed_m_s=variant.walking_speed_m_s,
            primary_threshold_deg_c=variant.primary_threshold_deg_c,
        )
        for od_index, od in enumerate(od_sample.itertuples(index=False), start=1):
            print(
                f"[{variant_index}/{len(variants)} {variant.variant_id}] "
                f"OD {od_index}/{len(od_sample)} {od.od_id}",
                flush=True,
            )
            routes, _, _ = compute_time_dependent_cptl_routes(
                nodes,
                edges,
                thermal,
                int(od.origin_node),
                int(od.destination_node),
                run_config,
                routing_graph=graph,
            )
            routes.insert(0, "variant_id", variant.variant_id)
            routes.insert(1, "varied_parameter", variant.varied_parameter)
            routes.insert(2, "varied_value", variant.varied_value)
            routes.insert(3, "primary_threshold_deg_c", variant.primary_threshold_deg_c)
            routes.insert(4, "walking_speed_m_s", variant.walking_speed_m_s)
            routes.insert(5, "od_id", od.od_id)
            routes.insert(6, "origin_node", int(od.origin_node))
            routes.insert(7, "destination_node", int(od.destination_node))
            routes.insert(8, "distance_band_rank", int(od.distance_band_rank))
            route_frames.append(routes)
    all_routes = gpd.GeoDataFrame(
        pd.concat(route_frames, ignore_index=True),
        geometry="geometry",
        crs=base.output_crs,
    )
    summary = summarize_algorithm_sensitivity(all_routes)
    baseline_routes = all_routes.loc[
        all_routes["variant_id"].eq("baseline"),
        ["od_id", "departure_time_sgt", "detour_limit_fraction", "route_id"],
    ].rename(columns={"route_id": "baseline_route_id"})
    comparison = all_routes.merge(
        baseline_routes,
        on=["od_id", "departure_time_sgt", "detour_limit_fraction"],
        how="left",
        validate="many_to_one",
    )
    comparison["route_changed_vs_baseline"] = comparison["route_id"].ne(
        comparison["baseline_route_id"]
    )

    processed = project_root / "data/processed/routing"
    processed.mkdir(parents=True, exist_ok=True)
    geopackage = processed / f"{sensitivity.output_stem}.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    all_routes.to_file(geopackage, layer="algorithm_sensitivity_routes", driver="GPKG")
    all_routes.drop(columns="geometry").to_csv(
        processed / f"{sensitivity.output_stem}_routes.csv", index=False
    )
    summary.to_csv(processed / f"{sensitivity.output_stem}_summary.csv", index=False)
    comparison.drop(columns="geometry").to_csv(
        processed / f"{sensitivity.output_stem}_comparison.csv", index=False
    )
    five = summary.loc[summary["detour_limit_fraction"].eq(0.05)].copy()
    result = {
        "analysis_id": sensitivity.analysis_id,
        "design": sensitivity.design,
        "thermal_source_status": base.thermal_source_status,
        "od_count": int(od_sample["od_id"].nunique()),
        "departure_count": len(base.departure_times),
        "detour_limits": list(sensitivity.detour_limits),
        "variant_count": len(variants),
        "route_scenario_count": len(all_routes),
        "five_percent_cap_median_reduction_range_percent": [
            float(five["median_cptl_reduction_percent"].min()),
            float(five["median_cptl_reduction_percent"].max()),
        ],
        "variants": [variant.__dict__ for variant in variants],
        "interpretation_limit": (
            "This is an OFAT computational sensitivity on one CHMv2 clear-sky SOLWEIG "
            "thermal field and a network-coverage OD sample, not a global interaction "
            "analysis, observed demand model, field validation, or health assessment."
        ),
        "outputs": {
            "geopackage": str(geopackage.relative_to(project_root)),
            "routes_csv": f"data/processed/routing/{sensitivity.output_stem}_routes.csv",
            "summary_csv": f"data/processed/routing/{sensitivity.output_stem}_summary.csv",
            "comparison_csv": f"data/processed/routing/{sensitivity.output_stem}_comparison.csv",
        },
    }
    summary_path = processed / f"{sensitivity.output_stem}.json"
    summary_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="Run dynamic CPTL algorithm sensitivity.")
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/routing_algorithm_sensitivity.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(run_algorithm_sensitivity(args.config), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
