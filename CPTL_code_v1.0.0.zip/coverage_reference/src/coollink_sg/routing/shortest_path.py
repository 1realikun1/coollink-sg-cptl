"""Directed shortest-distance routing on the processed pedestrian network."""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from itertools import pairwise
from pathlib import Path
from typing import Any

import geopandas as gpd
import networkx as nx
import pandas as pd
from pyproj import CRS
from shapely.geometry import Point

from coollink_sg.config import ShortestPathConfig, load_shortest_path_config

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class ShortestRoute:
    """One distance-minimizing route and its selected directed edges."""

    origin_node: int
    destination_node: int
    distance_m: float
    node_path: tuple[int, ...]
    edges: gpd.GeoDataFrame


def build_routing_graph(
    nodes: gpd.GeoDataFrame,
    edges: gpd.GeoDataFrame,
    config: ShortestPathConfig,
) -> nx.MultiDiGraph:
    """Validate processed layers and build a directed multigraph with geometry."""

    node_fields = {"osmid", "geometry"}
    edge_fields = {"u", "v", "key", "segment_id", config.cost_field, "geometry"}
    missing_nodes = node_fields.difference(nodes.columns)
    missing_edges = edge_fields.difference(edges.columns)
    if missing_nodes:
        raise ValueError(f"Nodes are missing fields: {sorted(missing_nodes)}")
    if missing_edges:
        raise ValueError(f"Edges are missing fields: {sorted(missing_edges)}")
    if nodes.crs is None or edges.crs is None:
        raise ValueError("Nodes and edges must have explicit CRS values")
    expected = CRS.from_user_input(config.output_crs)
    if CRS.from_user_input(nodes.crs) != expected:
        raise ValueError(f"Node CRS must equal configured {config.output_crs}")
    if CRS.from_user_input(edges.crs) != expected:
        raise ValueError(f"Edge CRS must equal configured {config.output_crs}")
    if nodes["osmid"].isna().any() or nodes["osmid"].duplicated().any():
        raise ValueError("Node osmid values must be complete and unique")
    if edges["segment_id"].isna().any() or edges["segment_id"].duplicated().any():
        raise ValueError("Edge segment_id values must be complete and unique")
    cost = pd.to_numeric(edges[config.cost_field], errors="raise")
    if cost.isna().any() or (cost <= 0).any():
        raise ValueError(f"Every edge {config.cost_field} must be positive")
    node_ids = set(nodes["osmid"])
    unknown = set(edges["u"]).union(edges["v"]).difference(node_ids)
    if unknown:
        raise ValueError(f"Edges reference {len(unknown)} unknown nodes")

    graph = nx.MultiDiGraph(crs=config.output_crs)
    for row in nodes.itertuples(index=False):
        graph.add_node(
            int(row.osmid),
            x=float(row.geometry.x),
            y=float(row.geometry.y),
            geometry=row.geometry,
        )
    for index, row in edges.iterrows():
        attributes = row.to_dict()
        u = int(attributes.pop("u"))
        v = int(attributes.pop("v"))
        key = int(attributes.pop("key"))
        attributes[config.cost_field] = float(cost.loc[index])
        graph.add_edge(u, v, key=key, **attributes)
    return graph


def nearest_network_node(
    nodes: gpd.GeoDataFrame,
    x: float,
    y: float,
    point_crs: str,
) -> tuple[int, float]:
    """Return the nearest node and planar snap distance in the network CRS."""

    if nodes.crs is None:
        raise ValueError("Nodes must have an explicit CRS")
    point = gpd.GeoSeries([Point(x, y)], crs=point_crs).to_crs(nodes.crs).iloc[0]
    distances = nodes.geometry.distance(point)
    index = distances.idxmin()
    return int(nodes.loc[index, "osmid"]), float(distances.loc[index])


def _select_edge(
    graph: nx.MultiDiGraph,
    u: int,
    v: int,
    cost_field: str,
) -> tuple[int, dict[str, Any]]:
    candidates = graph.get_edge_data(u, v)
    if not candidates:
        raise ValueError(f"Node path contains no directed edge from {u} to {v}")
    key, attributes = min(
        candidates.items(),
        key=lambda item: (
            float(item[1][cost_field]),
            str(item[1]["segment_id"]),
            int(item[0]),
        ),
    )
    return int(key), attributes


def shortest_route(
    graph: nx.MultiDiGraph,
    origin_node: int,
    destination_node: int,
    cost_field: str = "length_m",
) -> ShortestRoute:
    """Find a directed Dijkstra route and recover its exact parallel edges."""

    if origin_node == destination_node:
        raise ValueError("Origin and destination nodes must be different")
    if origin_node not in graph:
        raise ValueError(f"Origin node is not in the network: {origin_node}")
    if destination_node not in graph:
        raise ValueError(f"Destination node is not in the network: {destination_node}")
    try:
        node_path = nx.shortest_path(
            graph,
            source=origin_node,
            target=destination_node,
            weight=cost_field,
            method="dijkstra",
        )
    except nx.NetworkXNoPath as exc:
        raise ValueError(
            f"No directed path exists from {origin_node} to {destination_node}"
        ) from exc

    rows: list[dict[str, Any]] = []
    for sequence, (u, v) in enumerate(pairwise(node_path)):
        key, attributes = _select_edge(graph, int(u), int(v), cost_field)
        rows.append(
            {
                "route_sequence": sequence,
                "u": int(u),
                "v": int(v),
                "key": key,
                **attributes,
            }
        )
    route_edges = gpd.GeoDataFrame(rows, geometry="geometry", crs=graph.graph["crs"])
    distance = float(route_edges[cost_field].sum())
    return ShortestRoute(
        origin_node=origin_node,
        destination_node=destination_node,
        distance_m=distance,
        node_path=tuple(int(node) for node in node_path),
        edges=route_edges,
    )


def routing_quality_summary(
    graph: nx.MultiDiGraph,
    config: ShortestPathConfig,
) -> dict[str, Any]:
    """Run a deterministic real-network smoke route and summarize connectivity."""

    components = list(nx.weakly_connected_components(graph))
    largest = max(components, key=len)
    smoke_u, smoke_v, _ = min(
        graph.edges(keys=True), key=lambda edge: (int(edge[0]), int(edge[1]), int(edge[2]))
    )
    route = shortest_route(graph, int(smoke_u), int(smoke_v), config.cost_field)
    return {
        "node_count": graph.number_of_nodes(),
        "directed_edge_count": graph.number_of_edges(),
        "weak_component_count": len(components),
        "largest_weak_component_node_count": len(largest),
        "largest_weak_component_node_percent": round(
            100 * len(largest) / graph.number_of_nodes(), 6
        ),
        "directed": graph.is_directed(),
        "multigraph": graph.is_multigraph(),
        "algorithm": "Dijkstra",
        "cost_field": config.cost_field,
        "cost_unit": "metre",
        "smoke_origin_node": route.origin_node,
        "smoke_destination_node": route.destination_node,
        "smoke_route_segment_count": len(route.edges),
        "smoke_route_distance_m": round(route.distance_m, 6),
        "travel_time": "not_calculated",
        "heat_cost": "not_used",
    }


def run_shortest_path_baseline(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
    origin_node: int | None = None,
    destination_node: int | None = None,
) -> dict[str, Any]:
    """Build the graph, save QA summary, and optionally save a requested route."""

    if (origin_node is None) != (destination_node is None):
        raise ValueError("origin_node and destination_node must be supplied together")
    config = load_shortest_path_config(config_path)
    network_path = project_root / config.network_path
    nodes = gpd.read_file(network_path, layer=config.nodes_layer)
    edges = gpd.read_file(network_path, layer=config.edges_layer)
    graph = build_routing_graph(nodes, edges, config)
    summary = routing_quality_summary(graph, config)

    processed = project_root / "data/processed/routing"
    tables = project_root / "outputs/tables"
    processed.mkdir(parents=True, exist_ok=True)
    tables.mkdir(parents=True, exist_ok=True)
    if origin_node is not None and destination_node is not None:
        route = shortest_route(graph, origin_node, destination_node, config.cost_field)
        route_path = processed / "shortest_route_latest.gpkg"
        if route_path.exists():
            route_path.unlink()
        route.edges.to_file(route_path, layer="shortest_route", driver="GPKG")
        route.edges.drop(columns="geometry").to_csv(
            processed / "shortest_route_latest.csv", index=False
        )
        summary["requested_route"] = {
            "origin_node": origin_node,
            "destination_node": destination_node,
            "segment_count": len(route.edges),
            "distance_m": route.distance_m,
        }
    else:
        summary["requested_route"] = None
    (processed / "shortest_path_baseline_quality.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    flat = {key: value for key, value in summary.items() if key != "requested_route"}
    pd.DataFrame([flat]).to_csv(
        tables / "shortest_path_baseline_quality.csv", index=False
    )
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(
        description="Run the directed shortest-distance routing baseline."
    )
    parser.add_argument(
        "--config", type=Path, default=PROJECT_ROOT / "config/shortest_path.yaml"
    )
    parser.add_argument("--origin-node", type=int, default=None)
    parser.add_argument("--destination-node", type=int, default=None)
    args = parser.parse_args()
    print(
        json.dumps(
            run_shortest_path_baseline(
                args.config,
                origin_node=args.origin_node,
                destination_node=args.destination_node,
            ),
            indent=2,
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
