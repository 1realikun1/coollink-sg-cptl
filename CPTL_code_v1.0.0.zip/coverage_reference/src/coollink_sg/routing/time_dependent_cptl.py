"""Time-dependent cumulative UTCI-exceedance pedestrian routing."""

from __future__ import annotations

import argparse
import hashlib
import heapq
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import geopandas as gpd
import networkx as nx
import numpy as np
import pandas as pd
from shapely.geometry import MultiLineString

from coollink_sg.config import (
    DynamicCPTLConfig,
    ShortestPathConfig,
    load_dynamic_cptl_config,
)
from coollink_sg.heat.dynamic_utci import TimeVaryingUTCI
from coollink_sg.routing.shortest_path import build_routing_graph, shortest_route

PROJECT_ROOT = Path(__file__).resolve().parents[3]
LENGTH_FIELD = "length_m"


@dataclass(frozen=True)
class _DynamicLabel:
    node: int
    arrival_time: pd.Timestamp
    time_bin: int
    distance_m: float
    cptl_deg_c_min: float
    previous_label: int | None
    incoming_edge: tuple[int, int, int] | None


def _threshold_slug(threshold: float) -> str:
    text = f"{threshold:g}".replace("-", "minus_").replace(".", "p")
    return f"cptl_above_{text}_deg_c_min"


def _route_id(departure: pd.Timestamp, segment_ids: list[str]) -> str:
    payload = f"{departure.isoformat()}|{'|'.join(segment_ids)}".encode()
    return f"td_cptl_{hashlib.sha256(payload).hexdigest()[:12]}"


def _time_bin(
    departure: pd.Timestamp,
    arrival: pd.Timestamp,
    bin_seconds: int,
) -> int:
    elapsed = (arrival - departure).total_seconds()
    return int(np.floor((elapsed + 1e-9) / bin_seconds))


def _is_dominated_in_time_bin(
    labels: list[_DynamicLabel],
    candidate_ids: list[int],
    distance_m: float,
    cptl: float,
    tolerance: float,
) -> bool:
    return any(
        labels[label_id].distance_m <= distance_m + tolerance
        and labels[label_id].cptl_deg_c_min <= cptl + tolerance
        for label_id in candidate_ids
    )


def _dynamic_destination_labels(
    graph: nx.MultiDiGraph,
    thermal: TimeVaryingUTCI,
    origin_node: int,
    destination_node: int,
    departure_time: pd.Timestamp,
    maximum_distance_m: float,
    config: DynamicCPTLConfig,
) -> tuple[list[_DynamicLabel], list[int], dict[str, int]]:
    """Build time-binned non-dominated labels under one maximum distance cap."""

    if origin_node not in graph or destination_node not in graph:
        raise ValueError("Dynamic CPTL endpoints must exist in the network")
    if origin_node == destination_node:
        raise ValueError("Dynamic CPTL endpoints must differ")
    reverse = graph.reverse(copy=False)
    lower_bounds = nx.single_source_dijkstra_path_length(
        reverse, destination_node, weight=LENGTH_FIELD
    )
    if origin_node not in lower_bounds:
        raise ValueError("No directed path exists between the dynamic CPTL endpoints")
    tolerance = max(1e-7, maximum_distance_m * 1e-10)
    first = _DynamicLabel(
        node=origin_node,
        arrival_time=departure_time,
        time_bin=0,
        distance_m=0.0,
        cptl_deg_c_min=0.0,
        previous_label=None,
        incoming_edge=None,
    )
    labels = [first]
    active: set[int] = {0}
    state_labels: dict[tuple[int, int], list[int]] = {(origin_node, 0): [0]}
    destination_ids: list[int] = []
    queue: list[tuple[float, float, int]] = [(0.0, 0.0, 0)]
    generated = 1
    expanded = 0
    while queue:
        _, _, label_id = heapq.heappop(queue)
        if label_id not in active:
            continue
        label = labels[label_id]
        if label.node == destination_node:
            destination_ids.append(label_id)
            continue
        expanded += 1
        for _, target, key, attributes in graph.out_edges(
            label.node, keys=True, data=True
        ):
            edge_length = float(attributes[LENGTH_FIELD])
            if not np.isfinite(edge_length) or edge_length <= 0:
                raise ValueError("Dynamic CPTL edge lengths must be finite and positive")
            distance = label.distance_m + edge_length
            lower_bound = lower_bounds.get(int(target))
            if lower_bound is None or distance + lower_bound > maximum_distance_m + tolerance:
                continue
            duration_min = edge_length / config.walking_speed_m_s / 60
            exposure = thermal.integrate_exposure(
                str(attributes["segment_id"]),
                label.arrival_time,
                duration_min,
                (config.primary_threshold_deg_c,),
            )
            arrival = label.arrival_time + pd.to_timedelta(duration_min, unit="min")
            cptl = (
                label.cptl_deg_c_min
                + exposure.exceedance_deg_c_min[config.primary_threshold_deg_c]
            )
            time_bin = _time_bin(
                departure_time, arrival, config.time_bin_seconds
            )
            state = (int(target), time_bin)
            candidates = [
                candidate
                for candidate in state_labels.get(state, [])
                if candidate in active
            ]
            if _is_dominated_in_time_bin(
                labels, candidates, distance, cptl, tolerance
            ):
                continue
            for candidate in candidates:
                existing = labels[candidate]
                if (
                    distance <= existing.distance_m + tolerance
                    and cptl <= existing.cptl_deg_c_min + tolerance
                ):
                    active.discard(candidate)
            new_id = len(labels)
            labels.append(
                _DynamicLabel(
                    node=int(target),
                    arrival_time=arrival,
                    time_bin=time_bin,
                    distance_m=distance,
                    cptl_deg_c_min=cptl,
                    previous_label=label_id,
                    incoming_edge=(label.node, int(target), int(key)),
                )
            )
            active.add(new_id)
            state_labels.setdefault(state, []).append(new_id)
            heapq.heappush(queue, (cptl, distance, new_id))
            generated += 1
            if generated > 2_000_000:
                raise RuntimeError("Dynamic CPTL label safety limit exceeded")
    destination_ids = [label_id for label_id in destination_ids if label_id in active]
    if not destination_ids:
        raise ValueError("No dynamic CPTL route satisfies the maximum distance cap")
    return labels, destination_ids, {
        "generated_label_count": generated,
        "expanded_label_count": expanded,
        "destination_label_count": len(destination_ids),
        "time_bin_seconds": config.time_bin_seconds,
    }


def _select_destination_label(
    labels: list[_DynamicLabel],
    destination_ids: list[int],
    distance_cap_m: float,
) -> int:
    tolerance = max(1e-7, distance_cap_m * 1e-10)
    eligible = [
        label_id
        for label_id in destination_ids
        if labels[label_id].distance_m <= distance_cap_m + tolerance
    ]
    if not eligible:
        raise ValueError("No dynamic CPTL label is eligible under this distance cap")
    return min(
        eligible,
        key=lambda label_id: (
            labels[label_id].cptl_deg_c_min,
            labels[label_id].distance_m,
            labels[label_id].arrival_time.value,
            label_id,
        ),
    )


def _recover_edge_keys(
    labels: list[_DynamicLabel],
    destination_label: int,
) -> list[tuple[int, int, int]]:
    keys: list[tuple[int, int, int]] = []
    current = destination_label
    while labels[current].previous_label is not None:
        incoming = labels[current].incoming_edge
        if incoming is None:
            raise RuntimeError("Dynamic CPTL label chain is incomplete")
        keys.append(incoming)
        current = int(labels[current].previous_label)
    keys.reverse()
    return keys


def _evaluate_route(
    graph: nx.MultiDiGraph,
    edge_keys: list[tuple[int, int, int]],
    thermal: TimeVaryingUTCI,
    departure: pd.Timestamp,
    thresholds: tuple[float, ...],
    walking_speed_m_s: float,
) -> tuple[dict[str, float | str], list[dict[str, Any]], list[Any]]:
    current_time = departure
    totals = {threshold: 0.0 for threshold in thresholds}
    utci_integral = 0.0
    total_minutes = 0.0
    maximum_utci = -np.inf
    segment_rows: list[dict[str, Any]] = []
    geometries: list[Any] = []
    segment_ids: list[str] = []
    total_distance = 0.0
    for sequence, (u, v, key) in enumerate(edge_keys):
        attributes = graph[u][v][key]
        segment_id = str(attributes["segment_id"])
        length = float(attributes[LENGTH_FIELD])
        duration = length / walking_speed_m_s / 60
        exposure = thermal.integrate_exposure(
            segment_id, current_time, duration, thresholds
        )
        exit_time = current_time + pd.to_timedelta(duration, unit="min")
        row: dict[str, Any] = {
            "route_sequence": sequence,
            "u": u,
            "v": v,
            "key": key,
            "segment_id": segment_id,
            "entry_time_sgt": current_time.isoformat(),
            "exit_time_sgt": exit_time.isoformat(),
            "length_m": length,
            "travel_time_min": duration,
            "entry_utci_deg_c": exposure.entry_utci_deg_c,
            "exit_utci_deg_c": exposure.exit_utci_deg_c,
            "mean_utci_deg_c": exposure.mean_utci_deg_c,
            "maximum_utci_deg_c": exposure.maximum_utci_deg_c,
        }
        for threshold in thresholds:
            value = exposure.exceedance_deg_c_min[threshold]
            row[_threshold_slug(threshold)] = value
            totals[threshold] += value
        segment_rows.append(row)
        segment_ids.append(segment_id)
        geometries.append(attributes["geometry"])
        utci_integral += exposure.utci_integral_deg_c_min
        total_minutes += duration
        total_distance += length
        maximum_utci = max(maximum_utci, exposure.maximum_utci_deg_c)
        current_time = exit_time
    metrics: dict[str, float | str] = {
        "route_length_m": total_distance,
        "travel_time_min": total_minutes,
        "arrival_time_sgt": current_time.isoformat(),
        "route_mean_utci_deg_c": utci_integral / total_minutes,
        "route_maximum_utci_deg_c": maximum_utci,
        "segment_ids": "|".join(segment_ids),
    }
    for threshold in thresholds:
        metrics[_threshold_slug(threshold)] = totals[threshold]
    return metrics, segment_rows, geometries


def compute_time_dependent_cptl_routes(
    nodes: gpd.GeoDataFrame,
    edges: gpd.GeoDataFrame,
    thermal: TimeVaryingUTCI,
    origin_node: int,
    destination_node: int,
    config: DynamicCPTLConfig,
    routing_graph: nx.MultiDiGraph | None = None,
) -> tuple[gpd.GeoDataFrame, pd.DataFrame, dict[str, Any]]:
    """Compute phase-one time-dependent CPTL routes for configured departures."""

    if set(edges["segment_id"].astype(str)) != set(thermal.segment_ids):
        raise ValueError("Network and dynamic UTCI segment IDs must match exactly")
    routing_config = ShortestPathConfig(
        network_path=config.network_path,
        nodes_layer=config.nodes_layer,
        edges_layer=config.edges_layer,
        output_crs=config.output_crs,
        cost_field=LENGTH_FIELD,
    )
    graph = routing_graph or build_routing_graph(nodes, edges, routing_config)
    distance_route = shortest_route(graph, origin_node, destination_node, LENGTH_FIELD)
    shortest_distance = distance_route.distance_m
    maximum_distance = shortest_distance * (1 + max(config.detour_limits))
    route_rows: list[dict[str, Any]] = []
    segment_rows: list[dict[str, Any]] = []
    diagnostics: dict[str, dict[str, int]] = {}
    primary_field = _threshold_slug(config.primary_threshold_deg_c)
    for departure_text in config.departure_times:
        departure = pd.Timestamp(departure_text)
        labels, destination_ids, diagnostic = _dynamic_destination_labels(
            graph,
            thermal,
            origin_node,
            destination_node,
            departure,
            maximum_distance,
            config,
        )
        diagnostics[departure.isoformat()] = diagnostic
        departure_route_indices: list[int] = []
        for detour_limit in config.detour_limits:
            cap = shortest_distance * (1 + detour_limit)
            label_id = _select_destination_label(labels, destination_ids, cap)
            edge_keys = _recover_edge_keys(labels, label_id)
            metrics, evaluated_segments, geometries = _evaluate_route(
                graph,
                edge_keys,
                thermal,
                departure,
                config.sensitivity_thresholds_deg_c,
                config.walking_speed_m_s,
            )
            segment_ids = str(metrics.pop("segment_ids")).split("|")
            route_id = _route_id(departure, segment_ids)
            row: dict[str, Any] = {
                "route_id": route_id,
                "departure_time_sgt": departure.isoformat(),
                "detour_limit_fraction": detour_limit,
                "detour_limit_percent": 100 * detour_limit,
                "distance_ratio_to_shortest": (
                    float(metrics["route_length_m"]) / shortest_distance
                ),
                "route_role": (
                    "shortest_distance_constraint"
                    if detour_limit == 0
                    else "minimum_dynamic_cptl_within_detour_cap"
                ),
                "optimization_method": "time_binned_epsilon_constrained_pareto_labels",
                "time_bin_seconds": config.time_bin_seconds,
                "thermal_source_status": thermal.source_status,
                "dynamic_solweig_result": config.is_solweig_dynamic_result,
                **metrics,
                "geometry": MultiLineString(geometries),
            }
            if not np.isclose(
                float(row[primary_field]),
                labels[label_id].cptl_deg_c_min,
                atol=1e-8,
            ):
                raise RuntimeError("Recovered route CPTL differs from its search label")
            route_rows.append(row)
            departure_route_indices.append(len(route_rows) - 1)
            for segment in evaluated_segments:
                segment_rows.append(
                    {
                        "route_id": route_id,
                        "departure_time_sgt": departure.isoformat(),
                        "detour_limit_fraction": detour_limit,
                        **segment,
                    }
                )
        baseline = float(route_rows[departure_route_indices[0]][primary_field])
        for index in departure_route_indices:
            value = float(route_rows[index][primary_field])
            route_rows[index]["primary_cptl_reduction_vs_shortest_percent"] = (
                100 * (baseline - value) / baseline if baseline > 0 else 0.0
            )
    routes = gpd.GeoDataFrame(route_rows, geometry="geometry", crs=edges.crs)
    summary = {
        "analysis_id": config.analysis_id,
        "origin_node": origin_node,
        "destination_node": destination_node,
        "departure_count": len(config.departure_times),
        "route_scenario_count": len(routes),
        "shortest_route_distance_m": round(shortest_distance, 6),
        "primary_cptl_threshold_deg_c": config.primary_threshold_deg_c,
        "sensitivity_thresholds_deg_c": list(config.sensitivity_thresholds_deg_c),
        "detour_limits": list(config.detour_limits),
        "walking_speed_m_s": config.walking_speed_m_s,
        "time_bin_seconds": config.time_bin_seconds,
        "waiting_allowed": config.waiting_allowed,
        "integration_method": config.integration_method,
        "thermal_source_status": thermal.source_status,
        "is_solweig_dynamic_result": config.is_solweig_dynamic_result,
        "algorithm_status": (
            "phase_two_time_dependent_cptl_on_solweig_design_scenario"
            if config.is_solweig_dynamic_result
            else "phase_one_time_dependent_algorithm_validated_on_static_repeat"
        ),
        "diagnostics": diagnostics,
        "warning": (
            "This is a clear-sky SOLWEIG design or sensitivity scenario with static station "
            "weather context. Its exact building/canopy provenance is given by "
            "thermal_source_status; it omits observed radiation and field validation."
            if config.is_solweig_dynamic_result
            else (
                "The routing clock and CPTL integration are time dependent, but this "
                "phase-one fixture repeats one static UTCI field. It validates the "
                "algorithm only and is not a SOLWEIG dynamic thermal result or a "
                "coolest-route recommendation."
            )
        ),
    }
    return routes, pd.DataFrame(segment_rows), summary


def build_time_dependent_cptl_routes(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Run time-dependent CPTL routing on the configured dynamic thermal field."""

    config = load_dynamic_cptl_config(config_path)
    network_path = project_root / config.network_path
    nodes = gpd.read_file(network_path, layer=config.nodes_layer)
    edges = gpd.read_file(network_path, layer=config.edges_layer)
    thermal_frame = pd.read_csv(project_root / config.dynamic_thermal_path)
    thermal = TimeVaryingUTCI(
        thermal_frame,
        config.primary_height_scenario,
        config.thermal_source_status,
    )
    od_summary = json.loads(
        (project_root / config.od_summary_path).read_text(encoding="utf-8")
    )
    endpoints = gpd.read_file(
        project_root / config.endpoints.path, layer=config.endpoints.layer
    )
    routes, segments, summary = compute_time_dependent_cptl_routes(
        nodes,
        edges,
        thermal,
        int(od_summary["origin_node"]),
        int(od_summary["destination_node"]),
        config,
    )
    processed = project_root / "data/processed/routing"
    processed.mkdir(parents=True, exist_ok=True)
    geopackage = processed / f"{config.output_stem}.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    routes.to_file(geopackage, layer="dynamic_cptl_routes", driver="GPKG")
    endpoints.to_file(geopackage, layer="endpoints", driver="GPKG", mode="a")
    routes.drop(columns="geometry").to_csv(
        processed / f"{config.output_stem}_routes.csv", index=False
    )
    segments.to_csv(
        processed / f"{config.output_stem}_segments.csv", index=False
    )
    (processed / f"{config.output_stem}_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run time-dependent cumulative UTCI routing."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/dynamic_cptl.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(build_time_dependent_cptl_routes(args.config), indent=2))


if __name__ == "__main__":
    main()
