"""Test dynamic-CPTL time-bin sensitivity across representative regions."""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass, replace
from pathlib import Path
from time import perf_counter
from typing import Any

import geopandas as gpd
import pandas as pd
import yaml

from coollink_sg.heat.dynamic_utci import TimeVaryingUTCI
from coollink_sg.routing.multi_od_cptl import _routing_graph
from coollink_sg.routing.representative_cptl import (
    _dynamic_config,
    load_representative_cptl_config,
)
from coollink_sg.routing.time_dependent_cptl import compute_time_dependent_cptl_routes

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class RepresentativeTimeBinSensitivityConfig:
    """Validated settings for a regional OFAT time-bin experiment."""

    analysis_id: str
    design: str
    base_representative_cptl_config: str
    od_sample: str
    output_stem: str
    detour_limits: tuple[float, ...]
    time_bins_seconds: tuple[int, ...]
    baseline_time_bin_seconds: int
    paper_summary_path: str


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    if key not in mapping:
        raise ValueError(f"Missing required field {section}.{key}")
    return mapping[key]


def load_representative_time_bin_sensitivity_config(
    path: str | Path,
) -> RepresentativeTimeBinSensitivityConfig:
    """Load the explicit representative-region time-bin design."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Time-bin sensitivity configuration must be a mapping")
    analysis = _required(payload, "representative_time_bin_sensitivity", "root")
    parameters = _required(payload, "parameters", "root")
    baseline = _required(payload, "baseline", "root")
    outputs = _required(payload, "outputs", "root")
    design = str(_required(analysis, "design", "analysis"))
    if design != "one_factor_at_a_time":
        raise ValueError("Only one_factor_at_a_time sensitivity is supported")
    bins = tuple(int(value) for value in _required(parameters, "time_bin_seconds", "parameters"))
    if not bins or bins != tuple(sorted(set(bins))) or any(value <= 0 for value in bins):
        raise ValueError("time_bin_seconds must be unique, positive, and increasing")
    baseline_bin = int(_required(baseline, "time_bin_seconds", "baseline"))
    if baseline_bin not in bins:
        raise ValueError("Baseline time bin must be included in sensitivity values")
    limits = tuple(float(value) for value in _required(parameters, "detour_limits", "parameters"))
    if not limits or limits != tuple(sorted(set(limits))) or limits[0] != 0:
        raise ValueError("detour_limits must be unique, increasing, and start at zero")
    output_stem = str(_required(analysis, "output_stem", "analysis"))
    if not output_stem or Path(output_stem).name != output_stem:
        raise ValueError("output_stem must be a filename stem")
    return RepresentativeTimeBinSensitivityConfig(
        analysis_id=str(_required(analysis, "analysis_id", "analysis")),
        design=design,
        base_representative_cptl_config=str(
            _required(analysis, "base_representative_cptl_config", "analysis")
        ),
        od_sample=str(_required(analysis, "od_sample", "analysis")),
        output_stem=output_stem,
        detour_limits=limits,
        time_bins_seconds=bins,
        baseline_time_bin_seconds=baseline_bin,
        paper_summary_path=str(_required(outputs, "paper_summary", "outputs")),
    )


def compare_time_bins_to_baseline(
    routes: pd.DataFrame,
    baseline_time_bin_seconds: int,
) -> pd.DataFrame:
    """Attach exact route and metric differences from the baseline time bin."""

    keys = ["region_id", "od_id", "departure_time_sgt", "detour_limit_fraction"]
    if routes.duplicated(keys + ["time_bin_seconds"]).any():
        raise ValueError("Routes contain duplicate region/OD/departure/cap/time-bin rows")
    baseline = routes.loc[
        routes["time_bin_seconds"].eq(baseline_time_bin_seconds),
        keys + ["route_id", "cptl_above_26_deg_c_min", "route_length_m"],
    ].rename(
        columns={
            "route_id": "baseline_route_id",
            "cptl_above_26_deg_c_min": "baseline_cptl_above_26_deg_c_min",
            "route_length_m": "baseline_route_length_m",
        }
    )
    if baseline.empty or baseline.duplicated(keys).any():
        raise ValueError("Baseline routes are missing or non-unique")
    compared = routes.merge(baseline, on=keys, how="left", validate="many_to_one")
    if compared["baseline_route_id"].isna().any():
        raise ValueError("Every time-bin result must have a matching baseline route")
    compared["route_changed_vs_baseline"] = compared["route_id"].ne(
        compared["baseline_route_id"]
    )
    compared["cptl_delta_vs_baseline_deg_c_min"] = (
        compared["cptl_above_26_deg_c_min"]
        - compared["baseline_cptl_above_26_deg_c_min"]
    )
    compared["route_length_delta_vs_baseline_m"] = (
        compared["route_length_m"] - compared["baseline_route_length_m"]
    )
    return compared


def summarize_time_bin_sensitivity(
    compared: pd.DataFrame,
    runtimes: pd.DataFrame,
) -> pd.DataFrame:
    """Summarize solution stability and measured search runtime."""

    runtime_summary = (
        runtimes.groupby(["region_id", "time_bin_seconds"], as_index=False)
        .agg(
            od_run_count=("runtime_seconds", "size"),
            total_search_runtime_seconds=("runtime_seconds", "sum"),
            median_od_search_runtime_seconds=("runtime_seconds", "median"),
        )
    )
    rows: list[dict[str, Any]] = []
    for (region_id, time_bin, cap), frame in compared.groupby(
        ["region_id", "time_bin_seconds", "detour_limit_fraction"], sort=True
    ):
        reductions = frame["primary_cptl_reduction_vs_shortest_percent"].astype(float)
        rows.append(
            {
                "region_id": region_id,
                "time_bin_seconds": int(time_bin),
                "detour_limit_fraction": float(cap),
                "case_count": len(frame),
                "route_changed_share_vs_60s_percent": float(
                    100 * frame["route_changed_vs_baseline"].mean()
                ),
                "maximum_absolute_cptl_delta_vs_60s_deg_c_min": float(
                    frame["cptl_delta_vs_baseline_deg_c_min"].abs().max()
                ),
                "maximum_absolute_length_delta_vs_60s_m": float(
                    frame["route_length_delta_vs_baseline_m"].abs().max()
                ),
                "median_cptl_reduction_percent": float(reductions.median()),
                "positive_reduction_share_percent": float(100 * reductions.gt(1e-9).mean()),
            }
        )
    return pd.DataFrame(rows).merge(
        runtime_summary,
        on=["region_id", "time_bin_seconds"],
        how="left",
        validate="many_to_one",
    )


def run_representative_time_bin_sensitivity(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Run 30/60/120-second time-bin variants on both representative regions."""

    sensitivity = load_representative_time_bin_sensitivity_config(config_path)
    base = load_representative_cptl_config(
        project_root / sensitivity.base_representative_cptl_config
    )
    if not set(sensitivity.detour_limits).issubset(base.detour_limits):
        raise ValueError("Sensitivity detour limits must be present in the base design")
    sample = pd.read_csv(project_root / sensitivity.od_sample)
    required = {"region_id", "od_id", "origin_node", "destination_node", "distance_band_rank"}
    missing = required.difference(sample.columns)
    if missing or sample.duplicated(["region_id", "od_id"]).any():
        raise ValueError(f"OD sample is invalid; missing fields: {sorted(missing)}")
    if set(sample["region_id"]) != {region.region_id for region in base.regions}:
        raise ValueError("OD sample regions do not match the base representative design")

    route_frames: list[gpd.GeoDataFrame] = []
    runtime_rows: list[dict[str, Any]] = []
    for region_index, region in enumerate(base.regions, start=1):
        network_path = project_root / region.network_path
        nodes = gpd.read_file(network_path, layer="nodes").to_crs(base.output_crs)
        edges = gpd.read_file(network_path, layer="edges").to_crs(base.output_crs)
        graph = _routing_graph(nodes, edges, base.output_crs)
        thermal = TimeVaryingUTCI(
            pd.read_csv(project_root / region.dynamic_thermal_path),
            "central",
            base.thermal_source_status,
        )
        region_sample = sample.loc[sample["region_id"].eq(region.region_id)]
        for bin_index, time_bin in enumerate(sensitivity.time_bins_seconds, start=1):
            run_config = replace(
                _dynamic_config(base, region),
                analysis_id=f"{sensitivity.analysis_id}|{region.region_id}|{time_bin}s",
                detour_limits=sensitivity.detour_limits,
                time_bin_seconds=time_bin,
                output_stem=f"{sensitivity.output_stem}_{region.region_id}_{time_bin}s",
            )
            for od_index, od in enumerate(region_sample.itertuples(index=False), start=1):
                print(
                    f"[{region_index}/{len(base.regions)} {region.region_id}] "
                    f"bin {bin_index}/{len(sensitivity.time_bins_seconds)} {time_bin}s "
                    f"OD {od_index}/{len(region_sample)} {od.od_id}",
                    flush=True,
                )
                started = perf_counter()
                routes, _, _ = compute_time_dependent_cptl_routes(
                    nodes,
                    edges,
                    thermal,
                    int(od.origin_node),
                    int(od.destination_node),
                    run_config,
                    routing_graph=graph,
                )
                runtime_rows.append(
                    {
                        "region_id": region.region_id,
                        "time_bin_seconds": time_bin,
                        "od_id": od.od_id,
                        "runtime_seconds": perf_counter() - started,
                    }
                )
                routes.insert(0, "region_id", region.region_id)
                routes.insert(1, "od_id", od.od_id)
                routes.insert(2, "origin_node", int(od.origin_node))
                routes.insert(3, "destination_node", int(od.destination_node))
                routes.insert(4, "distance_band_rank", int(od.distance_band_rank))
                routes.insert(5, "variant_id", f"time_bin_{time_bin}s")
                routes["sensitivity_route_id"] = [
                    f"{region.region_id}|{time_bin}s|{od.od_id}|{departure}|{cap:g}|{route_id}"
                    for departure, cap, route_id in zip(
                        routes["departure_time_sgt"],
                        routes["detour_limit_fraction"],
                        routes["route_id"],
                        strict=True,
                    )
                ]
                route_frames.append(routes)

    routes = gpd.GeoDataFrame(
        pd.concat(route_frames, ignore_index=True), geometry="geometry", crs=base.output_crs
    )
    runtimes = pd.DataFrame(runtime_rows)
    compared = compare_time_bins_to_baseline(
        routes.drop(columns="geometry"), sensitivity.baseline_time_bin_seconds
    )
    summary = summarize_time_bin_sensitivity(compared, runtimes)
    processed = project_root / "data/processed/routing"
    processed.mkdir(parents=True, exist_ok=True)
    geopackage = processed / f"{sensitivity.output_stem}.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    routes.to_file(geopackage, layer="time_bin_sensitivity_routes", driver="GPKG")
    routes.drop(columns="geometry").to_csv(
        processed / f"{sensitivity.output_stem}_routes.csv", index=False
    )
    compared.to_csv(processed / f"{sensitivity.output_stem}_comparison.csv", index=False)
    runtimes.to_csv(processed / f"{sensitivity.output_stem}_runtime.csv", index=False)
    summary.to_csv(processed / f"{sensitivity.output_stem}_summary.csv", index=False)
    paper_summary = project_root / sensitivity.paper_summary_path
    paper_summary.parent.mkdir(parents=True, exist_ok=True)
    summary.to_csv(paper_summary, index=False)
    nonbaseline = summary.loc[
        summary["time_bin_seconds"].ne(sensitivity.baseline_time_bin_seconds)
    ]
    result = {
        "analysis_id": sensitivity.analysis_id,
        "design": sensitivity.design,
        "region_count": len(base.regions),
        "od_count": int(sample[["region_id", "od_id"]].drop_duplicates().shape[0]),
        "departure_count": len(base.departure_times),
        "detour_limits": list(sensitivity.detour_limits),
        "time_bins_seconds": list(sensitivity.time_bins_seconds),
        "route_scenario_count": len(routes),
        "maximum_route_changed_share_vs_60s_percent": float(
            nonbaseline["route_changed_share_vs_60s_percent"].max()
        ),
        "maximum_absolute_cptl_delta_vs_60s_deg_c_min": float(
            nonbaseline["maximum_absolute_cptl_delta_vs_60s_deg_c_min"].max()
        ),
        "interpretation_limit": (
            "This is an OFAT computational check on network-coverage OD samples and "
            "unvalidated clear-sky SOLWEIG fields, not observed travel demand, field "
            "validation, or proof that the tested bins are safe for every network."
        ),
        "outputs": {
            "geopackage": str(geopackage.relative_to(project_root)),
            "routes_csv": f"data/processed/routing/{sensitivity.output_stem}_routes.csv",
            "comparison_csv": f"data/processed/routing/{sensitivity.output_stem}_comparison.csv",
            "runtime_csv": f"data/processed/routing/{sensitivity.output_stem}_runtime.csv",
            "summary_csv": f"data/processed/routing/{sensitivity.output_stem}_summary.csv",
            "paper_summary_csv": sensitivity.paper_summary_path,
        },
    }
    (processed / f"{sensitivity.output_stem}_summary.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/representative_time_bin_sensitivity.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(run_representative_time_bin_sensitivity(args.config), indent=2))


if __name__ == "__main__":
    main()
