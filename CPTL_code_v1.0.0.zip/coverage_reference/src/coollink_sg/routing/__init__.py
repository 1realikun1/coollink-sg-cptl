"""Pedestrian routing modules."""

