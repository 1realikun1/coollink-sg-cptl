"""Build the first documented real origin-destination route scenario."""

from __future__ import annotations

import argparse
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import osmnx as ox
import pandas as pd
from shapely.geometry import Point

from coollink_sg.config import (
    ODScenarioConfig,
    ShortestPathConfig,
    StudyAreaConfig,
    load_od_scenario_config,
    load_shortest_path_config,
    load_study_area_config,
)
from coollink_sg.routing.shortest_path import (
    ShortestRoute,
    build_routing_graph,
    nearest_network_node,
    shortest_route,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]


def fetch_destination_geocode(config: ODScenarioConfig) -> gpd.GeoDataFrame:
    """Fetch the first Nominatim result for the configured destination query."""

    result = ox.geocode_to_gdf(config.destination_query)
    if result.empty:
        raise ValueError("Nominatim returned no destination result")
    required = {"lat", "lon", "display_name", "osm_type", "osm_id", "geometry"}
    missing = required.difference(result.columns)
    if missing:
        raise ValueError(f"Destination geocode is missing fields: {sorted(missing)}")
    if result.crs is None:
        result = result.set_crs(config.geographic_crs)
    return result.iloc[[0]].copy()


def _serialize(value: Any) -> Any:
    if isinstance(value, (list, tuple, set, dict)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True)
    return value


def save_raw_geocode_snapshot(
    destination: gpd.GeoDataFrame,
    retrieved_at_utc: datetime,
    config: ODScenarioConfig,
    raw_root: Path,
) -> Path:
    """Save a new immutable Nominatim result and provenance manifest."""

    snapshot_id = retrieved_at_utc.strftime("%Y%m%dT%H%M%S%fZ")
    directory = raw_root / snapshot_id
    directory.mkdir(parents=True, exist_ok=False)
    safe = destination.copy()
    for column in safe.columns:
        if column != safe.geometry.name and safe[column].dtype == object:
            safe[column] = safe[column].map(_serialize)
    safe.to_file(directory / "destination_geocode.gpkg", layer="destination", driver="GPKG")
    row = destination.iloc[0]
    manifest = {
        "snapshot_id": snapshot_id,
        "retrieved_at_utc": retrieved_at_utc.isoformat(),
        "scenario_id": config.scenario_id,
        "query": config.destination_query,
        "selected_result_rule": "first Nominatim result",
        "selected_result": {
            "display_name": str(row["display_name"]),
            "latitude": float(row["lat"]),
            "longitude": float(row["lon"]),
            "osm_type": str(row["osm_type"]),
            "osm_id": int(row["osm_id"]),
        },
        "source": config.source_metadata,
        "software": {"osmnx": ox.__version__},
    }
    with (directory / "manifest.json").open("x", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2, ensure_ascii=False)
    return directory


def load_raw_geocode_snapshot(directory: Path) -> gpd.GeoDataFrame:
    """Load an immutable destination geocode result."""

    return gpd.read_file(directory / "destination_geocode.gpkg", layer="destination")


def route_configured_scenario(
    nodes: gpd.GeoDataFrame,
    edges: gpd.GeoDataFrame,
    destination: gpd.GeoDataFrame,
    study_area: StudyAreaConfig,
    routing_config: ShortestPathConfig,
    scenario_config: ODScenarioConfig,
) -> tuple[ShortestRoute, gpd.GeoDataFrame, dict[str, Any]]:
    """Snap documented endpoints and calculate their shortest directed route."""

    if destination.empty or not {"lat", "lon"}.issubset(destination.columns):
        raise ValueError("Destination must contain a geocoded lat/lon result")
    origin_node, origin_snap_m = nearest_network_node(
        nodes,
        study_area.longitude,
        study_area.latitude,
        scenario_config.geographic_crs,
    )
    row = destination.iloc[0]
    destination_lon = float(row["lon"])
    destination_lat = float(row["lat"])
    destination_node, destination_snap_m = nearest_network_node(
        nodes,
        destination_lon,
        destination_lat,
        scenario_config.geographic_crs,
    )
    graph = build_routing_graph(nodes, edges, routing_config)
    route = shortest_route(
        graph, origin_node, destination_node, routing_config.cost_field
    )

    node_lookup = nodes.set_index("osmid")
    origin_snapped = node_lookup.loc[origin_node].geometry
    destination_snapped = node_lookup.loc[destination_node].geometry
    source_points = gpd.GeoSeries(
        [
            Point(study_area.longitude, study_area.latitude),
            Point(destination_lon, destination_lat),
        ],
        crs=scenario_config.geographic_crs,
    ).to_crs(routing_config.output_crs)
    endpoints = gpd.GeoDataFrame(
        {
            "role": [
                "origin_source",
                "origin_snapped_node",
                "destination_source",
                "destination_snapped_node",
            ],
            "label": [
                scenario_config.origin_label,
                f"Snapped node {origin_node}",
                scenario_config.destination_label,
                f"Snapped node {destination_node}",
            ],
            "node_id": [None, origin_node, None, destination_node],
            "snap_distance_m": [
                origin_snap_m,
                origin_snap_m,
                destination_snap_m,
                destination_snap_m,
            ],
        },
        geometry=[
            source_points.iloc[0],
            origin_snapped,
            source_points.iloc[1],
            destination_snapped,
        ],
        crs=routing_config.output_crs,
    )
    summary = {
        "scenario_id": scenario_config.scenario_id,
        "origin_label": scenario_config.origin_label,
        "destination_label": scenario_config.destination_label,
        "origin_node": origin_node,
        "destination_node": destination_node,
        "origin_snap_distance_m": round(origin_snap_m, 6),
        "destination_snap_distance_m": round(destination_snap_m, 6),
        "route_segment_count": len(route.edges),
        "route_distance_m": round(route.distance_m, 6),
        "algorithm": "Dijkstra",
        "cost_field": routing_config.cost_field,
        "travel_time": "not_calculated",
        "heat_exposure": "not_calculated",
    }
    return route, endpoints, summary


def create_scenario_map(
    route: ShortestRoute,
    endpoints: gpd.GeoDataFrame,
    scenario: ODScenarioConfig,
    output_path: Path,
) -> None:
    """Create an interactive route map with source and snapped endpoints."""

    route_wgs84 = route.edges.to_crs(scenario.geographic_crs)
    endpoint_wgs84 = endpoints.to_crs(scenario.geographic_crs)
    map_object = folium.Map(tiles="OpenStreetMap", control_scale=True)
    folium.GeoJson(
        route_wgs84[["route_sequence", "segment_id", "length_m", "geometry"]].to_json(),
        name="Shortest-distance route",
        style_function=lambda _feature: {"color": "#dc2626", "weight": 6, "opacity": 0.9},
        tooltip=folium.GeoJsonTooltip(
            fields=["route_sequence", "segment_id", "length_m"],
            aliases=["Sequence", "Segment", "Length (m)"],
        ),
    ).add_to(map_object)
    colours = {
        "origin_source": "green",
        "origin_snapped_node": "darkgreen",
        "destination_source": "blue",
        "destination_snapped_node": "darkblue",
    }
    for row in endpoint_wgs84.itertuples(index=False):
        folium.Marker(
            [row.geometry.y, row.geometry.x],
            tooltip=row.label,
            icon=folium.Icon(color=colours[row.role]),
        ).add_to(map_object)
    for source_index, snapped_index in ((0, 1), (2, 3)):
        source = endpoint_wgs84.geometry.iloc[source_index]
        snapped = endpoint_wgs84.geometry.iloc[snapped_index]
        folium.PolyLine(
            [(source.y, source.x), (snapped.y, snapped.x)],
            color="#64748b",
            weight=2,
            dash_array="5,5",
            tooltip="Endpoint-to-network snap",
        ).add_to(map_object)
    bounds = route_wgs84.total_bounds
    map_object.fit_bounds([[bounds[1], bounds[0]], [bounds[3], bounds[2]]])
    legend = """
    <div style="position:fixed;bottom:30px;left:30px;z-index:9999;background:white;
      padding:10px;border:1px solid #777;font-size:12px"><b>Shortest-distance route</b><br>
      Red: selected pedestrian edges<br>Dashed: endpoint snap<br>
      <small>No travel-time or heat cost</small></div>
    """
    map_object.get_root().html.add_child(folium.Element(legend))
    folium.LayerControl().add_to(map_object)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    map_object.save(output_path)


def build_od_scenario(
    scenario_config_path: Path,
    routing_config_path: Path,
    study_area_config_path: Path,
    project_root: Path = PROJECT_ROOT,
    raw_snapshot: Path | None = None,
) -> dict[str, Any]:
    """Fetch or reload the destination, calculate, and save the first real route."""

    scenario = load_od_scenario_config(scenario_config_path)
    routing = load_shortest_path_config(routing_config_path)
    study_area = load_study_area_config(study_area_config_path)
    if raw_snapshot is None:
        destination = fetch_destination_geocode(scenario)
        snapshot = save_raw_geocode_snapshot(
            destination,
            datetime.now(UTC),
            scenario,
            project_root / "data/raw/od_scenarios" / scenario.scenario_id,
        )
    else:
        snapshot = raw_snapshot.resolve()
        destination = load_raw_geocode_snapshot(snapshot)

    network_path = project_root / routing.network_path
    nodes = gpd.read_file(network_path, layer=routing.nodes_layer)
    edges = gpd.read_file(network_path, layer=routing.edges_layer)
    route, endpoints, summary = route_configured_scenario(
        nodes, edges, destination, study_area, routing, scenario
    )
    summary["geocode_snapshot_id"] = snapshot.name
    summary["geocode_snapshot_directory"] = str(snapshot)
    summary["geocode_snapshot_reused"] = raw_snapshot is not None
    summary["destination_display_name"] = str(destination.iloc[0]["display_name"])

    processed = project_root / "data/processed/routing"
    tables = project_root / "outputs/tables"
    processed.mkdir(parents=True, exist_ok=True)
    tables.mkdir(parents=True, exist_ok=True)
    stem = f"{scenario.scenario_id}_shortest_route"
    geopackage = processed / f"{stem}.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    route.edges.to_file(geopackage, layer="route", driver="GPKG")
    endpoints.to_file(geopackage, layer="endpoints", driver="GPKG", mode="a")
    route.edges.drop(columns="geometry").to_csv(processed / f"{stem}.csv", index=False)
    (processed / f"{stem}_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    pd.DataFrame([summary]).to_csv(tables / f"{stem}_summary.csv", index=False)
    create_scenario_map(
        route,
        endpoints,
        scenario,
        project_root / "outputs/maps" / f"{stem}.html",
    )
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(
        description="Build the Clementi MRT to NUS University Town route scenario."
    )
    parser.add_argument(
        "--scenario-config", type=Path, default=PROJECT_ROOT / "config/od_scenario.yaml"
    )
    parser.add_argument(
        "--routing-config", type=Path, default=PROJECT_ROOT / "config/shortest_path.yaml"
    )
    parser.add_argument(
        "--study-area-config", type=Path, default=PROJECT_ROOT / "config/study_area.yaml"
    )
    parser.add_argument("--raw-snapshot", type=Path, default=None)
    args = parser.parse_args()
    print(
        json.dumps(
            build_od_scenario(
                args.scenario_config,
                args.routing_config,
                args.study_area_config,
                raw_snapshot=args.raw_snapshot,
            ),
            indent=2,
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
