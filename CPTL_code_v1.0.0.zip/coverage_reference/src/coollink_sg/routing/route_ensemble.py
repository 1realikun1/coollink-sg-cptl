"""Distance–exposure route ensemble without a preferred proxy model."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import numpy as np
import pandas as pd
from shapely.geometry import MultiLineString

from coollink_sg.config import (
    RouteEnsembleConfig,
    ShortestPathConfig,
    load_route_ensemble_config,
)
from coollink_sg.heat.road_exposure_proxy import COMPONENT_FIELDS
from coollink_sg.routing.shortest_path import build_routing_graph, shortest_route

PROJECT_ROOT = Path(__file__).resolve().parents[3]
WEIGHT_FIELDS = (
    "weight_wbgt_station_context",
    "weight_shade_deficit",
    "weight_vegetation_context_deficit",
)


def generate_tradeoff_scenarios(config: RouteEnsembleConfig) -> pd.DataFrame:
    """Generate distance-to-exposure tradeoffs including both endpoints."""

    steps = round(1 / config.tradeoff_step)
    return pd.DataFrame(
        {
            "tradeoff_id": [f"distance_exposure_{i:03d}_of_{steps:03d}" for i in range(steps + 1)],
            "exposure_tradeoff": [i / steps for i in range(steps + 1)],
            "distance_tradeoff": [1 - i / steps for i in range(steps + 1)],
            "preferred_tradeoff": [False] * (steps + 1),
        }
    )


def _route_id(segment_ids: list[str]) -> str:
    payload = "|".join(segment_ids).encode("utf-8")
    return f"route_{hashlib.sha256(payload).hexdigest()[:12]}"


def _route_line(edges: gpd.GeoDataFrame) -> MultiLineString:
    return MultiLineString([geometry for geometry in edges.geometry if not geometry.is_empty])


def compute_route_ensemble(
    nodes: gpd.GeoDataFrame,
    network_edges: gpd.GeoDataFrame,
    exposure: gpd.GeoDataFrame,
    weight_scenarios: pd.DataFrame,
    origin_node: int,
    destination_node: int,
    config: RouteEnsembleConfig,
) -> tuple[gpd.GeoDataFrame, pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    """Run all component-weight and distance–exposure route scenarios."""

    required_exposure = {"segment_id", *COMPONENT_FIELDS}
    missing_exposure = required_exposure.difference(exposure.columns)
    if missing_exposure:
        raise ValueError(f"Exposure table is missing fields: {sorted(missing_exposure)}")
    if exposure["segment_id"].isna().any() or not exposure["segment_id"].is_unique:
        raise ValueError("Exposure segment_id values must be complete and unique")
    if network_edges["segment_id"].isna().any() or not network_edges["segment_id"].is_unique:
        raise ValueError("Network segment_id values must be complete and unique")
    if set(network_edges["segment_id"]) != set(exposure["segment_id"]):
        raise ValueError("Network and exposure segment IDs must match exactly")
    required_weights = {"scenario_id", *WEIGHT_FIELDS, "preferred_scenario"}
    missing_weights = required_weights.difference(weight_scenarios.columns)
    if missing_weights:
        raise ValueError(f"Weight scenarios are missing fields: {sorted(missing_weights)}")
    weights = weight_scenarios[list(WEIGHT_FIELDS)].apply(pd.to_numeric, errors="raise")
    if weights.isna().any().any() or not np.allclose(
        weights.sum(axis=1).to_numpy(), 1, rtol=0, atol=1e-9
    ):
        raise ValueError("Every exposure weight scenario must be complete and sum to one")
    if weight_scenarios["scenario_id"].duplicated().any():
        raise ValueError("Weight scenario IDs must be unique")
    preferred = weight_scenarios["preferred_scenario"].astype(str).str.lower()
    if preferred.isin({"true", "1"}).any():
        raise ValueError("Route ensemble cannot accept a preferred exposure scenario")

    exposure_attributes = exposure[["segment_id", *COMPONENT_FIELDS]]
    edges = network_edges.merge(
        exposure_attributes, on="segment_id", how="left", validate="one_to_one"
    )
    component_values = edges[list(COMPONENT_FIELDS)].apply(pd.to_numeric, errors="raise")
    if component_values.isna().any().any() or not (
        (component_values >= 0) & (component_values <= 1)
    ).all().all():
        raise ValueError("Route exposure components must be complete and within 0–1")
    length = pd.to_numeric(edges["length_m"], errors="raise").to_numpy(dtype=float)
    if np.isnan(length).any() or (length <= 0).any():
        raise ValueError("Network edge length_m must be positive")

    routing_config = ShortestPathConfig(
        network_path=config.network_path,
        nodes_layer=config.nodes_layer,
        edges_layer=config.edges_layer,
        output_crs=config.output_crs,
        cost_field="length_m",
    )
    graph = build_routing_graph(nodes, edges, routing_config)
    graph_edges = [
        (int(row.u), int(row.v), int(row.key)) for row in edges.itertuples(index=False)
    ]
    shortest = shortest_route(graph, origin_node, destination_node, "length_m")
    shortest_segments = shortest.edges["segment_id"].astype(str).tolist()
    shortest_route_id = _route_id(shortest_segments)
    tradeoffs = generate_tradeoff_scenarios(config)

    route_edges_by_id: dict[str, gpd.GeoDataFrame] = {shortest_route_id: shortest.edges.copy()}
    assignments: list[dict[str, Any]] = []
    component_matrix = component_values.to_numpy(dtype=float)
    for weight_row in weight_scenarios.itertuples(index=False):
        weight_vector = np.array(
            [getattr(weight_row, field) for field in WEIGHT_FIELDS], dtype=float
        )
        edge_exposure = component_matrix @ weight_vector
        for tradeoff_row in tradeoffs.itertuples(index=False):
            exposure_tradeoff = float(tradeoff_row.exposure_tradeoff)
            if exposure_tradeoff == 0:
                route = shortest
            else:
                cost = length * (
                    (1 - exposure_tradeoff) + exposure_tradeoff * edge_exposure
                )
                for (u, v, key), value in zip(graph_edges, cost, strict=True):
                    graph[u][v][key]["route_ensemble_cost_m"] = float(value)
                route = shortest_route(
                    graph, origin_node, destination_node, "route_ensemble_cost_m"
                )
            segment_ids = route.edges["segment_id"].astype(str).tolist()
            route_id = _route_id(segment_ids)
            if route_id not in route_edges_by_id:
                route_edges_by_id[route_id] = route.edges.copy()
            route_length = float(route.edges["length_m"].sum())
            route_component_means = np.array(
                [
                    np.average(route.edges[field], weights=route.edges["length_m"])
                    for field in COMPONENT_FIELDS
                ]
            )
            scenario_exposure_mean = float(route_component_means @ weight_vector)
            assignments.append(
                {
                    "weight_scenario_id": str(weight_row.scenario_id),
                    **{field: float(getattr(weight_row, field)) for field in WEIGHT_FIELDS},
                    "tradeoff_id": str(tradeoff_row.tradeoff_id),
                    "distance_tradeoff": float(tradeoff_row.distance_tradeoff),
                    "exposure_tradeoff": exposure_tradeoff,
                    "route_id": route_id,
                    "route_segment_count": len(route.edges),
                    "route_length_m": route_length,
                    "distance_ratio_to_shortest": route_length / shortest.distance_m,
                    "route_scenario_exposure_mean_0_1": scenario_exposure_mean,
                    "route_scenario_exposure_dose_m": route_length
                    * scenario_exposure_mean,
                    "generalized_cost_m": route_length
                    * (
                        (1 - exposure_tradeoff)
                        + exposure_tradeoff * scenario_exposure_mean
                    ),
                    "preferred_scenario": False,
                }
            )
    assignment_table = pd.DataFrame(assignments)

    all_support = assignment_table["route_id"].value_counts()
    nonzero = assignment_table.loc[assignment_table["exposure_tradeoff"] > 0]
    nonzero_support = nonzero["route_id"].value_counts()
    route_rows: list[dict[str, Any]] = []
    for route_id, route_edges in sorted(route_edges_by_id.items()):
        route_length = float(route_edges["length_m"].sum())
        component_means = {
            field: float(np.average(route_edges[field], weights=route_edges["length_m"]))
            for field in COMPONENT_FIELDS
        }
        route_rows.append(
            {
                "route_id": route_id,
                "route_segment_count": len(route_edges),
                "route_length_m": route_length,
                "distance_ratio_to_shortest": route_length / shortest.distance_m,
                **{f"route_mean_{field}": value for field, value in component_means.items()},
                "all_scenario_support_count": int(all_support.get(route_id, 0)),
                "all_scenario_support_fraction": float(
                    all_support.get(route_id, 0) / len(assignment_table)
                ),
                "nonzero_tradeoff_support_count": int(nonzero_support.get(route_id, 0)),
                "nonzero_tradeoff_support_fraction": float(
                    nonzero_support.get(route_id, 0) / len(nonzero)
                ),
                "is_shortest_route": route_id == shortest_route_id,
                "geometry": _route_line(route_edges),
            }
        )
    routes = gpd.GeoDataFrame(route_rows, geometry="geometry", crs=network_edges.crs)
    alternatives = routes.loc[~routes["is_shortest_route"]].sort_values(
        ["nonzero_tradeoff_support_count", "route_length_m", "route_id"],
        ascending=[False, True, True],
    )
    robust_alternative_id = None if alternatives.empty else str(alternatives.iloc[0]["route_id"])
    routes["route_role"] = "other_sensitivity_route"
    routes.loc[routes["is_shortest_route"], "route_role"] = "shortest_distance"
    if robust_alternative_id is not None:
        routes.loc[
            routes["route_id"].eq(robust_alternative_id), "route_role"
        ] = "most_supported_nonshortest_sensitivity_route"
    catalogue = pd.DataFrame(routes.drop(columns="geometry"))
    summary = {
        "analysis_id": config.analysis_id,
        "origin_node": origin_node,
        "destination_node": destination_node,
        "weight_scenario_count": len(weight_scenarios),
        "tradeoff_scenario_count": len(tradeoffs),
        "route_scenario_count": len(assignment_table),
        "unique_route_count": len(routes),
        "shortest_route_id": shortest_route_id,
        "shortest_route_distance_m": round(shortest.distance_m, 6),
        "most_supported_nonshortest_route_id": robust_alternative_id,
        "preferred_route": None,
        "heat_score_used": False,
        "cost_method": config.cost_method,
        "warning": (
            "Routes are sensitivity outcomes based on context-only WBGT and "
            "incomplete shade/green proxies. The most-supported alternative is "
            "a robustness diagnostic, not a recommended or validated coolest route."
        ),
    }
    return routes, assignment_table, catalogue, summary


def create_route_ensemble_map(
    routes: gpd.GeoDataFrame,
    endpoints: gpd.GeoDataFrame,
    output_path: Path,
) -> None:
    """Create the final route sensitivity web map."""

    display = routes.to_crs("EPSG:4326").copy()
    endpoint_display = endpoints.to_crs("EPSG:4326")
    map_object = folium.Map(tiles="OpenStreetMap", control_scale=True)
    other = display.loc[display["route_role"].eq("other_sensitivity_route")]
    if not other.empty:
        folium.GeoJson(
            other.to_json(),
            name="Other sensitivity routes",
            show=False,
            style_function=lambda _feature: {
                "color": "#9ca3af",
                "weight": 2,
                "opacity": 0.35,
            },
            tooltip=folium.GeoJsonTooltip(
                fields=["route_id", "route_length_m", "nonzero_tradeoff_support_count"]
            ),
        ).add_to(map_object)
    styles = {
        "shortest_distance": ("Shortest-distance route", "#dc2626", 6),
        "most_supported_nonshortest_sensitivity_route": (
            "Most-supported non-shortest sensitivity route",
            "#2563eb",
            6,
        ),
    }
    for role, (name, colour, width) in styles.items():
        selected = display.loc[display["route_role"].eq(role)]
        if selected.empty:
            continue
        folium.GeoJson(
            selected.to_json(),
            name=name,
            style_function=lambda _feature, c=colour, w=width: {
                "color": c,
                "weight": w,
                "opacity": 0.9,
            },
            tooltip=folium.GeoJsonTooltip(
                fields=[
                    "route_id",
                    "route_length_m",
                    "distance_ratio_to_shortest",
                    "nonzero_tradeoff_support_count",
                ]
            ),
        ).add_to(map_object)
    colours = {
        "origin_source": "green",
        "origin_snapped_node": "darkgreen",
        "destination_source": "blue",
        "destination_snapped_node": "darkblue",
    }
    for row in endpoint_display.itertuples(index=False):
        folium.Marker(
            [row.geometry.y, row.geometry.x],
            tooltip=row.label,
            icon=folium.Icon(color=colours.get(row.role, "gray")),
        ).add_to(map_object)
    bounds = display.total_bounds
    map_object.fit_bounds([[bounds[1], bounds[0]], [bounds[3], bounds[2]]])
    legend = """
    <div style="position:fixed;bottom:30px;left:30px;z-index:9999;background:white;
      padding:10px;border:1px solid #777;font-size:12px"><b>Route sensitivity ensemble</b><br>
      Red: shortest distance<br>Blue: most-supported non-shortest sensitivity route<br>
      Grey: other scenario routes (layer control)<br>
      <small>No preferred route; no validated Heat Score or coolest-route claim.</small></div>
    """
    map_object.get_root().html.add_child(folium.Element(legend))
    folium.LayerControl().add_to(map_object)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    map_object.save(output_path)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def build_route_ensemble(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Build all route scenarios and final sensitivity artifacts."""

    config = load_route_ensemble_config(config_path)
    network_path = project_root / config.network_path
    exposure_path = project_root / config.exposure.path
    weight_path = project_root / config.weight_scenarios_path
    od_summary_path = project_root / config.od_summary_path
    endpoint_path = project_root / config.endpoints.path
    nodes = gpd.read_file(network_path, layer=config.nodes_layer)
    edges = gpd.read_file(network_path, layer=config.edges_layer)
    exposure = gpd.read_file(exposure_path, layer=config.exposure.layer)
    weights = pd.read_csv(weight_path)
    od_summary = json.loads(od_summary_path.read_text(encoding="utf-8"))
    endpoints = gpd.read_file(endpoint_path, layer=config.endpoints.layer)
    routes, assignments, catalogue, summary = compute_route_ensemble(
        nodes,
        edges,
        exposure,
        weights,
        int(od_summary["origin_node"]),
        int(od_summary["destination_node"]),
        config,
    )
    summary["input_sha256"] = {
        "network": _sha256(network_path),
        "exposure": _sha256(exposure_path),
        "weight_scenarios": _sha256(weight_path),
        "od_summary": _sha256(od_summary_path),
    }
    robust_id = summary["most_supported_nonshortest_route_id"]
    if robust_id is not None:
        robust = catalogue.loc[catalogue["route_id"].eq(robust_id)].iloc[0]
        summary["most_supported_nonshortest_route"] = {
            "distance_m": round(float(robust["route_length_m"]), 6),
            "distance_ratio_to_shortest": round(
                float(robust["distance_ratio_to_shortest"]), 6
            ),
            "nonzero_tradeoff_support_count": int(
                robust["nonzero_tradeoff_support_count"]
            ),
            "nonzero_tradeoff_support_fraction": round(
                float(robust["nonzero_tradeoff_support_fraction"]), 6
            ),
        }
    summary["local_webgis_output"] = "app/index.html"

    processed = project_root / "data/processed/routing"
    tables = project_root / "outputs/tables"
    maps = project_root / "outputs/maps"
    processed.mkdir(parents=True, exist_ok=True)
    tables.mkdir(parents=True, exist_ok=True)
    geopackage = processed / "clementi_route_sensitivity_ensemble.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    routes.to_file(geopackage, layer="routes", driver="GPKG")
    endpoints.to_file(geopackage, layer="endpoints", driver="GPKG", mode="a")
    catalogue.to_csv(processed / "clementi_route_sensitivity_routes.csv", index=False)
    assignments.to_csv(
        processed / "clementi_route_sensitivity_scenarios.csv", index=False
    )
    (processed / "clementi_route_sensitivity_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    pd.DataFrame(
        [{key: value for key, value in summary.items() if not isinstance(value, dict)}]
    ).to_csv(tables / "clementi_route_sensitivity_summary.csv", index=False)
    create_route_ensemble_map(
        routes, endpoints, maps / "clementi_route_sensitivity_ensemble.html"
    )
    create_route_ensemble_map(routes, endpoints, project_root / "app/index.html")
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(
        description="Build the complete distance–exposure route sensitivity ensemble."
    )
    parser.add_argument(
        "--config", type=Path, default=PROJECT_ROOT / "config/route_ensemble.yaml"
    )
    args = parser.parse_args()
    print(json.dumps(build_route_ensemble(args.config), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
