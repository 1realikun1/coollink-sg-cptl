"""Summarize and visualize the Clementi multi-OD CPTL robustness run."""

from __future__ import annotations

import argparse
import html
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[3]
PRIMARY_FIELD = "cptl_above_26_deg_c_min"


def summarize_multi_od_results(
    routes: pd.DataFrame,
    comparison: pd.DataFrame,
) -> dict[str, Any]:
    """Return compact statistics for the precomputed multi-OD routes."""

    required = {
        "thermal_scenario",
        "od_id",
        "departure_time_sgt",
        "detour_limit_fraction",
        "distance_band_rank",
        "distance_ratio_to_shortest",
        "primary_cptl_reduction_vs_shortest_percent",
        PRIMARY_FIELD,
        "route_id",
    }
    missing = required.difference(routes.columns)
    if missing:
        raise ValueError(f"Multi-OD route table is missing fields: {sorted(missing)}")
    scenario_labels = tuple(routes["thermal_scenario"].drop_duplicates())
    if len(scenario_labels) != 2:
        raise ValueError("Robustness report requires exactly two thermal scenarios")
    expected_count = (
        routes["od_id"].nunique()
        * routes["departure_time_sgt"].nunique()
        * routes["detour_limit_fraction"].nunique()
        * len(scenario_labels)
    )
    if len(routes) != expected_count:
        raise ValueError("Multi-OD route scenario grid is incomplete")

    by_scenario_cap: dict[str, dict[str, Any]] = {}
    for (scenario, cap), frame in routes.groupby(
        ["thermal_scenario", "detour_limit_fraction"], sort=True
    ):
        reductions = frame["primary_cptl_reduction_vs_shortest_percent"]
        by_scenario_cap[f"{scenario}|{100 * cap:g}%"] = {
            "scenario_count": len(frame),
            "median_cptl_reduction_percent": float(reductions.median()),
            "mean_cptl_reduction_percent": float(reductions.mean()),
            "q25_cptl_reduction_percent": float(reductions.quantile(0.25)),
            "q75_cptl_reduction_percent": float(reductions.quantile(0.75)),
            "positive_reduction_share_percent": float(100 * reductions.gt(1e-9).mean()),
            "median_distance_increase_percent": float(
                100 * (frame["distance_ratio_to_shortest"].median() - 1)
            ),
        }

    five_percent = routes.loc[routes["detour_limit_fraction"].eq(0.05)]
    five_percent_by_distance_band: dict[str, dict[str, Any]] = {}
    for (scenario, band), frame in five_percent.groupby(
        ["thermal_scenario", "distance_band_rank"], sort=True
    ):
        reductions = frame["primary_cptl_reduction_vs_shortest_percent"]
        five_percent_by_distance_band[f"{scenario}|band_{int(band)}"] = {
            "scenario_count": len(frame),
            "median_cptl_reduction_percent": float(reductions.median()),
            "positive_reduction_share_percent": float(100 * reductions.gt(1e-9).mean()),
            "median_distance_increase_percent": float(
                100 * (frame["distance_ratio_to_shortest"].median() - 1)
            ),
        }

    canopy_by_cap: dict[str, dict[str, Any]] = {}
    for cap, frame in comparison.groupby("detour_limit_fraction", sort=True):
        delta = frame["alternative_minus_reference_cptl_percent"]
        canopy_by_cap[f"{100 * cap:g}%"] = {
            "scenario_count": len(frame),
            "median_cptl_change_percent": float(delta.median()),
            "q25_cptl_change_percent": float(delta.quantile(0.25)),
            "q75_cptl_change_percent": float(delta.quantile(0.75)),
            "cptl_decreased_share_percent": float(100 * delta.lt(0).mean()),
            "route_changed_share_percent": float(100 * frame["route_changed"].mean()),
        }

    route_ids = routes.pivot(
        index=["thermal_scenario", "od_id", "departure_time_sgt"],
        columns="detour_limit_fraction",
        values="route_id",
    )
    cap_saturation = {
        scenario: {
            "route_changed_0_to_5_percent_share": float(
                100 * frame[0.0].ne(frame[0.05]).mean()
            ),
            "route_changed_5_to_10_percent_share": float(
                100 * frame[0.05].ne(frame[0.10]).mean()
            ),
            "route_changed_10_to_15_percent_share": float(
                100 * frame[0.10].ne(frame[0.15]).mean()
            ),
        }
        for scenario, frame in route_ids.groupby(level=0)
    }
    return {
        "analysis_id": "clementi_multi_od_dynamic_cptl_robustness_v1",
        "od_count": int(routes["od_id"].nunique()),
        "departure_count": int(routes["departure_time_sgt"].nunique()),
        "detour_limit_count": int(routes["detour_limit_fraction"].nunique()),
        "thermal_scenario_count": len(scenario_labels),
        "route_scenario_count": len(routes),
        "scenario_labels": list(scenario_labels),
        "by_scenario_and_detour_cap": by_scenario_cap,
        "five_percent_cap_by_distance_band": five_percent_by_distance_band,
        "canopy_minus_building_only": canopy_by_cap,
        "cap_saturation": cap_saturation,
        "principal_finding": (
            "With CHMv2 canopy represented, a 5% distance allowance yielded a 2.34% "
            "median CPTL reduction across 60 OD-departure cases, with positive reductions "
            "in 78.3% of cases; the building-only median was 0.03%."
        ),
        "interpretation_limit": (
            "The 12 OD pairs are a deterministic network-coverage sample rather than "
            "observed travel demand. Results are clear-sky SOLWEIG design-scenario outputs "
            "with static station weather context and no field validation."
        ),
    }


def render_multi_od_figure(routes: pd.DataFrame, output_path: Path) -> None:
    """Render median multi-OD CPTL benefits as a dependency-free SVG."""

    width, height = 1200, 500
    panels = [(75, 75, 470, 330), (665, 75, 470, 330)]
    colors = {"building_only": "#377EB8", "building_canopy_chmv2": "#159A92"}
    cap_summary = (
        routes.groupby(["thermal_scenario", "detour_limit_fraction"])[
            "primary_cptl_reduction_vs_shortest_percent"
        ]
        .median()
        .unstack(0)
    )
    five = routes.loc[routes["detour_limit_fraction"].eq(0.05)].copy()
    five["hour"] = pd.to_datetime(five["departure_time_sgt"]).dt.strftime("%H:%M")
    time_summary = (
        five.groupby(["thermal_scenario", "hour"])[
            "primary_cptl_reduction_vs_shortest_percent"
        ]
        .median()
        .unstack(0)
    )
    maximum = max(float(cap_summary.max().max()), float(time_summary.max().max()), 1.0)
    y_max = np.ceil(maximum * 1.18)

    def y_coordinate(value: float, panel: tuple[int, int, int, int]) -> float:
        return panel[1] + panel[3] - float(value) * panel[3] / y_max

    svg = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="white"/>',
        '<style>text{font-family:Arial,sans-serif;fill:#24364B}.title{font-size:18px;'
        'font-weight:700}.axis{stroke:#8090A5;stroke-width:1}.grid{stroke:#D9E0E8;'
        'stroke-width:1}.tick{font-size:12px}.label{font-size:13px}.legend{font-size:12px}</style>',
        '<text x="75" y="34" class="title">Median CPTL reduction by distance cap</text>',
        '<text x="665" y="34" class="title">Median CPTL reduction at 5% cap by departure</text>',
    ]
    for panel in panels:
        for tick in np.linspace(0, y_max, 5):
            y = y_coordinate(float(tick), panel)
            svg.append(
                f'<line x1="{panel[0]}" y1="{y:.1f}" x2="{panel[0] + panel[2]}" '
                f'y2="{y:.1f}" class="grid"/>'
            )
            svg.append(
                f'<text x="{panel[0] - 10}" y="{y + 4:.1f}" text-anchor="end" '
                f'class="tick">{tick:.1f}%</text>'
            )
        svg.append(
            f'<line x1="{panel[0]}" y1="{panel[1]}" x2="{panel[0]}" '
            f'y2="{panel[1] + panel[3]}" class="axis"/>'
        )
        svg.append(
            f'<line x1="{panel[0]}" y1="{panel[1] + panel[3]}" '
            f'x2="{panel[0] + panel[2]}" y2="{panel[1] + panel[3]}" class="axis"/>'
        )
    for panel, summary, tick_labels in [
        (panels[0], cap_summary, [f"{100 * value:g}%" for value in cap_summary.index]),
        (panels[1], time_summary, list(time_summary.index)),
    ]:
        for scenario in summary.columns:
            points = []
            for index, value in enumerate(summary[scenario]):
                x = panel[0] + index * panel[2] / max(len(summary) - 1, 1)
                y = y_coordinate(float(value), panel)
                points.append(f"{x:.1f},{y:.1f}")
                svg.append(
                    f'<circle cx="{x:.1f}" cy="{y:.1f}" r="4" '
                    f'fill="{colors[scenario]}"/>'
                )
            svg.append(
                f'<polyline points="{" ".join(points)}" fill="none" '
                f'stroke="{colors[scenario]}" stroke-width="3"/>'
            )
        for index, label in enumerate(tick_labels):
            x = panel[0] + index * panel[2] / max(len(tick_labels) - 1, 1)
            svg.append(
                f'<text x="{x:.1f}" y="425" text-anchor="middle" class="tick">'
                f'{html.escape(str(label))}</text>'
            )
    svg.extend(
        [
            '<line x1="385" y1="462" x2="415" y2="462" stroke="#377EB8" '
            'stroke-width="3"/><text x="423" y="466" class="legend">Building-only</text>',
            '<line x1="555" y1="462" x2="585" y2="462" stroke="#159A92" '
            'stroke-width="3"/><text x="593" y="466" class="legend">Building + CHMv2</text>',
            '</svg>',
        ]
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(svg), encoding="utf-8")


def build_multi_od_report(project_root: Path = PROJECT_ROOT) -> dict[str, Any]:
    """Read processed batch outputs and write publication-facing artifacts."""

    routing = project_root / "data/processed/routing"
    routes = pd.read_csv(routing / "clementi_multi_od_dynamic_cptl_routes.csv")
    comparison = pd.read_csv(
        routing / "clementi_multi_od_dynamic_cptl_scenario_comparison.csv"
    )
    summary = summarize_multi_od_results(routes, comparison)
    summary_path = project_root / "outputs/tables/clementi_multi_od_robustness_summary.json"
    figure_path = project_root / "outputs/figures/clementi_multi_od_robustness.svg"
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    render_multi_od_figure(routes, figure_path)
    return summary | {
        "summary_path": str(summary_path),
        "figure_path": str(figure_path),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Report multi-OD CPTL robustness results.")
    parser.parse_args()
    print(json.dumps(build_multi_od_report(), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
