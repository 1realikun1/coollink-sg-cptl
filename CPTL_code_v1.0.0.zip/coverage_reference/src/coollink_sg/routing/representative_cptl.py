"""Run comparable network-coverage dynamic CPTL samples across expansion regions."""

from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import geopandas as gpd
import pandas as pd
import yaml
from pyproj import CRS
from shapely.geometry import LineString

from coollink_sg.config import (
    DynamicCPTLConfig,
    MultiODCPTLConfig,
    ProcessedLayerConfig,
)
from coollink_sg.heat.dynamic_utci import TimeVaryingUTCI
from coollink_sg.routing.multi_od_cptl import select_network_coverage_od_pairs
from coollink_sg.routing.time_dependent_cptl import (
    _threshold_slug,
    compute_time_dependent_cptl_routes,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class RepresentativeCPTLRegion:
    region_id: str
    network_path: str
    dynamic_thermal_path: str


@dataclass(frozen=True)
class RepresentativeCPTLConfig:
    analysis_id: str
    output_crs: str
    timezone: str
    sample_type: str
    sampling_method: str
    origin_count: int
    distance_bands_m: tuple[tuple[float, float], ...]
    departure_times: tuple[str, ...]
    thermal_series_start_sgt: str
    thermal_series_end_sgt: str
    thermal_series_interval_seconds: int
    walking_speed_m_s: float
    primary_threshold_deg_c: float
    sensitivity_thresholds_deg_c: tuple[float, ...]
    detour_limits: tuple[float, ...]
    time_bin_seconds: int
    waiting_allowed: bool
    thermal_source_status: str
    output_stem: str
    regions: tuple[RepresentativeCPTLRegion, ...]
    paper_summary_path: str


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    if key not in mapping:
        raise ValueError(f"Missing required field '{section}.{key}'")
    return mapping[key]


def _increasing(values: tuple[float, ...], name: str, start_zero: bool = False) -> None:
    if not values or tuple(sorted(set(values))) != values:
        raise ValueError(f"{name} must be unique and increasing")
    if start_zero and values[0] != 0:
        raise ValueError(f"{name} must start at zero")


def load_representative_cptl_config(path: str | Path) -> RepresentativeCPTLConfig:
    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Representative CPTL configuration must be a mapping")
    model = _required(payload, "representative_cptl", "root")
    inputs = _required(payload, "inputs", "root")
    outputs = _required(payload, "outputs", "root")
    output_crs = str(_required(model, "output_crs", "representative_cptl"))
    if not CRS.from_user_input(output_crs).is_projected:
        raise ValueError("representative_cptl.output_crs must be projected")
    bands = tuple(
        (float(item[0]), float(item[1]))
        for item in _required(model, "shortest_path_distance_bands_m", "model")
    )
    if any(lower <= 0 or upper <= lower for lower, upper in bands):
        raise ValueError("Every shortest-path distance band must be positive and ordered")
    departures = tuple(
        str(value) for value in _required(model, "departure_times_sgt", "model")
    )
    if not departures or len(set(departures)) != len(departures):
        raise ValueError("departure_times_sgt must be unique and non-empty")
    for departure in departures:
        if pd.Timestamp(departure).tzinfo is None:
            raise ValueError("Every departure time must be timezone-aware")
    thermal_start = str(_required(model, "thermal_series_start_sgt", "model"))
    thermal_end = str(_required(model, "thermal_series_end_sgt", "model"))
    thermal_interval = int(
        _required(model, "thermal_series_interval_seconds", "model")
    )
    if (
        pd.Timestamp(thermal_start).tzinfo is None
        or pd.Timestamp(thermal_end).tzinfo is None
        or pd.Timestamp(thermal_end) <= pd.Timestamp(thermal_start)
        or thermal_interval <= 0
    ):
        raise ValueError("Thermal-series bounds and interval are invalid")
    thresholds = tuple(
        float(value) for value in _required(model, "sensitivity_thresholds_deg_c", "model")
    )
    _increasing(thresholds, "sensitivity_thresholds_deg_c")
    primary = float(_required(model, "primary_threshold_deg_c", "model"))
    if primary not in thresholds:
        raise ValueError("primary_threshold_deg_c must be an evaluation threshold")
    limits = tuple(float(value) for value in _required(model, "detour_limits", "model"))
    _increasing(limits, "detour_limits", start_zero=True)
    regions = tuple(
        RepresentativeCPTLRegion(
            region_id=str(_required(item, "region_id", "inputs.regions")),
            network_path=str(_required(item, "network", "inputs.regions")),
            dynamic_thermal_path=str(
                _required(item, "dynamic_thermal", "inputs.regions")
            ),
        )
        for item in _required(inputs, "regions", "inputs")
    )
    if not regions or len({item.region_id for item in regions}) != len(regions):
        raise ValueError("At least one unique representative CPTL region is required")
    output_stem = str(_required(model, "output_stem", "model"))
    if not output_stem or Path(output_stem).name != output_stem:
        raise ValueError("output_stem must be a filename stem")
    speed = float(_required(model, "walking_speed_m_s", "model"))
    time_bin = int(_required(model, "time_bin_seconds", "model"))
    origin_count = int(_required(model, "origin_count", "model"))
    if speed <= 0 or time_bin <= 0 or origin_count <= 0:
        raise ValueError("origin count, walking speed, and time bin must be positive")
    waiting = bool(_required(model, "waiting_allowed", "model"))
    if waiting:
        raise ValueError("Representative CPTL does not support waiting")
    source_status = str(_required(model, "thermal_source_status", "model"))
    if "solweig" not in source_status or "not_field_validated" not in source_status:
        raise ValueError("thermal_source_status must retain SOLWEIG validation limits")
    return RepresentativeCPTLConfig(
        analysis_id=str(_required(model, "analysis_id", "model")),
        output_crs=output_crs,
        timezone=str(_required(model, "timezone", "model")),
        sample_type=str(_required(model, "sample_type", "model")),
        sampling_method=str(_required(model, "sampling_method", "model")),
        origin_count=origin_count,
        distance_bands_m=bands,
        departure_times=departures,
        thermal_series_start_sgt=thermal_start,
        thermal_series_end_sgt=thermal_end,
        thermal_series_interval_seconds=thermal_interval,
        walking_speed_m_s=speed,
        primary_threshold_deg_c=primary,
        sensitivity_thresholds_deg_c=thresholds,
        detour_limits=limits,
        time_bin_seconds=time_bin,
        waiting_allowed=waiting,
        thermal_source_status=source_status,
        output_stem=output_stem,
        regions=regions,
        paper_summary_path=str(_required(outputs, "paper_summary", "outputs")),
    )


def summarize_representative_routes(
    routes: pd.DataFrame,
    primary_field: str,
) -> pd.DataFrame:
    """Summarize each region and detour cap across OD and departure cases."""

    rows: list[dict[str, Any]] = []
    for (region_id, cap), frame in routes.groupby(
        ["region_id", "detour_limit_fraction"], sort=True
    ):
        reductions = frame["primary_cptl_reduction_vs_shortest_percent"].astype(float)
        rows.append(
            {
                "region_id": region_id,
                "detour_limit_fraction": float(cap),
                "case_count": len(frame),
                "od_count": int(frame["od_id"].nunique()),
                "departure_count": int(frame["departure_time_sgt"].nunique()),
                "median_route_cptl_deg_c_min": float(frame[primary_field].median()),
                "median_cptl_reduction_percent": float(reductions.median()),
                "q25_cptl_reduction_percent": float(reductions.quantile(0.25)),
                "q75_cptl_reduction_percent": float(reductions.quantile(0.75)),
                "positive_reduction_share_percent": float(100 * reductions.gt(1e-9).mean()),
                "median_distance_increase_percent": float(
                    100 * (frame["distance_ratio_to_shortest"].median() - 1)
                ),
            }
        )
    return pd.DataFrame(rows)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def _dynamic_config(
    config: RepresentativeCPTLConfig,
    region: RepresentativeCPTLRegion,
) -> DynamicCPTLConfig:
    placeholder = ProcessedLayerConfig(path="not_used", layer="not_used")
    return DynamicCPTLConfig(
        analysis_id=f"{config.analysis_id}|{region.region_id}",
        output_crs=config.output_crs,
        timezone=config.timezone,
        departure_times=config.departure_times,
        walking_speed_m_s=config.walking_speed_m_s,
        primary_threshold_deg_c=config.primary_threshold_deg_c,
        sensitivity_thresholds_deg_c=config.sensitivity_thresholds_deg_c,
        detour_limits=config.detour_limits,
        time_bin_seconds=config.time_bin_seconds,
        integration_method="piecewise_linear_threshold_crossing_exact",
        waiting_allowed=config.waiting_allowed,
        primary_height_scenario="central",
        thermal_source_status=config.thermal_source_status,
        is_solweig_dynamic_result=True,
        output_stem=f"{config.output_stem}_{region.region_id}",
        validation_series_start_sgt=config.thermal_series_start_sgt,
        validation_series_end_sgt=config.thermal_series_end_sgt,
        validation_series_interval_seconds=config.thermal_series_interval_seconds,
        network_path=region.network_path,
        nodes_layer="nodes",
        edges_layer="edges",
        static_thermal=placeholder,
        dynamic_thermal_path=region.dynamic_thermal_path,
        od_summary_path="not_used",
        endpoints=placeholder,
    )


def build_representative_cptl(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Select matched network-coverage samples and run regional dynamic CPTL."""

    config = load_representative_cptl_config(config_path)
    sampling_config = MultiODCPTLConfig(
        analysis_id=config.analysis_id,
        output_crs=config.output_crs,
        sample_type=config.sample_type,
        sampling_method=config.sampling_method,
        origin_count=config.origin_count,
        distance_bands_m=config.distance_bands_m,
        scenarios=(),
        output_stem=config.output_stem,
    )
    route_frames: list[gpd.GeoDataFrame] = []
    segment_frames: list[pd.DataFrame] = []
    sample_frames: list[pd.DataFrame] = []
    endpoint_frames: list[gpd.GeoDataFrame] = []
    source_records: list[dict[str, Any]] = []
    for region_index, region in enumerate(config.regions, start=1):
        network_path = project_root / region.network_path
        thermal_path = project_root / region.dynamic_thermal_path
        nodes = gpd.read_file(network_path, layer="nodes").to_crs(config.output_crs)
        edges = gpd.read_file(network_path, layer="edges").to_crs(config.output_crs)
        od_pairs, endpoints, graph = select_network_coverage_od_pairs(
            nodes, edges, sampling_config
        )
        od_pairs.insert(0, "region_id", region.region_id)
        endpoints.insert(0, "region_id", region.region_id)
        sample_frames.append(od_pairs)
        endpoint_frames.append(endpoints)
        run_config = _dynamic_config(config, region)
        thermal = TimeVaryingUTCI(
            pd.read_csv(thermal_path), "central", config.thermal_source_status
        )
        source_records.append(
            {
                "region_id": region.region_id,
                "network_path": region.network_path,
                "network_sha256": _sha256(network_path),
                "dynamic_thermal_path": region.dynamic_thermal_path,
                "dynamic_thermal_sha256": _sha256(thermal_path),
            }
        )
        for od_index, od in enumerate(od_pairs.itertuples(index=False), start=1):
            print(
                f"[{region_index}/{len(config.regions)} {region.region_id}] "
                f"OD {od_index}/{len(od_pairs)} {od.od_id}",
                flush=True,
            )
            routes, segments, _ = compute_time_dependent_cptl_routes(
                nodes,
                edges,
                thermal,
                int(od.origin_node),
                int(od.destination_node),
                run_config,
                routing_graph=graph,
            )
            routes.insert(0, "region_id", region.region_id)
            routes.insert(1, "od_id", od.od_id)
            routes.insert(2, "origin_node", int(od.origin_node))
            routes.insert(3, "destination_node", int(od.destination_node))
            routes.insert(4, "distance_band_rank", int(od.distance_band_rank))
            routes["batch_route_id"] = [
                f"{region.region_id}|{od.od_id}|{departure}|{cap:g}|{route_id}"
                for departure, cap, route_id in zip(
                    routes["departure_time_sgt"],
                    routes["detour_limit_fraction"],
                    routes["route_id"],
                    strict=True,
                )
            ]
            segments.insert(0, "region_id", region.region_id)
            segments.insert(1, "od_id", od.od_id)
            route_keys = routes[
                [
                    "region_id",
                    "od_id",
                    "departure_time_sgt",
                    "detour_limit_fraction",
                    "route_id",
                    "batch_route_id",
                ]
            ]
            segments = segments.merge(
                route_keys,
                on=[
                    "region_id",
                    "od_id",
                    "departure_time_sgt",
                    "detour_limit_fraction",
                    "route_id",
                ],
                how="left",
                validate="many_to_one",
            )
            route_frames.append(routes)
            segment_frames.append(segments)
    routes = gpd.GeoDataFrame(
        pd.concat(route_frames, ignore_index=True),
        geometry="geometry",
        crs=config.output_crs,
    )
    segments = pd.concat(segment_frames, ignore_index=True)
    samples = pd.concat(sample_frames, ignore_index=True)
    endpoints = gpd.GeoDataFrame(
        pd.concat(endpoint_frames, ignore_index=True),
        geometry="geometry",
        crs=config.output_crs,
    )
    primary_field = _threshold_slug(config.primary_threshold_deg_c)
    aggregate = summarize_representative_routes(routes, primary_field)
    processed = project_root / "data/processed/routing"
    processed.mkdir(parents=True, exist_ok=True)
    geopackage = processed / f"{config.output_stem}.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    routes.to_file(geopackage, layer="regional_cptl_routes", driver="GPKG")
    endpoints.to_file(geopackage, layer="od_endpoints", driver="GPKG", mode="a")
    connectors = samples.copy()
    connectors["geometry"] = [
        LineString([(row.origin_x, row.origin_y), (row.destination_x, row.destination_y)])
        for row in samples.itertuples(index=False)
    ]
    gpd.GeoDataFrame(connectors, geometry="geometry", crs=config.output_crs).to_file(
        geopackage, layer="od_straight_connectors", driver="GPKG", mode="a"
    )
    routes.drop(columns="geometry").to_csv(
        processed / f"{config.output_stem}_routes.csv", index=False
    )
    segments.to_csv(processed / f"{config.output_stem}_segments.csv", index=False)
    samples.to_csv(processed / f"{config.output_stem}_sample.csv", index=False)
    aggregate.to_csv(processed / f"{config.output_stem}_aggregate.csv", index=False)
    paper_summary = project_root / config.paper_summary_path
    paper_summary.parent.mkdir(parents=True, exist_ok=True)
    aggregate.to_csv(paper_summary, index=False)
    summary = {
        "analysis_id": config.analysis_id,
        "sample_type": config.sample_type,
        "interpretation_warning": (
            "Network-coverage OD samples are not observed travel demand. Results are "
            "unvalidated clear-sky SOLWEIG design-scenario comparisons."
        ),
        "thermal_source_status": config.thermal_source_status,
        "region_count": len(config.regions),
        "od_count_per_region": config.origin_count * len(config.distance_bands_m),
        "departure_count": len(config.departure_times),
        "detour_limit_count": len(config.detour_limits),
        "route_scenario_count": len(routes),
        "route_segment_traversal_count": len(segments),
        "primary_cptl_field": primary_field,
        "sources": source_records,
        "outputs": {
            "geopackage": str(geopackage.relative_to(project_root)),
            "routes_csv": f"data/processed/routing/{config.output_stem}_routes.csv",
            "segments_csv": f"data/processed/routing/{config.output_stem}_segments.csv",
            "sample_csv": f"data/processed/routing/{config.output_stem}_sample.csv",
            "aggregate_csv": f"data/processed/routing/{config.output_stem}_aggregate.csv",
            "paper_summary_csv": config.paper_summary_path,
        },
    }
    (processed / f"{config.output_stem}_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/representative_cptl.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(build_representative_cptl(args.config), indent=2))


if __name__ == "__main__":
    main()
