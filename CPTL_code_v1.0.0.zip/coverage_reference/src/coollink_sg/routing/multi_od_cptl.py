"""Reproducible multi-OD robustness analysis for dynamic CPTL routing."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import geopandas as gpd
import networkx as nx
import numpy as np
import pandas as pd
from shapely.geometry import LineString

from coollink_sg.config import (
    MultiODCPTLConfig,
    ShortestPathConfig,
    load_dynamic_cptl_config,
    load_multi_od_cptl_config,
)
from coollink_sg.heat.dynamic_utci import TimeVaryingUTCI
from coollink_sg.routing.shortest_path import build_routing_graph
from coollink_sg.routing.time_dependent_cptl import (
    _threshold_slug,
    compute_time_dependent_cptl_routes,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]
LENGTH_FIELD = "length_m"


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _routing_graph(
    nodes: gpd.GeoDataFrame,
    edges: gpd.GeoDataFrame,
    output_crs: str,
) -> nx.MultiDiGraph:
    config = ShortestPathConfig(
        network_path="in_memory",
        nodes_layer="nodes",
        edges_layer="edges",
        output_crs=output_crs,
        cost_field=LENGTH_FIELD,
    )
    return build_routing_graph(nodes, edges, config)


def select_network_coverage_od_pairs(
    nodes: gpd.GeoDataFrame,
    edges: gpd.GeoDataFrame,
    config: MultiODCPTLConfig,
) -> tuple[pd.DataFrame, gpd.GeoDataFrame, nx.MultiDiGraph]:
    """Select deterministic, spatially dispersed origins and distance-band targets."""

    graph = _routing_graph(nodes, edges, config.output_crs)
    components = list(nx.strongly_connected_components(graph))
    largest = max(components, key=len)
    candidates = (
        nodes.loc[nodes["osmid"].astype(int).isin(largest), ["osmid", "geometry"]]
        .assign(osmid=lambda frame: frame["osmid"].astype(int))
        .sort_values("osmid")
        .reset_index(drop=True)
    )
    if len(candidates) < config.origin_count:
        raise ValueError("Largest strongly connected component is too small")
    coordinates = np.column_stack(
        [candidates.geometry.x.to_numpy(), candidates.geometry.y.to_numpy()]
    )
    centroid = coordinates.mean(axis=0)
    centroid_distance = np.sum((coordinates - centroid) ** 2, axis=1)
    selected_indices = [int(np.argmin(centroid_distance))]
    minimum_squared_distance = np.sum(
        (coordinates - coordinates[selected_indices[0]]) ** 2, axis=1
    )
    while len(selected_indices) < config.origin_count:
        minimum_squared_distance[selected_indices] = -1
        next_index = int(np.argmax(minimum_squared_distance))
        selected_indices.append(next_index)
        distance_to_next = np.sum(
            (coordinates - coordinates[next_index]) ** 2, axis=1
        )
        minimum_squared_distance = np.minimum(
            minimum_squared_distance, distance_to_next
        )

    rows: list[dict[str, Any]] = []
    endpoint_rows: list[dict[str, Any]] = []
    node_geometry = candidates.set_index("osmid")["geometry"].to_dict()
    maximum_distance = max(upper for _, upper in config.distance_bands_m)
    for origin_rank, selected_index in enumerate(selected_indices, start=1):
        origin_node = int(candidates.iloc[selected_index]["osmid"])
        lengths = nx.single_source_dijkstra_path_length(
            graph,
            origin_node,
            cutoff=maximum_distance,
            weight=LENGTH_FIELD,
        )
        for band_rank, (lower, upper) in enumerate(config.distance_bands_m, start=1):
            midpoint = (lower + upper) / 2
            eligible = [
                (abs(float(distance) - midpoint), int(node), float(distance))
                for node, distance in lengths.items()
                if node != origin_node and lower <= float(distance) <= upper
            ]
            if not eligible:
                raise ValueError(
                    f"No target exists for origin {origin_node} in {lower:g}-{upper:g} m"
                )
            _, destination_node, shortest_distance = min(eligible)
            od_id = f"od_{origin_rank:02d}_b{band_rank:02d}"
            origin_point = node_geometry[origin_node]
            destination_point = node_geometry[destination_node]
            rows.append(
                {
                    "od_id": od_id,
                    "origin_rank": origin_rank,
                    "distance_band_rank": band_rank,
                    "origin_node": origin_node,
                    "destination_node": destination_node,
                    "distance_band_min_m": lower,
                    "distance_band_max_m": upper,
                    "shortest_path_distance_m": shortest_distance,
                    "origin_x": float(origin_point.x),
                    "origin_y": float(origin_point.y),
                    "destination_x": float(destination_point.x),
                    "destination_y": float(destination_point.y),
                    "sampling_method": config.sampling_method,
                    "sample_type": config.sample_type,
                }
            )
            for role, node_id, geometry in (
                ("origin", origin_node, origin_point),
                ("destination", destination_node, destination_point),
            ):
                endpoint_rows.append(
                    {
                        "od_id": od_id,
                        "endpoint_role": role,
                        "node_id": node_id,
                        "distance_band_rank": band_rank,
                        "geometry": geometry,
                    }
                )
    od_pairs = pd.DataFrame(rows)
    endpoints = gpd.GeoDataFrame(
        endpoint_rows, geometry="geometry", crs=config.output_crs
    )
    return od_pairs, endpoints, graph


def _aggregate_routes(
    routes: pd.DataFrame,
    primary_field: str,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    group_fields = ["thermal_scenario", "departure_time_sgt", "detour_limit_fraction"]
    for keys, group in routes.groupby(group_fields, sort=True):
        reductions = group["primary_cptl_reduction_vs_shortest_percent"].astype(float)
        rows.append(
            {
                "thermal_scenario": keys[0],
                "departure_time_sgt": keys[1],
                "detour_limit_fraction": float(keys[2]),
                "od_count": int(group["od_id"].nunique()),
                "median_route_length_m": float(group["route_length_m"].median()),
                "median_distance_increase_percent": float(
                    100 * (group["distance_ratio_to_shortest"].median() - 1)
                ),
                "median_cptl_deg_c_min": float(group[primary_field].median()),
                "median_cptl_reduction_percent": float(reductions.median()),
                "q25_cptl_reduction_percent": float(reductions.quantile(0.25)),
                "q75_cptl_reduction_percent": float(reductions.quantile(0.75)),
                "od_share_with_positive_reduction_percent": float(
                    100 * reductions.gt(1e-9).mean()
                ),
            }
        )
    return pd.DataFrame(rows)


def _compare_scenarios(
    routes: pd.DataFrame,
    scenario_labels: tuple[str, ...],
    primary_field: str,
) -> pd.DataFrame:
    reference, alternative = scenario_labels[:2]
    keys = ["od_id", "departure_time_sgt", "detour_limit_fraction"]
    fields = keys + [
        "route_length_m",
        "distance_ratio_to_shortest",
        primary_field,
        "route_id",
    ]
    left = routes.loc[routes["thermal_scenario"].eq(reference), fields]
    right = routes.loc[routes["thermal_scenario"].eq(alternative), fields]
    merged = left.merge(
        right,
        on=keys,
        how="inner",
        validate="one_to_one",
        suffixes=(f"_{reference}", f"_{alternative}"),
    )
    ref_field = f"{primary_field}_{reference}"
    alt_field = f"{primary_field}_{alternative}"
    merged["alternative_minus_reference_cptl_deg_c_min"] = (
        merged[alt_field] - merged[ref_field]
    )
    merged["alternative_minus_reference_cptl_percent"] = np.where(
        merged[ref_field].gt(0),
        100 * (merged[alt_field] - merged[ref_field]) / merged[ref_field],
        np.nan,
    )
    merged["route_changed"] = merged[f"route_id_{reference}"].ne(
        merged[f"route_id_{alternative}"]
    )
    merged.insert(3, "reference_scenario", reference)
    merged.insert(4, "alternative_scenario", alternative)
    return merged


def build_multi_od_cptl_robustness(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Build the configured multi-OD sample and run every thermal scenario."""

    config = load_multi_od_cptl_config(config_path)
    scenario_configs = [
        load_dynamic_cptl_config(project_root / scenario.dynamic_cptl_config_path)
        for scenario in config.scenarios
    ]
    reference_config = scenario_configs[0]
    comparable_fields = (
        "network_path",
        "nodes_layer",
        "edges_layer",
        "output_crs",
        "departure_times",
        "walking_speed_m_s",
        "primary_threshold_deg_c",
        "sensitivity_thresholds_deg_c",
        "detour_limits",
        "time_bin_seconds",
        "integration_method",
        "waiting_allowed",
        "primary_height_scenario",
    )
    for scenario_config in scenario_configs[1:]:
        mismatched = [
            field
            for field in comparable_fields
            if getattr(scenario_config, field) != getattr(reference_config, field)
        ]
        if mismatched:
            raise ValueError(
                "Thermal scenarios differ in non-thermal routing settings: "
                + ", ".join(mismatched)
            )
    network_path = project_root / reference_config.network_path
    nodes = gpd.read_file(network_path, layer=reference_config.nodes_layer)
    edges = gpd.read_file(network_path, layer=reference_config.edges_layer)
    od_pairs, endpoints, graph = select_network_coverage_od_pairs(
        nodes, edges, config
    )
    route_frames: list[gpd.GeoDataFrame] = []
    segment_frames: list[pd.DataFrame] = []
    scenario_sources: list[dict[str, Any]] = []
    for scenario, routing_config in zip(
        config.scenarios, scenario_configs, strict=True
    ):
        thermal_path = project_root / routing_config.dynamic_thermal_path
        thermal_frame = pd.read_csv(thermal_path)
        thermal = TimeVaryingUTCI(
            thermal_frame,
            routing_config.primary_height_scenario,
            routing_config.thermal_source_status,
        )
        scenario_sources.append(
            {
                "label": scenario.label,
                "dynamic_cptl_config": scenario.dynamic_cptl_config_path,
                "dynamic_thermal_path": routing_config.dynamic_thermal_path,
                "dynamic_thermal_sha256": _file_sha256(thermal_path),
                "thermal_source_status": routing_config.thermal_source_status,
            }
        )
        for progress, od in enumerate(od_pairs.itertuples(index=False), start=1):
            print(
                f"[{scenario.label}] OD {progress}/{len(od_pairs)} "
                f"{od.od_id}: {od.shortest_path_distance_m:.1f} m",
                flush=True,
            )
            routes, segments, _ = compute_time_dependent_cptl_routes(
                nodes,
                edges,
                thermal,
                int(od.origin_node),
                int(od.destination_node),
                routing_config,
                routing_graph=graph,
            )
            routes.insert(0, "thermal_scenario", scenario.label)
            routes.insert(1, "od_id", od.od_id)
            routes.insert(2, "origin_node", int(od.origin_node))
            routes.insert(3, "destination_node", int(od.destination_node))
            routes.insert(4, "distance_band_rank", int(od.distance_band_rank))
            routes.insert(
                5, "sample_shortest_path_distance_m", od.shortest_path_distance_m
            )
            routes["batch_route_id"] = [
                f"{scenario.label}|{od.od_id}|{departure}|{detour:g}|{route_id}"
                for departure, detour, route_id in zip(
                    routes["departure_time_sgt"],
                    routes["detour_limit_fraction"],
                    routes["route_id"],
                    strict=True,
                )
            ]
            segments.insert(0, "thermal_scenario", scenario.label)
            segments.insert(1, "od_id", od.od_id)
            route_key = routes[
                [
                    "thermal_scenario",
                    "od_id",
                    "departure_time_sgt",
                    "detour_limit_fraction",
                    "route_id",
                    "batch_route_id",
                ]
            ]
            segments = segments.merge(
                route_key,
                on=[
                    "thermal_scenario",
                    "od_id",
                    "departure_time_sgt",
                    "detour_limit_fraction",
                    "route_id",
                ],
                how="left",
                validate="many_to_one",
            )
            route_frames.append(routes)
            segment_frames.append(segments)
    all_routes = gpd.GeoDataFrame(
        pd.concat(route_frames, ignore_index=True),
        geometry="geometry",
        crs=reference_config.output_crs,
    )
    all_segments = pd.concat(segment_frames, ignore_index=True)
    primary_field = _threshold_slug(reference_config.primary_threshold_deg_c)
    aggregate = _aggregate_routes(all_routes, primary_field)
    labels = tuple(scenario.label for scenario in config.scenarios)
    comparison = _compare_scenarios(all_routes, labels, primary_field)

    processed = project_root / "data/processed/routing"
    processed.mkdir(parents=True, exist_ok=True)
    geopackage = processed / f"{config.output_stem}.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    all_routes.to_file(geopackage, layer="multi_od_routes", driver="GPKG")
    endpoints.to_file(geopackage, layer="od_endpoints", driver="GPKG", mode="a")
    connector_rows = []
    for od in od_pairs.itertuples(index=False):
        connector_rows.append(
            {
                **od._asdict(),
                "geometry": LineString(
                    [(od.origin_x, od.origin_y), (od.destination_x, od.destination_y)]
                ),
            }
        )
    connectors = gpd.GeoDataFrame(
        connector_rows, geometry="geometry", crs=config.output_crs
    )
    connectors.to_file(geopackage, layer="od_straight_connectors", driver="GPKG", mode="a")
    od_pairs.to_csv(processed / f"{config.output_stem}_sample.csv", index=False)
    all_routes.drop(columns="geometry").to_csv(
        processed / f"{config.output_stem}_routes.csv", index=False
    )
    all_segments.to_csv(
        processed / f"{config.output_stem}_segments.csv", index=False
    )
    aggregate.to_csv(
        processed / f"{config.output_stem}_aggregate.csv", index=False
    )
    comparison.to_csv(
        processed / f"{config.output_stem}_scenario_comparison.csv", index=False
    )
    summary = {
        "analysis_id": config.analysis_id,
        "sample_type": config.sample_type,
        "sampling_method": config.sampling_method,
        "interpretation_warning": (
            "This deterministic network-coverage sample tests algorithmic robustness; "
            "it is not observed or modelled pedestrian travel demand."
        ),
        "output_crs": config.output_crs,
        "network_path": reference_config.network_path,
        "network_sha256": _file_sha256(network_path),
        "largest_strongly_connected_component_node_count": len(
            max(nx.strongly_connected_components(graph), key=len)
        ),
        "origin_count": config.origin_count,
        "distance_bands_m": [list(band) for band in config.distance_bands_m],
        "od_count": len(od_pairs),
        "departure_count": len(reference_config.departure_times),
        "detour_limit_count": len(reference_config.detour_limits),
        "thermal_scenario_count": len(config.scenarios),
        "route_scenario_count": len(all_routes),
        "route_segment_traversal_count": len(all_segments),
        "primary_cptl_field": primary_field,
        "thermal_sources": scenario_sources,
        "outputs": {
            "geopackage": str(geopackage.relative_to(project_root)),
            "sample_csv": f"data/processed/routing/{config.output_stem}_sample.csv",
            "routes_csv": f"data/processed/routing/{config.output_stem}_routes.csv",
            "segments_csv": f"data/processed/routing/{config.output_stem}_segments.csv",
            "aggregate_csv": f"data/processed/routing/{config.output_stem}_aggregate.csv",
            "scenario_comparison_csv": (
                f"data/processed/routing/{config.output_stem}_scenario_comparison.csv"
            ),
        },
    }
    summary_path = processed / f"{config.output_stem}_summary.json"
    summary_path.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run deterministic multi-OD dynamic CPTL robustness analysis."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/multi_od_cptl.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(build_multi_od_cptl_robustness(args.config), indent=2))


if __name__ == "__main__":
    main()
