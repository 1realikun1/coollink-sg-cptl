"""Fit a transferable binary sun--shade route-choice model to public observations."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import yaml
from scipy.optimize import minimize
from scipy.special import expit

PROJECT_ROOT = Path(__file__).resolve().parents[3]


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    if key not in mapping:
        raise ValueError(f"Missing required field '{section}.{key}'")
    return mapping[key]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def effective_components(
    frame: pd.DataFrame,
    tree_shade_intensity: float,
) -> pd.DataFrame:
    """Convert tree shade into the effective sun/full-shade components in the source model."""

    if not 0 <= tree_shade_intensity <= 1:
        raise ValueError("tree_shade_intensity must be between zero and one")
    required = {
        "Participant",
        "A_sun_length",
        "A_tree_length",
        "A_shade_length",
        "B_sun_length",
        "B_tree_length",
        "B_shade_length",
        "B_chosen",
        "Treatment",
    }
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"Behavioral observations are missing fields: {sorted(missing)}")
    result = frame.copy()
    rho = float(tree_shade_intensity)
    for option in ("A", "B"):
        sun = pd.to_numeric(result[f"{option}_sun_length"], errors="raise")
        tree = pd.to_numeric(result[f"{option}_tree_length"], errors="raise")
        shade = pd.to_numeric(result[f"{option}_shade_length"], errors="raise")
        result[f"{option}_effective_sun_m"] = sun + (1 - rho) * tree
        result[f"{option}_effective_shade_m"] = shade + rho * tree
    result["A_chosen"] = 1 - pd.to_numeric(result["B_chosen"], errors="raise")
    numeric = result.filter(regex=r"_(m|chosen)$").to_numpy(dtype=float)
    if not np.isfinite(numeric).all():
        raise ValueError("Behavioral choice components must be finite")
    return result


def route_choice_probability(
    cost_a_m: np.ndarray | float,
    cost_b_m: np.ndarray | float,
    scale_m: float,
) -> np.ndarray:
    """Probability of choosing A when lower generalized distance is preferred."""

    if not np.isfinite(scale_m) or scale_m <= 0:
        raise ValueError("scale_m must be finite and positive")
    return expit(-(np.asarray(cost_a_m, dtype=float) - np.asarray(cost_b_m, dtype=float)) / scale_m)


def _model_arrays(frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    sun_diff = (
        frame["A_effective_sun_m"].to_numpy(dtype=float)
        - frame["B_effective_sun_m"].to_numpy(dtype=float)
    )
    shade_diff = (
        frame["A_effective_shade_m"].to_numpy(dtype=float)
        - frame["B_effective_shade_m"].to_numpy(dtype=float)
    )
    choices = frame["A_chosen"].to_numpy(dtype=float)
    return sun_diff, shade_diff, choices


def fit_population_model(frame: pd.DataFrame) -> dict[str, float]:
    """Maximum-likelihood fit of beta and logistic scale in the published cost structure."""

    sun_diff, shade_diff, choices = _model_arrays(frame)
    if len(frame) < 2 or np.unique(choices).size != 2:
        raise ValueError("Both route choices and at least two observations are required")

    def objective(log_parameters: np.ndarray) -> float:
        beta, scale = np.exp(log_parameters)
        probability = route_choice_probability(
            beta * sun_diff + shade_diff,
            np.zeros_like(sun_diff),
            scale,
        )
        probability = np.clip(probability, 1e-12, 1 - 1e-12)
        log_likelihood = choices * np.log(probability)
        log_likelihood += (1 - choices) * np.log1p(-probability)
        return float(-np.sum(log_likelihood))

    fitted = minimize(
        objective,
        np.log([1.16, 25.0]),
        method="L-BFGS-B",
        bounds=[(np.log(0.05), np.log(5.0)), (np.log(0.25), np.log(500.0))],
    )
    if not fitted.success:
        raise RuntimeError(f"Behavior model optimization failed: {fitted.message}")
    beta, scale = np.exp(fitted.x)
    probability = route_choice_probability(
        beta * sun_diff + shade_diff,
        np.zeros_like(sun_diff),
        scale,
    )
    prediction = probability >= 0.5
    return {
        "sun_cost_factor_beta": float(beta),
        "choice_scale_m": float(scale),
        "negative_log_likelihood": float(fitted.fun),
        "mean_log_loss": float(fitted.fun / len(frame)),
        "brier_score": float(np.mean((probability - choices) ** 2)),
        "accuracy": float(np.mean(prediction == choices)),
    }


def _predict(frame: pd.DataFrame, parameters: dict[str, float]) -> np.ndarray:
    sun_diff, shade_diff, _ = _model_arrays(frame)
    cost_diff = parameters["sun_cost_factor_beta"] * sun_diff + shade_diff
    return route_choice_probability(
        cost_diff,
        np.zeros_like(cost_diff),
        parameters["choice_scale_m"],
    )


def leave_one_participant_out(frame: pd.DataFrame) -> dict[str, float]:
    """Evaluate transfer to held-out participants."""

    probability = np.full(len(frame), np.nan, dtype=float)
    participant = frame["Participant"].astype(str).to_numpy()
    for held_out in sorted(set(participant)):
        test = participant == held_out
        parameters = fit_population_model(frame.loc[~test])
        probability[test] = _predict(frame.loc[test], parameters)
    if not np.isfinite(probability).all():
        raise RuntimeError("Leave-one-participant-out predictions are incomplete")
    choices = frame["A_chosen"].to_numpy(dtype=float)
    clipped = np.clip(probability, 1e-12, 1 - 1e-12)
    log_likelihood = choices * np.log(clipped)
    log_likelihood += (1 - choices) * np.log1p(-clipped)
    return {
        "loocv_log_loss": float(-np.mean(log_likelihood)),
        "loocv_brier_score": float(np.mean((probability - choices) ** 2)),
        "loocv_accuracy": float(np.mean((probability >= 0.5) == choices)),
        "loocv_probability": probability,
    }


def participant_bootstrap(
    frame: pd.DataFrame,
    replicates: int,
    seed: int,
) -> pd.DataFrame:
    """Participant-cluster bootstrap for transferable parameter uncertainty."""

    if replicates <= 0:
        raise ValueError("bootstrap_replicates must be positive")
    grouped = {key: value for key, value in frame.groupby("Participant", sort=True)}
    participants = np.array(sorted(grouped), dtype=object)
    rng = np.random.default_rng(seed)
    rows: list[dict[str, float | int]] = []
    for replicate in range(replicates):
        sample = rng.choice(participants, size=len(participants), replace=True)
        pieces = []
        for draw_index, participant in enumerate(sample):
            piece = grouped[str(participant)].copy()
            piece["Participant"] = f"boot_{draw_index:03d}"
            pieces.append(piece)
        parameters = fit_population_model(pd.concat(pieces, ignore_index=True))
        rows.append({"bootstrap_replicate": replicate, **parameters})
    return pd.DataFrame(rows)


def _plot_diagnostics(
    observations: pd.DataFrame,
    bootstrap: pd.DataFrame,
    png_path: Path,
    svg_path: Path,
) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(8.4, 3.5), constrained_layout=True)
    axes[0].hist(bootstrap["sun_cost_factor_beta"], bins=25, color="#2563eb", alpha=0.85)
    axes[0].axvline(1, color="#111827", linestyle="--", linewidth=1)
    axes[0].set_xlabel("Sun cost factor, beta")
    axes[0].set_ylabel("Bootstrap replicates")
    axes[0].set_title("Participant-cluster uncertainty")
    bins = pd.qcut(observations["predicted_probability_a"], 8, duplicates="drop")
    calibration = observations.groupby(bins, observed=True).agg(
        predicted=("predicted_probability_a", "mean"),
        observed=("A_chosen", "mean"),
        count=("A_chosen", "size"),
    )
    axes[1].plot([0, 1], [0, 1], color="#6b7280", linestyle="--", linewidth=1)
    axes[1].scatter(
        calibration["predicted"],
        calibration["observed"],
        s=np.maximum(20, calibration["count"] * 2),
        color="#059669",
    )
    axes[1].set(xlim=(0, 1), ylim=(0, 1), xlabel="Predicted P(A)", ylabel="Observed A share")
    axes[1].set_title("Held-out participant calibration")
    for path in (png_path, svg_path):
        path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def build_behavior_choice_model(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    payload = yaml.safe_load(Path(config_path).read_text(encoding="utf-8"))
    model = _required(payload, "behavior_choice_model", "root")
    inputs = _required(payload, "inputs", "root")
    outputs = _required(payload, "outputs", "root")
    source = project_root / str(_required(inputs, "behavioral_data", "inputs"))
    frame = effective_components(
        pd.read_csv(source),
        float(_required(model, "tree_shade_intensity", "behavior_choice_model")),
    )
    if bool(_required(model, "treatment_only", "behavior_choice_model")):
        frame = frame.loc[frame["Treatment"].eq(1)].reset_index(drop=True)
    parameters = fit_population_model(frame)
    cv = leave_one_participant_out(frame)
    frame["predicted_probability_a"] = cv.pop("loocv_probability")
    bootstrap = participant_bootstrap(
        frame,
        int(_required(model, "bootstrap_replicates", "behavior_choice_model")),
        int(_required(model, "random_seed", "behavior_choice_model")),
    )
    quantiles = bootstrap[["sun_cost_factor_beta", "choice_scale_m"]].quantile([0.025, 0.5, 0.975])
    summary: dict[str, Any] = {
        "analysis_id": str(_required(model, "analysis_id", "behavior_choice_model")),
        "source_path": str(source.relative_to(project_root)),
        "source_sha256": _sha256(source),
        "observation_count": int(len(frame)),
        "participant_count": int(frame["Participant"].nunique()),
        "tree_shade_intensity": float(
            _required(model, "tree_shade_intensity", "behavior_choice_model")
        ),
        **parameters,
        **cv,
        "beta_bootstrap_95_interval": [
            float(quantiles.loc[0.025, "sun_cost_factor_beta"]),
            float(quantiles.loc[0.975, "sun_cost_factor_beta"]),
        ],
        "scale_bootstrap_95_interval_m": [
            float(quantiles.loc[0.025, "choice_scale_m"]),
            float(quantiles.loc[0.975, "choice_scale_m"]),
        ],
        "bootstrap_replicates": int(len(bootstrap)),
        "interpretation_warning": str(_required(model, "interpretation", "behavior_choice_model")),
    }
    paths = {key: project_root / str(value) for key, value in outputs.items()}
    for path in paths.values():
        path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(paths["observations"], index=False)
    bootstrap.to_csv(paths["bootstrap_parameters"], index=False)
    paths["summary_json"].write_text(json.dumps(summary, indent=2), encoding="utf-8")
    flat_summary = {
        key: value for key, value in summary.items() if not isinstance(value, list)
    }
    pd.DataFrame([flat_summary]).to_csv(paths["summary_table"], index=False)
    _plot_diagnostics(frame, bootstrap, paths["figure_png"], paths["figure_svg"])
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/behavior_choice_model.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(build_behavior_choice_model(args.config), indent=2))


if __name__ == "__main__":
    main()
