"""Exact epsilon-constrained routing on modeled UTCI thermal burden."""

from __future__ import annotations

import argparse
import hashlib
import heapq
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import networkx as nx
import numpy as np
import pandas as pd
from shapely.geometry import MultiLineString

from coollink_sg.config import (
    ShortestPathConfig,
    ThermalRouteConfig,
    load_thermal_route_config,
)
from coollink_sg.heat.utci_thermal_burden import HEIGHT_SCENARIOS
from coollink_sg.routing.shortest_path import build_routing_graph, shortest_route

PROJECT_ROOT = Path(__file__).resolve().parents[3]
LENGTH_FIELD = "length_m"


@dataclass(frozen=True)
class _RouteLabel:
    node: int
    distance_m: float
    burden_deg_c_min: float
    previous_label: int | None
    incoming_edge: tuple[int, int, int] | None


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def _route_id(segment_ids: list[str]) -> str:
    payload = "|".join(segment_ids).encode("utf-8")
    return f"thermal_route_{hashlib.sha256(payload).hexdigest()[:12]}"


def _is_dominated(
    labels: list[_RouteLabel],
    active_ids: list[int],
    distance_m: float,
    burden: float,
    tolerance: float = 1e-9,
) -> bool:
    return any(
        labels[label_id].distance_m <= distance_m + tolerance
        and labels[label_id].burden_deg_c_min <= burden + tolerance
        for label_id in active_ids
    )


def _epsilon_constrained_destination_labels(
    graph: nx.MultiDiGraph,
    origin_node: int,
    destination_node: int,
    burden_field: str,
    maximum_distance_m: float,
) -> tuple[list[_RouteLabel], list[int], dict[str, int]]:
    """Build the exact non-dominated distance–burden label set within a distance cap."""

    if origin_node not in graph or destination_node not in graph:
        raise ValueError("Thermal-route endpoints must exist in the network")
    if origin_node == destination_node:
        raise ValueError("Thermal-route endpoints must differ")
    reverse = graph.reverse(copy=False)
    lower_bounds = nx.single_source_dijkstra_path_length(
        reverse, destination_node, weight=LENGTH_FIELD
    )
    if origin_node not in lower_bounds:
        raise ValueError("No directed path exists between the thermal-route endpoints")
    tolerance = max(1e-7, maximum_distance_m * 1e-10)
    labels = [_RouteLabel(origin_node, 0.0, 0.0, None, None)]
    active: set[int] = {0}
    node_labels: dict[int, list[int]] = {origin_node: [0]}
    queue: list[tuple[float, float, int]] = [(0.0, 0.0, 0)]
    expanded = 0
    generated = 1
    while queue:
        _, _, label_id = heapq.heappop(queue)
        if label_id not in active:
            continue
        label = labels[label_id]
        if label.node == destination_node:
            continue
        expanded += 1
        for _, target, key, attributes in graph.out_edges(
            label.node, keys=True, data=True
        ):
            edge_length = float(attributes[LENGTH_FIELD])
            edge_burden = float(attributes[burden_field])
            if not np.isfinite(edge_burden) or edge_burden < 0:
                raise ValueError(f"Every edge {burden_field} must be finite and non-negative")
            distance = label.distance_m + edge_length
            lower_bound = lower_bounds.get(int(target))
            if lower_bound is None or distance + lower_bound > maximum_distance_m + tolerance:
                continue
            burden = label.burden_deg_c_min + edge_burden
            target_ids = [
                candidate
                for candidate in node_labels.get(int(target), [])
                if candidate in active
            ]
            if _is_dominated(labels, target_ids, distance, burden):
                continue
            for candidate in target_ids:
                existing = labels[candidate]
                if (
                    distance <= existing.distance_m + tolerance
                    and burden <= existing.burden_deg_c_min + tolerance
                ):
                    active.discard(candidate)
            new_id = len(labels)
            labels.append(
                _RouteLabel(
                    node=int(target),
                    distance_m=distance,
                    burden_deg_c_min=burden,
                    previous_label=label_id,
                    incoming_edge=(label.node, int(target), int(key)),
                )
            )
            active.add(new_id)
            node_labels.setdefault(int(target), []).append(new_id)
            heapq.heappush(queue, (burden, distance, new_id))
            generated += 1
            if generated > 2_000_000:
                raise RuntimeError(
                    "Exact thermal-route label set exceeded the documented safety limit"
                )
    destination_labels = [
        label_id
        for label_id in node_labels.get(destination_node, [])
        if label_id in active
    ]
    if not destination_labels:
        raise ValueError("No route satisfies the configured maximum detour constraint")
    return labels, destination_labels, {
        "generated_label_count": generated,
        "expanded_label_count": expanded,
        "destination_pareto_label_count": len(destination_labels),
    }


def _select_label_within_cap(
    labels: list[_RouteLabel],
    destination_labels: list[int],
    distance_cap_m: float,
) -> int:
    tolerance = max(1e-7, distance_cap_m * 1e-10)
    eligible = [
        label_id
        for label_id in destination_labels
        if labels[label_id].distance_m <= distance_cap_m + tolerance
    ]
    if not eligible:
        raise ValueError("No Pareto route is eligible under the requested distance cap")
    return min(
        eligible,
        key=lambda label_id: (
            labels[label_id].burden_deg_c_min,
            labels[label_id].distance_m,
            label_id,
        ),
    )


def _recover_route_edges(
    graph: nx.MultiDiGraph,
    labels: list[_RouteLabel],
    label_id: int,
) -> gpd.GeoDataFrame:
    edge_keys: list[tuple[int, int, int]] = []
    current = label_id
    while labels[current].previous_label is not None:
        incoming = labels[current].incoming_edge
        if incoming is None:
            raise RuntimeError("Thermal-route label chain is incomplete")
        edge_keys.append(incoming)
        current = int(labels[current].previous_label)
    edge_keys.reverse()
    rows: list[dict[str, Any]] = []
    for sequence, (u, v, key) in enumerate(edge_keys):
        rows.append(
            {
                "route_sequence": sequence,
                "u": u,
                "v": v,
                "key": key,
                **graph[u][v][key],
            }
        )
    return gpd.GeoDataFrame(rows, geometry="geometry", crs=graph.graph["crs"])


def compute_thermal_routes(
    nodes: gpd.GeoDataFrame,
    network_edges: gpd.GeoDataFrame,
    thermal: gpd.GeoDataFrame,
    origin_node: int,
    destination_node: int,
    config: ThermalRouteConfig,
) -> tuple[gpd.GeoDataFrame, pd.DataFrame, dict[str, Any]]:
    """Compute exact minimum-burden routes under explicit detour caps."""

    thermal_fields = {
        "segment_id",
        "travel_time_min",
        *{f"modeled_utci_mean_{scenario}_deg_c" for scenario in HEIGHT_SCENARIOS},
        *{f"thermal_burden_{scenario}_deg_c_min" for scenario in HEIGHT_SCENARIOS},
    }
    missing = thermal_fields.difference(thermal.columns)
    if missing:
        raise ValueError(f"Thermal table is missing fields: {sorted(missing)}")
    if thermal["segment_id"].isna().any() or not thermal["segment_id"].is_unique:
        raise ValueError("Thermal segment_id values must be complete and unique")
    if network_edges["segment_id"].isna().any() or not network_edges["segment_id"].is_unique:
        raise ValueError("Network segment_id values must be complete and unique")
    if set(network_edges["segment_id"]) != set(thermal["segment_id"]):
        raise ValueError("Network and thermal segment IDs must match exactly")
    joined = network_edges.merge(
        thermal[list(thermal_fields)], on="segment_id", how="left", validate="one_to_one"
    )
    routing_config = ShortestPathConfig(
        network_path=config.network_path,
        nodes_layer=config.nodes_layer,
        edges_layer=config.edges_layer,
        output_crs=config.output_crs,
        cost_field=LENGTH_FIELD,
    )
    graph = build_routing_graph(nodes, joined, routing_config)
    shortest = shortest_route(graph, origin_node, destination_node, LENGTH_FIELD)
    shortest_distance = shortest.distance_m
    maximum_distance = shortest_distance * (1 + max(config.detour_limits))
    rows: list[dict[str, Any]] = []
    route_edge_records: list[dict[str, Any]] = []
    diagnostics: dict[str, dict[str, int]] = {}
    for scenario in HEIGHT_SCENARIOS:
        burden_field = f"thermal_burden_{scenario}_deg_c_min"
        labels, destination_labels, diagnostic = _epsilon_constrained_destination_labels(
            graph,
            origin_node,
            destination_node,
            burden_field,
            maximum_distance,
        )
        diagnostics[scenario] = diagnostic
        for detour_limit in config.detour_limits:
            distance_cap = shortest_distance * (1 + detour_limit)
            label_id = _select_label_within_cap(labels, destination_labels, distance_cap)
            route_edges = _recover_route_edges(graph, labels, label_id)
            segment_ids = route_edges["segment_id"].astype(str).tolist()
            route_id = _route_id(segment_ids)
            route_length = float(route_edges[LENGTH_FIELD].sum())
            travel_time = float(route_edges["travel_time_min"].sum())
            route_row: dict[str, Any] = {
                "route_id": route_id,
                "height_scenario": scenario,
                "detour_limit_fraction": detour_limit,
                "detour_limit_percent": 100 * detour_limit,
                "route_segment_count": len(route_edges),
                "route_length_m": route_length,
                "distance_ratio_to_shortest": route_length / shortest_distance,
                "travel_time_min": travel_time,
                "selected_scenario_thermal_burden_deg_c_min": float(
                    route_edges[burden_field].sum()
                ),
                "selected_scenario_mean_utci_deg_c": float(
                    np.average(
                        route_edges[f"modeled_utci_mean_{scenario}_deg_c"],
                        weights=route_edges["travel_time_min"],
                    )
                ),
                "route_role": (
                    "shortest_distance"
                    if detour_limit == 0
                    else "minimum_utci_burden_within_detour_cap"
                ),
                "optimization_method": "exact_epsilon_constrained_pareto_label_setting",
                "subjective_thermal_component_weights_used": False,
                "geometry": MultiLineString(
                    [geometry for geometry in route_edges.geometry if not geometry.is_empty]
                ),
            }
            for evaluation_scenario in HEIGHT_SCENARIOS:
                route_row[f"thermal_burden_{evaluation_scenario}_deg_c_min"] = float(
                    route_edges[
                        f"thermal_burden_{evaluation_scenario}_deg_c_min"
                    ].sum()
                )
            rows.append(route_row)
            for edge in route_edges.itertuples(index=False):
                route_edge_records.append(
                    {
                        "route_id": route_id,
                        "height_scenario": scenario,
                        "detour_limit_fraction": detour_limit,
                        "route_sequence": int(edge.route_sequence),
                        "segment_id": str(edge.segment_id),
                    }
                )
    routes = gpd.GeoDataFrame(rows, geometry="geometry", crs=network_edges.crs)
    for scenario in HEIGHT_SCENARIOS:
        mask = routes["height_scenario"].eq(scenario)
        baseline = float(
            routes.loc[mask & routes["detour_limit_fraction"].eq(0),
                       "selected_scenario_thermal_burden_deg_c_min"].iloc[0]
        )
        if baseline > 0:
            routes.loc[mask, "thermal_burden_reduction_vs_shortest_percent"] = (
                100
                * (baseline - routes.loc[mask, "selected_scenario_thermal_burden_deg_c_min"])
                / baseline
            )
        else:
            routes.loc[mask, "thermal_burden_reduction_vs_shortest_percent"] = 0.0
    assignments = pd.DataFrame(route_edge_records)
    primary = routes.loc[routes["height_scenario"].eq(config.primary_height_scenario)]
    summary = {
        "analysis_id": config.analysis_id,
        "origin_node": origin_node,
        "destination_node": destination_node,
        "shortest_route_distance_m": round(shortest_distance, 6),
        "detour_limits": list(config.detour_limits),
        "height_scenarios": list(HEIGHT_SCENARIOS),
        "route_scenario_count": len(routes),
        "primary_height_scenario": config.primary_height_scenario,
        "primary_unique_route_count": int(primary["route_id"].nunique()),
        "optimization_method": "exact_epsilon_constrained_pareto_label_setting",
        "subjective_thermal_component_weights_used": False,
        "distance_constraint_is_user_policy_not_thermal_weight": True,
        "label_diagnostics": diagnostics,
        "validated_coolest_route_generated": False,
        "warning": (
            "Routes minimize modeled clear-sky UTCI burden within explicit distance "
            "caps. Thermal inputs are not field validated, so outputs are research "
            "scenarios rather than validated coolest-route or health recommendations."
        ),
    }
    return routes, assignments, summary


def create_thermal_route_map(
    routes: gpd.GeoDataFrame,
    endpoints: gpd.GeoDataFrame,
    primary_scenario: str,
    output_path: Path,
) -> None:
    """Create a WebGIS for central-height epsilon-constrained routes."""

    display = routes.loc[routes["height_scenario"].eq(primary_scenario)].to_crs(
        "EPSG:4326"
    )
    endpoint_display = endpoints.to_crs("EPSG:4326")
    colours = {0.0: "#dc2626", 0.05: "#f59e0b", 0.10: "#16a34a", 0.15: "#2563eb"}
    map_object = folium.Map(tiles="OpenStreetMap", control_scale=True)
    for row in display.sort_values("detour_limit_fraction", ascending=False).itertuples(
        index=False
    ):
        detour = float(row.detour_limit_fraction)
        name = "Shortest distance" if detour == 0 else f"Minimum burden, ≤{detour:.0%} detour"
        route_colour = colours.get(detour, "#6b7280")
        feature = gpd.GeoDataFrame([row._asdict()], geometry="geometry", crs=display.crs)
        folium.GeoJson(
            feature.to_json(),
            name=name,
            style_function=lambda _feature, c=route_colour: {
                "color": c,
                "weight": 6,
                "opacity": 0.85,
            },
            tooltip=folium.GeoJsonTooltip(
                fields=[
                    "route_length_m",
                    "travel_time_min",
                    "selected_scenario_mean_utci_deg_c",
                    "selected_scenario_thermal_burden_deg_c_min",
                    "thermal_burden_reduction_vs_shortest_percent",
                ]
            ),
        ).add_to(map_object)
    for row in endpoint_display.itertuples(index=False):
        folium.Marker([row.geometry.y, row.geometry.x], tooltip=row.label).add_to(map_object)
    bounds = display.total_bounds
    map_object.fit_bounds([[bounds[1], bounds[0]], [bounds[3], bounds[2]]])
    note = """
    <div style="position:fixed;left:20px;bottom:25px;z-index:9999;background:white;
      padding:10px;border:1px solid #777;font-size:12px;max-width:380px">
      <b>UTCI thermal-burden routes</b><br>
      Red: shortest; orange/green/blue: minimum modeled burden within 5/10/15% detour.<br>
      No guessed heat-component weights. Clear-sky scenario, not field validated.<br>
      <b>Not a health or validated coolest-route recommendation.</b></div>
    """
    map_object.get_root().html.add_child(folium.Element(note))
    folium.LayerControl(collapsed=False).add_to(map_object)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    map_object.save(output_path)


def build_thermal_routes(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Build epsilon-constrained UTCI route outputs and the local WebGIS."""

    config = load_thermal_route_config(config_path)
    network_path = project_root / config.network_path
    thermal_path = project_root / config.thermal.path
    od_path = project_root / config.od_summary_path
    endpoint_path = project_root / config.endpoints.path
    nodes = gpd.read_file(network_path, layer=config.nodes_layer)
    edges = gpd.read_file(network_path, layer=config.edges_layer)
    thermal = gpd.read_file(thermal_path, layer=config.thermal.layer)
    od_summary = json.loads(od_path.read_text(encoding="utf-8"))
    endpoints = gpd.read_file(endpoint_path, layer=config.endpoints.layer)
    routes, assignments, summary = compute_thermal_routes(
        nodes,
        edges,
        thermal,
        int(od_summary["origin_node"]),
        int(od_summary["destination_node"]),
        config,
    )
    summary["input_sha256"] = {
        "network": _sha256(network_path),
        "thermal": _sha256(thermal_path),
        "od_summary": _sha256(od_path),
    }
    summary["local_webgis_output"] = "app/index.html"
    processed = project_root / "data/processed/routing"
    tables = project_root / "outputs/tables"
    maps = project_root / "outputs/maps"
    processed.mkdir(parents=True, exist_ok=True)
    tables.mkdir(parents=True, exist_ok=True)
    maps.mkdir(parents=True, exist_ok=True)
    geopackage = processed / "clementi_utci_thermal_routes.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    routes.to_file(geopackage, layer="thermal_routes", driver="GPKG")
    endpoints.to_file(geopackage, layer="endpoints", driver="GPKG", mode="a")
    routes.drop(columns="geometry").to_csv(
        processed / "clementi_utci_thermal_routes.csv", index=False
    )
    assignments.to_csv(
        processed / "clementi_utci_thermal_route_segments.csv", index=False
    )
    (processed / "clementi_utci_thermal_routes_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    pd.DataFrame(
        [{key: value for key, value in summary.items() if not isinstance(value, dict)}]
    ).to_csv(tables / "clementi_utci_thermal_routes_summary.csv", index=False)
    create_thermal_route_map(
        routes,
        endpoints,
        config.primary_height_scenario,
        maps / "clementi_utci_thermal_routes.html",
    )
    create_thermal_route_map(
        routes, endpoints, config.primary_height_scenario, project_root / "app/index.html"
    )
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(
        description="Build exact epsilon-constrained UTCI thermal-burden routes."
    )
    parser.add_argument(
        "--config", type=Path, default=PROJECT_ROOT / "config/thermal_route.yaml"
    )
    args = parser.parse_args()
    # Persisted artifacts remain UTF-8; escaped CLI output also works in GBK consoles.
    print(json.dumps(build_thermal_routes(args.config), indent=2, ensure_ascii=True))


if __name__ == "__main__":
    main()
