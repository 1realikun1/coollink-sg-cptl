"""Configuration loading and validation."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

import yaml
from pyproj import CRS


@dataclass(frozen=True)
class NetworkConfig:
    """OSM pedestrian-network query options."""

    network_type: str
    simplify: bool
    retain_all: bool
    truncate_by_edge: bool


@dataclass(frozen=True)
class StudyAreaConfig:
    """Validated study-area and source metadata."""

    name: str
    display_name: str
    latitude: float
    longitude: float
    radius_m: float
    geographic_crs: str
    analysis_crs: str
    center_metadata: dict[str, Any]
    network: NetworkConfig
    source_metadata: dict[str, Any]


@dataclass(frozen=True)
class WeatherEndpointConfig:
    """Configuration for one data.gov.sg weather endpoint."""

    metric: str
    url: str
    params: dict[str, str]
    response_family: str
    source_unit: str
    standard_unit: str
    conversion: str | None
    max_age_minutes: float


@dataclass(frozen=True)
class WeatherConfig:
    """Validated weather-ingestion configuration."""

    timezone: str
    request_timeout_seconds: float
    api_key_environment_variable: str
    output_crs: str
    endpoints: tuple[WeatherEndpointConfig, ...]
    source_metadata: dict[str, Any]


@dataclass(frozen=True)
class RoadWeatherAssociationConfig:
    """Configuration for metric-separated road-to-station associations."""

    analysis_id: str
    assignment_method: str
    road_reference_point: str
    analysis_crs: str
    geographic_crs: str
    accepted_quality_flags: tuple[str, ...]
    required_metrics: tuple[str, ...]
    roads: ProcessedLayerConfig
    observations_path: str
    study_area: ProcessedLayerConfig


@dataclass(frozen=True)
class VegetationConfig:
    """Validated OSM vegetation-proxy configuration."""

    road_context_buffer_m: float
    boundary_query_margin_m: float
    analysis_crs: str
    geographic_crs: str
    output_metric_name: str
    green_area_tags: dict[str, list[str]]
    tree_tags: dict[str, list[str]]
    source_metadata: dict[str, Any]


@dataclass(frozen=True)
class BuiltEnvironmentConfig:
    """Validated OSM building and artificial-cover proxy configuration."""

    road_context_buffer_m: float
    boundary_query_margin_m: float
    analysis_crs: str
    geographic_crs: str
    accepted_covered_values: tuple[str, ...]
    building_passage_values: tuple[str, ...]
    roof_building_values: tuple[str, ...]
    shelter_values: tuple[str, ...]
    source_metadata: dict[str, Any]


@dataclass(frozen=True)
class BuildingHeightConfig:
    """Configuration for provenance-labelled building-height completion."""

    model_id: str
    height_field: str
    levels_field: str
    floor_height_quantiles: tuple[float, float, float]
    minimum_type_level_sample: int
    analysis_crs: str
    built_environment_raw_snapshot: str
    hdb3d_cityjson_path: str


@dataclass(frozen=True)
class SolarShadeConfig:
    """Configuration for height-sensitivity solar-shadow evidence."""

    model_id: str
    scenario_time_sgt: str
    timezone: str
    solar_position_method: str
    height_field: str
    use_building_levels_as_height: bool
    direct_cover_match_tolerance_m: float
    shadow_projection_method: str
    analysis_crs: str
    geographic_crs: str
    roads: ProcessedLayerConfig
    building_heights: ProcessedLayerConfig
    built_environment_raw_snapshot: str
    built_environment_config_path: str
    study_area_config_path: str
    source_weather_snapshot_id: str


@dataclass(frozen=True)
class ProcessedLayerConfig:
    """Location of one processed GeoPackage layer."""

    path: str
    layer: str


@dataclass(frozen=True)
class RoadFeatureTableConfig:
    """Validated strict-join configuration for the unified road table."""

    join_key: str
    output_crs: str
    network: ProcessedLayerConfig
    vegetation: ProcessedLayerConfig
    built_environment: ProcessedLayerConfig
    sentinel2_ndvi: ProcessedLayerConfig
    solar_shade: ProcessedLayerConfig
    vegetation_fields: tuple[str, ...]
    built_environment_fields: tuple[str, ...]
    sentinel2_ndvi_fields: tuple[str, ...]
    solar_shade_fields: tuple[str, ...]
    sentinel2_ndvi_nullable_fields: tuple[str, ...]


@dataclass(frozen=True)
class HeatComponentConfig:
    """One explicitly configured input to a transparent heat model."""

    name: str
    input_field: str
    direction: str
    weight: float | None
    reference_min: float | None
    reference_max: float | None
    proxy_candidate_field: str | None
    unavailable_reason: str


@dataclass(frozen=True)
class HeatModelConfig:
    """Heat-model configuration that may intentionally remain incomplete."""

    model_id: str
    enabled: bool
    score_min: float
    score_max: float
    missing_value_policy: str
    components: tuple[HeatComponentConfig, ...]


@dataclass(frozen=True)
class ShortestPathConfig:
    """Validated distance-only routing configuration."""

    network_path: str
    nodes_layer: str
    edges_layer: str
    output_crs: str
    cost_field: str


@dataclass(frozen=True)
class ODScenarioConfig:
    """One documented origin-destination routing scenario."""

    scenario_id: str
    origin_label: str
    origin_source: str
    destination_label: str
    destination_query: str
    geographic_crs: str
    source_metadata: dict[str, Any]


@dataclass(frozen=True)
class CoolingProxyComponentConfig:
    """One bounded mapped component in the exploratory cooling proxy."""

    name: str
    input_field: str
    interpretation: str


@dataclass(frozen=True)
class CoolingProxySensitivityConfig:
    """Configuration for a full two-component weight sensitivity sweep."""

    analysis_id: str
    input_path: str
    input_layer: str
    output_crs: str
    weight_step: float
    diagnostic_top_fraction: float
    components: tuple[CoolingProxyComponentConfig, ...]


@dataclass(frozen=True)
class RoadHeatExposureProxyConfig:
    """Configuration for a non-preferred road heat-exposure proxy sweep."""

    analysis_id: str
    output_crs: str
    weight_step: float
    diagnostic_top_fraction: float
    weather_metric: str
    weather_normalization: str
    road_features: ProcessedLayerConfig
    weather_associations_path: str
    weather_observations_path: str
    shade_field: str
    vegetation_field: str
    component_interpretations: dict[str, str]


@dataclass(frozen=True)
class RouteEnsembleConfig:
    """Configuration for distance–exposure route sensitivity analysis."""

    analysis_id: str
    output_crs: str
    tradeoff_step: float
    cost_method: str
    network_path: str
    nodes_layer: str
    edges_layer: str
    exposure: ProcessedLayerConfig
    weight_scenarios_path: str
    od_summary_path: str
    endpoints: ProcessedLayerConfig


@dataclass(frozen=True)
class UTCIThermalBurdenConfig:
    """Configuration for a radiation-driven, non-validated UTCI scenario."""

    analysis_id: str
    output_crs: str
    scenario_time_sgt: str
    timezone: str
    walking_speed_m_s: float
    heat_stress_threshold_deg_c: float
    solar_position_method: str
    clear_sky_model: str
    solar_gain_model: str
    sky_view_fraction: float
    body_exposure_fraction: float
    shortwave_absorptivity: float
    floor_reflectance: float
    posture: str
    minimum_utci_wind_speed_m_s: float
    roads: ProcessedLayerConfig
    weather_associations_path: str
    study_area_config_path: str
    shade_fields: dict[str, str]


@dataclass(frozen=True)
class ThermalRouteConfig:
    """Configuration for epsilon-constrained thermal-burden routing."""

    analysis_id: str
    output_crs: str
    detour_limits: tuple[float, ...]
    primary_height_scenario: str
    network_path: str
    nodes_layer: str
    edges_layer: str
    thermal: ProcessedLayerConfig
    od_summary_path: str
    endpoints: ProcessedLayerConfig


@dataclass(frozen=True)
class DynamicCPTLConfig:
    """Configuration for time-dependent cumulative UTCI-exceedance routing."""

    analysis_id: str
    output_crs: str
    timezone: str
    departure_times: tuple[str, ...]
    walking_speed_m_s: float
    primary_threshold_deg_c: float
    sensitivity_thresholds_deg_c: tuple[float, ...]
    detour_limits: tuple[float, ...]
    time_bin_seconds: int
    integration_method: str
    waiting_allowed: bool
    primary_height_scenario: str
    thermal_source_status: str
    is_solweig_dynamic_result: bool
    output_stem: str
    validation_series_start_sgt: str
    validation_series_end_sgt: str
    validation_series_interval_seconds: int
    network_path: str
    nodes_layer: str
    edges_layer: str
    static_thermal: ProcessedLayerConfig
    dynamic_thermal_path: str
    od_summary_path: str
    endpoints: ProcessedLayerConfig


@dataclass(frozen=True)
class MultiODThermalScenarioConfig:
    """One dynamic thermal scenario included in a multi-OD robustness run."""

    label: str
    dynamic_cptl_config_path: str


@dataclass(frozen=True)
class MultiODCPTLConfig:
    """Configuration for a reproducible network-coverage multi-OD sample."""

    analysis_id: str
    output_crs: str
    sample_type: str
    sampling_method: str
    origin_count: int
    distance_bands_m: tuple[tuple[float, float], ...]
    scenarios: tuple[MultiODThermalScenarioConfig, ...]
    output_stem: str


@dataclass(frozen=True)
class SolweigTimeseriesConfig:
    """Configuration for the phase-two SOLWEIG road thermal time series."""

    analysis_id: str
    output_crs: str
    timezone: str
    start_sgt: str
    end_sgt: str
    interval_minutes: int
    raster_resolution_m: float
    max_shadow_distance_m: float
    edge_sampling_interval_m: float
    building_height_field: str
    weather_station_id: str
    weather_snapshot_id: str
    use_anisotropic_sky: bool
    canopy_source_path: str | None
    canopy_source_nodata: float | None
    canopy_height_multiplier: float
    minimum_canopy_height_m: float
    canopy_trunk_ratio: float
    thermal_source_status: str
    buildings: ProcessedLayerConfig
    network: ProcessedLayerConfig
    weather_observations_path: str
    study_area_config_path: str
    dsm_path: str
    canopy_dsm_path: str | None
    solweig_output_directory: str
    road_timeseries_path: str
    weather_timeseries_path: str
    readiness_path: str


@dataclass(frozen=True)
class InterventionScreeningConfig:
    """Configuration for non-validated shade-intervention candidate screening."""

    analysis_id: str
    output_crs: str
    ranking_method: str
    diagnostic_top_fraction: float
    exposure: ProcessedLayerConfig
    screening_field: str
    sensitivity_field: str
    scenario_frequency_field: str


@dataclass(frozen=True)
class SentinelNDVIConfig:
    """Validated Sentinel-2 L2A NDVI acquisition and aggregation settings."""

    stac_url: str
    collection: str
    datetime_range: str
    max_items: int
    asset_red: str
    asset_nir: str
    asset_scl: str
    valid_scl_classes: tuple[int, ...]
    road_context_buffer_m: float
    geographic_crs: str
    output_crs: str
    source_metadata: dict[str, Any]


@dataclass(frozen=True)
class SentinelCompositeConfig:
    """Configuration for a fixed-count multi-date Sentinel-2 NDVI composite."""

    source_stac_snapshot: str
    scene_count: int
    selection_rule: str
    composite_statistic: str
    asset_red: str
    asset_nir: str
    asset_scl: str
    valid_scl_classes: tuple[int, ...]
    road_context_buffer_m: float
    geographic_crs: str
    output_crs: str
    source_metadata: dict[str, Any]


@dataclass(frozen=True)
class NDVIOSMConsistencyConfig:
    """Configuration for NDVI versus mapped OSM green-context diagnostics."""

    analysis_id: str
    input_path: str
    input_layer: str
    output_crs: str
    missing_value_policy: str
    ndvi_field: str
    ndvi_valid_fraction_field: str
    osm_green_proxy_field: str


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    try:
        return mapping[key]
    except KeyError as exc:
        raise ValueError(f"Missing required field '{section}.{key}'") from exc


def load_study_area_config(path: str | Path) -> StudyAreaConfig:
    """Load and validate a study-area YAML file."""

    config_path = Path(path)
    payload = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Study-area configuration must be a YAML mapping")

    area = _required(payload, "study_area", "root")
    network = _required(payload, "network", "root")
    source = _required(payload, "source", "root")
    center = _required(area, "center", "study_area")

    latitude = float(_required(center, "latitude", "study_area.center"))
    longitude = float(_required(center, "longitude", "study_area.center"))
    radius_m = float(_required(area, "radius_m", "study_area"))
    geographic_crs = str(_required(area, "geographic_crs", "study_area"))
    analysis_crs = str(_required(area, "analysis_crs", "study_area"))

    if not -90 <= latitude <= 90:
        raise ValueError("Study-area latitude must be between -90 and 90")
    if not -180 <= longitude <= 180:
        raise ValueError("Study-area longitude must be between -180 and 180")
    if radius_m <= 0:
        raise ValueError("Study-area radius_m must be positive")

    geographic = CRS.from_user_input(geographic_crs)
    analysis = CRS.from_user_input(analysis_crs)
    if not geographic.is_geographic:
        raise ValueError("geographic_crs must be geographic")
    if not analysis.is_projected:
        raise ValueError("analysis_crs must be projected for metric analysis")

    network_type = str(_required(network, "network_type", "network"))
    if network_type != "walk":
        raise ValueError("The MVP network_type must be 'walk'")

    return StudyAreaConfig(
        name=str(_required(area, "name", "study_area")),
        display_name=str(_required(area, "display_name", "study_area")),
        latitude=latitude,
        longitude=longitude,
        radius_m=radius_m,
        geographic_crs=geographic_crs,
        analysis_crs=analysis_crs,
        center_metadata=dict(center),
        network=NetworkConfig(
            network_type=network_type,
            simplify=bool(_required(network, "simplify", "network")),
            retain_all=bool(_required(network, "retain_all", "network")),
            truncate_by_edge=bool(_required(network, "truncate_by_edge", "network")),
        ),
        source_metadata=dict(source),
    )


def load_weather_config(path: str | Path) -> WeatherConfig:
    """Load and validate weather endpoint configuration."""

    config_path = Path(path)
    payload = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Weather configuration must be a YAML mapping")

    weather = _required(payload, "weather", "root")
    endpoints_payload = _required(payload, "endpoints", "root")
    source = _required(payload, "source", "root")
    if not isinstance(endpoints_payload, dict) or not endpoints_payload:
        raise ValueError("Weather configuration must define at least one endpoint")

    endpoints: list[WeatherEndpointConfig] = []
    valid_families = {"station_readings", "wbgt_records"}
    valid_conversions = {None, "knots_to_mps"}
    for metric, endpoint in endpoints_payload.items():
        family = str(_required(endpoint, "response_family", f"endpoints.{metric}"))
        conversion = endpoint.get("conversion")
        max_age_minutes = float(_required(endpoint, "max_age_minutes", f"endpoints.{metric}"))
        if family not in valid_families:
            raise ValueError(f"Unsupported response_family for {metric}: {family}")
        if conversion not in valid_conversions:
            raise ValueError(f"Unsupported conversion for {metric}: {conversion}")
        if max_age_minutes <= 0:
            raise ValueError(f"max_age_minutes must be positive for {metric}")

        url = str(_required(endpoint, "url", f"endpoints.{metric}"))
        if not url.startswith("https://"):
            raise ValueError(f"Weather endpoint URL must use HTTPS: {metric}")
        endpoints.append(
            WeatherEndpointConfig(
                metric=str(metric),
                url=url,
                params={str(k): str(v) for k, v in endpoint.get("params", {}).items()},
                response_family=family,
                source_unit=str(_required(endpoint, "source_unit", f"endpoints.{metric}")),
                standard_unit=str(_required(endpoint, "standard_unit", f"endpoints.{metric}")),
                conversion=str(conversion) if conversion is not None else None,
                max_age_minutes=max_age_minutes,
            )
        )

    timeout = float(_required(weather, "request_timeout_seconds", "weather"))
    if timeout <= 0:
        raise ValueError("request_timeout_seconds must be positive")
    output_crs = str(_required(weather, "output_crs", "weather"))
    if not CRS.from_user_input(output_crs).is_geographic:
        raise ValueError("weather.output_crs must be a geographic CRS")

    return WeatherConfig(
        timezone=str(_required(weather, "timezone", "weather")),
        request_timeout_seconds=timeout,
        api_key_environment_variable=str(
            _required(
                weather,
                "optional_api_key_environment_variable",
                "weather",
            )
        ),
        output_crs=output_crs,
        endpoints=tuple(endpoints),
        source_metadata=dict(source),
    )


def load_road_weather_association_config(
    path: str | Path,
) -> RoadWeatherAssociationConfig:
    """Load metric-separated nearest-station association settings."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Road-weather association config must be a YAML mapping")
    association = _required(payload, "road_weather_association", "root")
    inputs = _required(payload, "inputs", "root")
    method = str(_required(association, "assignment_method", "road_weather_association"))
    if method != "nearest_nonmissing_station_by_metric":
        raise ValueError("Unsupported road-weather assignment method")
    reference_point = str(
        _required(association, "road_reference_point", "road_weather_association")
    )
    if reference_point != "geometry_midpoint":
        raise ValueError("Only geometry_midpoint road reference is supported")
    analysis_crs = str(_required(association, "analysis_crs", "road_weather_association"))
    geographic_crs = str(_required(association, "geographic_crs", "road_weather_association"))
    if not CRS.from_user_input(analysis_crs).is_projected:
        raise ValueError("road_weather_association.analysis_crs must be projected")
    if not CRS.from_user_input(geographic_crs).is_geographic:
        raise ValueError("road_weather_association.geographic_crs must be geographic")
    quality_raw = _required(association, "accepted_quality_flags", "road_weather_association")
    metrics_raw = _required(association, "required_metrics", "road_weather_association")
    if not isinstance(quality_raw, list) or not quality_raw:
        raise ValueError("accepted_quality_flags must be a non-empty list")
    if not isinstance(metrics_raw, list) or not metrics_raw:
        raise ValueError("required_metrics must be a non-empty list")
    qualities = tuple(str(value) for value in quality_raw)
    metrics = tuple(str(value) for value in metrics_raw)
    if len(qualities) != len(set(qualities)) or len(metrics) != len(set(metrics)):
        raise ValueError("Quality flags and required metrics must be unique")

    def layer(name: str) -> ProcessedLayerConfig:
        source = _required(inputs, name, "inputs")
        return ProcessedLayerConfig(
            path=str(_required(source, "path", f"inputs.{name}")),
            layer=str(_required(source, "layer", f"inputs.{name}")),
        )

    observations = _required(inputs, "observations", "inputs")
    return RoadWeatherAssociationConfig(
        analysis_id=str(_required(association, "analysis_id", "road_weather_association")),
        assignment_method=method,
        road_reference_point=reference_point,
        analysis_crs=analysis_crs,
        geographic_crs=geographic_crs,
        accepted_quality_flags=qualities,
        required_metrics=metrics,
        roads=layer("roads"),
        observations_path=str(_required(observations, "path", "inputs.observations")),
        study_area=layer("study_area"),
    )


def load_vegetation_config(path: str | Path) -> VegetationConfig:
    """Load and validate the vegetation-proxy configuration."""

    config_path = Path(path)
    payload = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Vegetation configuration must be a YAML mapping")

    vegetation = _required(payload, "vegetation", "root")
    green_area_tags = _required(payload, "green_area_tags", "root")
    tree_tags = _required(payload, "tree_tags", "root")
    source = _required(payload, "source", "root")

    road_buffer = float(_required(vegetation, "road_context_buffer_m", "vegetation"))
    query_margin = float(_required(vegetation, "boundary_query_margin_m", "vegetation"))
    if road_buffer <= 0:
        raise ValueError("road_context_buffer_m must be positive")
    if query_margin < road_buffer:
        raise ValueError("boundary_query_margin_m must be at least road_context_buffer_m")

    analysis_crs = str(_required(vegetation, "analysis_crs", "vegetation"))
    geographic_crs = str(_required(vegetation, "geographic_crs", "vegetation"))
    if not CRS.from_user_input(analysis_crs).is_projected:
        raise ValueError("vegetation.analysis_crs must be projected")
    if not CRS.from_user_input(geographic_crs).is_geographic:
        raise ValueError("vegetation.geographic_crs must be geographic")

    def normalize_tags(tags: Any, section: str) -> dict[str, list[str]]:
        if not isinstance(tags, dict) or not tags:
            raise ValueError(f"{section} must contain OSM tag mappings")
        normalized: dict[str, list[str]] = {}
        for key, values in tags.items():
            if not isinstance(values, list) or not values:
                raise ValueError(f"{section}.{key} must be a non-empty list")
            normalized[str(key)] = [str(value) for value in values]
        return normalized

    return VegetationConfig(
        road_context_buffer_m=road_buffer,
        boundary_query_margin_m=query_margin,
        analysis_crs=analysis_crs,
        geographic_crs=geographic_crs,
        output_metric_name=str(_required(vegetation, "output_metric_name", "vegetation")),
        green_area_tags=normalize_tags(green_area_tags, "green_area_tags"),
        tree_tags=normalize_tags(tree_tags, "tree_tags"),
        source_metadata=dict(source),
    )


def load_built_environment_config(path: str | Path) -> BuiltEnvironmentConfig:
    """Load and validate building and artificial-cover proxy configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Built-environment configuration must be a YAML mapping")

    built = _required(payload, "built_environment", "root")
    classification = _required(payload, "classification", "root")
    source = _required(payload, "source", "root")
    road_buffer = float(_required(built, "road_context_buffer_m", "built_environment"))
    query_margin = float(_required(built, "boundary_query_margin_m", "built_environment"))
    if road_buffer <= 0:
        raise ValueError("road_context_buffer_m must be positive")
    if query_margin < road_buffer:
        raise ValueError("boundary_query_margin_m must be at least road_context_buffer_m")

    analysis_crs = str(_required(built, "analysis_crs", "built_environment"))
    geographic_crs = str(_required(built, "geographic_crs", "built_environment"))
    if not CRS.from_user_input(analysis_crs).is_projected:
        raise ValueError("built_environment.analysis_crs must be projected")
    if not CRS.from_user_input(geographic_crs).is_geographic:
        raise ValueError("built_environment.geographic_crs must be geographic")

    def values(key: str) -> tuple[str, ...]:
        raw = _required(classification, key, "classification")
        if not isinstance(raw, list) or not raw:
            raise ValueError(f"classification.{key} must be a non-empty list")
        return tuple(str(value) for value in raw)

    return BuiltEnvironmentConfig(
        road_context_buffer_m=road_buffer,
        boundary_query_margin_m=query_margin,
        analysis_crs=analysis_crs,
        geographic_crs=geographic_crs,
        accepted_covered_values=values("accepted_covered_values"),
        building_passage_values=values("building_passage_values"),
        roof_building_values=values("roof_building_values"),
        shelter_values=values("shelter_values"),
        source_metadata=dict(source),
    )


def load_building_height_config(path: str | Path) -> BuildingHeightConfig:
    """Load transparent data-derived building-height completion settings."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Building-height configuration must be a YAML mapping")
    model = _required(payload, "building_height", "root")
    inputs = _required(payload, "inputs", "root")
    quantiles_raw = _required(model, "floor_height_quantiles", "building_height")
    if not isinstance(quantiles_raw, list) or len(quantiles_raw) != 3:
        raise ValueError("floor_height_quantiles must contain low, central, high")
    quantiles = tuple(float(value) for value in quantiles_raw)
    if not (0 <= quantiles[0] < quantiles[1] < quantiles[2] <= 1):
        raise ValueError("floor_height_quantiles must be increasing within 0–1")
    minimum_type_sample = int(_required(model, "minimum_type_level_sample", "building_height"))
    if minimum_type_sample < 2:
        raise ValueError("minimum_type_level_sample must be at least two")
    analysis_crs = str(_required(model, "analysis_crs", "building_height"))
    if not CRS.from_user_input(analysis_crs).is_projected:
        raise ValueError("building_height.analysis_crs must be projected")
    return BuildingHeightConfig(
        model_id=str(_required(model, "model_id", "building_height")),
        height_field=str(_required(model, "height_field", "building_height")),
        levels_field=str(_required(model, "levels_field", "building_height")),
        floor_height_quantiles=quantiles,
        minimum_type_level_sample=minimum_type_sample,
        analysis_crs=analysis_crs,
        built_environment_raw_snapshot=str(
            _required(inputs, "built_environment_raw_snapshot", "inputs")
        ),
        hdb3d_cityjson_path=str(_required(inputs, "hdb3d_cityjson", "inputs")),
    )


def load_solar_shade_config(path: str | Path) -> SolarShadeConfig:
    """Load a conservative partial solar-shadow scenario configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Solar-shade configuration must be a YAML mapping")
    shade = _required(payload, "solar_shade", "root")
    inputs = _required(payload, "inputs", "root")
    timezone = str(_required(shade, "timezone", "solar_shade"))
    try:
        zone = ZoneInfo(timezone)
    except Exception as exc:
        raise ValueError(f"Unknown solar_shade.timezone: {timezone}") from exc
    scenario_text = str(_required(shade, "scenario_time_sgt", "solar_shade"))
    try:
        scenario = datetime.fromisoformat(scenario_text)
    except ValueError as exc:
        raise ValueError("scenario_time_sgt must be ISO 8601") from exc
    if scenario.tzinfo is None or scenario.utcoffset() is None:
        raise ValueError("scenario_time_sgt must include a UTC offset")
    if scenario.astimezone(zone).utcoffset() != scenario.utcoffset():
        raise ValueError("scenario_time_sgt offset does not match configured timezone")
    analysis_crs = str(_required(shade, "analysis_crs", "solar_shade"))
    geographic_crs = str(_required(shade, "geographic_crs", "solar_shade"))
    if not CRS.from_user_input(analysis_crs).is_projected:
        raise ValueError("solar_shade.analysis_crs must be projected")
    if not CRS.from_user_input(geographic_crs).is_geographic:
        raise ValueError("solar_shade.geographic_crs must be geographic")
    method = str(_required(shade, "solar_position_method", "solar_shade"))
    if method != "noaa_fractional_year_approximation":
        raise ValueError("Unsupported solar_position_method")
    use_levels = bool(_required(shade, "use_building_levels_as_height", "solar_shade"))
    if use_levels:
        raise ValueError("Building-level height conversion is intentionally unsupported")
    tolerance = float(_required(shade, "direct_cover_match_tolerance_m", "solar_shade"))
    if tolerance < 0:
        raise ValueError("direct_cover_match_tolerance_m cannot be negative")
    projection_method = str(_required(shade, "shadow_projection_method", "solar_shade"))
    if projection_method != "polygon_boundary_vector_sweep":
        raise ValueError("Unsupported shadow_projection_method")
    roads = _required(inputs, "roads", "inputs")
    building_heights = _required(inputs, "building_heights", "inputs")
    return SolarShadeConfig(
        model_id=str(_required(shade, "model_id", "solar_shade")),
        scenario_time_sgt=scenario_text,
        timezone=timezone,
        solar_position_method=method,
        height_field=str(_required(shade, "height_field", "solar_shade")),
        use_building_levels_as_height=use_levels,
        direct_cover_match_tolerance_m=tolerance,
        shadow_projection_method=projection_method,
        analysis_crs=analysis_crs,
        geographic_crs=geographic_crs,
        roads=ProcessedLayerConfig(
            path=str(_required(roads, "path", "inputs.roads")),
            layer=str(_required(roads, "layer", "inputs.roads")),
        ),
        building_heights=ProcessedLayerConfig(
            path=str(_required(building_heights, "path", "inputs.building_heights")),
            layer=str(_required(building_heights, "layer", "inputs.building_heights")),
        ),
        built_environment_raw_snapshot=str(
            _required(inputs, "built_environment_raw_snapshot", "inputs")
        ),
        built_environment_config_path=str(_required(inputs, "built_environment_config", "inputs")),
        study_area_config_path=str(_required(inputs, "study_area_config", "inputs")),
        source_weather_snapshot_id=str(
            _required(shade, "source_weather_snapshot_id", "solar_shade")
        ),
    )


def load_road_feature_table_config(path: str | Path) -> RoadFeatureTableConfig:
    """Load and validate the unified road-feature table configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Road-feature configuration must be a YAML mapping")
    table = _required(payload, "road_feature_table", "root")
    sources = _required(payload, "sources", "root")
    fields = _required(payload, "feature_fields", "root")
    nullable_fields = _required(payload, "nullable_fields", "root")
    output_crs = str(_required(table, "output_crs", "road_feature_table"))
    if not CRS.from_user_input(output_crs).is_projected:
        raise ValueError("road_feature_table.output_crs must be projected")

    def layer(name: str) -> ProcessedLayerConfig:
        source = _required(sources, name, "sources")
        return ProcessedLayerConfig(
            path=str(_required(source, "path", f"sources.{name}")),
            layer=str(_required(source, "layer", f"sources.{name}")),
        )

    def field_list(name: str) -> tuple[str, ...]:
        raw = _required(fields, name, "feature_fields")
        if not isinstance(raw, list) or not raw:
            raise ValueError(f"feature_fields.{name} must be a non-empty list")
        values = tuple(str(value) for value in raw)
        if len(values) != len(set(values)):
            raise ValueError(f"feature_fields.{name} contains duplicates")
        return values

    sentinel_fields = field_list("sentinel2_ndvi")
    nullable_raw = _required(nullable_fields, "sentinel2_ndvi", "nullable_fields")
    if not isinstance(nullable_raw, list):
        raise ValueError("nullable_fields.sentinel2_ndvi must be a list")
    sentinel_nullable = tuple(str(value) for value in nullable_raw)
    if len(sentinel_nullable) != len(set(sentinel_nullable)):
        raise ValueError("nullable_fields.sentinel2_ndvi contains duplicates")
    if not set(sentinel_nullable).issubset(sentinel_fields):
        raise ValueError("nullable_fields.sentinel2_ndvi must be a subset of its feature fields")

    return RoadFeatureTableConfig(
        join_key=str(_required(table, "join_key", "road_feature_table")),
        output_crs=output_crs,
        network=layer("network"),
        vegetation=layer("vegetation"),
        built_environment=layer("built_environment"),
        sentinel2_ndvi=layer("sentinel2_ndvi"),
        solar_shade=layer("solar_shade"),
        vegetation_fields=field_list("vegetation"),
        built_environment_fields=field_list("built_environment"),
        sentinel2_ndvi_fields=sentinel_fields,
        solar_shade_fields=field_list("solar_shade"),
        sentinel2_ndvi_nullable_fields=sentinel_nullable,
    )


def load_heat_model_config(path: str | Path) -> HeatModelConfig:
    """Load a heat model without inventing missing weights or reference bounds."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Heat-model configuration must be a YAML mapping")
    model = _required(payload, "heat_model", "root")
    components_payload = _required(payload, "components", "root")
    if not isinstance(components_payload, list) or not components_payload:
        raise ValueError("components must be a non-empty list")

    score_range = _required(model, "score_range", "heat_model")
    if not isinstance(score_range, list) or len(score_range) != 2:
        raise ValueError("heat_model.score_range must contain two values")
    score_min, score_max = (float(value) for value in score_range)
    if score_min >= score_max:
        raise ValueError("heat_model.score_range must be increasing")
    missing_policy = str(_required(model, "missing_value_policy", "heat_model"))
    if missing_policy != "reject":
        raise ValueError("Only missing_value_policy: reject is supported")

    components: list[HeatComponentConfig] = []
    valid_directions = {"higher_is_hotter", "higher_is_cooler"}
    for index, component in enumerate(components_payload):
        section = f"components[{index}]"
        direction = str(_required(component, "direction", section))
        if direction not in valid_directions:
            raise ValueError(f"Unsupported direction in {section}: {direction}")

        def optional_float(key: str, source: dict[str, Any] = component) -> float | None:
            value = source.get(key)
            return None if value is None else float(value)

        components.append(
            HeatComponentConfig(
                name=str(_required(component, "name", section)),
                input_field=str(_required(component, "input_field", section)),
                direction=direction,
                weight=optional_float("weight"),
                reference_min=optional_float("reference_min"),
                reference_max=optional_float("reference_max"),
                proxy_candidate_field=(
                    str(component["proxy_candidate_field"])
                    if component.get("proxy_candidate_field") is not None
                    else None
                ),
                unavailable_reason=str(_required(component, "unavailable_reason", section)),
            )
        )
    names = [component.name for component in components]
    if len(names) != len(set(names)):
        raise ValueError("Heat component names must be unique")

    return HeatModelConfig(
        model_id=str(_required(model, "model_id", "heat_model")),
        enabled=bool(_required(model, "enabled", "heat_model")),
        score_min=score_min,
        score_max=score_max,
        missing_value_policy=missing_policy,
        components=tuple(components),
    )


def load_shortest_path_config(path: str | Path) -> ShortestPathConfig:
    """Load and validate the shortest-distance routing configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Shortest-path configuration must be a YAML mapping")
    routing = _required(payload, "shortest_path", "root")
    output_crs = str(_required(routing, "output_crs", "shortest_path"))
    if not CRS.from_user_input(output_crs).is_projected:
        raise ValueError("shortest_path.output_crs must be projected")
    cost_field = str(_required(routing, "cost_field", "shortest_path"))
    if cost_field != "length_m":
        raise ValueError("The baseline shortest-path cost_field must be length_m")
    return ShortestPathConfig(
        network_path=str(_required(routing, "network_path", "shortest_path")),
        nodes_layer=str(_required(routing, "nodes_layer", "shortest_path")),
        edges_layer=str(_required(routing, "edges_layer", "shortest_path")),
        output_crs=output_crs,
        cost_field=cost_field,
    )


def load_od_scenario_config(path: str | Path) -> ODScenarioConfig:
    """Load and validate an explicit origin-destination scenario."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("OD-scenario configuration must be a YAML mapping")
    scenario = _required(payload, "scenario", "root")
    origin = _required(scenario, "origin", "scenario")
    destination = _required(scenario, "destination", "scenario")
    source = _required(payload, "source", "root")
    origin_source = str(_required(origin, "source", "scenario.origin"))
    if origin_source != "study_area_center":
        raise ValueError("The current OD origin source must be study_area_center")
    geographic_crs = str(_required(scenario, "geographic_crs", "scenario"))
    if not CRS.from_user_input(geographic_crs).is_geographic:
        raise ValueError("scenario.geographic_crs must be geographic")
    query = str(_required(destination, "nominatim_query", "scenario.destination"))
    if not query.strip():
        raise ValueError("scenario.destination.nominatim_query cannot be empty")
    return ODScenarioConfig(
        scenario_id=str(_required(scenario, "id", "scenario")),
        origin_label=str(_required(origin, "label", "scenario.origin")),
        origin_source=origin_source,
        destination_label=str(_required(destination, "label", "scenario.destination")),
        destination_query=query,
        geographic_crs=geographic_crs,
        source_metadata=dict(source),
    )


def load_cooling_proxy_sensitivity_config(
    path: str | Path,
) -> CoolingProxySensitivityConfig:
    """Load the exploratory proxy sweep without selecting a preferred weight."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Cooling-proxy configuration must be a YAML mapping")
    analysis = _required(payload, "cooling_proxy_sensitivity", "root")
    source = _required(payload, "input", "root")
    components_payload = _required(payload, "components", "root")
    if not isinstance(components_payload, list) or len(components_payload) != 2:
        raise ValueError("Cooling-proxy sensitivity currently requires two components")
    output_crs = str(_required(analysis, "output_crs", "cooling_proxy_sensitivity"))
    if not CRS.from_user_input(output_crs).is_projected:
        raise ValueError("cooling_proxy_sensitivity.output_crs must be projected")
    weight_step = float(_required(analysis, "weight_step", "cooling_proxy_sensitivity"))
    if not 0 < weight_step <= 1:
        raise ValueError("weight_step must be in (0, 1]")
    reciprocal = 1 / weight_step
    if abs(reciprocal - round(reciprocal)) > 1e-9:
        raise ValueError("weight_step must divide the interval 0–1 exactly")
    top_fraction = float(
        _required(
            analysis,
            "diagnostic_top_fraction",
            "cooling_proxy_sensitivity",
        )
    )
    if not 0 < top_fraction < 1:
        raise ValueError("diagnostic_top_fraction must be in (0, 1)")
    components = tuple(
        CoolingProxyComponentConfig(
            name=str(_required(component, "name", "components")),
            input_field=str(_required(component, "input_field", "components")),
            interpretation=str(_required(component, "interpretation", "components")),
        )
        for component in components_payload
    )
    names = [component.name for component in components]
    fields = [component.input_field for component in components]
    if len(set(names)) != 2 or len(set(fields)) != 2:
        raise ValueError("Cooling-proxy component names and input fields must be unique")
    return CoolingProxySensitivityConfig(
        analysis_id=str(_required(analysis, "analysis_id", "cooling_proxy_sensitivity")),
        input_path=str(_required(source, "path", "input")),
        input_layer=str(_required(source, "layer", "input")),
        output_crs=output_crs,
        weight_step=weight_step,
        diagnostic_top_fraction=top_fraction,
        components=components,
    )


def load_road_heat_exposure_proxy_config(
    path: str | Path,
) -> RoadHeatExposureProxyConfig:
    """Load an exploratory three-component exposure-proxy sweep."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Road heat-exposure proxy config must be a YAML mapping")
    analysis = _required(payload, "road_heat_exposure_proxy", "root")
    inputs = _required(payload, "inputs", "root")
    fields = _required(payload, "fields", "root")
    interpretations = _required(payload, "component_interpretations", "root")
    if not isinstance(interpretations, dict) or set(interpretations) != {
        "wbgt_station_context",
        "shade_deficit",
        "vegetation_context_deficit",
    }:
        raise ValueError("Exactly three documented proxy component interpretations are required")
    output_crs = str(_required(analysis, "output_crs", "road_heat_exposure_proxy"))
    if not CRS.from_user_input(output_crs).is_projected:
        raise ValueError("road_heat_exposure_proxy.output_crs must be projected")
    weight_step = float(_required(analysis, "weight_step", "road_heat_exposure_proxy"))
    if not 0 < weight_step <= 1:
        raise ValueError("weight_step must be in (0, 1]")
    reciprocal = 1 / weight_step
    if abs(reciprocal - round(reciprocal)) > 1e-9:
        raise ValueError("weight_step must divide the interval 0–1 exactly")
    top_fraction = float(_required(analysis, "diagnostic_top_fraction", "road_heat_exposure_proxy"))
    if not 0 < top_fraction < 1:
        raise ValueError("diagnostic_top_fraction must be in (0, 1)")
    weather_metric = str(_required(analysis, "weather_metric", "road_heat_exposure_proxy"))
    if weather_metric != "wbgt":
        raise ValueError("The exploratory exposure proxy currently requires WBGT context")
    normalization = str(_required(analysis, "weather_normalization", "road_heat_exposure_proxy"))
    if normalization != "valid_national_snapshot_minmax":
        raise ValueError("Unsupported weather_normalization")
    roads = _required(inputs, "road_features", "inputs")
    shade_field = str(_required(fields, "shade", "fields"))
    vegetation_field = str(_required(fields, "vegetation", "fields"))
    if shade_field == vegetation_field:
        raise ValueError("Shade and vegetation fields must differ")
    return RoadHeatExposureProxyConfig(
        analysis_id=str(_required(analysis, "analysis_id", "road_heat_exposure_proxy")),
        output_crs=output_crs,
        weight_step=weight_step,
        diagnostic_top_fraction=top_fraction,
        weather_metric=weather_metric,
        weather_normalization=normalization,
        road_features=ProcessedLayerConfig(
            path=str(_required(roads, "path", "inputs.road_features")),
            layer=str(_required(roads, "layer", "inputs.road_features")),
        ),
        weather_associations_path=str(_required(inputs, "weather_associations", "inputs")),
        weather_observations_path=str(_required(inputs, "weather_observations", "inputs")),
        shade_field=shade_field,
        vegetation_field=vegetation_field,
        component_interpretations={str(k): str(v) for k, v in interpretations.items()},
    )


def load_route_ensemble_config(path: str | Path) -> RouteEnsembleConfig:
    """Load a complete non-preferred route sensitivity configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Route-ensemble configuration must be a YAML mapping")
    analysis = _required(payload, "route_ensemble", "root")
    inputs = _required(payload, "inputs", "root")
    output_crs = str(_required(analysis, "output_crs", "route_ensemble"))
    if not CRS.from_user_input(output_crs).is_projected:
        raise ValueError("route_ensemble.output_crs must be projected")
    tradeoff_step = float(_required(analysis, "tradeoff_step", "route_ensemble"))
    if not 0 < tradeoff_step <= 1:
        raise ValueError("tradeoff_step must be in (0, 1]")
    reciprocal = 1 / tradeoff_step
    if abs(reciprocal - round(reciprocal)) > 1e-9:
        raise ValueError("tradeoff_step must divide the interval 0–1 exactly")
    cost_method = str(_required(analysis, "cost_method", "route_ensemble"))
    if cost_method != "length_times_convex_distance_exposure_proxy":
        raise ValueError("Unsupported route ensemble cost_method")
    network = _required(inputs, "network", "inputs")
    exposure = _required(inputs, "exposure", "inputs")
    endpoints = _required(inputs, "endpoints", "inputs")
    return RouteEnsembleConfig(
        analysis_id=str(_required(analysis, "analysis_id", "route_ensemble")),
        output_crs=output_crs,
        tradeoff_step=tradeoff_step,
        cost_method=cost_method,
        network_path=str(_required(network, "path", "inputs.network")),
        nodes_layer=str(_required(network, "nodes_layer", "inputs.network")),
        edges_layer=str(_required(network, "edges_layer", "inputs.network")),
        exposure=ProcessedLayerConfig(
            path=str(_required(exposure, "path", "inputs.exposure")),
            layer=str(_required(exposure, "layer", "inputs.exposure")),
        ),
        weight_scenarios_path=str(_required(inputs, "weight_scenarios", "inputs")),
        od_summary_path=str(_required(inputs, "od_summary", "inputs")),
        endpoints=ProcessedLayerConfig(
            path=str(_required(endpoints, "path", "inputs.endpoints")),
            layer=str(_required(endpoints, "layer", "inputs.endpoints")),
        ),
    )


def load_utci_thermal_burden_config(
    path: str | Path,
) -> UTCIThermalBurdenConfig:
    """Load a literature-grounded, radiation-driven UTCI scenario."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("UTCI thermal-burden configuration must be a YAML mapping")
    model = _required(payload, "utci_thermal_burden", "root")
    inputs = _required(payload, "inputs", "root")
    fields = _required(payload, "shade_fields", "root")
    output_crs = str(_required(model, "output_crs", "utci_thermal_burden"))
    if not CRS.from_user_input(output_crs).is_projected:
        raise ValueError("utci_thermal_burden.output_crs must be projected")
    timezone = str(_required(model, "timezone", "utci_thermal_burden"))
    try:
        zone = ZoneInfo(timezone)
    except Exception as exc:
        raise ValueError(f"Unknown utci_thermal_burden.timezone: {timezone}") from exc
    scenario_text = str(_required(model, "scenario_time_sgt", "utci_thermal_burden"))
    try:
        scenario = datetime.fromisoformat(scenario_text)
    except ValueError as exc:
        raise ValueError("scenario_time_sgt must be ISO 8601") from exc
    if scenario.tzinfo is None or scenario.utcoffset() is None:
        raise ValueError("scenario_time_sgt must include a UTC offset")
    if scenario.astimezone(zone).utcoffset() != scenario.utcoffset():
        raise ValueError("scenario_time_sgt offset does not match configured timezone")
    walking_speed = float(_required(model, "walking_speed_m_s", "utci_thermal_burden"))
    if walking_speed <= 0:
        raise ValueError("walking_speed_m_s must be positive")
    threshold = float(_required(model, "heat_stress_threshold_deg_c", "utci_thermal_burden"))
    if threshold != 26.0:
        raise ValueError("The UTCI moderate-heat threshold must be 26 degC")
    solar_position_method = str(_required(model, "solar_position_method", "utci_thermal_burden"))
    if solar_position_method != "pvlib_nrel_spa":
        raise ValueError("Unsupported UTCI solar_position_method")
    clear_sky_model = str(_required(model, "clear_sky_model", "utci_thermal_burden"))
    if clear_sky_model != "pvlib_ineichen":
        raise ValueError("Unsupported UTCI clear_sky_model")
    solar_gain_model = str(_required(model, "solar_gain_model", "utci_thermal_burden"))
    if solar_gain_model != "ashrae_55_erf":
        raise ValueError("Unsupported UTCI solar_gain_model")
    bounded_fields = {
        "sky_view_fraction": float(_required(model, "sky_view_fraction", "utci_thermal_burden")),
        "body_exposure_fraction": float(
            _required(model, "body_exposure_fraction", "utci_thermal_burden")
        ),
        "shortwave_absorptivity": float(
            _required(model, "shortwave_absorptivity", "utci_thermal_burden")
        ),
        "floor_reflectance": float(_required(model, "floor_reflectance", "utci_thermal_burden")),
    }
    if any(not 0 <= value <= 1 for value in bounded_fields.values()):
        raise ValueError("Radiative fractions must be between zero and one")
    posture = str(_required(model, "posture", "utci_thermal_burden"))
    if posture != "standing":
        raise ValueError("The pedestrian UTCI scenario requires standing posture")
    wind_floor = float(_required(model, "minimum_utci_wind_speed_m_s", "utci_thermal_burden"))
    if wind_floor != 0.5:
        raise ValueError("UTCI operational lower wind bound must be 0.5 m/s")
    if not isinstance(fields, dict) or set(fields) != {"low", "central", "high"}:
        raise ValueError("shade_fields must define low, central, and high scenarios")
    road_source = _required(inputs, "roads", "inputs")
    return UTCIThermalBurdenConfig(
        analysis_id=str(_required(model, "analysis_id", "utci_thermal_burden")),
        output_crs=output_crs,
        scenario_time_sgt=scenario_text,
        timezone=timezone,
        walking_speed_m_s=walking_speed,
        heat_stress_threshold_deg_c=threshold,
        solar_position_method=solar_position_method,
        clear_sky_model=clear_sky_model,
        solar_gain_model=solar_gain_model,
        sky_view_fraction=bounded_fields["sky_view_fraction"],
        body_exposure_fraction=bounded_fields["body_exposure_fraction"],
        shortwave_absorptivity=bounded_fields["shortwave_absorptivity"],
        floor_reflectance=bounded_fields["floor_reflectance"],
        posture=posture,
        minimum_utci_wind_speed_m_s=wind_floor,
        roads=ProcessedLayerConfig(
            path=str(_required(road_source, "path", "inputs.roads")),
            layer=str(_required(road_source, "layer", "inputs.roads")),
        ),
        weather_associations_path=str(_required(inputs, "weather_associations", "inputs")),
        study_area_config_path=str(_required(inputs, "study_area_config", "inputs")),
        shade_fields={str(key): str(value) for key, value in fields.items()},
    )


def load_thermal_route_config(path: str | Path) -> ThermalRouteConfig:
    """Load epsilon-constrained thermal-burden route settings."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Thermal-route configuration must be a YAML mapping")
    model = _required(payload, "thermal_route", "root")
    inputs = _required(payload, "inputs", "root")
    output_crs = str(_required(model, "output_crs", "thermal_route"))
    if not CRS.from_user_input(output_crs).is_projected:
        raise ValueError("thermal_route.output_crs must be projected")
    raw_limits = _required(model, "detour_limits", "thermal_route")
    if not isinstance(raw_limits, list) or not raw_limits:
        raise ValueError("thermal_route.detour_limits must be a non-empty list")
    limits = tuple(float(value) for value in raw_limits)
    if limits[0] != 0 or any(value < 0 for value in limits):
        raise ValueError("detour_limits must start at zero and remain non-negative")
    if tuple(sorted(set(limits))) != limits:
        raise ValueError("detour_limits must be unique and increasing")
    primary = str(_required(model, "primary_height_scenario", "thermal_route"))
    if primary not in {"low", "central", "high"}:
        raise ValueError("Unsupported primary_height_scenario")
    network = _required(inputs, "network", "inputs")
    thermal = _required(inputs, "thermal", "inputs")
    endpoints = _required(inputs, "endpoints", "inputs")
    return ThermalRouteConfig(
        analysis_id=str(_required(model, "analysis_id", "thermal_route")),
        output_crs=output_crs,
        detour_limits=limits,
        primary_height_scenario=primary,
        network_path=str(_required(network, "path", "inputs.network")),
        nodes_layer=str(_required(network, "nodes_layer", "inputs.network")),
        edges_layer=str(_required(network, "edges_layer", "inputs.network")),
        thermal=ProcessedLayerConfig(
            path=str(_required(thermal, "path", "inputs.thermal")),
            layer=str(_required(thermal, "layer", "inputs.thermal")),
        ),
        od_summary_path=str(_required(inputs, "od_summary", "inputs")),
        endpoints=ProcessedLayerConfig(
            path=str(_required(endpoints, "path", "inputs.endpoints")),
            layer=str(_required(endpoints, "layer", "inputs.endpoints")),
        ),
    )


def load_dynamic_cptl_config(path: str | Path) -> DynamicCPTLConfig:
    """Load a validation or SOLWEIG-backed time-dependent CPTL configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Dynamic CPTL configuration must be a YAML mapping")
    model = _required(payload, "dynamic_cptl", "root")
    series_section = (
        "thermal_series" if "thermal_series" in payload else "algorithm_validation_series"
    )
    validation = _required(payload, series_section, "root")
    inputs = _required(payload, "inputs", "root")
    output_crs = str(_required(model, "output_crs", "dynamic_cptl"))
    if not CRS.from_user_input(output_crs).is_projected:
        raise ValueError("dynamic_cptl.output_crs must be projected")
    timezone = str(_required(model, "timezone", "dynamic_cptl"))
    try:
        zone = ZoneInfo(timezone)
    except Exception as exc:
        raise ValueError(f"Unknown dynamic_cptl.timezone: {timezone}") from exc

    def _aware_timestamp(value: Any, field: str) -> str:
        text = str(value)
        try:
            parsed = datetime.fromisoformat(text)
        except ValueError as exc:
            raise ValueError(f"{field} must be ISO 8601") from exc
        if parsed.tzinfo is None or parsed.utcoffset() is None:
            raise ValueError(f"{field} must include a UTC offset")
        if parsed.astimezone(zone).utcoffset() != parsed.utcoffset():
            raise ValueError(f"{field} offset does not match configured timezone")
        return text

    raw_departures = _required(model, "departure_times_sgt", "dynamic_cptl")
    if not isinstance(raw_departures, list) or not raw_departures:
        raise ValueError("dynamic_cptl.departure_times_sgt must be a non-empty list")
    departures = tuple(_aware_timestamp(value, "departure_times_sgt") for value in raw_departures)
    if len(set(departures)) != len(departures):
        raise ValueError("departure_times_sgt must be unique")
    walking_speed = float(_required(model, "walking_speed_m_s", "dynamic_cptl"))
    if walking_speed <= 0:
        raise ValueError("dynamic_cptl.walking_speed_m_s must be positive")
    raw_thresholds = _required(model, "sensitivity_thresholds_deg_c", "dynamic_cptl")
    if not isinstance(raw_thresholds, list) or not raw_thresholds:
        raise ValueError("sensitivity_thresholds_deg_c must be a non-empty list")
    thresholds = tuple(float(value) for value in raw_thresholds)
    if tuple(sorted(set(thresholds))) != thresholds:
        raise ValueError("sensitivity_thresholds_deg_c must be unique and increasing")
    primary_threshold = float(_required(model, "primary_threshold_deg_c", "dynamic_cptl"))
    if primary_threshold not in thresholds:
        raise ValueError("primary_threshold_deg_c must be in sensitivity thresholds")
    raw_limits = _required(model, "detour_limits", "dynamic_cptl")
    if not isinstance(raw_limits, list) or not raw_limits:
        raise ValueError("dynamic_cptl.detour_limits must be a non-empty list")
    limits = tuple(float(value) for value in raw_limits)
    if limits[0] != 0 or tuple(sorted(set(limits))) != limits:
        raise ValueError("dynamic_cptl.detour_limits must start at zero and increase")
    if any(value < 0 for value in limits):
        raise ValueError("dynamic_cptl.detour_limits must be non-negative")
    time_bin_seconds = int(_required(model, "time_bin_seconds", "dynamic_cptl"))
    if time_bin_seconds <= 0:
        raise ValueError("dynamic_cptl.time_bin_seconds must be positive")
    integration = str(_required(model, "integration_method", "dynamic_cptl"))
    if integration != "piecewise_linear_threshold_crossing_exact":
        raise ValueError("Unsupported dynamic_cptl.integration_method")
    waiting_allowed = bool(_required(model, "waiting_allowed", "dynamic_cptl"))
    if waiting_allowed:
        raise ValueError("Phase-one dynamic CPTL routing does not support waiting")
    scenario = str(_required(model, "primary_height_scenario", "dynamic_cptl"))
    if scenario not in {"low", "central", "high"}:
        raise ValueError("Unsupported dynamic CPTL primary_height_scenario")
    source_status = str(_required(validation, "thermal_source_status", series_section))
    is_solweig_dynamic_result = bool(validation.get("is_solweig_dynamic_result", False))
    validation_status = "provisional_static_repeat_not_solweig_dynamic_output"
    if is_solweig_dynamic_result:
        if "solweig" not in source_status or "provisional_static_repeat" in source_status:
            raise ValueError("Dynamic SOLWEIG series must retain explicit SOLWEIG provenance")
    elif source_status != validation_status:
        raise ValueError("Algorithm-validation thermal source must retain its warning status")
    start = _aware_timestamp(
        _required(validation, "start_sgt", series_section),
        f"{series_section}.start_sgt",
    )
    end = _aware_timestamp(
        _required(validation, "end_sgt", series_section),
        f"{series_section}.end_sgt",
    )
    if datetime.fromisoformat(end) <= datetime.fromisoformat(start):
        raise ValueError("Algorithm-validation series end must follow start")
    interval = int(_required(validation, "interval_seconds", series_section))
    if interval <= 0:
        raise ValueError("Algorithm-validation series interval must be positive")
    network = _required(inputs, "network", "inputs")
    static = _required(inputs, "static_thermal", "inputs")
    endpoints = _required(inputs, "endpoints", "inputs")
    output_stem = str(model.get("output_stem", "clementi_time_dependent_cptl_validation"))
    if not output_stem or Path(output_stem).name != output_stem:
        raise ValueError("dynamic_cptl.output_stem must be a filename stem")
    return DynamicCPTLConfig(
        analysis_id=str(_required(model, "analysis_id", "dynamic_cptl")),
        output_crs=output_crs,
        timezone=timezone,
        departure_times=departures,
        walking_speed_m_s=walking_speed,
        primary_threshold_deg_c=primary_threshold,
        sensitivity_thresholds_deg_c=thresholds,
        detour_limits=limits,
        time_bin_seconds=time_bin_seconds,
        integration_method=integration,
        waiting_allowed=waiting_allowed,
        primary_height_scenario=scenario,
        thermal_source_status=source_status,
        is_solweig_dynamic_result=is_solweig_dynamic_result,
        output_stem=output_stem,
        validation_series_start_sgt=start,
        validation_series_end_sgt=end,
        validation_series_interval_seconds=interval,
        network_path=str(_required(network, "path", "inputs.network")),
        nodes_layer=str(_required(network, "nodes_layer", "inputs.network")),
        edges_layer=str(_required(network, "edges_layer", "inputs.network")),
        static_thermal=ProcessedLayerConfig(
            path=str(_required(static, "path", "inputs.static_thermal")),
            layer=str(_required(static, "layer", "inputs.static_thermal")),
        ),
        dynamic_thermal_path=str(_required(inputs, "dynamic_thermal", "inputs")),
        od_summary_path=str(_required(inputs, "od_summary", "inputs")),
        endpoints=ProcessedLayerConfig(
            path=str(_required(endpoints, "path", "inputs.endpoints")),
            layer=str(_required(endpoints, "layer", "inputs.endpoints")),
        ),
    )


def load_multi_od_cptl_config(path: str | Path) -> MultiODCPTLConfig:
    """Load a deterministic multi-OD robustness configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Multi-OD CPTL configuration must be a YAML mapping")
    analysis = _required(payload, "multi_od_cptl", "root")
    sampling = _required(payload, "sampling", "root")
    scenarios_raw = _required(payload, "thermal_scenarios", "root")
    output_crs = str(_required(analysis, "output_crs", "multi_od_cptl"))
    if not CRS.from_user_input(output_crs).is_projected:
        raise ValueError("multi_od_cptl.output_crs must be projected")
    sample_type = str(_required(analysis, "sample_type", "multi_od_cptl"))
    if sample_type != "network_coverage_not_travel_demand":
        raise ValueError("Multi-OD sample must retain its non-demand interpretation")
    method = str(_required(sampling, "method", "sampling"))
    if method != "largest_scc_farthest_origins_distance_bands":
        raise ValueError("Unsupported multi-OD sampling method")
    origin_count = int(_required(sampling, "origin_count", "sampling"))
    if origin_count < 2:
        raise ValueError("sampling.origin_count must be at least two")
    bands_raw = _required(sampling, "shortest_path_distance_bands_m", "sampling")
    if not isinstance(bands_raw, list) or not bands_raw:
        raise ValueError("shortest_path_distance_bands_m must be a non-empty list")
    bands: list[tuple[float, float]] = []
    previous_max = 0.0
    for raw in bands_raw:
        if not isinstance(raw, list) or len(raw) != 2:
            raise ValueError("Every shortest-path distance band must contain [min, max]")
        lower, upper = (float(value) for value in raw)
        if lower <= 0 or upper <= lower or lower < previous_max:
            raise ValueError("Distance bands must be positive, ordered, and non-overlapping")
        bands.append((lower, upper))
        previous_max = upper
    if not isinstance(scenarios_raw, list) or len(scenarios_raw) < 2:
        raise ValueError("At least two thermal scenarios are required")
    scenarios = tuple(
        MultiODThermalScenarioConfig(
            label=str(_required(item, "label", "thermal_scenarios")),
            dynamic_cptl_config_path=str(
                _required(item, "dynamic_cptl_config", "thermal_scenarios")
            ),
        )
        for item in scenarios_raw
    )
    labels = [scenario.label for scenario in scenarios]
    if len(set(labels)) != len(labels):
        raise ValueError("Thermal scenario labels must be unique")
    output_stem = str(_required(analysis, "output_stem", "multi_od_cptl"))
    if not output_stem or Path(output_stem).name != output_stem:
        raise ValueError("multi_od_cptl.output_stem must be a filename stem")
    return MultiODCPTLConfig(
        analysis_id=str(_required(analysis, "analysis_id", "multi_od_cptl")),
        output_crs=output_crs,
        sample_type=sample_type,
        sampling_method=method,
        origin_count=origin_count,
        distance_bands_m=tuple(bands),
        scenarios=scenarios,
        output_stem=output_stem,
    )


def load_intervention_screening_config(
    path: str | Path,
) -> InterventionScreeningConfig:
    """Load an explicitly exploratory intervention-screening configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Intervention-screening config must be a YAML mapping")
    analysis = _required(payload, "intervention_screening", "root")
    source = _required(payload, "input", "root")
    fields = _required(payload, "fields", "root")
    output_crs = str(_required(analysis, "output_crs", "intervention_screening"))
    if not CRS.from_user_input(output_crs).is_projected:
        raise ValueError("intervention_screening.output_crs must be projected")
    method = str(_required(analysis, "ranking_method", "intervention_screening"))
    if method != "percentile_of_symmetric_weight_sweep_mean":
        raise ValueError("Unsupported intervention screening ranking_method")
    top_fraction = float(_required(analysis, "diagnostic_top_fraction", "intervention_screening"))
    if not 0 < top_fraction < 1:
        raise ValueError("diagnostic_top_fraction must be in (0, 1)")
    return InterventionScreeningConfig(
        analysis_id=str(_required(analysis, "analysis_id", "intervention_screening")),
        output_crs=output_crs,
        ranking_method=method,
        diagnostic_top_fraction=top_fraction,
        exposure=ProcessedLayerConfig(
            path=str(_required(source, "path", "input")),
            layer=str(_required(source, "layer", "input")),
        ),
        screening_field=str(_required(fields, "screening", "fields")),
        sensitivity_field=str(_required(fields, "sensitivity", "fields")),
        scenario_frequency_field=str(_required(fields, "scenario_frequency", "fields")),
    )


def load_sentinel_ndvi_config(path: str | Path) -> SentinelNDVIConfig:
    """Load and validate Sentinel-2 NDVI acquisition configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Sentinel NDVI configuration must be a YAML mapping")
    ndvi = _required(payload, "sentinel_ndvi", "root")
    assets = _required(payload, "assets", "root")
    source = _required(payload, "source", "root")
    stac_url = str(_required(ndvi, "stac_url", "sentinel_ndvi"))
    if not stac_url.startswith("https://"):
        raise ValueError("sentinel_ndvi.stac_url must use HTTPS")
    datetime_range = str(_required(ndvi, "datetime_range", "sentinel_ndvi"))
    if "/" not in datetime_range:
        raise ValueError("sentinel_ndvi.datetime_range must be an interval")
    max_items = int(_required(ndvi, "max_items", "sentinel_ndvi"))
    if max_items <= 0:
        raise ValueError("sentinel_ndvi.max_items must be positive")
    valid_classes_raw = _required(ndvi, "valid_scl_classes", "sentinel_ndvi")
    if not isinstance(valid_classes_raw, list) or not valid_classes_raw:
        raise ValueError("sentinel_ndvi.valid_scl_classes must be a non-empty list")
    valid_classes = tuple(int(value) for value in valid_classes_raw)
    if any(value < 0 or value > 11 for value in valid_classes):
        raise ValueError("Sentinel-2 SCL classes must be between 0 and 11")
    road_buffer = float(_required(ndvi, "road_context_buffer_m", "sentinel_ndvi"))
    if road_buffer <= 0:
        raise ValueError("sentinel_ndvi.road_context_buffer_m must be positive")
    geographic_crs = str(_required(ndvi, "geographic_crs", "sentinel_ndvi"))
    output_crs = str(_required(ndvi, "output_crs", "sentinel_ndvi"))
    if not CRS.from_user_input(geographic_crs).is_geographic:
        raise ValueError("sentinel_ndvi.geographic_crs must be geographic")
    if not CRS.from_user_input(output_crs).is_projected:
        raise ValueError("sentinel_ndvi.output_crs must be projected")
    return SentinelNDVIConfig(
        stac_url=stac_url.rstrip("/"),
        collection=str(_required(ndvi, "collection", "sentinel_ndvi")),
        datetime_range=datetime_range,
        max_items=max_items,
        asset_red=str(_required(assets, "red", "assets")),
        asset_nir=str(_required(assets, "nir", "assets")),
        asset_scl=str(_required(assets, "scl", "assets")),
        valid_scl_classes=valid_classes,
        road_context_buffer_m=road_buffer,
        geographic_crs=geographic_crs,
        output_crs=output_crs,
        source_metadata=dict(source),
    )


def load_ndvi_osm_consistency_config(
    path: str | Path,
) -> NDVIOSMConsistencyConfig:
    """Load NDVI versus OSM green-context diagnostic configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("NDVI/OSM consistency configuration must be a YAML mapping")
    analysis = _required(payload, "ndvi_osm_consistency", "root")
    source = _required(payload, "input", "root")
    fields = _required(payload, "fields", "root")
    output_crs = str(_required(analysis, "output_crs", "ndvi_osm_consistency"))
    if not CRS.from_user_input(output_crs).is_projected:
        raise ValueError("ndvi_osm_consistency.output_crs must be projected")
    missing_policy = str(
        _required(
            analysis,
            "missing_value_policy",
            "ndvi_osm_consistency",
        )
    )
    if missing_policy != "pairwise_complete_no_imputation":
        raise ValueError("Only pairwise_complete_no_imputation missing-value policy is supported")
    configured_fields = {
        "ndvi": str(_required(fields, "ndvi", "fields")),
        "ndvi_valid_fraction": str(_required(fields, "ndvi_valid_fraction", "fields")),
        "osm_green_proxy": str(_required(fields, "osm_green_proxy", "fields")),
    }
    if len(set(configured_fields.values())) != 3:
        raise ValueError("NDVI/OSM diagnostic fields must be unique")
    return NDVIOSMConsistencyConfig(
        analysis_id=str(_required(analysis, "analysis_id", "ndvi_osm_consistency")),
        input_path=str(_required(source, "path", "input")),
        input_layer=str(_required(source, "layer", "input")),
        output_crs=output_crs,
        missing_value_policy=missing_policy,
        ndvi_field=configured_fields["ndvi"],
        ndvi_valid_fraction_field=configured_fields["ndvi_valid_fraction"],
        osm_green_proxy_field=configured_fields["osm_green_proxy"],
    )


def load_sentinel_composite_config(path: str | Path) -> SentinelCompositeConfig:
    """Load a reproducible multi-date Sentinel-2 composite configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Sentinel composite configuration must be a YAML mapping")
    composite = _required(payload, "sentinel_composite", "root")
    assets = _required(payload, "assets", "root")
    source = _required(payload, "source", "root")
    scene_count = int(_required(composite, "scene_count", "sentinel_composite"))
    if scene_count < 2:
        raise ValueError("sentinel_composite.scene_count must be at least 2")
    selection_rule = str(_required(composite, "selection_rule", "sentinel_composite"))
    if selection_rule != "lowest_scene_cloud_full_coverage_unique_dates":
        raise ValueError("Unsupported Sentinel composite selection rule")
    statistic = str(_required(composite, "composite_statistic", "sentinel_composite"))
    if statistic != "median":
        raise ValueError("Only median Sentinel composite is supported")
    valid_raw = _required(composite, "valid_scl_classes", "sentinel_composite")
    if not isinstance(valid_raw, list) or not valid_raw:
        raise ValueError("sentinel_composite.valid_scl_classes must be a list")
    valid_classes = tuple(int(value) for value in valid_raw)
    if any(value < 0 or value > 11 for value in valid_classes):
        raise ValueError("Sentinel-2 SCL classes must be between 0 and 11")
    road_buffer = float(_required(composite, "road_context_buffer_m", "sentinel_composite"))
    if road_buffer <= 0:
        raise ValueError("sentinel_composite.road_context_buffer_m must be positive")
    geographic_crs = str(_required(composite, "geographic_crs", "sentinel_composite"))
    output_crs = str(_required(composite, "output_crs", "sentinel_composite"))
    if not CRS.from_user_input(geographic_crs).is_geographic:
        raise ValueError("sentinel_composite.geographic_crs must be geographic")
    if not CRS.from_user_input(output_crs).is_projected:
        raise ValueError("sentinel_composite.output_crs must be projected")
    return SentinelCompositeConfig(
        source_stac_snapshot=str(
            _required(
                composite,
                "source_stac_snapshot",
                "sentinel_composite",
            )
        ),
        scene_count=scene_count,
        selection_rule=selection_rule,
        composite_statistic=statistic,
        asset_red=str(_required(assets, "red", "assets")),
        asset_nir=str(_required(assets, "nir", "assets")),
        asset_scl=str(_required(assets, "scl", "assets")),
        valid_scl_classes=valid_classes,
        road_context_buffer_m=road_buffer,
        geographic_crs=geographic_crs,
        output_crs=output_crs,
        source_metadata=dict(source),
    )


def load_solweig_timeseries_config(path: str | Path) -> SolweigTimeseriesConfig:
    """Load and validate the phase-two SOLWEIG scenario configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("SOLWEIG configuration must be a YAML mapping")
    model = _required(payload, "solweig_timeseries", "root")
    inputs = _required(payload, "inputs", "root")
    outputs = _required(payload, "outputs", "root")
    output_crs = str(_required(model, "output_crs", "solweig_timeseries"))
    if not CRS.from_user_input(output_crs).is_projected:
        raise ValueError("solweig_timeseries.output_crs must be projected")
    timezone = str(_required(model, "timezone", "solweig_timeseries"))
    try:
        zone = ZoneInfo(timezone)
    except Exception as exc:
        raise ValueError(f"Unknown solweig_timeseries.timezone: {timezone}") from exc

    def _aware(value: Any, field: str) -> str:
        text = str(value)
        try:
            parsed = datetime.fromisoformat(text)
        except ValueError as exc:
            raise ValueError(f"{field} must be ISO 8601") from exc
        if parsed.tzinfo is None or parsed.utcoffset() is None:
            raise ValueError(f"{field} must include a UTC offset")
        if parsed.astimezone(zone).utcoffset() != parsed.utcoffset():
            raise ValueError(f"{field} offset does not match configured timezone")
        return text

    start = _aware(_required(model, "start_sgt", "solweig_timeseries"), "start_sgt")
    end = _aware(_required(model, "end_sgt", "solweig_timeseries"), "end_sgt")
    if datetime.fromisoformat(end) <= datetime.fromisoformat(start):
        raise ValueError("SOLWEIG end_sgt must follow start_sgt")
    interval = int(_required(model, "interval_minutes", "solweig_timeseries"))
    resolution = float(_required(model, "raster_resolution_m", "solweig_timeseries"))
    shadow_distance = float(_required(model, "max_shadow_distance_m", "solweig_timeseries"))
    sampling_interval = float(_required(model, "edge_sampling_interval_m", "solweig_timeseries"))
    if interval <= 0 or resolution <= 0 or shadow_distance <= 0 or sampling_interval <= 0:
        raise ValueError("SOLWEIG intervals, resolution, and shadow distance must be positive")
    buildings = _required(inputs, "buildings", "inputs")
    network = _required(inputs, "network", "inputs")
    canopy = inputs.get("canopy")
    canopy_source_path: str | None = None
    canopy_source_nodata: float | None = None
    canopy_height_multiplier = 1.0
    minimum_canopy_height_m = 0.0
    canopy_trunk_ratio = 0.25
    canopy_dsm_path: str | None = None
    if canopy is not None:
        if not isinstance(canopy, dict):
            raise ValueError("inputs.canopy must be a mapping")
        canopy_source_path = str(_required(canopy, "path", "inputs.canopy"))
        source_nodata = canopy.get("source_nodata")
        canopy_source_nodata = float(source_nodata) if source_nodata is not None else None
        canopy_height_multiplier = float(_required(canopy, "height_multiplier", "inputs.canopy"))
        minimum_canopy_height_m = float(_required(canopy, "minimum_height_m", "inputs.canopy"))
        canopy_trunk_ratio = float(_required(canopy, "trunk_ratio", "inputs.canopy"))
        if canopy_height_multiplier <= 0:
            raise ValueError("inputs.canopy.height_multiplier must be positive")
        if minimum_canopy_height_m < 0:
            raise ValueError("inputs.canopy.minimum_height_m cannot be negative")
        if not 0 < canopy_trunk_ratio < 1:
            raise ValueError("inputs.canopy.trunk_ratio must be between zero and one")
        canopy_dsm_path = str(_required(outputs, "canopy_dsm", "outputs"))
    source_status = str(_required(model, "thermal_source_status", "solweig_timeseries"))
    if "solweig" not in source_status or "not_field_validated" not in source_status:
        raise ValueError("SOLWEIG source status must identify the model and validation limit")
    return SolweigTimeseriesConfig(
        analysis_id=str(_required(model, "analysis_id", "solweig_timeseries")),
        output_crs=output_crs,
        timezone=timezone,
        start_sgt=start,
        end_sgt=end,
        interval_minutes=interval,
        raster_resolution_m=resolution,
        max_shadow_distance_m=shadow_distance,
        edge_sampling_interval_m=sampling_interval,
        building_height_field=str(_required(model, "building_height_field", "solweig_timeseries")),
        weather_station_id=str(_required(model, "weather_station_id", "solweig_timeseries")),
        weather_snapshot_id=str(_required(model, "weather_snapshot_id", "solweig_timeseries")),
        use_anisotropic_sky=bool(_required(model, "use_anisotropic_sky", "solweig_timeseries")),
        canopy_source_path=canopy_source_path,
        canopy_source_nodata=canopy_source_nodata,
        canopy_height_multiplier=canopy_height_multiplier,
        minimum_canopy_height_m=minimum_canopy_height_m,
        canopy_trunk_ratio=canopy_trunk_ratio,
        thermal_source_status=source_status,
        buildings=ProcessedLayerConfig(
            path=str(_required(buildings, "path", "inputs.buildings")),
            layer=str(_required(buildings, "layer", "inputs.buildings")),
        ),
        network=ProcessedLayerConfig(
            path=str(_required(network, "path", "inputs.network")),
            layer=str(_required(network, "layer", "inputs.network")),
        ),
        weather_observations_path=str(_required(inputs, "weather_observations", "inputs")),
        study_area_config_path=str(_required(inputs, "study_area_config", "inputs")),
        dsm_path=str(_required(outputs, "dsm", "outputs")),
        canopy_dsm_path=canopy_dsm_path,
        solweig_output_directory=str(_required(outputs, "solweig_directory", "outputs")),
        road_timeseries_path=str(_required(outputs, "road_timeseries", "outputs")),
        weather_timeseries_path=str(_required(outputs, "weather_timeseries", "outputs")),
        readiness_path=str(_required(outputs, "readiness", "outputs")),
    )
