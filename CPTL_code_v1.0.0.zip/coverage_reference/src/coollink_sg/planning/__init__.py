"""Shade-intervention prioritization modules."""

