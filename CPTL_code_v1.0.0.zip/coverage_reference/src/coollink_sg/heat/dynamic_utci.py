"""Time-indexed UTCI interface and phase-one algorithm-validation series."""

from __future__ import annotations

import argparse
import json
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd

from coollink_sg.config import DynamicCPTLConfig, load_dynamic_cptl_config

PROJECT_ROOT = Path(__file__).resolve().parents[3]
TIMESTAMP_FIELD = "timestamp_sgt"
UTCI_FIELD = "modeled_utci_deg_c"
STATUS_FIELD = "thermal_source_status"


@dataclass(frozen=True)
class ExposureIntegral:
    """Thermal quantities integrated across one continuous traversal."""

    duration_min: float
    entry_utci_deg_c: float
    exit_utci_deg_c: float
    mean_utci_deg_c: float
    maximum_utci_deg_c: float
    utci_integral_deg_c_min: float
    exceedance_deg_c_min: dict[float, float]


def _positive_linear_integral(
    value_start: float,
    value_end: float,
    threshold: float,
    duration_min: float,
) -> float:
    """Integrate the positive part of a linear UTCI-minus-threshold interval."""

    excess_start = value_start - threshold
    excess_end = value_end - threshold
    if excess_start <= 0 and excess_end <= 0:
        return 0.0
    if excess_start >= 0 and excess_end >= 0:
        return duration_min * (excess_start + excess_end) / 2
    crossing_fraction = -excess_start / (excess_end - excess_start)
    if excess_start < 0:
        positive_duration = duration_min * (1 - crossing_fraction)
        return positive_duration * excess_end / 2
    positive_duration = duration_min * crossing_fraction
    return positive_duration * excess_start / 2


class TimeVaryingUTCI:
    """Validated piecewise-linear UTCI lookup for road segments and time."""

    def __init__(
        self,
        frame: pd.DataFrame,
        height_scenario: str,
        expected_source_status: str | None = None,
    ) -> None:
        required = {
            "segment_id",
            TIMESTAMP_FIELD,
            "height_scenario",
            UTCI_FIELD,
            STATUS_FIELD,
        }
        missing = required.difference(frame.columns)
        if missing:
            raise ValueError(f"Dynamic UTCI table is missing fields: {sorted(missing)}")
        selected = frame.loc[frame["height_scenario"].eq(height_scenario)].copy()
        if selected.empty:
            raise ValueError(f"No UTCI rows exist for height scenario: {height_scenario}")
        if selected["segment_id"].isna().any():
            raise ValueError("Dynamic UTCI segment_id values must be complete")
        selected["_timestamp_utc"] = pd.to_datetime(
            selected[TIMESTAMP_FIELD], utc=True, errors="raise"
        )
        selected[UTCI_FIELD] = pd.to_numeric(selected[UTCI_FIELD], errors="raise")
        if not np.isfinite(selected[UTCI_FIELD]).all():
            raise ValueError("Dynamic UTCI values must be finite")
        if selected.duplicated(["segment_id", "_timestamp_utc"]).any():
            raise ValueError("Dynamic UTCI segment-time rows must be unique")
        statuses = set(selected[STATUS_FIELD].astype(str))
        if len(statuses) != 1:
            raise ValueError("Dynamic UTCI table must have one thermal source status")
        self.source_status = statuses.pop()
        if expected_source_status is not None and self.source_status != expected_source_status:
            raise ValueError("Dynamic UTCI source status differs from configuration")
        pivot = selected.pivot(
            index="segment_id", columns="_timestamp_utc", values=UTCI_FIELD
        ).sort_index(axis=1)
        if pivot.isna().any().any():
            raise ValueError("Every segment must have the complete UTCI time grid")
        if pivot.shape[1] < 2:
            raise ValueError("Dynamic UTCI requires at least two timestamps")
        self.height_scenario = height_scenario
        self.segment_ids = frozenset(pivot.index.astype(str))
        self._segment_rows = {
            str(segment_id): row_index
            for row_index, segment_id in enumerate(pivot.index.astype(str))
        }
        self._timestamps = pd.DatetimeIndex(pivot.columns)
        self._seconds = (
            self._timestamps - self._timestamps[0]
        ).total_seconds().to_numpy(dtype=float)
        if np.any(np.diff(self._seconds) <= 0):
            raise ValueError("Dynamic UTCI timestamps must increase")
        self._values = pivot.to_numpy(dtype=float)

    @property
    def start_time(self) -> pd.Timestamp:
        return pd.Timestamp(self._timestamps[0])

    @property
    def end_time(self) -> pd.Timestamp:
        return pd.Timestamp(self._timestamps[-1])

    def _time_seconds(self, timestamp: str | pd.Timestamp) -> float:
        parsed = pd.Timestamp(timestamp)
        if parsed.tzinfo is None:
            raise ValueError("Dynamic UTCI lookup timestamps must be timezone-aware")
        parsed = parsed.tz_convert("UTC")
        if parsed < self.start_time or parsed > self.end_time:
            raise ValueError("Dynamic UTCI lookup falls outside the modeled time window")
        return float((parsed - self.start_time).total_seconds())

    def utci_at(self, segment_id: str, timestamp: str | pd.Timestamp) -> float:
        """Linearly interpolate one segment UTCI at one aware timestamp."""

        try:
            row = self._segment_rows[str(segment_id)]
        except KeyError as exc:
            raise ValueError(f"Unknown dynamic UTCI segment_id: {segment_id}") from exc
        seconds = self._time_seconds(timestamp)
        return float(np.interp(seconds, self._seconds, self._values[row]))

    def integrate_exposure(
        self,
        segment_id: str,
        entry_time: str | pd.Timestamp,
        duration_min: float,
        thresholds_deg_c: Iterable[float],
    ) -> ExposureIntegral:
        """Integrate UTCI and threshold exceedance across one road traversal."""

        if not np.isfinite(duration_min) or duration_min <= 0:
            raise ValueError("Traversal duration must be finite and positive")
        start = pd.Timestamp(entry_time)
        if start.tzinfo is None:
            raise ValueError("Traversal entry time must be timezone-aware")
        start = start.tz_convert("UTC")
        end = start + pd.to_timedelta(duration_min, unit="min")
        self._time_seconds(start)
        self._time_seconds(end)
        internal = self._timestamps[(self._timestamps > start) & (self._timestamps < end)]
        breakpoints = pd.DatetimeIndex([start, *internal, end])
        values = np.array(
            [self.utci_at(segment_id, timestamp) for timestamp in breakpoints],
            dtype=float,
        )
        thresholds = tuple(float(value) for value in thresholds_deg_c)
        if not thresholds:
            raise ValueError("At least one CPTL threshold is required")
        exceedance = {threshold: 0.0 for threshold in thresholds}
        utci_integral = 0.0
        for index in range(len(breakpoints) - 1):
            interval_min = (
                breakpoints[index + 1] - breakpoints[index]
            ).total_seconds() / 60
            value_start = float(values[index])
            value_end = float(values[index + 1])
            utci_integral += interval_min * (value_start + value_end) / 2
            for threshold in thresholds:
                exceedance[threshold] += _positive_linear_integral(
                    value_start, value_end, threshold, interval_min
                )
        return ExposureIntegral(
            duration_min=duration_min,
            entry_utci_deg_c=float(values[0]),
            exit_utci_deg_c=float(values[-1]),
            mean_utci_deg_c=utci_integral / duration_min,
            maximum_utci_deg_c=float(values.max()),
            utci_integral_deg_c_min=utci_integral,
            exceedance_deg_c_min=exceedance,
        )


def repeat_static_utci_for_algorithm_validation(
    static_thermal: pd.DataFrame,
    timestamps: pd.DatetimeIndex,
    height_scenario: str,
    source_status: str,
) -> pd.DataFrame:
    """Repeat one static UTCI field solely to validate the dynamic algorithm."""

    field = f"modeled_utci_mean_{height_scenario}_deg_c"
    required = {"segment_id", field}
    missing = required.difference(static_thermal.columns)
    if missing:
        raise ValueError(f"Static thermal table is missing fields: {sorted(missing)}")
    if static_thermal["segment_id"].isna().any() or not static_thermal["segment_id"].is_unique:
        raise ValueError("Static thermal segment_id values must be complete and unique")
    values = pd.to_numeric(static_thermal[field], errors="raise").to_numpy(dtype=float)
    if not np.isfinite(values).all():
        raise ValueError("Static UTCI values must be finite")
    if len(timestamps) < 2 or timestamps.tz is None:
        raise ValueError("Validation timestamps must be aware and contain at least two values")
    segment_ids = static_thermal["segment_id"].astype(str).to_numpy()
    return pd.DataFrame(
        {
            "segment_id": np.repeat(segment_ids, len(timestamps)),
            TIMESTAMP_FIELD: np.tile(timestamps.astype(str), len(segment_ids)),
            "height_scenario": height_scenario,
            UTCI_FIELD: np.repeat(values, len(timestamps)),
            STATUS_FIELD: source_status,
        }
    )


def build_algorithm_validation_series(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, object]:
    """Create the explicitly non-dynamic phase-one UTCI algorithm fixture."""

    config: DynamicCPTLConfig = load_dynamic_cptl_config(config_path)
    if config.is_solweig_dynamic_result:
        raise ValueError("Static-repeat builder cannot overwrite a SOLWEIG dynamic series")
    source = project_root / config.static_thermal.path
    thermal = gpd.read_file(source, layer=config.static_thermal.layer)
    timestamps = pd.date_range(
        start=config.validation_series_start_sgt,
        end=config.validation_series_end_sgt,
        freq=pd.to_timedelta(config.validation_series_interval_seconds, unit="s"),
    )
    result = repeat_static_utci_for_algorithm_validation(
        thermal,
        timestamps,
        config.primary_height_scenario,
        config.thermal_source_status,
    )
    output = project_root / config.dynamic_thermal_path
    output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output, index=False)
    summary: dict[str, object] = {
        "analysis_id": config.analysis_id,
        "row_count": len(result),
        "segment_count": int(result["segment_id"].nunique()),
        "timestamp_count": len(timestamps),
        "start_sgt": str(timestamps[0]),
        "end_sgt": str(timestamps[-1]),
        "height_scenario": config.primary_height_scenario,
        "thermal_source_status": config.thermal_source_status,
        "is_solweig_output": False,
        "is_observed_dynamic_thermal_field": False,
        "purpose": "algorithm_validation_and_static_degradation_test_only",
    }
    summary_path = output.with_name(f"{output.stem}_summary.json")
    summary_path.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build the phase-one dynamic-CPTL algorithm-validation UTCI series."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/dynamic_cptl.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(build_algorithm_validation_series(args.config), indent=2))


if __name__ == "__main__":
    main()
