"""Route-aware temporal thinning audit for SOLWEIG-derived UTCI fields."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import matplotlib as mpl
import numpy as np
import pandas as pd
import yaml
from matplotlib import pyplot as plt

PROJECT_ROOT = Path(__file__).resolve().parents[3]
KEY_FIELDS = ["region_id", "od_id", "departure_time_sgt", "route_id"]
BLUE = "#0077BB"
ORANGE = "#EE7733"
TEAL = "#009988"


def anchor_indices(timestamp_count: int, step: int) -> np.ndarray:
    """Return regular anchor indices while always retaining the final timestamp."""

    if timestamp_count < 2 or step < 1:
        raise ValueError("timestamp_count must be at least two and step must be positive")
    anchors = list(range(0, timestamp_count, step))
    if anchors[-1] != timestamp_count - 1:
        anchors.append(timestamp_count - 1)
    return np.asarray(anchors, dtype=int)


def reconstruct_from_anchors(values: np.ndarray, anchors: np.ndarray) -> np.ndarray:
    """Linearly reconstruct a segment-by-time matrix from retained columns."""

    data = np.asarray(values, dtype=float)
    selected = np.asarray(anchors, dtype=int)
    if data.ndim != 2 or data.shape[1] < 2:
        raise ValueError("values must be a two-dimensional time matrix")
    if selected.ndim != 1 or len(selected) < 2:
        raise ValueError("at least two anchors are required")
    if selected[0] != 0 or selected[-1] != data.shape[1] - 1:
        raise ValueError("anchors must retain the first and last timestamps")
    if np.any(np.diff(selected) <= 0):
        raise ValueError("anchors must be strictly increasing")
    result = np.empty_like(data)
    for left, right in zip(selected[:-1], selected[1:], strict=True):
        fraction = np.linspace(0.0, 1.0, right - left + 1)
        result[:, left : right + 1] = (
            data[:, [left]] * (1.0 - fraction) + data[:, [right]] * fraction
        )
    return result


def positive_linear_integral(
    start: np.ndarray,
    end: np.ndarray,
    duration_min: np.ndarray,
    threshold: float,
) -> np.ndarray:
    """Vectorized exact integral of the positive part of a linear interval."""

    start_excess = np.asarray(start, dtype=float) - threshold
    end_excess = np.asarray(end, dtype=float) - threshold
    duration = np.asarray(duration_min, dtype=float)
    result = np.zeros_like(start_excess)
    both_positive = (start_excess >= 0) & (end_excess >= 0)
    result[both_positive] = (
        duration[both_positive]
        * (start_excess[both_positive] + end_excess[both_positive])
        / 2
    )
    rising = (start_excess < 0) & (end_excess > 0)
    falling = (start_excess > 0) & (end_excess < 0)
    if rising.any():
        positive_fraction = end_excess[rising] / (
            end_excess[rising] - start_excess[rising]
        )
        result[rising] = duration[rising] * positive_fraction * end_excess[rising] / 2
    if falling.any():
        positive_fraction = start_excess[falling] / (
            start_excess[falling] - end_excess[falling]
        )
        result[falling] = (
            duration[falling] * positive_fraction * start_excess[falling] / 2
        )
    return result


def _lookup(
    values: np.ndarray,
    rows: np.ndarray,
    time_index: np.ndarray,
) -> np.ndarray:
    lower = np.floor(time_index).astype(int)
    upper = np.minimum(lower + 1, values.shape[1] - 1)
    fraction = time_index - lower
    return values[rows, lower] * (1.0 - fraction) + values[rows, upper] * fraction


def segment_cptl(
    segments: pd.DataFrame,
    reconstructed: np.ndarray,
    segment_rows: dict[str, int],
    start_time: pd.Timestamp,
    base_interval_minutes: int,
    threshold: float,
) -> np.ndarray:
    """Integrate reconstructed UTCI exactly across each sub-15-minute segment."""

    rows = segments["segment_id"].astype(str).map(segment_rows)
    if rows.isna().any():
        raise ValueError("Candidate segments contain unknown segment identifiers")
    row_index = rows.to_numpy(dtype=int)
    entry = pd.to_datetime(segments["entry_time_sgt"], utc=True, format="mixed")
    exit_time = pd.to_datetime(segments["exit_time_sgt"], utc=True, format="mixed")
    start_utc = pd.Timestamp(start_time).tz_convert("UTC")
    interval_seconds = 60.0 * base_interval_minutes
    entry_index = (entry - start_utc).dt.total_seconds().to_numpy() / interval_seconds
    exit_index = (exit_time - start_utc).dt.total_seconds().to_numpy() / interval_seconds
    if np.any(entry_index < 0) or np.any(exit_index > reconstructed.shape[1] - 1):
        raise ValueError("Candidate traversal falls outside the thermal time grid")
    if np.any(exit_index <= entry_index):
        raise ValueError("Candidate segment exit must follow entry")

    entry_value = _lookup(reconstructed, row_index, entry_index)
    exit_value = _lookup(reconstructed, row_index, exit_index)
    duration = (exit_time - entry).dt.total_seconds().to_numpy() / 60.0
    next_boundary = np.ceil(entry_index - 1e-12).astype(int)
    crosses = next_boundary < exit_index - 1e-12
    result = positive_linear_integral(entry_value, exit_value, duration, threshold)
    if crosses.any():
        cross_rows = row_index[crosses]
        boundary_index = next_boundary[crosses]
        boundary_value = reconstructed[cross_rows, boundary_index]
        duration_left = (boundary_index - entry_index[crosses]) * base_interval_minutes
        duration_right = duration[crosses] - duration_left
        result[crosses] = positive_linear_integral(
            entry_value[crosses], boundary_value, duration_left, threshold
        ) + positive_linear_integral(
            boundary_value, exit_value[crosses], duration_right, threshold
        )
    return result


def _select_routes(candidates: pd.DataFrame, minimum_probability: float) -> pd.DataFrame:
    selected_rows: list[pd.Series] = []
    case_fields = ["region_id", "od_id", "departure_time_sgt"]
    for _, frame in candidates.groupby(case_fields, sort=False):
        shortest = frame.loc[frame["is_shortest_distance"]]
        if len(shortest) != 1:
            raise ValueError("Each case must contain exactly one shortest route")
        baseline = float(shortest["thinned_cptl"].iloc[0])
        working = frame.copy()
        working["thinned_improvement"] = baseline - working["thinned_cptl"]
        working["thinned_score"] = (
            working["mean_acceptance_probability"] * working["thinned_improvement"]
        )
        eligible = working.loc[
            ~working["is_shortest_distance"]
            & working["thinned_improvement"].gt(0)
            & working["mean_acceptance_probability"].ge(minimum_probability)
        ]
        if eligible.empty:
            selected_rows.append(shortest.iloc[0])
        else:
            selected_rows.append(
                eligible.sort_values(
                    [
                        "thinned_score",
                        "mean_acceptance_probability",
                        "route_length_m",
                        "route_id",
                    ],
                    ascending=[False, False, True, True],
                ).iloc[0]
            )
    return pd.DataFrame(selected_rows).reset_index(drop=True)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _plot(summary: pd.DataFrame, paths: list[Path]) -> None:
    mpl.use("Agg")
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
            "font.size": 8.5,
            "axes.labelsize": 9,
            "xtick.labelsize": 8,
            "ytick.labelsize": 8,
            "savefig.dpi": 600,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )
    x = np.arange(len(summary))
    labels = summary["interval_minutes"].astype(str).tolist()
    fig, axes = plt.subplots(1, 3, figsize=(6.9, 2.55), constrained_layout=True)
    axes[0].plot(x, summary["field_mae_deg_c"], "o-", color=BLUE, label="MAE")
    axes[0].plot(x, summary["field_rmse_deg_c"], "s-", color=ORANGE, label="RMSE")
    axes[0].set_ylabel("Held-out UTCI error ($^{\\circ}$C)")
    axes[0].legend(frameon=False)
    axes[1].bar(x, summary["exact_route_agreement_percent"], color=TEAL)
    axes[1].set_ylabel("Exact route agreement (%)")
    axes[1].set_ylim(0, 105)
    axes[2].bar(x, summary["solweig_run_reduction_percent"], color=ORANGE)
    axes[2].set_ylabel("Fewer SOLWEIG timestamps (%)")
    for label, axis in zip("ABC", axes, strict=True):
        axis.set_xticks(x, labels)
        axis.set_xlabel("Retained interval (min)")
        axis.text(-0.16, 1.03, label, transform=axis.transAxes, fontweight="bold")
        axis.grid(axis="y", color="#E6E6E6", linewidth=0.6)
        axis.set_axisbelow(True)
    for path in paths:
        path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def run_temporal_thinning_audit(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Run field-, route-, and decision-level temporal thinning checks."""

    config_file = Path(config_path)
    config = yaml.safe_load(config_file.read_text(encoding="utf-8"))
    base_interval = int(config["base_interval_minutes"])
    intervals = [int(value) for value in config["tested_intervals_minutes"]]
    threshold = float(config["primary_threshold_deg_c"])
    minimum_probability = float(config["minimum_acceptance_probability"])
    for interval in intervals:
        if interval % base_interval:
            raise ValueError("Tested intervals must be multiples of the base interval")

    candidates = pd.read_csv(project_root / config["candidate_routes_path"])
    segments = pd.read_csv(project_root / config["candidate_segments_path"])
    recommendations = pd.read_csv(project_root / config["recommended_routes_path"])
    original_selection = recommendations[KEY_FIELDS].rename(
        columns={"route_id": "original_route_id"}
    )
    metric_rows: list[dict[str, Any]] = []
    source_hashes: dict[str, str] = {}

    for region in config["regions"]:
        region_id = str(region["region_id"])
        thermal_path = project_root / str(region["thermal_path"])
        source_hashes[region_id] = _sha256(thermal_path)
        thermal = pd.read_csv(
            thermal_path,
            usecols=["segment_id", "timestamp_sgt", "height_scenario", "modeled_utci_deg_c"],
        )
        thermal = thermal.loc[thermal["height_scenario"].eq("central")].copy()
        thermal["timestamp_sgt"] = pd.to_datetime(thermal["timestamp_sgt"], utc=True)
        pivot = thermal.pivot(
            index="segment_id", columns="timestamp_sgt", values="modeled_utci_deg_c"
        ).sort_index(axis=1)
        if pivot.isna().any().any():
            raise ValueError(f"Incomplete thermal grid for {region_id}")
        values = pivot.to_numpy(dtype=float)
        timestamps = pd.DatetimeIndex(pivot.columns)
        segment_rows = {str(value): index for index, value in enumerate(pivot.index)}
        region_segments = segments.loc[segments["region_id"].eq(region_id)].copy()
        region_candidates = candidates.loc[candidates["region_id"].eq(region_id)].copy()

        for interval in intervals:
            anchors = anchor_indices(values.shape[1], interval // base_interval)
            reconstructed = reconstruct_from_anchors(values, anchors)
            held_out = np.ones(values.shape[1], dtype=bool)
            held_out[anchors] = False
            error = reconstructed[:, held_out] - values[:, held_out]
            segment_values = segment_cptl(
                region_segments,
                reconstructed,
                segment_rows,
                timestamps[0],
                base_interval,
                threshold,
            )
            route_cptl = region_segments[KEY_FIELDS].copy()
            route_cptl["thinned_cptl"] = segment_values
            route_cptl = route_cptl.groupby(KEY_FIELDS, as_index=False)["thinned_cptl"].sum()
            evaluated = region_candidates.merge(route_cptl, on=KEY_FIELDS, validate="one_to_one")
            selected = _select_routes(evaluated, minimum_probability)
            selected = selected.merge(
                original_selection.loc[original_selection["region_id"].eq(region_id)],
                on=["region_id", "od_id", "departure_time_sgt"],
                validate="one_to_one",
            )
            original_selected = evaluated.merge(
                original_selection.loc[original_selection["region_id"].eq(region_id)],
                on=["region_id", "od_id", "departure_time_sgt"],
                validate="many_to_one",
            )
            original_selected = original_selected.loc[
                original_selected["route_id"].eq(original_selected["original_route_id"])
            ]
            if len(selected) != 60 or len(original_selected) != 60:
                raise RuntimeError(f"Incomplete route panel for {region_id}")
            cptl_error = (
                original_selected["thinned_cptl"]
                - original_selected["cptl_above_26_deg_c_min"]
            )
            metric_rows.append(
                {
                    "region_id": region_id,
                    "interval_minutes": interval,
                    "retained_timestamp_count": len(anchors),
                    "full_timestamp_count": values.shape[1],
                    "held_out_value_count": int(error.size),
                    "field_mae_deg_c": float(np.mean(np.abs(error))),
                    "field_rmse_deg_c": float(np.sqrt(np.mean(error**2))),
                    "route_cptl_mae_deg_c_min": float(np.mean(np.abs(cptl_error))),
                    "route_cptl_rmse_deg_c_min": float(np.sqrt(np.mean(cptl_error**2))),
                    "exact_route_agreement_percent": float(
                        100 * selected["route_id"].eq(selected["original_route_id"]).mean()
                    ),
                    "alternative_offer_share_percent": float(
                        100 * (~selected["is_shortest_distance"]).mean()
                    ),
                }
            )

    regional = pd.DataFrame(metric_rows)
    summary_rows = []
    for interval, frame in regional.groupby("interval_minutes", sort=True):
        retained = int(frame["retained_timestamp_count"].iloc[0])
        full = int(frame["full_timestamp_count"].iloc[0])
        weights = frame["held_out_value_count"].to_numpy(dtype=float)
        summary_rows.append(
            {
                "interval_minutes": int(interval),
                "retained_timestamp_count": retained,
                "full_timestamp_count": full,
                "solweig_run_reduction_percent": 100 * (1 - retained / full),
                "theoretical_timestamp_speedup": full / retained,
                "field_mae_deg_c": float(np.average(frame["field_mae_deg_c"], weights=weights)),
                "field_rmse_deg_c": float(
                    np.sqrt(np.average(frame["field_rmse_deg_c"] ** 2, weights=weights))
                ),
                "route_cptl_mae_deg_c_min": float(frame["route_cptl_mae_deg_c_min"].mean()),
                "route_cptl_rmse_deg_c_min": float(
                    np.sqrt(np.mean(frame["route_cptl_rmse_deg_c_min"] ** 2))
                ),
                "exact_route_agreement_percent": float(
                    frame["exact_route_agreement_percent"].mean()
                ),
                "alternative_offer_share_percent": float(
                    frame["alternative_offer_share_percent"].mean()
                ),
            }
        )
    summary = pd.DataFrame(summary_rows)
    outputs = {key: project_root / str(value) for key, value in config["outputs"].items()}
    outputs["summary_csv"].parent.mkdir(parents=True, exist_ok=True)
    outputs["regional_csv"].parent.mkdir(parents=True, exist_ok=True)
    summary.to_csv(outputs["summary_csv"], index=False)
    regional.to_csv(outputs["regional_csv"], index=False)
    trace = {
        "analysis_id": config["analysis_id"],
        "method": "retain_regular_SOLWEIG_timestamps_and_linearly_reconstruct_road_UTCI",
        "scope": "four_multistation_design_day_regions_and_fixed_behavior_candidate_pool",
        "not_claimed": [
            "measured_UTCI_validation",
            "general_speedup_benchmark",
            "new_weather_or_date_transfer",
            "deep_surrogate_model",
        ],
        "source_sha256": source_hashes,
        "summary": summary.to_dict(orient="records"),
        "regional_metrics": regional.to_dict(orient="records"),
    }
    outputs["trace_json"].parent.mkdir(parents=True, exist_ok=True)
    outputs["trace_json"].write_text(
        json.dumps(trace, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    _plot(summary, [outputs["figure_pdf"], outputs["figure_png"], outputs["figure_svg"]])
    return trace
