"""Traceably export SOLWEIG's internal ground-temperature state.

SOLWEIG 0.1.0b92 exposes ``ThermalState.tgout1`` on each timestep result but
does not list it as a public GeoTIFF output.  This module temporarily routes
that exact state through an otherwise unused writer channel, immediately
renames and retags the files, and restores the installed package function.
No temperature is reconstructed from Tmrt or from upwelling radiation.
"""

from __future__ import annotations

import os
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import numpy as np
import rasterio
import solweig
import solweig.api

GROUND_EXPORT_TRANSPORT = "kup"
GROUND_OUTPUT_NAME = "tg_sol_c"


@contextmanager
def route_ground_state_to_writer() -> Iterator[None]:
    """Route an exact copy of ``state.tgout1`` to the tiled writer."""

    original: Callable[..., Any] = solweig.api._calculate_single

    def wrapped(*args: Any, **kwargs: Any) -> Any:
        result = original(*args, **kwargs)
        if result.state is None:
            raise RuntimeError("SOLWEIG result omitted the thermal state required for T_g_SOL")
        ground = np.asarray(result.state.tgout1, dtype=np.float32)
        if ground.shape != result.tmrt.shape or not np.isfinite(ground).all():
            raise RuntimeError("Invalid SOLWEIG ThermalState.tgout1 grid")
        result.kup = ground.copy()
        return result

    solweig.api._calculate_single = wrapped
    try:
        yield
    finally:
        solweig.api._calculate_single = original


def finalize_ground_exports(output_dir: Path) -> list[Path]:
    """Rename the temporary writer channel and attach explicit physical tags."""

    transport_dir = output_dir / GROUND_EXPORT_TRANSPORT
    if not transport_dir.is_dir():
        raise FileNotFoundError(f"Missing SOLWEIG ground export channel: {transport_dir}")
    destination_dir = output_dir / GROUND_OUTPUT_NAME
    destination_dir.mkdir(parents=True, exist_ok=True)
    outputs: list[Path] = sorted(destination_dir.glob(f"{GROUND_OUTPUT_NAME}_*.tif"))
    for source in sorted(transport_dir.glob(f"{GROUND_EXPORT_TRANSPORT}_*.tif")):
        stamp = source.stem.removeprefix(f"{GROUND_EXPORT_TRANSPORT}_")
        destination = destination_dir / f"{GROUND_OUTPUT_NAME}_{stamp}.tif"
        if destination.exists():
            raise FileExistsError(f"Ground export destination already exists: {destination}")
        # The immutable experiment hierarchy can exceed the legacy Windows
        # MAX_PATH limit.  Prefix both absolute operands for an atomic rename.
        if os.name == "nt":
            os.replace(f"\\\\?\\{source.resolve()}", f"\\\\?\\{destination.resolve()}")
        else:
            source.rename(destination)
        with rasterio.open(destination, "r+") as dataset:
            dataset.update_tags(
                physical_variable="baseline_ground_surface_temperature",
                unit="degree_Celsius",
                source_state="solweig.models.ThermalState.tgout1",
                derivation="direct_internal_state_export_not_inferred_from_tmrt_or_lup",
                writer_transport_channel=GROUND_EXPORT_TRANSPORT,
                solweig_version=solweig.__version__,
            )
        outputs.append(destination)
    transport_dir.rmdir()
    if not outputs:
        raise RuntimeError("SOLWEIG produced no ground-temperature GeoTIFFs")
    return outputs


def calculate_with_ground_export(
    surface: Any,
    weather: Any,
    location: Any,
    *,
    output_dir: Path,
    outputs: list[str] | None = None,
    **kwargs: Any,
) -> tuple[Any, list[Path]]:
    """Run SOLWEIG and persist its exact per-timestep ground state."""

    requested = list(dict.fromkeys([*(outputs or []), "tmrt", "lup", GROUND_EXPORT_TRANSPORT]))
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(f"Immutable SOLWEIG output is not empty: {output_dir}")
    output_dir.mkdir(parents=True, exist_ok=True)
    with route_ground_state_to_writer():
        summary = solweig.calculate(
            surface,
            weather,
            location,
            output_dir=output_dir,
            outputs=requested,
            **kwargs,
        )
    ground_paths = finalize_ground_exports(output_dir)
    return summary, ground_paths
