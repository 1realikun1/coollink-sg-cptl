"""Run four-region SOLWEIG using quarter-hour multi-station weather backgrounds."""

from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import geopandas as gpd
import pandas as pd
import solweig
import yaml
from pyproj import CRS

from coollink_sg.heat.representative_solweig_timeseries import validate_surface_pair
from coollink_sg.heat.solweig_timeseries import sample_solweig_to_roads

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class RegionInput:
    region_id: str
    network_path: str
    building_dsm_path: str
    canopy_dsm_path: str


@dataclass(frozen=True)
class Config:
    analysis_id: str
    analysis_crs: str
    timezone: str
    interval_minutes: int
    max_shadow_distance_m: float
    edge_sampling_interval_m: float
    canopy_trunk_ratio: float
    use_anisotropic_sky: bool
    thermal_source_status: str
    regional_weather_path: str
    regions: tuple[RegionInput, ...]
    solweig_root: str
    heat_root: str
    summary_path: str
    provenance_path: str


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    if key not in mapping:
        raise ValueError(f"Missing required field '{section}.{key}'")
    return mapping[key]


def load_config(path: str | Path) -> Config:
    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Multi-station SOLWEIG configuration must be a mapping")
    model = _required(payload, "multistation_solweig", "root")
    inputs = _required(payload, "inputs", "root")
    outputs = _required(payload, "outputs", "root")
    crs = str(_required(model, "analysis_crs", "multistation_solweig"))
    if not CRS.from_user_input(crs).is_projected:
        raise ValueError("analysis_crs must be projected")
    regions = tuple(
        RegionInput(
            region_id=str(_required(item, "region_id", "inputs.regions")),
            network_path=str(_required(item, "network", "inputs.regions")),
            building_dsm_path=str(_required(item, "building_dsm", "inputs.regions")),
            canopy_dsm_path=str(_required(item, "canopy_dsm", "inputs.regions")),
        )
        for item in _required(inputs, "regions", "inputs")
    )
    if not regions or len({region.region_id for region in regions}) != len(regions):
        raise ValueError("At least one unique region is required")
    interval = int(_required(model, "interval_minutes", "multistation_solweig"))
    shadow = float(_required(model, "max_shadow_distance_m", "multistation_solweig"))
    sampling = float(_required(model, "edge_sampling_interval_m", "multistation_solweig"))
    trunk = float(_required(model, "canopy_trunk_ratio", "multistation_solweig"))
    if interval <= 0 or shadow <= 0 or sampling <= 0 or not 0 < trunk < 1:
        raise ValueError("SOLWEIG interval, distance, sampling, or trunk ratio is invalid")
    source_status = str(_required(model, "thermal_source_status", "multistation_solweig"))
    if "multistation" not in source_status or "not_field_validated" not in source_status:
        raise ValueError("Source status must retain multi-station and validation limits")
    return Config(
        analysis_id=str(_required(model, "analysis_id", "multistation_solweig")),
        analysis_crs=crs,
        timezone=str(_required(model, "timezone", "multistation_solweig")),
        interval_minutes=interval,
        max_shadow_distance_m=shadow,
        edge_sampling_interval_m=sampling,
        canopy_trunk_ratio=trunk,
        use_anisotropic_sky=bool(
            _required(model, "use_anisotropic_sky", "multistation_solweig")
        ),
        thermal_source_status=source_status,
        regional_weather_path=str(_required(inputs, "regional_weather", "inputs")),
        regions=regions,
        solweig_root=str(_required(outputs, "solweig_root", "outputs")),
        heat_root=str(_required(outputs, "heat_root", "outputs")),
        summary_path=str(_required(outputs, "summary", "outputs")),
        provenance_path=str(_required(outputs, "provenance", "outputs")),
    )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def validate_weather(frame: pd.DataFrame, config: Config, region_id: str) -> pd.DataFrame:
    required = {
        "region_id",
        "region_latitude",
        "region_longitude",
        "timestamp_sgt",
        "air_temperature_deg_c",
        "relative_humidity_percent",
        "wind_speed_m_s",
        "clear_sky_ghi_w_m2",
    }
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"Regional weather is missing fields: {sorted(missing)}")
    selected = frame.loc[frame["region_id"].eq(region_id)].copy()
    selected["timestamp_sgt"] = pd.to_datetime(selected["timestamp_sgt"])
    selected = selected.sort_values("timestamp_sgt")
    if selected.empty or selected["timestamp_sgt"].duplicated().any():
        raise ValueError(f"Weather for {region_id} is empty or duplicated")
    differences = selected["timestamp_sgt"].diff().dropna().dt.total_seconds()
    if not differences.eq(config.interval_minutes * 60).all():
        raise ValueError(f"Weather clock is incomplete for {region_id}")
    if not selected["relative_humidity_percent"].between(0, 100).all():
        raise ValueError(f"Relative humidity is invalid for {region_id}")
    if (selected["wind_speed_m_s"] < 0).any() or (selected["clear_sky_ghi_w_m2"] <= 0).any():
        raise ValueError(f"Wind speed or radiation is invalid for {region_id}")
    return selected


def run_multistation_solweig(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    config = load_config(config_path)
    weather_path = project_root / config.regional_weather_path
    weather_all = pd.read_csv(weather_path)
    records: list[dict[str, Any]] = []
    for index, region in enumerate(config.regions, start=1):
        print(
            f"[{index}/{len(config.regions)}] multi-station SOLWEIG {region.region_id}",
            flush=True,
        )
        weather = validate_weather(weather_all, config, region.region_id)
        latitude = float(weather.iloc[0]["region_latitude"])
        longitude = float(weather.iloc[0]["region_longitude"])
        network_path = project_root / region.network_path
        building_path = project_root / region.building_dsm_path
        canopy_path = project_root / region.canopy_dsm_path
        surface_metadata = validate_surface_pair(building_path, canopy_path, config.analysis_crs)
        edges = gpd.read_file(network_path, layer="edges").to_crs(config.analysis_crs)
        if edges["segment_id"].isna().any() or not edges["segment_id"].astype(str).is_unique:
            raise ValueError(f"{region.region_id} segment identifiers are invalid")
        output_directory = project_root / config.solweig_root / region.region_id
        output_directory.mkdir(parents=True, exist_ok=True)
        fingerprint = f"{_sha256(building_path)[:10]}_{_sha256(canopy_path)[:10]}"
        surface = solweig.SurfaceData.prepare(
            dsm=building_path,
            working_dir=(
                project_root
                / "data/interim/solweig"
                / f"{region.region_id}_{fingerprint}_5m_precomputed"
            ),
            cdsm=canopy_path,
            trunk_ratio=config.canopy_trunk_ratio,
            dsm_relative=False,
            cdsm_relative=True,
            force_recompute=False,
        )
        solweig_weather = [
            solweig.Weather(
                datetime=pd.Timestamp(row.timestamp_sgt).tz_localize(None).to_pydatetime(),
                ta=float(row.air_temperature_deg_c),
                rh=float(row.relative_humidity_percent),
                global_rad=float(row.clear_sky_ghi_w_m2),
                ws=float(row.wind_speed_m_s),
                timestep_minutes=config.interval_minutes,
            )
            for row in weather.itertuples(index=False)
        ]
        result = solweig.calculate(
            surface,
            solweig_weather,
            solweig.Location(latitude=latitude, longitude=longitude, utc_offset=8),
            output_dir=output_directory,
            use_anisotropic_sky=config.use_anisotropic_sky,
            max_shadow_distance_m=config.max_shadow_distance_m,
            outputs=["tmrt", "utci", "shadow"],
        )
        timestamps = pd.DatetimeIndex(weather["timestamp_sgt"])
        roads, sampling = sample_solweig_to_roads(
            edges,
            building_path,
            output_directory,
            timestamps,
            config.edge_sampling_interval_m,
            config.thermal_source_status,
        )
        heat_path = (
            project_root
            / config.heat_root
            / f"{region.region_id}_solweig_multistation_road_thermal_timeseries.csv"
        )
        heat_path.parent.mkdir(parents=True, exist_ok=True)
        roads.to_csv(heat_path, index=False)
        record = {
            "analysis_id": config.analysis_id,
            "region_id": region.region_id,
            "latitude": latitude,
            "longitude": longitude,
            "network_path": region.network_path,
            "network_sha256": _sha256(network_path),
            "building_dsm_sha256": _sha256(building_path),
            "canopy_dsm_sha256": _sha256(canopy_path),
            "weather_source_path": config.regional_weather_path,
            "weather_source_sha256": _sha256(weather_path),
            "road_timeseries_path": str(heat_path.relative_to(project_root)),
            "road_timeseries_sha256": _sha256(heat_path),
            "thermal_source_status": config.thermal_source_status,
            "paper_validation_ready": False,
            "solweig_version": solweig.__version__,
            "compute_backend": solweig.get_compute_backend(),
            "solweig_timesteps": int(result.n_timesteps),
            "solweig_daytime_timesteps": int(result.n_daytime),
            **surface_metadata,
            **sampling,
        }
        records.append(record)
    summary = pd.DataFrame(records)
    summary_path = project_root / config.summary_path
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary.to_csv(summary_path, index=False)
    provenance = {
        "analysis_id": config.analysis_id,
        "region_count": len(records),
        "thermal_source_status": config.thermal_source_status,
        "weather_source_sha256": _sha256(weather_path),
        "regions": records,
        "interpretation_warning": (
            "The run uses quarter-hour multi-station mesoscale weather and modeled "
            "clear-sky radiation. It remains uncalibrated against pedestrian-height "
            "MRT or UTCI observations."
        ),
    }
    provenance_path = project_root / config.provenance_path
    provenance_path.parent.mkdir(parents=True, exist_ok=True)
    provenance_path.write_text(
        json.dumps(provenance, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return provenance


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/multistation_solweig.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(run_multistation_solweig(args.config), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
