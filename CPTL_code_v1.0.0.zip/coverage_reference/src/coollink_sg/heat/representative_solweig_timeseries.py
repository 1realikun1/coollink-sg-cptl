"""Run comparable building-plus-canopy SOLWEIG fields for expansion regions."""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
import solweig
import yaml
from pyproj import CRS

from coollink_sg.heat.solweig_timeseries import (
    _sha256,
    build_weather_timeseries,
    extract_station_weather,
    sample_solweig_to_roads,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class RepresentativeThermalRegion:
    region_id: str
    network_path: str
    building_dsm_path: str
    canopy_dsm_path: str


@dataclass(frozen=True)
class RepresentativeSolweigTimeseriesConfig:
    analysis_id: str
    analysis_crs: str
    timezone: str
    start_sgt: str
    end_sgt: str
    interval_minutes: int
    max_shadow_distance_m: float
    edge_sampling_interval_m: float
    canopy_trunk_ratio: float
    use_anisotropic_sky: bool
    weather_station_id: str
    weather_snapshot_id: str
    thermal_source_status: str
    registry_path: str
    registry_layer: str
    weather_observations_path: str
    regions: tuple[RepresentativeThermalRegion, ...]
    solweig_root: str
    weather_root: str
    heat_root: str
    summary_path: str


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    if key not in mapping:
        raise ValueError(f"Missing required field '{section}.{key}'")
    return mapping[key]


def load_representative_solweig_timeseries_config(
    path: str | Path,
) -> RepresentativeSolweigTimeseriesConfig:
    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Representative SOLWEIG configuration must be a mapping")
    model = _required(payload, "representative_solweig_timeseries", "root")
    inputs = _required(payload, "inputs", "root")
    outputs = _required(payload, "outputs", "root")
    analysis_crs = str(_required(model, "analysis_crs", "model"))
    if not CRS.from_user_input(analysis_crs).is_projected:
        raise ValueError("representative SOLWEIG analysis_crs must be projected")
    interval = int(_required(model, "interval_minutes", "model"))
    if interval <= 0:
        raise ValueError("interval_minutes must be positive")
    trunk_ratio = float(_required(model, "canopy_trunk_ratio", "model"))
    if not 0 < trunk_ratio < 1:
        raise ValueError("canopy_trunk_ratio must be between zero and one")
    start = pd.Timestamp(str(_required(model, "start_sgt", "model")))
    end = pd.Timestamp(str(_required(model, "end_sgt", "model")))
    if start.tzinfo is None or end.tzinfo is None or end <= start:
        raise ValueError("SOLWEIG start/end must be ordered timezone-aware timestamps")
    if (end - start).total_seconds() % (interval * 60) != 0:
        raise ValueError("interval_minutes must divide the configured period")
    regions = tuple(
        RepresentativeThermalRegion(
            region_id=str(_required(item, "region_id", "inputs.regions")),
            network_path=str(_required(item, "network", "inputs.regions")),
            building_dsm_path=str(_required(item, "building_dsm", "inputs.regions")),
            canopy_dsm_path=str(_required(item, "canopy_dsm", "inputs.regions")),
        )
        for item in _required(inputs, "regions", "inputs")
    )
    if not regions or len({item.region_id for item in regions}) != len(regions):
        raise ValueError("At least one unique representative region is required")
    registry = _required(inputs, "representative_regions", "inputs")
    return RepresentativeSolweigTimeseriesConfig(
        analysis_id=str(_required(model, "analysis_id", "model")),
        analysis_crs=analysis_crs,
        timezone=str(_required(model, "timezone", "model")),
        start_sgt=start.isoformat(),
        end_sgt=end.isoformat(),
        interval_minutes=interval,
        max_shadow_distance_m=float(_required(model, "max_shadow_distance_m", "model")),
        edge_sampling_interval_m=float(
            _required(model, "edge_sampling_interval_m", "model")
        ),
        canopy_trunk_ratio=trunk_ratio,
        use_anisotropic_sky=bool(_required(model, "use_anisotropic_sky", "model")),
        weather_station_id=str(_required(model, "weather_station_id", "model")),
        weather_snapshot_id=str(_required(model, "weather_snapshot_id", "model")),
        thermal_source_status=str(_required(model, "thermal_source_status", "model")),
        registry_path=str(_required(registry, "path", "inputs.representative_regions")),
        registry_layer=str(_required(registry, "layer", "inputs.representative_regions")),
        weather_observations_path=str(
            _required(inputs, "weather_observations", "inputs")
        ),
        regions=regions,
        solweig_root=str(_required(outputs, "solweig_root", "outputs")),
        weather_root=str(_required(outputs, "weather_root", "outputs")),
        heat_root=str(_required(outputs, "heat_root", "outputs")),
        summary_path=str(_required(outputs, "summary", "outputs")),
    )


def validate_surface_pair(
    building_dsm_path: Path,
    canopy_dsm_path: Path,
    analysis_crs: str,
) -> dict[str, Any]:
    """Validate grid identity and relative-CDSM zero-value semantics."""

    with rasterio.open(building_dsm_path) as dsm, rasterio.open(canopy_dsm_path) as cdsm:
        if dsm.crs != CRS.from_user_input(analysis_crs) or cdsm.crs != dsm.crs:
            raise ValueError("Building and canopy surfaces must use the analysis CRS")
        if (
            dsm.width != cdsm.width
            or dsm.height != cdsm.height
            or dsm.transform != cdsm.transform
        ):
            raise ValueError("Building and canopy surfaces must share an identical grid")
        if cdsm.nodata is not None and np.isclose(cdsm.nodata, 0):
            raise ValueError("Zero must be valid no-canopy data, not canopy nodata")
        building = dsm.read(1)
        canopy = cdsm.read(1)
        if not np.isfinite(building).all() or (building < 0).any():
            raise ValueError("Building DSM must contain finite non-negative heights")
        valid_canopy = canopy if cdsm.nodata is None else canopy[~np.isclose(canopy, cdsm.nodata)]
        if not np.isfinite(valid_canopy).all() or (valid_canopy < 0).any():
            raise ValueError("Canopy DSM must contain finite non-negative relative heights")
        overlap = (building > 0) & (canopy > 0)
        if np.any(overlap):
            raise ValueError("Canopy DSM must be zero where the building DSM is positive")
        return {
            "width": dsm.width,
            "height": dsm.height,
            "bounds": list(dsm.bounds),
            "resolution_m": abs(float(dsm.transform.a)),
            "building_positive_pixel_count": int(np.count_nonzero(building > 0)),
            "canopy_positive_pixel_count": int(np.count_nonzero(canopy > 0)),
            "building_maximum_height_m": float(building.max()),
            "canopy_maximum_height_m": float(valid_canopy.max()),
            "canopy_nodata": cdsm.nodata,
        }


def run_representative_solweig_timeseries(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Run every configured expansion region under one comparable scenario."""

    config = load_representative_solweig_timeseries_config(config_path)
    registry = gpd.read_file(
        project_root / config.registry_path, layer=config.registry_layer
    )
    observations = pd.read_csv(project_root / config.weather_observations_path)
    station = extract_station_weather(
        observations, config.weather_station_id, config.weather_snapshot_id
    )
    timestamps = pd.date_range(
        config.start_sgt,
        config.end_sgt,
        freq=pd.to_timedelta(config.interval_minutes, unit="min"),
    )
    records: list[dict[str, Any]] = []
    for index, region in enumerate(config.regions, start=1):
        print(f"[{index}/{len(config.regions)}] SOLWEIG {region.region_id}", flush=True)
        registry_row = registry.loc[registry["region_id"].eq(region.region_id)]
        if len(registry_row) != 1:
            raise ValueError(f"Expected one registry row for {region.region_id}")
        latitude = float(registry_row.iloc[0]["latitude"])
        longitude = float(registry_row.iloc[0]["longitude"])
        network_path = project_root / region.network_path
        building_path = project_root / region.building_dsm_path
        canopy_path = project_root / region.canopy_dsm_path
        surface_metadata = validate_surface_pair(
            building_path, canopy_path, config.analysis_crs
        )
        edges = gpd.read_file(network_path, layer="edges").to_crs(config.analysis_crs)
        if edges["segment_id"].isna().any() or not edges["segment_id"].astype(str).is_unique:
            raise ValueError(f"{region.region_id} network segment_id values must be unique")
        weather = build_weather_timeseries(
            timestamps, latitude, longitude, config.timezone, station
        )
        weather_path = (
            project_root / config.weather_root / f"{region.region_id}_clear_sky_weather.csv"
        )
        weather_path.parent.mkdir(parents=True, exist_ok=True)
        weather.to_csv(weather_path, index=False)
        output_directory = project_root / config.solweig_root / region.region_id
        output_directory.mkdir(parents=True, exist_ok=True)
        fingerprint = f"{_sha256(building_path)[:10]}_{_sha256(canopy_path)[:10]}"
        surface = solweig.SurfaceData.prepare(
            dsm=building_path,
            working_dir=(
                project_root
                / "data/interim/solweig"
                / f"{region.region_id}_{fingerprint}_5m_precomputed"
            ),
            cdsm=canopy_path,
            trunk_ratio=config.canopy_trunk_ratio,
            dsm_relative=False,
            cdsm_relative=True,
            force_recompute=False,
        )
        solweig_weather = [
            solweig.Weather(
                datetime=pd.Timestamp(row.timestamp_sgt).tz_localize(None).to_pydatetime(),
                ta=float(row.air_temperature_deg_c),
                rh=float(row.relative_humidity_percent),
                global_rad=float(row.clear_sky_ghi_w_m2),
                ws=float(row.wind_speed_m_s),
                timestep_minutes=config.interval_minutes,
            )
            for row in weather.itertuples(index=False)
        ]
        result = solweig.calculate(
            surface,
            solweig_weather,
            solweig.Location(latitude=latitude, longitude=longitude, utc_offset=8),
            output_dir=output_directory,
            use_anisotropic_sky=config.use_anisotropic_sky,
            max_shadow_distance_m=config.max_shadow_distance_m,
            outputs=["tmrt", "utci", "shadow"],
        )
        roads, sampling = sample_solweig_to_roads(
            edges,
            building_path,
            output_directory,
            timestamps,
            config.edge_sampling_interval_m,
            config.thermal_source_status,
        )
        heat_path = (
            project_root
            / config.heat_root
            / f"{region.region_id}_solweig_canopy_road_thermal_timeseries.csv"
        )
        heat_path.parent.mkdir(parents=True, exist_ok=True)
        roads.to_csv(heat_path, index=False)
        record = {
            "analysis_id": config.analysis_id,
            "region_id": region.region_id,
            "latitude": latitude,
            "longitude": longitude,
            "network_path": region.network_path,
            "network_sha256": _sha256(network_path),
            "building_dsm_sha256": _sha256(building_path),
            "canopy_dsm_sha256": _sha256(canopy_path),
            "weather_timeseries_sha256": _sha256(weather_path),
            "road_timeseries_path": str(heat_path.relative_to(project_root)),
            "road_timeseries_sha256": _sha256(heat_path),
            "thermal_source_status": config.thermal_source_status,
            "paper_validation_ready": False,
            "solweig_version": solweig.__version__,
            "compute_backend": solweig.get_compute_backend(),
            "solweig_timesteps": int(result.n_timesteps),
            "solweig_daytime_timesteps": int(result.n_daytime),
            **surface_metadata,
            **sampling,
        }
        summary_path = heat_path.with_name(f"{heat_path.stem}_summary.json")
        summary_path.write_text(
            json.dumps(record, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        records.append(record)
    summary = pd.DataFrame(records)
    output_summary = project_root / config.summary_path
    output_summary.parent.mkdir(parents=True, exist_ok=True)
    summary.to_csv(output_summary, index=False)
    return {
        "analysis_id": config.analysis_id,
        "region_count": len(records),
        "thermal_source_status": config.thermal_source_status,
        "regions": records,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/representative_solweig_timeseries.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(run_representative_solweig_timeseries(args.config), indent=2))


if __name__ == "__main__":
    main()
