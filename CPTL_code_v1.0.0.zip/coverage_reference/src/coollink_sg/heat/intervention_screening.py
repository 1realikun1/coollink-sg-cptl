"""Exploratory shade-intervention candidate screening, not priority scoring."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import pandas as pd
from pyproj import CRS

from coollink_sg.config import (
    InterventionScreeningConfig,
    load_intervention_screening_config,
)
from coollink_sg.heat.road_exposure_proxy import COMPONENT_FIELDS

PROJECT_ROOT = Path(__file__).resolve().parents[3]


def compute_intervention_screening(
    exposure: gpd.GeoDataFrame,
    config: InterventionScreeningConfig,
) -> gpd.GeoDataFrame:
    """Rank a declared symmetric-sweep diagnostic while retaining uncertainty."""

    required = {
        "segment_id",
        "geometry",
        config.screening_field,
        config.sensitivity_field,
        config.scenario_frequency_field,
        *COMPONENT_FIELDS,
    }
    missing = required.difference(exposure.columns)
    if missing:
        raise ValueError(f"Exposure table is missing fields: {sorted(missing)}")
    if exposure.crs is None:
        raise ValueError("Exposure table must have an explicit CRS")
    if CRS.from_user_input(exposure.crs) != CRS.from_user_input(config.output_crs):
        raise ValueError(f"Exposure CRS must equal configured {config.output_crs}")
    if exposure["segment_id"].isna().any() or not exposure["segment_id"].is_unique:
        raise ValueError("segment_id values must be complete and unique")
    fields = [
        config.screening_field,
        config.sensitivity_field,
        config.scenario_frequency_field,
        *COMPONENT_FIELDS,
    ]
    numeric = exposure[fields].apply(pd.to_numeric, errors="raise")
    if numeric.isna().any().any() or not ((numeric >= 0) & (numeric <= 1)).all().all():
        raise ValueError("Intervention-screening inputs must be complete and within 0–1")

    result = exposure[["segment_id", *fields, "geometry"]].copy()
    result["screening_percentile"] = numeric[config.screening_field].rank(
        method="average", pct=True
    )
    result["exploratory_screening_rank"] = numeric[config.screening_field].rank(
        method="min", ascending=False
    ).astype(int)
    threshold = 1 - config.diagnostic_top_fraction
    result["top_screening_fraction_flag"] = (
        result["screening_percentile"] >= threshold
    ).astype(int)
    result["analysis_id"] = config.analysis_id
    result["ranking_method"] = config.ranking_method
    result["screening_status"] = (
        "exploratory_candidate_screening_not_validated_intervention_priority"
    )
    result["preferred_intervention_priority"] = "none"
    if "priority_score" in result.columns or "heat_score" in result.columns:
        raise ValueError("Screening result must not contain priority_score or heat_score")
    return gpd.GeoDataFrame(result, geometry="geometry", crs=exposure.crs)


def summarize_intervention_screening(
    result: gpd.GeoDataFrame,
    config: InterventionScreeningConfig,
) -> dict[str, Any]:
    """Summarize screening coverage with an explicit non-priority warning."""

    return {
        "analysis_id": config.analysis_id,
        "segment_count": len(result),
        "ranking_method": config.ranking_method,
        "diagnostic_top_fraction": config.diagnostic_top_fraction,
        "top_screening_segment_count": int(result["top_screening_fraction_flag"].sum()),
        "maximum_weight_sensitivity_rank_range": round(
            float(result[config.sensitivity_field].max()), 6
        ),
        "preferred_intervention_priority": None,
        "validated_priority_generated": False,
        "warning": (
            "This is an exploratory candidate-screening percentile based on the "
            "symmetric exposure-proxy weight sweep. It is not a benefit estimate, "
            "cost-effectiveness ranking, validated intervention priority, or Heat Score."
        ),
    }


def _screening_colour(value: float) -> str:
    value = max(0.0, min(1.0, float(value)))
    red = round(80 + 175 * value)
    green = round(180 - 125 * value)
    blue = round(105 - 55 * value)
    return f"#{red:02x}{green:02x}{blue:02x}"


def create_intervention_screening_map(
    result: gpd.GeoDataFrame,
    config: InterventionScreeningConfig,
    output_path: Path,
) -> None:
    """Create a warning-labelled candidate screening map."""

    display = result.to_crs("EPSG:4326").copy()
    tooltip_fields = [
        "segment_id",
        "screening_percentile",
        "exploratory_screening_rank",
        "top_screening_fraction_flag",
        config.sensitivity_field,
        config.scenario_frequency_field,
        *COMPONENT_FIELDS,
    ]
    display[[field for field in tooltip_fields if field != "segment_id"]] = display[
        [field for field in tooltip_fields if field != "segment_id"]
    ].round(3)
    center = display.geometry.union_all().centroid
    map_object = folium.Map(
        location=[center.y, center.x], zoom_start=14, tiles="OpenStreetMap", control_scale=True
    )
    folium.GeoJson(
        display[[*tooltip_fields, "geometry"]].to_json(),
        name="Exploratory intervention screening",
        style_function=lambda feature: {
            "color": _screening_colour(feature["properties"]["screening_percentile"]),
            "weight": 3,
            "opacity": 0.8,
        },
        tooltip=folium.GeoJsonTooltip(fields=tooltip_fields),
    ).add_to(map_object)
    legend = """
    <div style="position:fixed;bottom:30px;left:30px;z-index:9999;background:white;
      padding:10px;border:1px solid #777;font-size:12px"><b>Candidate screening</b><br>
      Green: lower percentile &nbsp; Red: higher percentile<br>
      <small>Symmetric proxy sweep only; not validated intervention priority,<br>
      benefit, cost-effectiveness, or Heat Score.</small></div>
    """
    map_object.get_root().html.add_child(folium.Element(legend))
    folium.LayerControl().add_to(map_object)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    map_object.save(output_path)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def build_intervention_screening(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Build and export the intervention candidate-screening artifact."""

    config = load_intervention_screening_config(config_path)
    input_path = project_root / config.exposure.path
    exposure = gpd.read_file(input_path, layer=config.exposure.layer)
    result = compute_intervention_screening(exposure, config)
    summary = summarize_intervention_screening(result, config)
    summary["input_sha256"] = _sha256(input_path)

    processed = project_root / "data/processed/planning"
    tables = project_root / "outputs/tables"
    maps = project_root / "outputs/maps"
    processed.mkdir(parents=True, exist_ok=True)
    tables.mkdir(parents=True, exist_ok=True)
    geopackage = processed / "shade_intervention_candidate_screening.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    result.to_file(geopackage, layer="candidate_screening", driver="GPKG")
    result.drop(columns="geometry").to_csv(
        processed / "shade_intervention_candidate_screening.csv", index=False
    )
    (processed / "shade_intervention_candidate_screening_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    pd.DataFrame([summary]).to_csv(
        tables / "shade_intervention_candidate_screening_summary.csv", index=False
    )
    create_intervention_screening_map(
        result, config, maps / "clementi_shade_intervention_candidate_screening.html"
    )
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(
        description="Build exploratory shade-intervention candidate screening."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/intervention_screening.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(build_intervention_screening(args.config), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
