"""Compare building-only and building-plus-canopy SOLWEIG/CPTL scenarios."""

from __future__ import annotations

import argparse
import html
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[3]
ROAD_KEYS = ["segment_id", "timestamp_sgt"]
ROUTE_KEYS = ["departure_time_sgt", "detour_limit_fraction"]
THERMAL_FIELDS = [
    "road_mean_tmrt_deg_c",
    "modeled_utci_deg_c",
    "road_mean_sun_fraction",
]


def compare_road_timeseries(
    building_only: pd.DataFrame,
    building_canopy: pd.DataFrame,
) -> pd.DataFrame:
    """Return an exact road-time join with canopy-minus-baseline deltas."""

    required = set(ROAD_KEYS + THERMAL_FIELDS + ["sample_cell_count"])
    for name, frame in [("building_only", building_only), ("building_canopy", building_canopy)]:
        missing = required.difference(frame.columns)
        if missing:
            raise ValueError(f"{name} thermal series is missing fields: {sorted(missing)}")
        if frame.duplicated(ROAD_KEYS).any():
            raise ValueError(f"{name} thermal series has duplicate road-time keys")
    merged = building_only[ROAD_KEYS + THERMAL_FIELDS + ["sample_cell_count"]].merge(
        building_canopy[ROAD_KEYS + THERMAL_FIELDS + ["sample_cell_count"]],
        on=ROAD_KEYS,
        how="outer",
        suffixes=("_building_only", "_building_canopy"),
        indicator=True,
        validate="one_to_one",
    )
    if not merged["_merge"].eq("both").all():
        raise ValueError("Thermal scenarios do not have identical road-time keys")
    if not merged["sample_cell_count_building_only"].equals(
        merged["sample_cell_count_building_canopy"]
    ):
        raise ValueError("Thermal scenarios use different road sample cells")
    merged = merged.drop(columns="_merge")
    for field in THERMAL_FIELDS:
        merged[f"delta_{field}_canopy_minus_building_only"] = (
            merged[f"{field}_building_canopy"]
            - merged[f"{field}_building_only"]
        )
    return merged


def summarize_road_deltas(comparison: pd.DataFrame) -> pd.DataFrame:
    """Summarize the road-time paired differences at every modeled timestamp."""

    rows: list[dict[str, Any]] = []
    for timestamp, frame in comparison.groupby("timestamp_sgt", sort=True):
        row: dict[str, Any] = {
            "timestamp_sgt": timestamp,
            "road_record_count": len(frame),
        }
        for field in THERMAL_FIELDS:
            delta_field = f"delta_{field}_canopy_minus_building_only"
            values = frame[delta_field]
            row[f"mean_{field}_building_only"] = frame[
                f"{field}_building_only"
            ].mean()
            row[f"mean_{field}_building_canopy"] = frame[
                f"{field}_building_canopy"
            ].mean()
            row[f"mean_{delta_field}"] = values.mean()
            row[f"median_{delta_field}"] = values.median()
            row[f"q05_{delta_field}"] = values.quantile(0.05)
            row[f"q95_{delta_field}"] = values.quantile(0.95)
            row[f"fraction_{field}_decreased"] = float(np.mean(values < 0))
        rows.append(row)
    return pd.DataFrame(rows)


def compare_routes(
    building_only: pd.DataFrame,
    building_canopy: pd.DataFrame,
) -> pd.DataFrame:
    """Pair routes under identical departure and detour constraints."""

    required = set(
        ROUTE_KEYS
        + [
            "route_id",
            "route_length_m",
            "route_mean_utci_deg_c",
            "cptl_above_26_deg_c_min",
            "primary_cptl_reduction_vs_shortest_percent",
        ]
    )
    for name, frame in [("building_only", building_only), ("building_canopy", building_canopy)]:
        missing = required.difference(frame.columns)
        if missing:
            raise ValueError(f"{name} route table is missing fields: {sorted(missing)}")
        if frame.duplicated(ROUTE_KEYS).any():
            raise ValueError(f"{name} route table has duplicate scenario keys")
    merged = building_only.merge(
        building_canopy,
        on=ROUTE_KEYS,
        suffixes=("_building_only", "_building_canopy"),
        how="outer",
        indicator=True,
        validate="one_to_one",
    )
    if not merged["_merge"].eq("both").all():
        raise ValueError("Route scenarios do not share identical departure/detour keys")
    merged = merged.drop(columns="_merge")
    merged["route_changed"] = (
        merged["route_id_building_only"] != merged["route_id_building_canopy"]
    )
    for field in [
        "route_length_m",
        "route_mean_utci_deg_c",
        "cptl_above_26_deg_c_min",
        "primary_cptl_reduction_vs_shortest_percent",
    ]:
        merged[f"delta_{field}_canopy_minus_building_only"] = (
            merged[f"{field}_building_canopy"]
            - merged[f"{field}_building_only"]
        )
    merged["cptl_change_percent_canopy_minus_building_only"] = 100 * (
        merged["cptl_above_26_deg_c_min_building_canopy"]
        / merged["cptl_above_26_deg_c_min_building_only"]
        - 1
    )
    return merged


def build_summary(
    road_comparison: pd.DataFrame,
    route_comparison: pd.DataFrame,
) -> dict[str, Any]:
    """Build a compact, provenance-aware sensitivity summary."""

    overall: dict[str, Any] = {}
    for field in THERMAL_FIELDS:
        delta = road_comparison[f"delta_{field}_canopy_minus_building_only"]
        overall[field] = {
            "mean_delta_canopy_minus_building_only": float(delta.mean()),
            "median_delta_canopy_minus_building_only": float(delta.median()),
            "q05_delta": float(delta.quantile(0.05)),
            "q95_delta": float(delta.quantile(0.95)),
            "fraction_decreased": float(np.mean(delta < 0)),
            "fraction_unchanged": float(np.mean(np.isclose(delta, 0))),
        }
    shortest = route_comparison.loc[route_comparison["detour_limit_fraction"].eq(0)].copy()
    flexible = route_comparison.loc[route_comparison["detour_limit_fraction"].gt(0)].copy()
    return {
        "analysis_id": "clementi_building_plus_chmv2_canopy_sensitivity_v1",
        "comparison_design": (
            "paired building-only versus building-plus-CHMv2 SOLWEIG scenarios with "
            "identical buildings, weather, clock, raster grid, road samples and routing rules"
        ),
        "road_time_record_count": len(road_comparison),
        "segment_count": int(road_comparison["segment_id"].nunique()),
        "timestamp_count": int(road_comparison["timestamp_sgt"].nunique()),
        "road_time_effects": overall,
        "shortest_route_cptl_change_percent_by_departure": {
            str(row.departure_time_sgt): float(
                row.cptl_change_percent_canopy_minus_building_only
            )
            for row in shortest.itertuples(index=False)
        },
        "flexible_route_scenario_count": len(flexible),
        "flexible_route_changed_count": int(flexible["route_changed"].sum()),
        "canopy_scenario_internal_cptl_reduction_range_percent": [
            float(
                flexible[
                    "primary_cptl_reduction_vs_shortest_percent_building_canopy"
                ].min()
            ),
            float(
                flexible[
                    "primary_cptl_reduction_vs_shortest_percent_building_canopy"
                ].max()
            ),
        ],
        "interpretation_limit": (
            "CHMv2 is a predicted canopy-height product and this is a clear-sky, flat-ground, "
            "static-station sensitivity scenario without Singapore field validation. Paired "
            "differences are model effects, not observed causal cooling estimates."
        ),
    }


def render_figure(
    time_summary: pd.DataFrame,
    route_comparison: pd.DataFrame,
    output_path: Path,
) -> None:
    """Render the principal thermal and route results as dependency-free SVG."""

    width, height = 1200, 480
    left = (75, 70, 500, 330)
    right = (665, 70, 480, 330)
    mrt = time_summary[
        "mean_delta_road_mean_tmrt_deg_c_canopy_minus_building_only"
    ].to_numpy()
    utci = time_summary[
        "mean_delta_modeled_utci_deg_c_canopy_minus_building_only"
    ].to_numpy()
    y_min = float(min(mrt.min(), utci.min(), 0))
    y_max = float(max(mrt.max(), utci.max(), 0))
    y_pad = max((y_max - y_min) * 0.08, 0.25)
    y_min -= y_pad
    y_max += y_pad

    def line_points(values: np.ndarray) -> str:
        points = []
        for index, value in enumerate(values):
            x = left[0] + index * left[2] / max(len(values) - 1, 1)
            y = left[1] + (y_max - float(value)) * left[3] / (y_max - y_min)
            points.append(f"{x:.1f},{y:.1f}")
        return " ".join(points)

    selected = route_comparison.loc[
        route_comparison["detour_limit_fraction"].eq(0.15)
    ].reset_index(drop=True)
    base_bars = selected[
        "primary_cptl_reduction_vs_shortest_percent_building_only"
    ].to_numpy()
    canopy_bars = selected[
        "primary_cptl_reduction_vs_shortest_percent_building_canopy"
    ].to_numpy()
    bar_max = max(float(base_bars.max()), float(canopy_bars.max()), 1.0) * 1.12
    svg = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="white"/>',
        '<style>text{font-family:Arial,sans-serif;fill:#24364B}.title{font-size:18px;'
        'font-weight:700}.axis{stroke:#8090A5;stroke-width:1}.tick{font-size:12px}'
        '.label{font-size:13px}.legend{font-size:12px}</style>',
        '<text x="75" y="32" class="title">Paired road-time thermal effect</text>',
        '<text x="665" y="32" class="title">CPTL benefit within 15% distance cap</text>',
    ]
    for panel in [left, right]:
        svg.append(
            f'<line x1="{panel[0]}" y1="{panel[1] + panel[3]}" '
            f'x2="{panel[0] + panel[2]}" y2="{panel[1] + panel[3]}" class="axis"/>'
        )
        svg.append(
            f'<line x1="{panel[0]}" y1="{panel[1]}" x2="{panel[0]}" '
            f'y2="{panel[1] + panel[3]}" class="axis"/>'
        )
    zero_y = left[1] + (y_max - 0) * left[3] / (y_max - y_min)
    svg.append(
        f'<line x1="{left[0]}" y1="{zero_y:.1f}" x2="{left[0] + left[2]}" '
        f'y2="{zero_y:.1f}" stroke="#B8C1CC" stroke-dasharray="4 4"/>'
    )
    svg.append(
        f'<polyline points="{line_points(mrt)}" fill="none" stroke="#2C7FB8" '
        'stroke-width="3"/>'
    )
    svg.append(
        f'<polyline points="{line_points(utci)}" fill="none" stroke="#159A92" '
        'stroke-width="3"/>'
    )
    hours = pd.to_datetime(time_summary["timestamp_sgt"]).dt.strftime("%H:%M")
    for index in range(0, len(hours), 4):
        x = left[0] + index * left[2] / max(len(hours) - 1, 1)
        svg.append(
            f'<text x="{x:.1f}" y="420" text-anchor="middle" class="tick">'
            f'{html.escape(hours.iloc[index])}</text>'
        )
    svg.extend(
        [
            '<line x1="90" y1="445" x2="120" y2="445" stroke="#2C7FB8" '
            'stroke-width="3"/><text x="128" y="449" class="legend">Mean MRT change</text>',
            '<line x1="280" y1="445" x2="310" y2="445" stroke="#159A92" '
            'stroke-width="3"/><text x="318" y="449" class="legend">Mean UTCI change</text>',
        ]
    )
    group_width = right[2] / max(len(selected), 1)
    for index, row in selected.iterrows():
        center = right[0] + (index + 0.5) * group_width
        for offset, value, color in [
            (-13, base_bars[index], "#377EB8"),
            (13, canopy_bars[index], "#159A92"),
        ]:
            bar_height = float(value) / bar_max * right[3]
            svg.append(
                f'<rect x="{center + offset - 10:.1f}" y="{right[1] + right[3] - bar_height:.1f}" '
                f'width="20" height="{bar_height:.1f}" fill="{color}"/>'
            )
        label = pd.Timestamp(row["departure_time_sgt"]).strftime("%H:%M")
        svg.append(
            f'<text x="{center:.1f}" y="420" text-anchor="middle" class="tick">'
            f'{html.escape(label)}</text>'
        )
    svg.extend(
        [
            '<rect x="735" y="438" width="14" height="14" fill="#377EB8"/>'
            '<text x="756" y="449" class="legend">Building-only</text>',
            '<rect x="890" y="438" width="14" height="14" fill="#159A92"/>'
            '<text x="911" y="449" class="legend">Building + CHMv2</text>',
            '</svg>',
        ]
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(svg), encoding="utf-8")


def run_canopy_sensitivity(project_root: Path = PROJECT_ROOT) -> dict[str, Any]:
    """Run the paired comparison and write compact analysis outputs."""

    heat = project_root / "data/processed/heat"
    routing = project_root / "data/processed/routing"
    building_only = pd.read_csv(heat / "clementi_solweig_road_thermal_timeseries.csv")
    building_canopy = pd.read_csv(
        heat / "clementi_solweig_canopy_road_thermal_timeseries.csv"
    )
    road_comparison = compare_road_timeseries(building_only, building_canopy)
    time_summary = summarize_road_deltas(road_comparison)
    route_comparison = compare_routes(
        pd.read_csv(routing / "clementi_time_dependent_cptl_solweig_routes.csv"),
        pd.read_csv(routing / "clementi_time_dependent_cptl_solweig_canopy_routes.csv"),
    )
    summary = build_summary(road_comparison, route_comparison)

    time_path = heat / "clementi_canopy_thermal_comparison_by_time.csv"
    route_path = routing / "clementi_canopy_route_comparison.csv"
    summary_path = project_root / "outputs/tables/clementi_canopy_sensitivity_summary.json"
    figure_path = project_root / "outputs/figures/clementi_canopy_sensitivity.svg"
    time_summary.to_csv(time_path, index=False)
    route_comparison.to_csv(route_path, index=False)
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    render_figure(time_summary, route_comparison, figure_path)
    return summary | {
        "time_summary_path": str(time_path),
        "route_comparison_path": str(route_path),
        "summary_path": str(summary_path),
        "figure_path": str(figure_path),
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Compare Clementi building-only and CHMv2-canopy SOLWEIG scenarios."
    )
    parser.parse_args()
    print(json.dumps(run_canopy_sensitivity(), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
