"""Exploratory road heat-exposure proxy with a complete weight sweep."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import numpy as np
import pandas as pd
from pyproj import CRS

from coollink_sg.config import (
    RoadHeatExposureProxyConfig,
    load_road_heat_exposure_proxy_config,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]
COMPONENT_FIELDS = (
    "exposure_component_wbgt_station_context_0_1",
    "exposure_component_shade_deficit_0_1",
    "exposure_component_vegetation_context_deficit_0_1",
)


def generate_three_component_weight_scenarios(
    config: RoadHeatExposureProxyConfig,
) -> pd.DataFrame:
    """Enumerate the complete configured three-component simplex."""

    steps = round(1 / config.weight_step)
    rows: list[dict[str, float | str | bool]] = []
    scenario_index = 0
    for wbgt_units in range(steps + 1):
        for shade_units in range(steps - wbgt_units + 1):
            vegetation_units = steps - wbgt_units - shade_units
            rows.append(
                {
                    "scenario_id": f"simplex_{scenario_index:03d}_of_{steps:03d}",
                    "weight_wbgt_station_context": wbgt_units / steps,
                    "weight_shade_deficit": shade_units / steps,
                    "weight_vegetation_context_deficit": vegetation_units / steps,
                    "weight_sum": 1.0,
                    "preferred_scenario": False,
                }
            )
            scenario_index += 1
    return pd.DataFrame(rows)


def prepare_exposure_components(
    road_features: gpd.GeoDataFrame,
    weather_associations: pd.DataFrame,
    weather_observations: pd.DataFrame,
    config: RoadHeatExposureProxyConfig,
) -> tuple[gpd.GeoDataFrame, dict[str, Any]]:
    """Join context-only WBGT and create three directionally aligned proxies."""

    required_roads = {
        "segment_id",
        "geometry",
        config.shade_field,
        config.vegetation_field,
    }
    missing_roads = required_roads.difference(road_features.columns)
    if missing_roads:
        raise ValueError(f"Road features are missing fields: {sorted(missing_roads)}")
    if road_features.crs is None:
        raise ValueError("Road features must have an explicit CRS")
    if CRS.from_user_input(road_features.crs) != CRS.from_user_input(config.output_crs):
        raise ValueError(f"Road feature CRS must equal configured {config.output_crs}")
    if road_features["segment_id"].isna().any() or not road_features["segment_id"].is_unique:
        raise ValueError("Road segment_id values must be complete and unique")

    association_fields = {
        "segment_id",
        "metric",
        "source_station_id",
        "source_station_name",
        "source_value",
        "source_unit",
        "observed_at_sgt",
        "road_midpoint_to_station_distance_m",
        "weather_snapshot_id",
        "association_status",
    }
    missing_associations = association_fields.difference(weather_associations.columns)
    if missing_associations:
        raise ValueError(
            f"Weather associations are missing fields: {sorted(missing_associations)}"
        )
    associations = weather_associations.loc[
        weather_associations["metric"].eq(config.weather_metric),
        sorted(association_fields),
    ].copy()
    if len(associations) != len(road_features):
        raise ValueError("WBGT association count must equal road count")
    if associations["segment_id"].isna().any() or not associations["segment_id"].is_unique:
        raise ValueError("WBGT associations must have one complete row per segment_id")
    if set(associations["segment_id"]) != set(road_features["segment_id"]):
        raise ValueError("WBGT association segment IDs must exactly match road features")
    if not associations["association_status"].eq(
        "context_only_not_road_observation"
    ).all():
        raise ValueError("WBGT associations must retain context-only status")

    required_observations = {"metric", "value", "quality_flag", "station_id"}
    missing_observations = required_observations.difference(weather_observations.columns)
    if missing_observations:
        raise ValueError(
            f"Weather observations are missing fields: {sorted(missing_observations)}"
        )
    valid_wbgt = weather_observations.loc[
        weather_observations["metric"].eq(config.weather_metric)
        & weather_observations["quality_flag"].eq("valid")
    ].copy()
    valid_wbgt["value"] = pd.to_numeric(valid_wbgt["value"], errors="raise")
    if valid_wbgt.empty or valid_wbgt["value"].isna().any():
        raise ValueError("No complete valid WBGT snapshot observations are available")
    national_min = float(valid_wbgt["value"].min())
    national_max = float(valid_wbgt["value"].max())
    if national_min >= national_max:
        raise ValueError("Valid national WBGT snapshot must have a non-zero range")

    joined = road_features[
        ["segment_id", config.shade_field, config.vegetation_field, "geometry"]
    ].merge(
        associations.drop(columns=["metric", "association_status"]),
        on="segment_id",
        how="left",
        validate="one_to_one",
    )
    numeric = joined[
        [config.shade_field, config.vegetation_field, "source_value"]
    ].apply(pd.to_numeric, errors="raise")
    if numeric.isna().any().any():
        raise ValueError("Exposure-proxy inputs cannot contain missing values")
    if not numeric[config.shade_field].between(0, 1).all():
        raise ValueError("Shade evidence must be between 0 and 1")
    if not numeric[config.vegetation_field].between(0, 1).all():
        raise ValueError("Vegetation context must be between 0 and 1")
    if not numeric["source_value"].between(national_min, national_max).all():
        raise ValueError("Assigned WBGT values fall outside the source snapshot range")

    result = joined.rename(
        columns={
            "source_station_id": "wbgt_source_station_id",
            "source_station_name": "wbgt_source_station_name",
            "source_value": "wbgt_station_context_deg_c",
            "source_unit": "wbgt_source_unit",
            "observed_at_sgt": "wbgt_observed_at_sgt",
            "road_midpoint_to_station_distance_m": "wbgt_station_distance_m",
        }
    )
    result[COMPONENT_FIELDS[0]] = (
        result["wbgt_station_context_deg_c"] - national_min
    ) / (national_max - national_min)
    result[COMPONENT_FIELDS[1]] = 1 - numeric[config.shade_field].to_numpy()
    result[COMPONENT_FIELDS[2]] = 1 - numeric[config.vegetation_field].to_numpy()
    components = result[list(COMPONENT_FIELDS)]
    if not ((components >= 0) & (components <= 1)).all().all():
        raise ValueError("Normalized exposure-proxy components must be within 0–1")
    metadata = {
        "weather_normalization": config.weather_normalization,
        "valid_national_wbgt_station_count": int(valid_wbgt["station_id"].nunique()),
        "national_snapshot_wbgt_min_deg_c": national_min,
        "national_snapshot_wbgt_max_deg_c": national_max,
        "assigned_wbgt_station_count": int(result["wbgt_source_station_id"].nunique()),
        "assigned_wbgt_values_deg_c": sorted(
            float(value) for value in result["wbgt_station_context_deg_c"].unique()
        ),
        "median_road_to_wbgt_station_distance_m": round(
            float(result["wbgt_station_distance_m"].median()), 6
        ),
        "maximum_road_to_wbgt_station_distance_m": round(
            float(result["wbgt_station_distance_m"].max()), 6
        ),
    }
    return gpd.GeoDataFrame(result, geometry="geometry", crs=road_features.crs), metadata


def compute_exposure_proxy_sensitivity(
    components: gpd.GeoDataFrame,
    config: RoadHeatExposureProxyConfig,
) -> tuple[gpd.GeoDataFrame, pd.DataFrame]:
    """Evaluate all weights while selecting no preferred scenario."""

    required = {"segment_id", "geometry", *COMPONENT_FIELDS}
    missing = required.difference(components.columns)
    if missing:
        raise ValueError(f"Prepared components are missing fields: {sorted(missing)}")
    if components["segment_id"].isna().any() or not components["segment_id"].is_unique:
        raise ValueError("Prepared segment_id values must be complete and unique")
    values = components[list(COMPONENT_FIELDS)].apply(pd.to_numeric, errors="raise")
    if values.isna().any().any() or not ((values >= 0) & (values <= 1)).all().all():
        raise ValueError("Prepared components must be complete and within 0–1")

    scenarios = generate_three_component_weight_scenarios(config)
    weight_fields = [
        "weight_wbgt_station_context",
        "weight_shade_deficit",
        "weight_vegetation_context_deficit",
    ]
    scores = values.to_numpy(dtype=float) @ scenarios[weight_fields].to_numpy(dtype=float).T
    ranks = np.column_stack(
        [
            pd.Series(scores[:, index]).rank(method="average", pct=True).to_numpy()
            for index in range(scores.shape[1])
        ]
    )
    result = components.copy()
    result["exposure_proxy_min_across_weights"] = scores.min(axis=1)
    result["exposure_proxy_max_across_weights"] = scores.max(axis=1)
    result["exposure_proxy_mean_across_weights"] = scores.mean(axis=1)
    result["exposure_proxy_std_across_weights"] = scores.std(axis=1)
    result["exposure_proxy_range_across_weights"] = np.ptp(scores, axis=1)
    result["exposure_rank_percentile_min_across_weights"] = ranks.min(axis=1)
    result["exposure_rank_percentile_max_across_weights"] = ranks.max(axis=1)
    result["exposure_rank_percentile_range_across_weights"] = np.ptp(ranks, axis=1)
    top_threshold = 1 - config.diagnostic_top_fraction
    result["top_exposure_fraction_scenario_frequency"] = (
        ranks >= top_threshold
    ).mean(axis=1)
    result["component_disagreement_range"] = np.ptp(values.to_numpy(), axis=1)
    result["analysis_id"] = config.analysis_id
    result["preferred_weight_scenario"] = "none"
    result["proxy_status"] = "exploratory_context_and_proxy_sensitivity_not_heat_score"
    if "heat_score" in result.columns:
        raise ValueError("Exploratory result must not contain heat_score")
    return gpd.GeoDataFrame(result, geometry="geometry", crs=components.crs), scenarios


def summarize_exposure_proxy(
    result: gpd.GeoDataFrame,
    scenarios: pd.DataFrame,
    metadata: dict[str, Any],
    config: RoadHeatExposureProxyConfig,
) -> dict[str, Any]:
    """Summarize coverage and sensitivity without selecting a score."""

    score_range = result["exposure_proxy_range_across_weights"]
    rank_range = result["exposure_rank_percentile_range_across_weights"]
    return {
        "analysis_id": config.analysis_id,
        "segment_count": len(result),
        "weight_scenario_count": len(scenarios),
        "weight_step": config.weight_step,
        "component_count": 3,
        "component_interpretations": config.component_interpretations,
        "preferred_weight_scenario": None,
        **metadata,
        "mean_proxy_range_across_weights": round(float(score_range.mean()), 6),
        "median_proxy_range_across_weights": round(float(score_range.median()), 6),
        "mean_rank_percentile_range_across_weights": round(float(rank_range.mean()), 6),
        "segments_top_ranked_in_every_scenario": int(
            (result["top_exposure_fraction_scenario_frequency"] == 1).sum()
        ),
        "segments_never_top_ranked": int(
            (result["top_exposure_fraction_scenario_frequency"] == 0).sum()
        ),
        "heat_score_generated": False,
        "validated_road_weather_generated": False,
        "warning": (
            "This is an exploratory relative road heat-exposure proxy sensitivity "
            "analysis. Nearest-station WBGT is context only; shade and vegetation "
            "inputs are incomplete proxies. No preferred weights, validated road "
            "weather, thermal-comfort index, or Heat Score are generated."
        ),
    }


def _exposure_colour(value: float) -> str:
    value = max(0.0, min(1.0, float(value)))
    red = 220
    green = round(210 - 155 * value)
    blue = round(80 - 40 * value)
    return f"#{red:02x}{green:02x}{blue:02x}"


def create_exposure_proxy_map(result: gpd.GeoDataFrame, output_path: Path) -> None:
    """Map the symmetric-sweep mean with explicit non-score warnings."""

    display = result.to_crs("EPSG:4326").copy()
    fields = [
        "segment_id",
        "wbgt_station_context_deg_c",
        "wbgt_station_distance_m",
        *COMPONENT_FIELDS,
        "exposure_proxy_mean_across_weights",
        "exposure_proxy_range_across_weights",
        "exposure_rank_percentile_range_across_weights",
        "preferred_weight_scenario",
    ]
    display[fields[1:-1]] = display[fields[1:-1]].round(3)
    center = display.geometry.union_all().centroid
    map_object = folium.Map(
        location=[center.y, center.x], zoom_start=14, tiles="OpenStreetMap", control_scale=True
    )
    folium.GeoJson(
        display[[*fields, "geometry"]].to_json(),
        name="Symmetric weight-sweep mean (exploratory)",
        style_function=lambda feature: {
            "color": _exposure_colour(
                feature["properties"]["exposure_proxy_mean_across_weights"]
            ),
            "weight": 3,
            "opacity": 0.8,
        },
        tooltip=folium.GeoJsonTooltip(fields=fields),
    ).add_to(map_object)
    legend = """
    <div style="position:fixed;bottom:30px;left:30px;z-index:9999;background:white;
      padding:10px;border:1px solid #777;font-size:12px"><b>Exploratory exposure proxy</b><br>
      Yellow: lower sweep mean &nbsp; Red: higher sweep mean<br>
      <small>Nearest-station WBGT context + incomplete shade/green proxies.<br>
      No preferred weights; not Heat Score or measured road exposure.</small></div>
    """
    map_object.get_root().html.add_child(folium.Element(legend))
    folium.LayerControl().add_to(map_object)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    map_object.save(output_path)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def build_road_heat_exposure_proxy(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Build and export the exploratory road exposure sensitivity analysis."""

    config = load_road_heat_exposure_proxy_config(config_path)
    road_path = project_root / config.road_features.path
    association_path = project_root / config.weather_associations_path
    observation_path = project_root / config.weather_observations_path
    roads = gpd.read_file(road_path, layer=config.road_features.layer)
    associations = pd.read_csv(association_path, low_memory=False)
    observations = pd.read_csv(observation_path, low_memory=False)
    components, metadata = prepare_exposure_components(
        roads, associations, observations, config
    )
    result, scenarios = compute_exposure_proxy_sensitivity(components, config)
    summary = summarize_exposure_proxy(result, scenarios, metadata, config)
    summary["input_sha256"] = {
        "road_features": _sha256(road_path),
        "weather_associations": _sha256(association_path),
        "weather_observations": _sha256(observation_path),
    }

    processed = project_root / "data/processed/heat"
    tables = project_root / "outputs/tables"
    maps = project_root / "outputs/maps"
    processed.mkdir(parents=True, exist_ok=True)
    tables.mkdir(parents=True, exist_ok=True)
    geopackage = processed / "road_heat_exposure_proxy_sensitivity.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    result.to_file(geopackage, layer="road_exposure_proxy_sensitivity", driver="GPKG")
    result.drop(columns="geometry").to_csv(
        processed / "road_heat_exposure_proxy_sensitivity.csv", index=False
    )
    scenarios.to_csv(
        processed / "road_heat_exposure_proxy_weight_scenarios.csv", index=False
    )
    (processed / "road_heat_exposure_proxy_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    pd.DataFrame(
        [{key: value for key, value in summary.items() if not isinstance(value, dict)}]
    ).to_csv(tables / "road_heat_exposure_proxy_summary.csv", index=False)
    create_exposure_proxy_map(
        result, maps / "clementi_road_heat_exposure_proxy_sensitivity.html"
    )
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(
        description="Build exploratory road heat-exposure proxy sensitivity."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/road_heat_exposure_proxy.yaml",
    )
    args = parser.parse_args()
    print(
        json.dumps(
            build_road_heat_exposure_proxy(args.config), indent=2, ensure_ascii=False
        )
    )


if __name__ == "__main__":
    main()
