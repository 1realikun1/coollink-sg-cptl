"""OFAT CHMv2 canopy-structure sensitivity for SOLWEIG and dynamic CPTL."""

from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any

import geopandas as gpd
import pandas as pd
import yaml

from coollink_sg.config import DynamicCPTLConfig, load_dynamic_cptl_config
from coollink_sg.heat.dynamic_utci import TimeVaryingUTCI
from coollink_sg.heat.solweig_timeseries import run_solweig_timeseries
from coollink_sg.routing.algorithm_sensitivity import summarize_algorithm_sensitivity
from coollink_sg.routing.multi_od_cptl import _routing_graph
from coollink_sg.routing.time_dependent_cptl import compute_time_dependent_cptl_routes

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class CanopySensitivityConfig:
    """Validated orchestration settings for canopy-structure sensitivity."""

    analysis_id: str
    design: str
    base_solweig_config: str
    base_dynamic_cptl_config: str
    od_sample: str
    baseline_routes_geopackage: str
    baseline_routes_layer: str
    output_stem: str
    height_multipliers: tuple[float, ...]
    minimum_heights_m: tuple[float, ...]
    trunk_ratios: tuple[float, ...]
    detour_limits: tuple[float, ...]
    baseline_height_multiplier: float
    baseline_minimum_height_m: float
    baseline_trunk_ratio: float


@dataclass(frozen=True)
class CanopyVariant:
    """One baseline or single-factor CHMv2 canopy perturbation."""

    variant_id: str
    varied_parameter: str
    varied_value: float
    height_multiplier: float
    minimum_height_m: float
    trunk_ratio: float


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    if key not in mapping:
        raise ValueError(f"Missing required field {section}.{key}")
    return mapping[key]


def load_canopy_sensitivity_config(path: Path) -> CanopySensitivityConfig:
    """Load the explicit OFAT canopy sensitivity design."""

    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Canopy sensitivity configuration must be a YAML mapping")
    analysis = _required(payload, "canopy_parameter_sensitivity", "root")
    parameters = _required(payload, "parameters", "root")
    baseline = _required(payload, "baseline", "root")
    design = str(_required(analysis, "design", "canopy_parameter_sensitivity"))
    if design != "one_factor_at_a_time":
        raise ValueError("Only one_factor_at_a_time canopy sensitivity is supported")

    heights = tuple(
        float(value) for value in _required(parameters, "height_multipliers", "parameters")
    )
    minimums = tuple(
        float(value) for value in _required(parameters, "minimum_canopy_heights_m", "parameters")
    )
    trunks = tuple(float(value) for value in _required(parameters, "trunk_ratios", "parameters"))
    limits = tuple(float(value) for value in _required(parameters, "detour_limits", "parameters"))
    if any(value <= 0 for value in heights) or len(set(heights)) != len(heights):
        raise ValueError("height_multipliers must contain unique positive values")
    if any(value < 0 for value in minimums) or len(set(minimums)) != len(minimums):
        raise ValueError("minimum canopy heights must be unique and non-negative")
    if any(not 0 < value < 1 for value in trunks) or len(set(trunks)) != len(trunks):
        raise ValueError("trunk_ratios must contain unique values between zero and one")
    if not limits or limits[0] != 0 or limits != tuple(sorted(set(limits))):
        raise ValueError("detour_limits must be unique, increasing, and start at zero")
    base_height = float(_required(baseline, "height_multiplier", "baseline"))
    base_minimum = float(_required(baseline, "minimum_canopy_height_m", "baseline"))
    base_trunk = float(_required(baseline, "trunk_ratio", "baseline"))
    if base_height not in heights or base_minimum not in minimums or base_trunk not in trunks:
        raise ValueError("Every canopy baseline must be included in its parameter values")
    output_stem = str(_required(analysis, "output_stem", "canopy_parameter_sensitivity"))
    if not output_stem or Path(output_stem).name != output_stem:
        raise ValueError("output_stem must be a filename stem")
    return CanopySensitivityConfig(
        analysis_id=str(_required(analysis, "analysis_id", "canopy_parameter_sensitivity")),
        design=design,
        base_solweig_config=str(
            _required(analysis, "base_solweig_config", "canopy_parameter_sensitivity")
        ),
        base_dynamic_cptl_config=str(
            _required(analysis, "base_dynamic_cptl_config", "canopy_parameter_sensitivity")
        ),
        od_sample=str(_required(analysis, "od_sample", "canopy_parameter_sensitivity")),
        baseline_routes_geopackage=str(
            _required(analysis, "baseline_routes_geopackage", "canopy_parameter_sensitivity")
        ),
        baseline_routes_layer=str(
            _required(analysis, "baseline_routes_layer", "canopy_parameter_sensitivity")
        ),
        output_stem=output_stem,
        height_multipliers=heights,
        minimum_heights_m=minimums,
        trunk_ratios=trunks,
        detour_limits=limits,
        baseline_height_multiplier=base_height,
        baseline_minimum_height_m=base_minimum,
        baseline_trunk_ratio=base_trunk,
    )


def build_canopy_variants(config: CanopySensitivityConfig) -> tuple[CanopyVariant, ...]:
    """Return the canopy baseline and six single-factor perturbations."""

    variants = [
        CanopyVariant(
            variant_id="baseline",
            varied_parameter="baseline",
            varied_value=0.0,
            height_multiplier=config.baseline_height_multiplier,
            minimum_height_m=config.baseline_minimum_height_m,
            trunk_ratio=config.baseline_trunk_ratio,
        )
    ]
    for value in config.height_multipliers:
        if value != config.baseline_height_multiplier:
            variants.append(
                CanopyVariant(
                    variant_id=f"height_multiplier_{str(value).replace('.', 'p')}",
                    varied_parameter="height_multiplier",
                    varied_value=value,
                    height_multiplier=value,
                    minimum_height_m=config.baseline_minimum_height_m,
                    trunk_ratio=config.baseline_trunk_ratio,
                )
            )
    for value in config.minimum_heights_m:
        if value != config.baseline_minimum_height_m:
            variants.append(
                CanopyVariant(
                    variant_id=f"minimum_height_{str(value).replace('.', 'p')}m",
                    varied_parameter="minimum_canopy_height_m",
                    varied_value=value,
                    height_multiplier=config.baseline_height_multiplier,
                    minimum_height_m=value,
                    trunk_ratio=config.baseline_trunk_ratio,
                )
            )
    for value in config.trunk_ratios:
        if value != config.baseline_trunk_ratio:
            variants.append(
                CanopyVariant(
                    variant_id=f"trunk_ratio_{str(value).replace('.', 'p')}",
                    varied_parameter="trunk_ratio",
                    varied_value=value,
                    height_multiplier=config.baseline_height_multiplier,
                    minimum_height_m=config.baseline_minimum_height_m,
                    trunk_ratio=value,
                )
            )
    return tuple(variants)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _materialize_solweig_config(
    base_payload: dict[str, Any],
    variant: CanopyVariant,
    output_path: Path,
) -> tuple[Path, str, str]:
    """Write one fully expanded SOLWEIG variant config under data/interim."""

    payload = json.loads(json.dumps(base_payload))
    slug = variant.variant_id
    status = (
        f"solweig_building_chmv2_canopy_{slug}_clear_sky_static_station_context_not_field_validated"
    )
    model = payload["solweig_timeseries"]
    model["analysis_id"] = f"clementi_chmv2_canopy_{slug}_clear_sky_v1"
    model["thermal_source_status"] = status
    canopy = payload["inputs"]["canopy"]
    canopy["height_multiplier"] = variant.height_multiplier
    canopy["minimum_height_m"] = variant.minimum_height_m
    canopy["trunk_ratio"] = variant.trunk_ratio
    outputs = payload["outputs"]
    outputs["canopy_dsm"] = f"data/processed/solweig/inputs/clementi_chmv2_{slug}_dsm_5m.tif"
    outputs["solweig_directory"] = f"data/processed/solweig/runs/clementi_chmv2_{slug}_clear_sky_v1"
    road_path = f"data/processed/heat/clementi_chmv2_{slug}_road_thermal_timeseries.csv"
    outputs["road_timeseries"] = road_path
    outputs["weather_timeseries"] = (
        f"data/processed/solweig/weather/clementi_chmv2_{slug}_weather_timeseries.csv"
    )
    outputs["readiness"] = f"data/processed/solweig/clementi_chmv2_{slug}_readiness.json"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")
    return output_path, road_path, status


def _existing_complete_thermal(path: Path, status: str) -> bool:
    summary_path = path.with_name(f"{path.stem}_summary.json")
    if not path.exists() or not summary_path.exists():
        return False
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    recorded_hash = str(summary.get("road_timeseries_sha256", "")).lower()
    return (
        summary.get("thermal_source_status") == status
        and recorded_hash == _sha256(path).lower()
        and summary.get("sampling", {}).get("row_count") == 606356
    )


def _thermal_summary(
    baseline: pd.DataFrame,
    variant: pd.DataFrame,
    canopy_variant: CanopyVariant,
) -> dict[str, Any]:
    keys = ["segment_id", "timestamp_sgt"]
    if not baseline[keys].equals(variant[keys]):
        raise ValueError(f"Thermal keys differ for {canopy_variant.variant_id}")
    row: dict[str, Any] = {
        **canopy_variant.__dict__,
        "road_time_record_count": len(variant),
    }
    for field in ["road_mean_tmrt_deg_c", "modeled_utci_deg_c", "road_mean_sun_fraction"]:
        delta = variant[field] - baseline[field]
        row[f"mean_delta_{field}"] = float(delta.mean())
        row[f"median_delta_{field}"] = float(delta.median())
        row[f"q05_delta_{field}"] = float(delta.quantile(0.05))
        row[f"q95_delta_{field}"] = float(delta.quantile(0.95))
    return row


def run_canopy_parameter_sensitivity(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Run or resume SOLWEIG variants, route them, and summarize sensitivity."""

    sensitivity = load_canopy_sensitivity_config(config_path)
    variants = build_canopy_variants(sensitivity)
    base_solweig_path = project_root / sensitivity.base_solweig_config
    base_payload = yaml.safe_load(base_solweig_path.read_text(encoding="utf-8"))
    base_dynamic = load_dynamic_cptl_config(project_root / sensitivity.base_dynamic_cptl_config)
    baseline_thermal_path = project_root / base_dynamic.dynamic_thermal_path
    thermal_sources: dict[str, tuple[Path, str]] = {
        "baseline": (baseline_thermal_path, base_dynamic.thermal_source_status)
    }
    generated_dir = project_root / "data/interim/solweig/canopy_parameter_sensitivity/configs"
    for index, variant in enumerate(variants[1:], start=1):
        generated_path, road_relative, status = _materialize_solweig_config(
            base_payload,
            variant,
            generated_dir / f"{variant.variant_id}.yaml",
        )
        road_path = project_root / road_relative
        if _existing_complete_thermal(road_path, status):
            print(f"[SOLWEIG {index}/6] reuse {variant.variant_id}", flush=True)
        else:
            print(f"[SOLWEIG {index}/6] run {variant.variant_id}", flush=True)
            run_solweig_timeseries(generated_path, project_root)
        thermal_sources[variant.variant_id] = (road_path, status)

    baseline_thermal = pd.read_csv(baseline_thermal_path)
    thermal_rows = [
        {
            **variants[0].__dict__,
            "road_time_record_count": len(baseline_thermal),
            "mean_delta_road_mean_tmrt_deg_c": 0.0,
            "median_delta_road_mean_tmrt_deg_c": 0.0,
            "q05_delta_road_mean_tmrt_deg_c": 0.0,
            "q95_delta_road_mean_tmrt_deg_c": 0.0,
            "mean_delta_modeled_utci_deg_c": 0.0,
            "median_delta_modeled_utci_deg_c": 0.0,
            "q05_delta_modeled_utci_deg_c": 0.0,
            "q95_delta_modeled_utci_deg_c": 0.0,
            "mean_delta_road_mean_sun_fraction": 0.0,
            "median_delta_road_mean_sun_fraction": 0.0,
            "q05_delta_road_mean_sun_fraction": 0.0,
            "q95_delta_road_mean_sun_fraction": 0.0,
        }
    ]
    for variant in variants[1:]:
        thermal_rows.append(
            _thermal_summary(
                baseline_thermal,
                pd.read_csv(thermal_sources[variant.variant_id][0]),
                variant,
            )
        )
    thermal_summary = pd.DataFrame(thermal_rows)

    network_path = project_root / base_dynamic.network_path
    nodes = gpd.read_file(network_path, layer=base_dynamic.nodes_layer)
    edges = gpd.read_file(network_path, layer=base_dynamic.edges_layer)
    graph = _routing_graph(nodes, edges, base_dynamic.output_crs)
    od_sample = pd.read_csv(project_root / sensitivity.od_sample)
    route_interim = project_root / "data/interim/routing/canopy_parameter_sensitivity"
    route_interim.mkdir(parents=True, exist_ok=True)
    route_frames: list[gpd.GeoDataFrame] = []
    baseline_all = gpd.read_file(
        project_root / sensitivity.baseline_routes_geopackage,
        layer=sensitivity.baseline_routes_layer,
    )
    baseline_routes = baseline_all.loc[
        baseline_all["thermal_scenario"].eq("building_canopy_chmv2")
        & baseline_all["detour_limit_fraction"].isin(sensitivity.detour_limits)
    ].copy()
    baseline_routes.insert(0, "variant_id", "baseline")
    baseline_routes.insert(1, "varied_parameter", "baseline")
    baseline_routes.insert(2, "varied_value", 0.0)
    baseline_routes["height_multiplier"] = sensitivity.baseline_height_multiplier
    baseline_routes["minimum_height_m"] = sensitivity.baseline_minimum_height_m
    baseline_routes["trunk_ratio"] = sensitivity.baseline_trunk_ratio
    route_frames.append(baseline_routes)

    for variant_index, variant in enumerate(variants[1:], start=1):
        interim_path = route_interim / f"{variant.variant_id}.gpkg"
        if interim_path.exists():
            existing = gpd.read_file(interim_path, layer="routes")
            if len(existing) == len(od_sample) * len(base_dynamic.departure_times) * len(
                sensitivity.detour_limits
            ):
                print(f"[ROUTING {variant_index}/6] reuse {variant.variant_id}", flush=True)
                route_frames.append(existing)
                continue
        thermal_path, status = thermal_sources[variant.variant_id]
        thermal = TimeVaryingUTCI(
            pd.read_csv(thermal_path),
            base_dynamic.primary_height_scenario,
            status,
        )
        run_config: DynamicCPTLConfig = replace(
            base_dynamic,
            analysis_id=f"{sensitivity.analysis_id}|{variant.variant_id}",
            detour_limits=sensitivity.detour_limits,
            thermal_source_status=status,
            dynamic_thermal_path=str(thermal_path.relative_to(project_root)),
        )
        variant_frames: list[gpd.GeoDataFrame] = []
        for od_index, od in enumerate(od_sample.itertuples(index=False), start=1):
            print(
                f"[ROUTING {variant_index}/6 {variant.variant_id}] "
                f"OD {od_index}/{len(od_sample)} {od.od_id}",
                flush=True,
            )
            routes, _, _ = compute_time_dependent_cptl_routes(
                nodes,
                edges,
                thermal,
                int(od.origin_node),
                int(od.destination_node),
                run_config,
                routing_graph=graph,
            )
            routes.insert(0, "variant_id", variant.variant_id)
            routes.insert(1, "varied_parameter", variant.varied_parameter)
            routes.insert(2, "varied_value", variant.varied_value)
            routes.insert(3, "height_multiplier", variant.height_multiplier)
            routes.insert(4, "minimum_height_m", variant.minimum_height_m)
            routes.insert(5, "trunk_ratio", variant.trunk_ratio)
            routes.insert(6, "od_id", od.od_id)
            routes.insert(7, "origin_node", int(od.origin_node))
            routes.insert(8, "destination_node", int(od.destination_node))
            routes.insert(9, "distance_band_rank", int(od.distance_band_rank))
            variant_frames.append(routes)
        variant_routes = gpd.GeoDataFrame(
            pd.concat(variant_frames, ignore_index=True),
            geometry="geometry",
            crs=base_dynamic.output_crs,
        )
        if interim_path.exists():
            interim_path.unlink()
        variant_routes.to_file(interim_path, layer="routes", driver="GPKG")
        route_frames.append(variant_routes)

    all_routes = gpd.GeoDataFrame(
        pd.concat(route_frames, ignore_index=True),
        geometry="geometry",
        crs=base_dynamic.output_crs,
    )
    route_summary_input = all_routes.copy()
    route_summary_input["time_bin_seconds"] = base_dynamic.time_bin_seconds
    route_summary_input["walking_speed_m_s"] = base_dynamic.walking_speed_m_s
    route_summary_input["primary_threshold_deg_c"] = base_dynamic.primary_threshold_deg_c
    route_summary = summarize_algorithm_sensitivity(route_summary_input)
    route_summary = route_summary.drop(
        columns=["time_bin_seconds", "walking_speed_m_s", "primary_threshold_deg_c"]
    ).merge(
        pd.DataFrame([variant.__dict__ for variant in variants]),
        on=["variant_id", "varied_parameter", "varied_value"],
        validate="many_to_one",
    )

    processed = project_root / "data/processed/routing"
    output_gpkg = processed / f"{sensitivity.output_stem}.gpkg"
    if output_gpkg.exists():
        output_gpkg.unlink()
    all_routes.to_file(output_gpkg, layer="canopy_sensitivity_routes", driver="GPKG")
    all_routes.drop(columns="geometry").to_csv(
        processed / f"{sensitivity.output_stem}_routes.csv", index=False
    )
    route_summary.to_csv(processed / f"{sensitivity.output_stem}_route_summary.csv", index=False)
    heat_processed = project_root / "data/processed/heat"
    thermal_summary.to_csv(
        heat_processed / f"{sensitivity.output_stem}_thermal_summary.csv", index=False
    )
    five = route_summary.loc[route_summary["detour_limit_fraction"].eq(0.05)]
    result = {
        "analysis_id": sensitivity.analysis_id,
        "design": sensitivity.design,
        "variant_count": len(variants),
        "new_solweig_run_count": len(variants) - 1,
        "od_count": int(od_sample["od_id"].nunique()),
        "route_scenario_count": len(all_routes),
        "five_percent_cap_median_reduction_range_percent": [
            float(five["median_cptl_reduction_percent"].min()),
            float(five["median_cptl_reduction_percent"].max()),
        ],
        "thermal_sources": {
            key: {
                "path": str(path.relative_to(project_root)),
                "sha256": _sha256(path),
                "thermal_source_status": status,
            }
            for key, (path, status) in thermal_sources.items()
        },
        "interpretation_limit": (
            "This OFAT analysis perturbs a predicted CHMv2 canopy product in a clear-sky, "
            "flat-ground SOLWEIG design scenario. It does not estimate parameter probability, "
            "interactions, local canopy accuracy, causal cooling, or field validity."
        ),
        "outputs": {
            "geopackage": str(output_gpkg.relative_to(project_root)),
            "routes_csv": f"data/processed/routing/{sensitivity.output_stem}_routes.csv",
            "route_summary_csv": (
                f"data/processed/routing/{sensitivity.output_stem}_route_summary.csv"
            ),
            "thermal_summary_csv": (
                f"data/processed/heat/{sensitivity.output_stem}_thermal_summary.csv"
            ),
        },
    }
    result_path = processed / f"{sensitivity.output_stem}.json"
    result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="Run CHMv2 canopy parameter sensitivity.")
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/canopy_parameter_sensitivity.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(run_canopy_parameter_sensitivity(args.config), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
