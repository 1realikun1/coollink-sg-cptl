"""Transparent heat-score engine with an explicit readiness gate."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import geopandas as gpd
import numpy as np
import pandas as pd

from coollink_sg.config import HeatModelConfig, load_heat_model_config

PROJECT_ROOT = Path(__file__).resolve().parents[3]


def heat_model_issues(
    features: gpd.GeoDataFrame,
    config: HeatModelConfig,
) -> list[dict[str, str]]:
    """Return every condition preventing a defensible configured score run."""

    issues: list[dict[str, str]] = []

    def add(code: str, detail: str, component: str = "model") -> None:
        issues.append({"code": code, "component": component, "detail": detail})

    if not config.enabled:
        add("model_disabled", "heat_model.enabled is false")
    if "segment_id" not in features.columns:
        add("missing_segment_id", "Input table has no segment_id field")
    elif features["segment_id"].isna().any() or not features["segment_id"].is_unique:
        add("invalid_segment_id", "segment_id must be complete and unique")
    if features.crs is None:
        add("missing_crs", "Input road features must have an explicit CRS")

    weights: list[float] = []
    all_weights_configured = True
    for component in config.components:
        name = component.name
        if component.input_field not in features.columns:
            add(
                "missing_input_field",
                f"Required field '{component.input_field}' is unavailable",
                name,
            )
        elif features[component.input_field].isna().any():
            add(
                "missing_input_values",
                f"Field '{component.input_field}' contains missing values",
                name,
            )
        if component.weight is None:
            all_weights_configured = False
            add("missing_weight", "No research-approved weight is configured", name)
        elif not 0 <= component.weight <= 1:
            add("invalid_weight", "Weight must be between 0 and 1", name)
        else:
            weights.append(component.weight)
        if component.reference_min is None or component.reference_max is None:
            add(
                "missing_reference_bounds",
                "Normalization reference_min and reference_max are required",
                name,
            )
        elif component.reference_min >= component.reference_max:
            add(
                "invalid_reference_bounds",
                "reference_min must be less than reference_max",
                name,
            )
    if all_weights_configured and not np.isclose(sum(weights), 1.0, atol=1e-9):
        add("invalid_weight_sum", f"Configured weights sum to {sum(weights):.12g}, not 1")
    return issues


def audit_heat_model_readiness(
    features: gpd.GeoDataFrame,
    config: HeatModelConfig,
) -> dict[str, Any]:
    """Create a structured audit without substituting proxies or parameters."""

    issues = heat_model_issues(features, config)
    components = []
    for component in config.components:
        components.append(
            {
                "component": component.name,
                "required_input_field": component.input_field,
                "input_available": component.input_field in features.columns,
                "direction": component.direction,
                "weight_configured": component.weight is not None,
                "reference_bounds_configured": (
                    component.reference_min is not None
                    and component.reference_max is not None
                ),
                "proxy_candidate_field": component.proxy_candidate_field,
                "proxy_candidate_available": (
                    component.proxy_candidate_field in features.columns
                    if component.proxy_candidate_field is not None
                    else False
                ),
                "proxy_substitution_performed": False,
                "unavailable_reason": component.unavailable_reason,
            }
        )
    return {
        "model_id": config.model_id,
        "model_enabled": config.enabled,
        "ready": not issues,
        "status": "ready" if not issues else "not_ready_no_score_generated",
        "segment_count": len(features),
        "issue_count": len(issues),
        "issues": issues,
        "components": components,
        "warning": (
            "Candidate proxy fields are reported for review only. They are never "
            "substituted for required validated heat-model inputs."
        ),
    }


def compute_heat_scores(
    features: gpd.GeoDataFrame,
    config: HeatModelConfig,
) -> gpd.GeoDataFrame:
    """Compute a configured score only after every readiness check succeeds."""

    issues = heat_model_issues(features, config)
    if issues:
        codes = ", ".join(issue["code"] for issue in issues)
        raise ValueError(f"Heat model is not ready: {codes}")

    result = features.copy()
    total = pd.Series(0.0, index=result.index)
    for component in config.components:
        values = pd.to_numeric(result[component.input_field], errors="raise")
        normalized = (
            (values - component.reference_min)
            / (component.reference_max - component.reference_min)
        ).clip(0, 1)
        if component.direction == "higher_is_cooler":
            normalized = 1 - normalized
        component_field = f"heat_component_{component.name}_0_1"
        contribution_field = f"heat_contribution_{component.name}_0_1"
        result[component_field] = normalized
        result[contribution_field] = normalized * component.weight
        total += result[contribution_field]

    result["heat_model_id"] = config.model_id
    result["heat_score"] = config.score_min + total * (
        config.score_max - config.score_min
    )
    if not result["heat_score"].between(config.score_min, config.score_max).all():
        raise ValueError("Computed heat_score is outside the configured score range")
    return gpd.GeoDataFrame(result, geometry="geometry", crs=features.crs)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def run_heat_model_readiness(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Audit the current table and score it only if explicitly fully configured."""

    config = load_heat_model_config(config_path)
    input_path = project_root / "data/processed/features/clementi_road_feature_table.gpkg"
    features = gpd.read_file(input_path, layer="road_features")
    audit = audit_heat_model_readiness(features, config)
    audit["input_path"] = str(input_path)
    audit["input_sha256"] = _sha256(input_path)

    processed = project_root / "data/processed/heat"
    tables = project_root / "outputs/tables"
    processed.mkdir(parents=True, exist_ok=True)
    tables.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(audit["components"]).to_csv(
        tables / "heat_model_readiness_components.csv", index=False
    )
    pd.DataFrame(audit["issues"]).to_csv(
        tables / "heat_model_readiness_issues.csv", index=False
    )

    if audit["ready"]:
        scored = compute_heat_scores(features, config)
        output = processed / "clementi_road_heat_scores.gpkg"
        if output.exists():
            output.unlink()
        scored.to_file(output, layer="road_heat_scores", driver="GPKG")
        scored.drop(columns="geometry").to_csv(
            processed / "clementi_road_heat_scores.csv", index=False
        )
        audit["score_output_generated"] = True
    else:
        audit["score_output_generated"] = False
    (processed / "heat_model_readiness.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return audit


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(
        description="Audit and, only when fully configured, run baseline heat scoring."
    )
    parser.add_argument(
        "--config", type=Path, default=PROJECT_ROOT / "config/heat_model.yaml"
    )
    args = parser.parse_args()
    print(json.dumps(run_heat_model_readiness(args.config), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
