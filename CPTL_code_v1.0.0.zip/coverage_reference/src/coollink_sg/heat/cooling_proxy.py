"""Exploratory cooling-support proxy sensitivity analysis without Heat Score."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import numpy as np
import pandas as pd
from pyproj import CRS

from coollink_sg.config import (
    CoolingProxySensitivityConfig,
    load_cooling_proxy_sensitivity_config,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]


def generate_weight_scenarios(
    config: CoolingProxySensitivityConfig,
) -> pd.DataFrame:
    """Generate the complete configured two-component simplex, including endpoints."""

    steps = round(1 / config.weight_step)
    first, second = config.components
    rows = []
    for index in range(steps + 1):
        first_weight = index / steps
        second_weight = 1 - first_weight
        rows.append(
            {
                "scenario_id": f"weight_{index:03d}_of_{steps:03d}",
                f"weight_{first.name}": first_weight,
                f"weight_{second.name}": second_weight,
                "weight_sum": first_weight + second_weight,
                "preferred_scenario": False,
            }
        )
    return pd.DataFrame(rows)


def compute_cooling_proxy_sensitivity(
    features: gpd.GeoDataFrame,
    config: CoolingProxySensitivityConfig,
) -> tuple[gpd.GeoDataFrame, pd.DataFrame]:
    """Sweep all configured weights and retain only cross-scenario diagnostics."""

    fields = [component.input_field for component in config.components]
    required = {"segment_id", "geometry", *fields}
    missing = required.difference(features.columns)
    if missing:
        raise ValueError(f"Road feature table is missing fields: {sorted(missing)}")
    if features.crs is None:
        raise ValueError("Road features must have an explicit CRS")
    if CRS.from_user_input(features.crs) != CRS.from_user_input(config.output_crs):
        raise ValueError(f"Road feature CRS must equal configured {config.output_crs}")
    if features["segment_id"].isna().any() or not features["segment_id"].is_unique:
        raise ValueError("segment_id values must be complete and unique")
    values = features[fields].apply(pd.to_numeric, errors="raise")
    if values.isna().any().any():
        raise ValueError("Cooling-proxy component inputs cannot be missing")
    if not ((values >= 0) & (values <= 1)).all().all():
        raise ValueError("Cooling-proxy component inputs must be between 0 and 1")

    scenarios = generate_weight_scenarios(config)
    weight_columns = [f"weight_{component.name}" for component in config.components]
    weights = scenarios[weight_columns].to_numpy(dtype=float)
    scores = values.to_numpy(dtype=float) @ weights.T
    if np.any(scores < -1e-12) or np.any(scores > 1 + 1e-12):
        raise ValueError("Cooling-support proxy scenario values must be within 0–1")

    ranks = np.column_stack(
        [pd.Series(scores[:, index]).rank(method="average", pct=True).to_numpy()
         for index in range(scores.shape[1])]
    )
    top_threshold = 1 - config.diagnostic_top_fraction
    result = features[["segment_id", *fields, "geometry"]].copy()
    result["cooling_support_proxy_min"] = scores.min(axis=1)
    result["cooling_support_proxy_max"] = scores.max(axis=1)
    result["cooling_support_proxy_mean_across_weights"] = scores.mean(axis=1)
    result["cooling_support_proxy_std_across_weights"] = scores.std(axis=1)
    result["cooling_support_proxy_range_across_weights"] = np.ptp(scores, axis=1)
    result["rank_percentile_min_across_weights"] = ranks.min(axis=1)
    result["rank_percentile_max_across_weights"] = ranks.max(axis=1)
    result["rank_percentile_range_across_weights"] = np.ptp(ranks, axis=1)
    result["top_fraction_scenario_frequency"] = (ranks >= top_threshold).mean(axis=1)
    result["component_disagreement_abs"] = np.abs(
        values.iloc[:, 0].to_numpy() - values.iloc[:, 1].to_numpy()
    )
    result["analysis_id"] = config.analysis_id
    result["preferred_weight_scenario"] = "none"
    return gpd.GeoDataFrame(result, geometry="geometry", crs=features.crs), scenarios


def summarize_cooling_proxy_sensitivity(
    result: gpd.GeoDataFrame,
    scenarios: pd.DataFrame,
    config: CoolingProxySensitivityConfig,
) -> dict[str, Any]:
    """Summarize sensitivity without promoting a single scenario."""

    score_range = result["cooling_support_proxy_range_across_weights"]
    rank_range = result["rank_percentile_range_across_weights"]
    return {
        "analysis_id": config.analysis_id,
        "segment_count": len(result),
        "weight_scenario_count": len(scenarios),
        "weight_step": config.weight_step,
        "component_count": len(config.components),
        "components": [
            {
                "name": component.name,
                "input_field": component.input_field,
                "interpretation": component.interpretation,
            }
            for component in config.components
        ],
        "preferred_weight_scenario": None,
        "mean_score_range_across_weights": round(float(score_range.mean()), 6),
        "median_score_range_across_weights": round(float(score_range.median()), 6),
        "mean_rank_percentile_range_across_weights": round(float(rank_range.mean()), 6),
        "segments_top_ranked_in_every_scenario": int(
            (result["top_fraction_scenario_frequency"] == 1).sum()
        ),
        "segments_never_top_ranked": int(
            (result["top_fraction_scenario_frequency"] == 0).sum()
        ),
        "heat_score_generated": False,
        "weather_used": False,
        "warning": (
            "This is an exploratory mapped cooling-support proxy sensitivity "
            "analysis. It is not shade, thermal comfort, WBGT, UTCI, or Heat Score."
        ),
    }


def _sensitivity_colour(value: float) -> str:
    value = max(0.0, min(1.0, float(value)))
    red = round(45 + 200 * value)
    green = round(110 - 70 * value)
    blue = round(210 - 130 * value)
    return f"#{red:02x}{green:02x}{blue:02x}"


def create_cooling_proxy_sensitivity_map(
    result: gpd.GeoDataFrame,
    output_path: Path,
) -> None:
    """Map dependence on weights rather than claiming a preferred cooling score."""

    display = result.to_crs("EPSG:4326").copy()
    numeric = [
        "green_area_proxy_ratio",
        "building_passage_flag",
        "cooling_support_proxy_range_across_weights",
        "rank_percentile_range_across_weights",
        "top_fraction_scenario_frequency",
    ]
    display[numeric] = display[numeric].round(3)
    center = display.geometry.union_all().centroid
    map_object = folium.Map(
        location=[center.y, center.x], zoom_start=14, tiles="OpenStreetMap", control_scale=True
    )
    folium.GeoJson(
        display[["segment_id", *numeric, "geometry"]].to_json(),
        name="Weight sensitivity",
        style_function=lambda feature: {
            "color": _sensitivity_colour(
                feature["properties"]["cooling_support_proxy_range_across_weights"]
            ),
            "weight": 3,
            "opacity": 0.8,
        },
        tooltip=folium.GeoJsonTooltip(
            fields=["segment_id", *numeric],
            aliases=[
                "Segment",
                "Mapped green context",
                "Building passage flag",
                "Proxy range across weights",
                "Rank range across weights",
                "Top-decile scenario frequency",
            ],
        ),
    ).add_to(map_object)
    legend = """
    <div style="position:fixed;bottom:30px;left:30px;z-index:9999;background:white;
      padding:10px;border:1px solid #777;font-size:12px"><b>Weight sensitivity</b><br>
      Blue: low dependence &nbsp; Red: high dependence<br>
      <small>No preferred weight; not Heat Score</small></div>
    """
    map_object.get_root().html.add_child(folium.Element(legend))
    folium.LayerControl().add_to(map_object)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    map_object.save(output_path)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def build_cooling_proxy_sensitivity(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Run and export the configured exploratory proxy sensitivity analysis."""

    config = load_cooling_proxy_sensitivity_config(config_path)
    input_path = project_root / config.input_path
    features = gpd.read_file(input_path, layer=config.input_layer)
    result, scenarios = compute_cooling_proxy_sensitivity(features, config)
    summary = summarize_cooling_proxy_sensitivity(result, scenarios, config)
    summary["input_path"] = str(input_path)
    summary["input_sha256"] = _sha256(input_path)

    processed = project_root / "data/processed/heat"
    tables = project_root / "outputs/tables"
    maps = project_root / "outputs/maps"
    processed.mkdir(parents=True, exist_ok=True)
    tables.mkdir(parents=True, exist_ok=True)
    geopackage = processed / "cooling_support_proxy_sensitivity.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    result.to_file(geopackage, layer="cooling_proxy_sensitivity", driver="GPKG")
    result.drop(columns="geometry").to_csv(
        processed / "cooling_support_proxy_sensitivity.csv", index=False
    )
    scenarios.to_csv(processed / "cooling_support_proxy_weight_scenarios.csv", index=False)
    (processed / "cooling_support_proxy_sensitivity_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    flat = {key: value for key, value in summary.items() if key != "components"}
    pd.DataFrame([flat]).to_csv(
        tables / "cooling_support_proxy_sensitivity_summary.csv", index=False
    )
    create_cooling_proxy_sensitivity_map(
        result, maps / "clementi_cooling_support_proxy_sensitivity.html"
    )
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(
        description="Run exploratory cooling-support proxy weight sensitivity."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/cooling_proxy_sensitivity.yaml",
    )
    args = parser.parse_args()
    print(
        json.dumps(
            build_cooling_proxy_sensitivity(args.config),
            indent=2,
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
