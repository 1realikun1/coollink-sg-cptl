"""Build a phase-two SOLWEIG MRT/UTCI time series and sample it to roads."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from dataclasses import asdict
from pathlib import Path
from typing import Any

import geopandas as gpd
import numpy as np
import pandas as pd
import pvlib
import rasterio
import solweig
from rasterio.enums import MergeAlg
from rasterio.features import rasterize
from rasterio.transform import from_origin, rowcol
from rasterio.warp import Resampling, reproject
from shapely.geometry import LineString, MultiLineString

from coollink_sg.config import (
    SolweigTimeseriesConfig,
    load_solweig_timeseries_config,
    load_study_area_config,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]
REQUIRED_WEATHER_METRICS = ("air_temperature", "relative_humidity", "wind_speed")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def scenario_timestamps(config: SolweigTimeseriesConfig) -> pd.DatetimeIndex:
    """Return the configured timezone-aware, endpoint-inclusive model clock."""

    timestamps = pd.date_range(
        config.start_sgt,
        config.end_sgt,
        freq=pd.to_timedelta(config.interval_minutes, unit="min"),
    )
    if timestamps.tz is None or len(timestamps) < 2:
        raise ValueError("SOLWEIG scenario needs at least two timezone-aware timesteps")
    if timestamps[-1].isoformat() != pd.Timestamp(config.end_sgt).isoformat():
        raise ValueError("SOLWEIG interval must divide the configured period exactly")
    return timestamps


def extract_station_weather(
    observations: pd.DataFrame,
    station_id: str,
    snapshot_id: str,
) -> dict[str, Any]:
    """Extract a complete, explicitly context-only station snapshot."""

    required = {
        "snapshot_id",
        "metric",
        "station_id",
        "station_name",
        "value",
        "unit",
        "observed_at_sgt",
        "quality_flag",
        "latitude",
        "longitude",
    }
    missing = required.difference(observations.columns)
    if missing:
        raise ValueError(f"Weather observations are missing fields: {sorted(missing)}")
    selected = observations.loc[
        observations["station_id"].astype(str).eq(station_id)
        & observations["snapshot_id"].astype(str).eq(snapshot_id)
        & observations["metric"].isin(REQUIRED_WEATHER_METRICS)
        & observations["quality_flag"].eq("valid")
    ].copy()
    if selected["metric"].duplicated().any() or set(selected["metric"]) != set(
        REQUIRED_WEATHER_METRICS
    ):
        raise ValueError("Configured station must have one valid Ta, RH, and wind record")
    values = selected.set_index("metric")["value"].astype(float)
    if not 0 <= values["relative_humidity"] <= 100:
        raise ValueError("Relative humidity must be between zero and 100 percent")
    if values["wind_speed"] < 0:
        raise ValueError("Wind speed cannot be negative")
    first = selected.iloc[0]
    return {
        "station_id": station_id,
        "station_name": str(first["station_name"]),
        "station_latitude": float(first["latitude"]),
        "station_longitude": float(first["longitude"]),
        "observed_at_sgt": str(first["observed_at_sgt"]),
        "air_temperature_deg_c": float(values["air_temperature"]),
        "relative_humidity_percent": float(values["relative_humidity"]),
        "wind_speed_m_s": float(values["wind_speed"]),
    }


def build_weather_timeseries(
    timestamps: pd.DatetimeIndex,
    latitude: float,
    longitude: float,
    timezone: str,
    station: dict[str, Any],
) -> pd.DataFrame:
    """Build the declared static-station, time-varying clear-sky weather scenario."""

    location = pvlib.location.Location(latitude, longitude, tz=timezone)
    solar = location.get_solarposition(timestamps)
    clear_sky = location.get_clearsky(timestamps, model="ineichen")
    result = pd.DataFrame(
        {
            "timestamp_sgt": timestamps.astype(str),
            "air_temperature_deg_c": station["air_temperature_deg_c"],
            "relative_humidity_percent": station["relative_humidity_percent"],
            "wind_speed_m_s": station["wind_speed_m_s"],
            "clear_sky_ghi_w_m2": clear_sky["ghi"].to_numpy(dtype=float),
            "clear_sky_dni_w_m2": clear_sky["dni"].to_numpy(dtype=float),
            "clear_sky_dhi_w_m2": clear_sky["dhi"].to_numpy(dtype=float),
            "solar_apparent_elevation_deg": solar["apparent_elevation"].to_numpy(dtype=float),
            "solar_azimuth_deg": solar["azimuth"].to_numpy(dtype=float),
            "weather_station_id": station["station_id"],
            "weather_station_name": station["station_name"],
            "station_observed_at_sgt": station["observed_at_sgt"],
            "weather_temporal_status": "static_station_snapshot_repeated",
            "solar_radiation_status": "pvlib_ineichen_clear_sky_model_not_observed",
        }
    )
    if (result["clear_sky_ghi_w_m2"] <= 0).any():
        raise ValueError("Configured phase-two period must contain daylight timesteps only")
    return result


def raster_grid(
    buildings: gpd.GeoDataFrame,
    edges: gpd.GeoDataFrame,
    resolution_m: float,
) -> tuple[Any, int, int, tuple[float, float, float, float]]:
    """Create an aligned grid covering both the building inventory and network."""

    bounds = np.vstack([buildings.total_bounds, edges.total_bounds])
    left = math.floor(float(bounds[:, 0].min()) / resolution_m) * resolution_m
    bottom = math.floor(float(bounds[:, 1].min()) / resolution_m) * resolution_m
    right = math.ceil(float(bounds[:, 2].max()) / resolution_m) * resolution_m
    top = math.ceil(float(bounds[:, 3].max()) / resolution_m) * resolution_m
    width = int(round((right - left) / resolution_m))
    height = int(round((top - bottom) / resolution_m))
    return (
        from_origin(left, top, resolution_m, resolution_m),
        width,
        height,
        (
            left,
            bottom,
            right,
            top,
        ),
    )


def rasterize_building_dsm(
    buildings: gpd.GeoDataFrame,
    edges: gpd.GeoDataFrame,
    output_path: Path,
    output_crs: str,
    height_field: str,
    resolution_m: float,
) -> dict[str, Any]:
    """Rasterize completed building heights above a flat zero-elevation ground."""

    if buildings.crs is None or edges.crs is None:
        raise ValueError("Building and edge layers must have declared CRS values")
    buildings = buildings.to_crs(output_crs)
    edges = edges.to_crs(output_crs)
    if height_field not in buildings.columns:
        raise ValueError(f"Building height field is missing: {height_field}")
    heights = pd.to_numeric(buildings[height_field], errors="raise").to_numpy(dtype=float)
    if not np.isfinite(heights).all() or (heights <= 0).any():
        raise ValueError("All modeled building heights must be finite and positive")
    transform, width, height, bounds = raster_grid(buildings, edges, resolution_m)
    geometry_heights = sorted(
        zip(buildings.geometry, heights, strict=True), key=lambda item: item[1]
    )
    shapes = ((geometry, value) for geometry, value in geometry_heights)
    dsm = rasterize(
        shapes,
        out_shape=(height, width),
        transform=transform,
        fill=0.0,
        all_touched=True,
        dtype="float32",
        merge_alg=MergeAlg.replace,
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with rasterio.open(
        output_path,
        "w",
        driver="GTiff",
        height=height,
        width=width,
        count=1,
        dtype="float32",
        crs=output_crs,
        transform=transform,
        compress="deflate",
        predictor=3,
    ) as destination:
        destination.write(dsm, 1)
        destination.update_tags(
            model="building_height_above_flat_zero_ground",
            height_field=height_field,
            vertical_status="relative_height_only_no_dem",
        )
    return {
        "path": str(output_path),
        "sha256": _sha256(output_path),
        "crs": output_crs,
        "resolution_m": resolution_m,
        "width": width,
        "height": height,
        "bounds": list(bounds),
        "building_count": len(buildings),
        "building_pixel_count": int(np.count_nonzero(dsm > 0)),
        "maximum_height_m": float(dsm.max()),
        "ground_model": "flat_zero_elevation",
    }


def prepare_canopy_dsm(
    source_path: Path,
    building_dsm_path: Path,
    output_path: Path,
    source_nodata: float | None,
    minimum_height_m: float,
    height_multiplier: float = 1.0,
) -> dict[str, Any]:
    """Align a predicted relative canopy-height raster to the building DSM grid."""

    if minimum_height_m < 0:
        raise ValueError("Minimum canopy height cannot be negative")
    if height_multiplier <= 0:
        raise ValueError("Canopy height multiplier must be positive")
    with rasterio.open(building_dsm_path) as dsm_source:
        building_dsm = dsm_source.read(1)
        profile = dsm_source.profile.copy()
        destination = np.zeros((dsm_source.height, dsm_source.width), dtype=np.float32)
        target_crs = dsm_source.crs
        target_transform = dsm_source.transform
    with rasterio.open(source_path) as source:
        if source.crs is None or target_crs is None:
            raise ValueError("Canopy source and building DSM must have declared CRS values")
        effective_nodata = source_nodata if source_nodata is not None else source.nodata
        reproject(
            source=rasterio.band(source, 1),
            destination=destination,
            src_transform=source.transform,
            src_crs=source.crs,
            src_nodata=effective_nodata,
            dst_transform=target_transform,
            dst_crs=target_crs,
            dst_nodata=0.0,
            resampling=Resampling.max,
            init_dest_nodata=True,
        )
    invalid = ~np.isfinite(destination) | (destination < minimum_height_m)
    if source_nodata is not None:
        invalid |= np.isclose(destination, source_nodata)
    destination[invalid] = 0.0
    # Apply the height perturbation after the raw-height threshold so the
    # height-multiplier sensitivity holds the modeled canopy footprint fixed.
    destination *= height_multiplier
    overlapping_building_pixels = (destination > 0) & (building_dsm > 0)
    destination[overlapping_building_pixels] = 0.0
    output_path.parent.mkdir(parents=True, exist_ok=True)
    # Zero is a valid "no canopy" value. It must not be declared as nodata,
    # otherwise SOLWEIG fills those cells from the DSM before converting the
    # relative CDSM and can double modeled building elevations.
    profile.update(dtype="float32", nodata=-9999.0, compress="deflate", predictor=3)
    with rasterio.open(output_path, "w", **profile) as target:
        target.write(destination, 1)
        target.update_tags(
            model="predicted_canopy_height_aligned_to_building_dsm",
            source_path=str(source_path),
            source_sha256=_sha256(source_path),
            source_nodata=source_nodata,
            resampling="maximum",
            minimum_canopy_height_m=minimum_height_m,
            canopy_height_multiplier=height_multiplier,
            building_overlap_policy="canopy_zeroed_where_building_dsm_positive",
            validation_status="predicted_product_not_singapore_field_validated",
        )
    positive = destination[destination > 0]
    return {
        "path": str(output_path),
        "sha256": _sha256(output_path),
        "source_path": str(source_path),
        "source_sha256": _sha256(source_path),
        "crs": str(target_crs),
        "resolution_m": abs(float(target_transform.a)),
        "width": int(destination.shape[1]),
        "height": int(destination.shape[0]),
        "minimum_height_m": minimum_height_m,
        "height_multiplier": height_multiplier,
        "positive_pixel_count": int(positive.size),
        "positive_pixel_fraction": float(np.mean(destination > 0)),
        "median_positive_height_m": float(np.median(positive)) if positive.size else 0.0,
        "maximum_height_m": float(positive.max()) if positive.size else 0.0,
        "building_overlap_pixel_count_removed": int(np.count_nonzero(overlapping_building_pixels)),
        "validation_status": "predicted_product_not_singapore_field_validated",
    }


def build_readiness(
    config: SolweigTimeseriesConfig,
    dsm_metadata: dict[str, Any],
    weather: pd.DataFrame,
    canopy_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Declare minimum run readiness separately from publication validation readiness."""

    return {
        "analysis_id": config.analysis_id,
        "solweig_version": solweig.__version__,
        "minimum_model_inputs_ready": True,
        "paper_validation_ready": False,
        "required_inputs": {
            "dsm": {
                "available": True,
                "status": "modeled_building_heights_on_flat_ground",
                **dsm_metadata,
            },
            "location": {"available": True, "status": "study_area_centroid"},
            "air_temperature": {
                "available": True,
                "status": "single_station_snapshot_repeated",
            },
            "relative_humidity": {
                "available": True,
                "status": "single_station_snapshot_repeated",
            },
            "global_radiation": {
                "available": True,
                "status": "pvlib_ineichen_clear_sky_model_not_observed",
            },
        },
        "optional_or_validation_inputs": {
            "canopy_dsm": (
                {
                    "available": True,
                    "status": "predicted_chmv2_sensitivity_input_not_field_validated",
                    **canopy_metadata,
                }
                if canopy_metadata is not None
                else {"available": False, "effect": "tree shade omitted"}
            ),
            "dem": {"available": False, "effect": "terrain represented as flat"},
            "land_cover": {
                "available": False,
                "effect": "spatial surface material variation omitted",
            },
            "measured_time_series_radiation": {
                "available": False,
                "effect": "scenario cannot reconstruct observed sky conditions",
            },
            "field_mrt_or_utci_validation": {"available": False},
        },
        "timestep_count": len(weather),
        "start_sgt": str(weather.iloc[0]["timestamp_sgt"]),
        "end_sgt": str(weather.iloc[-1]["timestamp_sgt"]),
        "thermal_source_status": config.thermal_source_status,
        "allowed_claim": (
            "time-varying building-plus-predicted-canopy clear-sky SOLWEIG sensitivity "
            "scenario; not an observed or field-validated thermal reconstruction"
            if canopy_metadata is not None
            else "time-varying building-shadow clear-sky SOLWEIG design scenario; "
            "not an observed or field-validated thermal reconstruction"
        ),
    }


def _line_parts(geometry: Any) -> list[LineString]:
    if isinstance(geometry, LineString):
        return [geometry]
    if isinstance(geometry, MultiLineString):
        return list(geometry.geoms)
    raise ValueError("Road geometry must be LineString or MultiLineString")


def _nearest_ground_index(
    row: int,
    col: int,
    building_mask: np.ndarray,
    maximum_radius: int = 20,
) -> tuple[int, int] | None:
    if not building_mask[row, col]:
        return row, col
    height, width = building_mask.shape
    for radius in range(1, maximum_radius + 1):
        candidates: list[tuple[int, int, int]] = []
        for candidate_row in range(max(0, row - radius), min(height, row + radius + 1)):
            for candidate_col in range(max(0, col - radius), min(width, col + radius + 1)):
                if not building_mask[candidate_row, candidate_col]:
                    distance = (candidate_row - row) ** 2 + (candidate_col - col) ** 2
                    candidates.append((distance, candidate_row, candidate_col))
        if candidates:
            _, nearest_row, nearest_col = min(candidates)
            return nearest_row, nearest_col
    return None


def prepare_edge_sample_indices(
    edges: gpd.GeoDataFrame,
    transform: Any,
    width: int,
    height: int,
    building_mask: np.ndarray,
    interval_m: float,
) -> tuple[list[np.ndarray], dict[str, int]]:
    """Precompute ground-cell raster indices sampled along every stable road segment."""

    mappings: list[np.ndarray] = []
    shifted = 0
    rejected = 0
    for geometry in edges.geometry:
        coordinates: list[tuple[float, float]] = []
        for line in _line_parts(geometry):
            distances = np.arange(0.0, line.length, interval_m)
            distances = np.append(distances, line.length)
            for value in distances:
                point = line.interpolate(float(value))
                coordinates.append((point.x, point.y))
        rows, cols = rowcol(
            transform,
            [coordinate[0] for coordinate in coordinates],
            [coordinate[1] for coordinate in coordinates],
        )
        flat_indices: list[int] = []
        for sample_row, sample_col in zip(rows, cols, strict=True):
            if not (0 <= sample_row < height and 0 <= sample_col < width):
                rejected += 1
                continue
            original = (sample_row, sample_col)
            ground = _nearest_ground_index(sample_row, sample_col, building_mask)
            if ground is None:
                rejected += 1
                continue
            shifted += int(ground != original)
            flat_indices.append(ground[0] * width + ground[1])
        unique = np.unique(np.asarray(flat_indices, dtype=np.int64))
        if len(unique) == 0:
            raise ValueError("Every road segment must retain at least one ground-cell sample")
        mappings.append(unique)
    return mappings, {"shifted_building_samples": shifted, "rejected_samples": rejected}


def _sample_means(values: np.ndarray, mappings: list[np.ndarray]) -> np.ndarray:
    flat = values.ravel()
    means = np.asarray([np.nanmean(flat[indices]) for indices in mappings], dtype=float)
    if not np.isfinite(means).all():
        raise ValueError("SOLWEIG road sampling produced non-finite means")
    return means


def sample_solweig_to_roads(
    edges: gpd.GeoDataFrame,
    dsm_path: Path,
    output_directory: Path,
    timestamps: pd.DatetimeIndex,
    interval_m: float,
    source_status: str,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Sample timestep MRT, UTCI, and sun-fraction rasters to road geometries."""

    if not edges["segment_id"].astype(str).is_unique:
        raise ValueError("Road segment_id values must be unique")
    with rasterio.open(dsm_path) as source:
        dsm = source.read(1)
        transform = source.transform
        raster_crs = source.crs
        width = source.width
        height = source.height
    projected_edges = edges.to_crs(raster_crs)
    mappings, sampling_diagnostics = prepare_edge_sample_indices(
        projected_edges,
        transform,
        width,
        height,
        dsm > 0,
        interval_m,
    )
    frames: list[pd.DataFrame] = []
    for timestamp in timestamps:
        stamp = timestamp.strftime("%Y%m%d_%H%M")
        paths = {
            "tmrt": output_directory / "tmrt" / f"tmrt_{stamp}.tif",
            "utci": output_directory / "utci" / f"utci_{stamp}.tif",
            "sun": output_directory / "shadow" / f"shadow_{stamp}.tif",
        }
        arrays: dict[str, np.ndarray] = {}
        for name, path in paths.items():
            if not path.exists():
                raise FileNotFoundError(f"Missing SOLWEIG timestep output: {path}")
            with rasterio.open(path) as source:
                if source.crs != raster_crs or source.transform != transform:
                    raise ValueError("SOLWEIG output grid does not match its DSM")
                arrays[name] = source.read(1)
        frame = pd.DataFrame(
            {
                "segment_id": projected_edges["segment_id"].astype(str).to_numpy(),
                "timestamp_sgt": timestamp.isoformat(),
                "height_scenario": "central",
                "road_mean_tmrt_deg_c": _sample_means(arrays["tmrt"], mappings),
                "modeled_utci_deg_c": _sample_means(arrays["utci"], mappings),
                "road_mean_sun_fraction": _sample_means(arrays["sun"], mappings),
                "sample_cell_count": [len(indices) for indices in mappings],
                "thermal_source_status": source_status,
            }
        )
        frames.append(frame)
    result = pd.concat(frames, ignore_index=True)
    expected_rows = len(edges) * len(timestamps)
    if len(result) != expected_rows:
        raise RuntimeError("Road thermal time series is not a complete segment-time grid")
    summary = {
        **sampling_diagnostics,
        "segment_count": len(edges),
        "timestamp_count": len(timestamps),
        "row_count": len(result),
        "minimum_sample_cell_count": int(result["sample_cell_count"].min()),
        "mean_sample_cell_count": float(result["sample_cell_count"].mean()),
        "tmrt_range_deg_c": [
            float(result["road_mean_tmrt_deg_c"].min()),
            float(result["road_mean_tmrt_deg_c"].max()),
        ],
        "utci_range_deg_c": [
            float(result["modeled_utci_deg_c"].min()),
            float(result["modeled_utci_deg_c"].max()),
        ],
    }
    return result, summary


def run_solweig_timeseries(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Build inputs, run SOLWEIG, and export the road-level dynamic thermal field."""

    config = load_solweig_timeseries_config(config_path)
    study = load_study_area_config(project_root / config.study_area_config_path)
    if study.analysis_crs != config.output_crs:
        raise ValueError("Study-area and SOLWEIG analysis CRS values must match")
    buildings = gpd.read_file(
        project_root / config.buildings.path,
        layer=config.buildings.layer,
    )
    edges = gpd.read_file(project_root / config.network.path, layer=config.network.layer)
    dsm_path = project_root / config.dsm_path
    dsm_metadata = rasterize_building_dsm(
        buildings,
        edges,
        dsm_path,
        config.output_crs,
        config.building_height_field,
        config.raster_resolution_m,
    )
    canopy_path: Path | None = None
    canopy_metadata: dict[str, Any] | None = None
    if config.canopy_source_path is not None:
        if config.canopy_dsm_path is None:
            raise ValueError("A canopy-enabled scenario requires outputs.canopy_dsm")
        canopy_path = project_root / config.canopy_dsm_path
        canopy_metadata = prepare_canopy_dsm(
            project_root / config.canopy_source_path,
            dsm_path,
            canopy_path,
            config.canopy_source_nodata,
            config.minimum_canopy_height_m,
            config.canopy_height_multiplier,
        )
    observations = pd.read_csv(project_root / config.weather_observations_path)
    station = extract_station_weather(
        observations,
        config.weather_station_id,
        config.weather_snapshot_id,
    )
    timestamps = scenario_timestamps(config)
    weather = build_weather_timeseries(
        timestamps,
        study.latitude,
        study.longitude,
        config.timezone,
        station,
    )
    weather_path = project_root / config.weather_timeseries_path
    weather_path.parent.mkdir(parents=True, exist_ok=True)
    weather.to_csv(weather_path, index=False)
    readiness = build_readiness(config, dsm_metadata, weather, canopy_metadata)
    readiness_path = project_root / config.readiness_path
    readiness_path.parent.mkdir(parents=True, exist_ok=True)
    readiness_path.write_text(
        json.dumps(readiness, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    output_directory = project_root / config.solweig_output_directory
    output_directory.mkdir(parents=True, exist_ok=True)
    surface_fingerprint = (
        canopy_metadata["sha256"][:12]
        if canopy_metadata is not None
        else dsm_metadata["sha256"][:12]
    )
    surface = solweig.SurfaceData.prepare(
        dsm=dsm_path,
        working_dir=(
            project_root
            / "data/interim/solweig"
            / f"{config.analysis_id}_{surface_fingerprint}_5m_precomputed"
        ),
        cdsm=canopy_path,
        trunk_ratio=config.canopy_trunk_ratio,
        dsm_relative=False,
        cdsm_relative=True,
        force_recompute=False,
    )
    solweig_weather = [
        solweig.Weather(
            datetime=pd.Timestamp(row.timestamp_sgt).tz_localize(None).to_pydatetime(),
            ta=float(row.air_temperature_deg_c),
            rh=float(row.relative_humidity_percent),
            global_rad=float(row.clear_sky_ghi_w_m2),
            ws=float(row.wind_speed_m_s),
            timestep_minutes=config.interval_minutes,
        )
        for row in weather.itertuples(index=False)
    ]
    location = solweig.Location(
        latitude=study.latitude,
        longitude=study.longitude,
        utc_offset=8,
    )
    result = solweig.calculate(
        surface,
        solweig_weather,
        location,
        output_dir=output_directory,
        use_anisotropic_sky=config.use_anisotropic_sky,
        max_shadow_distance_m=config.max_shadow_distance_m,
        outputs=["tmrt", "utci", "shadow"],
    )
    roads, sampling_summary = sample_solweig_to_roads(
        edges,
        dsm_path,
        output_directory,
        timestamps,
        config.edge_sampling_interval_m,
        config.thermal_source_status,
    )
    road_path = project_root / config.road_timeseries_path
    road_path.parent.mkdir(parents=True, exist_ok=True)
    roads.to_csv(road_path, index=False)
    summary = {
        "analysis_id": config.analysis_id,
        "thermal_source_status": config.thermal_source_status,
        "is_solweig_dynamic_result": True,
        "is_observed_dynamic_thermal_field": False,
        "solweig_version": solweig.__version__,
        "compute_backend": solweig.get_compute_backend(),
        "config": asdict(config),
        "dsm": dsm_metadata,
        "canopy_dsm": canopy_metadata,
        "weather_station_context": station,
        "weather_timeseries_sha256": _sha256(weather_path),
        "road_timeseries_sha256": _sha256(road_path),
        "solweig_timesteps": int(result.n_timesteps),
        "solweig_daytime_timesteps": int(result.n_daytime),
        "sampling": sampling_summary,
        "readiness": readiness,
    }
    summary_path = road_path.with_name(f"{road_path.stem}_summary.json")
    summary_path.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run a configured clear-sky SOLWEIG road thermal time series."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/solweig_timeseries.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(run_solweig_timeseries(args.config), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
