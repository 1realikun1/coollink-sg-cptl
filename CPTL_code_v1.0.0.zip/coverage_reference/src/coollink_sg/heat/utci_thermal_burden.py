"""Radiation-driven UTCI thermal-burden screening for pedestrian roads."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import numpy as np
import pandas as pd
import pvlib
from pyproj import CRS
from pythermalcomfort.models import solar_gain, utci
from shapely.geometry import LineString, MultiLineString
from shapely.ops import linemerge

from coollink_sg.config import (
    UTCIThermalBurdenConfig,
    load_study_area_config,
    load_utci_thermal_burden_config,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]
HEIGHT_SCENARIOS = ("low", "central", "high")
WEATHER_FIELDS = {
    "air_temperature": "air_temperature_deg_c",
    "relative_humidity": "relative_humidity_percent",
    "wind_speed": "wind_speed_10m_context_m_s",
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def _line_heading_deg(geometry: LineString | MultiLineString) -> float:
    """Return directed line heading clockwise from north."""

    line = linemerge(geometry) if isinstance(geometry, MultiLineString) else geometry
    if isinstance(line, MultiLineString):
        line = max(line.geoms, key=lambda part: part.length)
    if line.is_empty or len(line.coords) < 2:
        raise ValueError("Every road geometry must contain at least two coordinates")
    x0, y0 = line.coords[0][:2]
    x1, y1 = line.coords[-1][:2]
    if math.isclose(x0, x1) and math.isclose(y0, y1):
        midpoint = line.interpolate(0.5, normalized=True)
        start = line.interpolate(0.49, normalized=True)
        end = line.interpolate(0.51, normalized=True)
        x0, y0, x1, y1 = start.x, start.y, end.x, end.y
        if start.equals(end) or midpoint.is_empty:
            raise ValueError("Cannot derive heading from a zero-displacement road")
    return float(math.degrees(math.atan2(x1 - x0, y1 - y0)) % 360)


def _sharp_deg(heading_deg: np.ndarray, solar_azimuth_deg: float) -> np.ndarray:
    """Return ASHRAE solar horizontal angle relative to walking direction."""

    difference = np.abs((heading_deg - solar_azimuth_deg + 180) % 360 - 180)
    return np.clip(difference, 0, 180)


def prepare_weather_context(
    associations: pd.DataFrame,
    segment_ids: pd.Series,
) -> pd.DataFrame:
    """Pivot metric-separated NEA station context without spatial interpolation."""

    required = {
        "segment_id",
        "metric",
        "source_value",
        "source_unit",
        "source_station_id",
        "source_station_name",
        "observed_at_sgt",
        "road_midpoint_to_station_distance_m",
        "association_status",
        "weather_snapshot_id",
    }
    missing = required.difference(associations.columns)
    if missing:
        raise ValueError(f"Weather associations are missing fields: {sorted(missing)}")
    selected = associations.loc[associations["metric"].isin(WEATHER_FIELDS)].copy()
    if not selected["association_status"].eq("context_only_not_road_observation").all():
        raise ValueError("Weather inputs must retain context-only provenance")
    if set(selected["metric"]) != set(WEATHER_FIELDS):
        raise ValueError("Air temperature, humidity, and wind context are required")
    expected_ids = set(segment_ids.astype(str))
    frames: list[pd.DataFrame] = []
    for metric, output_field in WEATHER_FIELDS.items():
        subset = selected.loc[selected["metric"].eq(metric)].copy()
        if subset["segment_id"].duplicated().any() or set(subset["segment_id"]) != expected_ids:
            raise ValueError(f"Metric {metric} must contain one row for every segment")
        prefix = output_field.removesuffix("_deg_c").removesuffix("_percent").removesuffix(
            "_m_s"
        )
        subset = subset.rename(
            columns={
                "source_value": output_field,
                "source_unit": f"{prefix}_source_unit",
                "source_station_id": f"{prefix}_source_station_id",
                "source_station_name": f"{prefix}_source_station_name",
                "observed_at_sgt": f"{prefix}_observed_at_sgt",
                "road_midpoint_to_station_distance_m": f"{prefix}_station_distance_m",
            }
        )
        frames.append(
            subset[
                [
                    "segment_id",
                    output_field,
                    f"{prefix}_source_unit",
                    f"{prefix}_source_station_id",
                    f"{prefix}_source_station_name",
                    f"{prefix}_observed_at_sgt",
                    f"{prefix}_station_distance_m",
                    "weather_snapshot_id",
                ]
            ].rename(columns={"weather_snapshot_id": f"{prefix}_weather_snapshot_id"})
        )
    result = frames[0]
    for frame in frames[1:]:
        result = result.merge(frame, on="segment_id", how="inner", validate="one_to_one")
    numeric = result[list(WEATHER_FIELDS.values())].apply(pd.to_numeric, errors="raise")
    if numeric.isna().any().any():
        raise ValueError("UTCI weather context cannot contain missing values")
    result[list(WEATHER_FIELDS.values())] = numeric
    if not result["relative_humidity_percent"].between(0, 100).all():
        raise ValueError("Relative humidity must be between zero and 100 percent")
    if (result["wind_speed_10m_context_m_s"] < 0).any():
        raise ValueError("Wind speed cannot be negative")
    return result


def calculate_clear_sky_context(
    latitude: float,
    longitude: float,
    scenario_time_sgt: str,
    timezone: str,
) -> dict[str, float]:
    """Calculate design-scenario solar position and Ineichen clear-sky irradiance."""

    timestamp = pd.Timestamp(scenario_time_sgt)
    times = pd.DatetimeIndex([timestamp])
    location = pvlib.location.Location(latitude, longitude, tz=timezone)
    position = location.get_solarposition(times).iloc[0]
    clear_sky = location.get_clearsky(times, model="ineichen").iloc[0]
    values = {
        "solar_apparent_elevation_deg": float(position["apparent_elevation"]),
        "solar_azimuth_deg": float(position["azimuth"]),
        "clear_sky_ghi_w_m2": float(clear_sky["ghi"]),
        "clear_sky_dni_w_m2": float(clear_sky["dni"]),
        "clear_sky_dhi_w_m2": float(clear_sky["dhi"]),
    }
    if values["solar_apparent_elevation_deg"] <= 0:
        raise ValueError("Configured UTCI scenario must occur during daylight")
    if any(values[field] <= 0 for field in values if field.endswith("_w_m2")):
        raise ValueError("Clear-sky irradiance components must be positive")
    return values


def compute_utci_thermal_burden(
    roads: gpd.GeoDataFrame,
    weather_associations: pd.DataFrame,
    latitude: float,
    longitude: float,
    config: UTCIThermalBurdenConfig,
) -> tuple[gpd.GeoDataFrame, dict[str, Any]]:
    """Compute modeled sun/shade UTCI states and time-integrated road burden."""

    required = {"segment_id", "length_m", "geometry", *config.shade_fields.values()}
    missing = required.difference(roads.columns)
    if missing:
        raise ValueError(f"Road features are missing fields: {sorted(missing)}")
    if roads.crs is None or CRS.from_user_input(roads.crs) != CRS.from_user_input(
        config.output_crs
    ):
        raise ValueError(f"Road features must use configured {config.output_crs}")
    if roads["segment_id"].isna().any() or not roads["segment_id"].is_unique:
        raise ValueError("Road segment_id values must be complete and unique")
    length = pd.to_numeric(roads["length_m"], errors="raise")
    if length.isna().any() or (length <= 0).any():
        raise ValueError("Road length_m must be positive")
    shade = roads[list(config.shade_fields.values())].apply(pd.to_numeric, errors="raise")
    if shade.isna().any().any() or not ((shade >= 0) & (shade <= 1)).all().all():
        raise ValueError("All shade scenarios must be complete fractions in [0, 1]")

    weather = prepare_weather_context(weather_associations, roads["segment_id"])
    result = roads[["segment_id", "length_m", *config.shade_fields.values(), "geometry"]].merge(
        weather, on="segment_id", how="left", validate="one_to_one"
    )
    solar = calculate_clear_sky_context(
        latitude, longitude, config.scenario_time_sgt, config.timezone
    )
    headings = np.array([_line_heading_deg(geometry) for geometry in result.geometry])
    sharp = _sharp_deg(headings, solar["solar_azimuth_deg"])
    direct_radiation = np.full(len(result), solar["clear_sky_dni_w_m2"])
    gain = solar_gain(
        sol_altitude=np.full(len(result), solar["solar_apparent_elevation_deg"]),
        sharp=sharp,
        sol_radiation_dir=direct_radiation,
        sol_transmittance=np.ones(len(result)),
        f_svv=np.full(len(result), config.sky_view_fraction),
        f_bes=np.full(len(result), config.body_exposure_fraction),
        asw=np.full(len(result), config.shortwave_absorptivity),
        posture=config.posture,
        floor_reflectance=np.full(len(result), config.floor_reflectance),
        round_output=False,
    )
    delta_mrt = np.asarray(gain.delta_mrt, dtype=float)
    erf = np.asarray(gain.erf, dtype=float)
    if np.isnan(delta_mrt).any() or (delta_mrt < 0).any():
        raise ValueError("ASHRAE solar-gain calculation returned invalid delta MRT")

    air = result["air_temperature_deg_c"].to_numpy(dtype=float)
    humidity = result["relative_humidity_percent"].to_numpy(dtype=float)
    raw_wind = result["wind_speed_10m_context_m_s"].to_numpy(dtype=float)
    wind = np.maximum(raw_wind, config.minimum_utci_wind_speed_m_s)
    mrt_sun = air + delta_mrt
    mrt_shade = air
    utci_sun = np.asarray(
        utci(
            tdb=air,
            tr=mrt_sun,
            v=wind,
            rh=humidity,
            limit_inputs=True,
            round_output=False,
        ).utci,
        dtype=float,
    )
    utci_shade = np.asarray(
        utci(
            tdb=air,
            tr=mrt_shade,
            v=wind,
            rh=humidity,
            limit_inputs=True,
            round_output=False,
        ).utci,
        dtype=float,
    )
    if np.isnan(utci_sun).any() or np.isnan(utci_shade).any():
        raise ValueError("UTCI inputs fall outside the operational model domain")

    travel_minutes = length.to_numpy(dtype=float) / config.walking_speed_m_s / 60
    result["scenario_time_sgt"] = config.scenario_time_sgt
    result["road_heading_deg"] = headings
    result["solar_horizontal_angle_deg"] = sharp
    result["solar_apparent_elevation_deg"] = solar["solar_apparent_elevation_deg"]
    result["solar_azimuth_deg"] = solar["solar_azimuth_deg"]
    result["clear_sky_ghi_w_m2"] = solar["clear_sky_ghi_w_m2"]
    result["clear_sky_dni_w_m2"] = solar["clear_sky_dni_w_m2"]
    result["clear_sky_dhi_w_m2"] = solar["clear_sky_dhi_w_m2"]
    result["ashrae_solar_erf_unshaded_w_m2"] = erf
    result["modeled_delta_mrt_unshaded_deg_c"] = delta_mrt
    result["modeled_mrt_unshaded_deg_c"] = mrt_sun
    result["modeled_mrt_shaded_reference_deg_c"] = mrt_shade
    result["modeled_utci_unshaded_deg_c"] = utci_sun
    result["modeled_utci_shaded_reference_deg_c"] = utci_shade
    result["utci_wind_speed_used_m_s"] = wind
    result["travel_time_min"] = travel_minutes
    threshold = config.heat_stress_threshold_deg_c
    sun_excess = np.maximum(utci_sun - threshold, 0)
    shade_excess = np.maximum(utci_shade - threshold, 0)
    for scenario in HEIGHT_SCENARIOS:
        shade_fraction = result[config.shade_fields[scenario]].to_numpy(dtype=float)
        sun_fraction = 1 - shade_fraction
        result[f"modeled_utci_mean_{scenario}_deg_c"] = (
            sun_fraction * utci_sun + shade_fraction * utci_shade
        )
        result[f"thermal_burden_{scenario}_deg_c_min"] = travel_minutes * (
            sun_fraction * sun_excess + shade_fraction * shade_excess
        )
    result["analysis_id"] = config.analysis_id
    result["thermal_model_status"] = (
        "clear_sky_radiation_driven_utci_screening_not_field_validated"
    )
    result["weather_assignment_status"] = "nearest_station_context_not_road_observation"
    result["sky_view_factor_status"] = "open_sky_upper_bound_not_road_measurement"
    result["tree_crown_radiation_status"] = "unavailable"
    result["formal_heat_score_generated"] = False
    metadata = {
        **solar,
        "wind_values_below_utci_floor_count": int((raw_wind < wind).sum()),
        "minimum_utci_wind_speed_m_s": config.minimum_utci_wind_speed_m_s,
        "walking_speed_m_s": config.walking_speed_m_s,
        "heat_stress_threshold_deg_c": threshold,
    }
    return gpd.GeoDataFrame(result, geometry="geometry", crs=roads.crs), metadata


def summarize_utci_thermal_burden(
    result: gpd.GeoDataFrame,
    metadata: dict[str, Any],
    config: UTCIThermalBurdenConfig,
) -> dict[str, Any]:
    """Summarize modeled UTCI ranges without claiming observed road conditions."""

    summary: dict[str, Any] = {
        "analysis_id": config.analysis_id,
        "segment_count": len(result),
        "scenario_time_sgt": config.scenario_time_sgt,
        "thermal_index": "UTCI",
        "solar_position_method": config.solar_position_method,
        "clear_sky_model": config.clear_sky_model,
        "solar_gain_model": config.solar_gain_model,
        "route_input_has_subjective_component_weights": False,
        "formal_heat_score_generated": False,
        "validated_road_utci_generated": False,
        "model_status": "modeled_clear_sky_screening_not_field_validated",
        **metadata,
    }
    for scenario in HEIGHT_SCENARIOS:
        utci_field = f"modeled_utci_mean_{scenario}_deg_c"
        burden_field = f"thermal_burden_{scenario}_deg_c_min"
        summary[f"mean_{utci_field}"] = round(float(result[utci_field].mean()), 6)
        summary[f"minimum_{utci_field}"] = round(float(result[utci_field].min()), 6)
        summary[f"maximum_{utci_field}"] = round(float(result[utci_field].max()), 6)
        summary[f"total_{burden_field}"] = round(float(result[burden_field].sum()), 6)
    summary["method_references"] = {
        "utci": "Bröde et al. 2012, doi:10.1007/s00484-011-0454-1",
        "solar_gain": "ASHRAE Standard 55 ERF method via pythermalcomfort",
        "clear_sky": "Ineichen clear-sky model via pvlib",
        "routing_precedent": "Verma et al. 2026, doi:10.1016/j.cacint.2026.100349",
    }
    summary["warning"] = (
        "Values are a clear-sky design scenario driven by regional station context, "
        "modeled building shade, and an open-sky SVF upper bound. They are not road "
        "measurements, field-validated MRT/UTCI, or health advice. Tree-crown radiation, "
        "street-canyon wind, and local surface-temperature effects remain unavailable."
    )
    return summary


def create_utci_map(result: gpd.GeoDataFrame, output_path: Path) -> None:
    """Map central-scenario modeled UTCI burden with explicit status language."""

    display = result.to_crs("EPSG:4326").copy()
    field = "thermal_burden_central_deg_c_min"
    low, high = display[field].quantile([0.05, 0.95])

    def style(feature: dict[str, Any]) -> dict[str, Any]:
        value = float(feature["properties"][field])
        scaled = 0.5 if high <= low else float(np.clip((value - low) / (high - low), 0, 1))
        return {
            "color": f"#{220:02x}{round(190 - 130 * scaled):02x}{round(70 - 35 * scaled):02x}",
            "weight": 3,
            "opacity": 0.8,
        }

    center = display.geometry.union_all().centroid
    map_object = folium.Map(
        location=[center.y, center.x], zoom_start=14, tiles="OpenStreetMap", control_scale=True
    )
    tooltip_fields = [
        "segment_id",
        "modeled_utci_mean_central_deg_c",
        field,
        "combined_shade_evidence_fraction_central",
        "air_temperature_deg_c",
        "relative_humidity_percent",
        "utci_wind_speed_used_m_s",
    ]
    display[tooltip_fields[1:]] = display[tooltip_fields[1:]].round(3)
    folium.GeoJson(
        display[[*tooltip_fields, "geometry"]].to_json(),
        name="Modeled UTCI thermal burden (central height scenario)",
        style_function=style,
        tooltip=folium.GeoJsonTooltip(fields=tooltip_fields),
    ).add_to(map_object)
    note = """
    <div style="position:fixed;left:20px;bottom:25px;z-index:9999;background:white;
      padding:10px;border:1px solid #777;font-size:12px;max-width:360px">
      <b>Radiation-driven UTCI screening</b><br>
      Clear-sky design scenario; central building-height shade.<br>
      Burden = walking minutes × UTCI excess above 26°C.<br>
      <b>Modeled and not field validated; not health advice.</b></div>
    """
    map_object.get_root().html.add_child(folium.Element(note))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    map_object.save(output_path)


def build_utci_thermal_burden(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Build modeled road UTCI and cumulative thermal-burden artifacts."""

    config = load_utci_thermal_burden_config(config_path)
    study_area = load_study_area_config(project_root / config.study_area_config_path)
    road_path = project_root / config.roads.path
    weather_path = project_root / config.weather_associations_path
    roads = gpd.read_file(road_path, layer=config.roads.layer)
    associations = pd.read_csv(weather_path, low_memory=False)
    result, metadata = compute_utci_thermal_burden(
        roads, associations, study_area.latitude, study_area.longitude, config
    )
    summary = summarize_utci_thermal_burden(result, metadata, config)
    summary["input_sha256"] = {
        "road_features": _sha256(road_path),
        "weather_associations": _sha256(weather_path),
    }
    processed = project_root / "data/processed/heat"
    tables = project_root / "outputs/tables"
    maps = project_root / "outputs/maps"
    processed.mkdir(parents=True, exist_ok=True)
    tables.mkdir(parents=True, exist_ok=True)
    maps.mkdir(parents=True, exist_ok=True)
    geopackage = processed / "road_utci_thermal_burden.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    result.to_file(geopackage, layer="road_utci_thermal_burden", driver="GPKG")
    result.drop(columns="geometry").to_csv(
        processed / "road_utci_thermal_burden.csv", index=False
    )
    (processed / "road_utci_thermal_burden_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    pd.DataFrame(
        [{key: value for key, value in summary.items() if not isinstance(value, dict)}]
    ).to_csv(tables / "road_utci_thermal_burden_summary.csv", index=False)
    create_utci_map(result, maps / "clementi_road_utci_thermal_burden.html")
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(
        description="Build a radiation-driven UTCI thermal-burden screening scenario."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/utci_thermal_burden.yaml",
    )
    args = parser.parse_args()
    # Persisted artifacts remain UTF-8; escaped CLI output also works in GBK consoles.
    print(json.dumps(build_utci_thermal_burden(args.config), indent=2, ensure_ascii=True))


if __name__ == "__main__":
    main()
