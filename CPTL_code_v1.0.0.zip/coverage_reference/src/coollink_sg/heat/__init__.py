"""Transparent heat-exposure modelling modules."""

