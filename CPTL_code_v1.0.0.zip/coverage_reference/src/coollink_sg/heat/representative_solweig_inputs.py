"""Build fixed-extent 5 m building and canopy DSMs for expansion regions."""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
import yaml
from pyproj import CRS
from rasterio.enums import Resampling
from rasterio.warp import reproject

from coollink_sg.data.regional_input_audit import (
    raster_bounds_in_analysis_crs,
    source_coverage_fraction,
)
from coollink_sg.heat.solweig_timeseries import _sha256, rasterize_building_dsm

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class SolweigInputRegion:
    region_id: str
    buildings_path: str
    network_path: str
    canopy_sources: tuple[str, ...]


@dataclass(frozen=True)
class RepresentativeSolweigInputConfig:
    analysis_id: str
    analysis_crs: str
    raster_resolution_m: float
    shadow_buffer_m: float
    building_height_field: str
    canopy_source_nodata: float
    canopy_minimum_height_m: float
    canopy_height_multiplier: float
    regions_path: str
    regions_layer: str
    tile_index_path: str
    tile_index_layer: str
    regions: tuple[SolweigInputRegion, ...]
    output_directory: str
    summary_path: str


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    try:
        return mapping[key]
    except KeyError as exc:
        raise ValueError(f"Missing required field '{section}.{key}'") from exc


def load_representative_solweig_input_config(
    path: str | Path,
) -> RepresentativeSolweigInputConfig:
    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Representative SOLWEIG input configuration must be a mapping")
    model = _required(payload, "representative_solweig_inputs", "root")
    inputs = _required(payload, "inputs", "root")
    outputs = _required(payload, "outputs", "root")
    analysis_crs = str(_required(model, "analysis_crs", "representative_solweig_inputs"))
    if not CRS.from_user_input(analysis_crs).is_projected:
        raise ValueError("representative_solweig_inputs.analysis_crs must be projected")
    region_items = _required(inputs, "regions", "inputs")
    regions = tuple(
        SolweigInputRegion(
            region_id=str(_required(item, "region_id", "inputs.regions")),
            buildings_path=str(_required(item, "buildings", "inputs.regions")),
            network_path=str(_required(item, "network", "inputs.regions")),
            canopy_sources=tuple(str(value) for value in item["canopy_sources"]),
        )
        for item in region_items
    )
    if not regions or len({region.region_id for region in regions}) != len(regions):
        raise ValueError("At least one unique SOLWEIG input region is required")
    registry = _required(inputs, "representative_regions", "inputs")
    tiles = _required(inputs, "national_tile_index", "inputs")
    return RepresentativeSolweigInputConfig(
        analysis_id=str(_required(model, "analysis_id", "representative_solweig_inputs")),
        analysis_crs=analysis_crs,
        raster_resolution_m=float(_required(model, "raster_resolution_m", "model")),
        shadow_buffer_m=float(_required(model, "shadow_buffer_m", "model")),
        building_height_field=str(_required(model, "building_height_field", "model")),
        canopy_source_nodata=float(_required(model, "canopy_source_nodata", "model")),
        canopy_minimum_height_m=float(
            _required(model, "canopy_minimum_height_m", "model")
        ),
        canopy_height_multiplier=float(
            _required(model, "canopy_height_multiplier", "model")
        ),
        regions_path=str(_required(registry, "path", "inputs.representative_regions")),
        regions_layer=str(_required(registry, "layer", "inputs.representative_regions")),
        tile_index_path=str(_required(tiles, "path", "inputs.national_tile_index")),
        tile_index_layer=str(_required(tiles, "layer", "inputs.national_tile_index")),
        regions=regions,
        output_directory=str(_required(outputs, "directory", "outputs")),
        summary_path=str(_required(outputs, "summary", "outputs")),
    )


def prepare_canopy_mosaic(
    source_paths: tuple[Path, ...],
    building_dsm_path: Path,
    output_path: Path,
    source_nodata: float,
    minimum_height_m: float,
    height_multiplier: float,
) -> dict[str, Any]:
    """Warp multiple CHMv2 rasters to one DSM grid and retain their maximum height."""

    with rasterio.open(building_dsm_path) as dsm:
        building = dsm.read(1)
        profile = dsm.profile.copy()
        target_crs = dsm.crs
        target_transform = dsm.transform
        target_bounds = tuple(float(value) for value in dsm.bounds)
        mosaic = np.zeros((dsm.height, dsm.width), dtype=np.float32)
    source_bounds = tuple(
        raster_bounds_in_analysis_crs(path, str(target_crs)) for path in source_paths
    )
    coverage = source_coverage_fraction(target_bounds, source_bounds)
    if coverage < 1 - 1e-9:
        raise ValueError(f"Canopy sources cover only {coverage:.6f} of target grid")
    for path in source_paths:
        temporary = np.zeros_like(mosaic)
        with rasterio.open(path) as source:
            reproject(
                source=rasterio.band(source, 1),
                destination=temporary,
                src_transform=source.transform,
                src_crs=source.crs,
                src_nodata=source.nodata,
                dst_transform=target_transform,
                dst_crs=target_crs,
                dst_nodata=0,
                resampling=Resampling.max,
                init_dest_nodata=True,
            )
        mosaic = np.maximum(mosaic, temporary)
    mosaic[
        ~np.isfinite(mosaic)
        | (mosaic < minimum_height_m)
        | (mosaic >= source_nodata)
    ] = 0
    mosaic *= height_multiplier
    overlap = (mosaic > 0) & (building > 0)
    positive_before_mask = int(np.count_nonzero(mosaic > 0))
    mosaic[building > 0] = 0
    # Zero is a valid "no canopy" value. Declaring zero as nodata lets SOLWEIG
    # fill those cells from the DSM before converting a relative CDSM, which can
    # duplicate modeled obstacles. Keep a sentinel outside the valid CHMv2 range.
    profile.update(dtype="float32", compress="deflate", predictor=3, nodata=-9999.0)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with rasterio.open(output_path, "w", **profile) as target:
        target.write(mosaic, 1)
        target.update_tags(
            model="CHMv2_mosaic_relative_canopy_height",
            minimum_height_m=minimum_height_m,
            height_multiplier=height_multiplier,
            building_overlap_removed=True,
            zero_value_semantics="valid_no_canopy",
        )
    return {
        "path": str(output_path),
        "sha256": _sha256(output_path),
        "source_count": len(source_paths),
        "source_coverage_fraction": coverage,
        "positive_canopy_pixel_count_before_building_mask": positive_before_mask,
        "building_overlap_pixel_count_removed": int(np.count_nonzero(overlap)),
        "positive_canopy_pixel_count": int(np.count_nonzero(mosaic > 0)),
        "maximum_canopy_height_m": float(mosaic.max()),
    }


def build_representative_solweig_inputs(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    config = load_representative_solweig_input_config(config_path)
    registry = gpd.read_file(
        project_root / config.regions_path, layer=config.regions_layer
    ).to_crs(config.analysis_crs)
    tiles = gpd.read_file(
        project_root / config.tile_index_path, layer=config.tile_index_layer
    ).to_crs(config.analysis_crs)
    output_directory = project_root / config.output_directory
    output_directory.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, Any]] = []
    for region in config.regions:
        registry_row = registry.loc[registry["region_id"].eq(region.region_id)]
        if len(registry_row) != 1:
            raise ValueError(f"Expected one registry row for {region.region_id}")
        tile_ids = str(registry_row.iloc[0]["required_core_tile_ids"]).split(";")
        selected_tiles = tiles.loc[tiles["tile_id"].isin(tile_ids)]
        if len(selected_tiles) != len(tile_ids):
            raise ValueError(f"Missing required tile for {region.region_id}")
        extent = selected_tiles.geometry.buffer(config.shadow_buffer_m).union_all()
        buildings = gpd.read_file(
            project_root / region.buildings_path, layer="building_heights"
        ).to_crs(config.analysis_crs)
        edges = gpd.read_file(project_root / region.network_path, layer="edges").to_crs(
            config.analysis_crs
        )
        buildings = gpd.clip(buildings, extent)
        edges = gpd.clip(edges, extent)
        fixed_extent = gpd.GeoDataFrame(
            {"segment_id": ["fixed_model_extent"]},
            geometry=[extent.boundary],
            crs=config.analysis_crs,
        )
        extent_edges = gpd.GeoDataFrame(
            pd.concat([edges[["segment_id", "geometry"]], fixed_extent], ignore_index=True),
            geometry="geometry",
            crs=config.analysis_crs,
        )
        building_path = output_directory / f"{region.region_id}_building_dsm_5m.tif"
        canopy_path = output_directory / f"{region.region_id}_canopy_dsm_5m.tif"
        building_metadata = rasterize_building_dsm(
            buildings,
            extent_edges,
            building_path,
            config.analysis_crs,
            config.building_height_field,
            config.raster_resolution_m,
        )
        canopy_metadata = prepare_canopy_mosaic(
            tuple(project_root / path for path in region.canopy_sources),
            building_path,
            canopy_path,
            config.canopy_source_nodata,
            config.canopy_minimum_height_m,
            config.canopy_height_multiplier,
        )
        record = {
            "region_id": region.region_id,
            "required_core_tile_count": len(tile_ids),
            "building_count": building_metadata["building_count"],
            "grid_width": building_metadata["width"],
            "grid_height": building_metadata["height"],
            "grid_bounds": building_metadata["bounds"],
            "building_pixel_count": building_metadata["building_pixel_count"],
            "maximum_building_height_m": building_metadata["maximum_height_m"],
            **{f"canopy_{key}": value for key, value in canopy_metadata.items()},
        }
        (output_directory / f"{region.region_id}_input_readiness.json").write_text(
            json.dumps(record, indent=2), encoding="utf-8"
        )
        records.append(record)
    summary = pd.DataFrame(records)
    summary_path = project_root / config.summary_path
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary.to_csv(summary_path, index=False)
    return {"analysis_id": config.analysis_id, "region_count": len(records), "regions": records}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/representative_solweig_inputs.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(build_representative_solweig_inputs(args.config), indent=2))


if __name__ == "__main__":
    main()
