"""Raffles Place OFAT weather sensitivity for SOLWEIG and dynamic CPTL."""

from __future__ import annotations

import argparse
import hashlib
import json
import tempfile
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any

import geopandas as gpd
import numpy as np
import pandas as pd
import solweig
import yaml

from coollink_sg.heat.dynamic_utci import TimeVaryingUTCI
from coollink_sg.heat.representative_solweig_timeseries import (
    load_representative_solweig_timeseries_config,
    validate_surface_pair,
)
from coollink_sg.heat.solweig_timeseries import sample_solweig_to_roads
from coollink_sg.routing.multi_od_cptl import _routing_graph
from coollink_sg.routing.representative_cptl import (
    _dynamic_config,
    load_representative_cptl_config,
)
from coollink_sg.routing.time_dependent_cptl import compute_time_dependent_cptl_routes

PROJECT_ROOT = Path(__file__).resolve().parents[3]
RADIATION_FIELDS = (
    "clear_sky_ghi_w_m2",
    "clear_sky_dni_w_m2",
    "clear_sky_dhi_w_m2",
)


@dataclass(frozen=True)
class WeatherSensitivityConfig:
    analysis_id: str
    design: str
    base_solweig_config: str
    base_cptl_config: str
    baseline_weather_timeseries: str
    baseline_thermal_timeseries: str
    baseline_routes_geopackage: str
    baseline_routes_layer: str
    od_sample: str
    output_stem: str
    thermal_source_status: str
    temperature_deltas_deg_c: tuple[float, ...]
    humidity_deltas_percentage_points: tuple[float, ...]
    wind_speed_multipliers: tuple[float, ...]
    radiation_multipliers: tuple[float, ...]
    detour_limits: tuple[float, ...]
    baseline_temperature_delta_deg_c: float
    baseline_humidity_delta_percentage_points: float
    baseline_wind_speed_multiplier: float
    baseline_radiation_multiplier: float
    weather_root: str
    heat_root: str
    routing_root: str
    table_root: str


@dataclass(frozen=True)
class WeatherVariant:
    variant_id: str
    varied_parameter: str
    varied_value: float
    air_temperature_delta_deg_c: float
    relative_humidity_delta_percentage_points: float
    wind_speed_multiplier: float
    global_radiation_multiplier: float


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    if key not in mapping:
        raise ValueError(f"Missing required field {section}.{key}")
    return mapping[key]


def _unique(values: tuple[float, ...], name: str) -> None:
    if not values or len(values) != len(set(values)):
        raise ValueError(f"{name} must contain unique values")


def load_weather_sensitivity_config(path: str | Path) -> WeatherSensitivityConfig:
    """Load the explicit one-factor weather sensitivity design."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Weather sensitivity configuration must be a YAML mapping")
    analysis = _required(payload, "raffles_place_weather_sensitivity", "root")
    parameters = _required(payload, "parameters", "root")
    baseline = _required(payload, "baseline", "root")
    outputs = _required(payload, "outputs", "root")
    design = str(_required(analysis, "design", "analysis"))
    if design != "one_factor_at_a_time":
        raise ValueError("Only one_factor_at_a_time weather sensitivity is supported")

    temperatures = tuple(
        float(value)
        for value in _required(parameters, "air_temperature_delta_deg_c", "parameters")
    )
    humidities = tuple(
        float(value)
        for value in _required(
            parameters, "relative_humidity_delta_percentage_points", "parameters"
        )
    )
    winds = tuple(
        float(value)
        for value in _required(parameters, "wind_speed_multiplier", "parameters")
    )
    radiations = tuple(
        float(value)
        for value in _required(parameters, "global_radiation_multiplier", "parameters")
    )
    limits = tuple(
        float(value) for value in _required(parameters, "detour_limits", "parameters")
    )
    for values, name in (
        (temperatures, "air_temperature_delta_deg_c"),
        (humidities, "relative_humidity_delta_percentage_points"),
        (winds, "wind_speed_multiplier"),
        (radiations, "global_radiation_multiplier"),
    ):
        _unique(values, name)
    if any(value <= 0 for value in winds + radiations):
        raise ValueError("Wind and radiation multipliers must be positive")
    if not limits or limits[0] != 0 or tuple(sorted(set(limits))) != limits:
        raise ValueError("detour_limits must be unique, increasing, and start at zero")

    base_temperature = float(
        _required(baseline, "air_temperature_delta_deg_c", "baseline")
    )
    base_humidity = float(
        _required(
            baseline, "relative_humidity_delta_percentage_points", "baseline"
        )
    )
    base_wind = float(_required(baseline, "wind_speed_multiplier", "baseline"))
    base_radiation = float(
        _required(baseline, "global_radiation_multiplier", "baseline")
    )
    if (
        base_temperature not in temperatures
        or base_humidity not in humidities
        or base_wind not in winds
        or base_radiation not in radiations
    ):
        raise ValueError("Every baseline value must occur in its parameter values")
    output_stem = str(_required(analysis, "output_stem", "analysis"))
    if not output_stem or Path(output_stem).name != output_stem:
        raise ValueError("output_stem must be a filename stem")
    status = str(_required(analysis, "thermal_source_status", "analysis"))
    if "solweig" not in status or "not_field_validated" not in status:
        raise ValueError("thermal_source_status must retain SOLWEIG validation limits")
    return WeatherSensitivityConfig(
        analysis_id=str(_required(analysis, "analysis_id", "analysis")),
        design=design,
        base_solweig_config=str(_required(analysis, "base_solweig_config", "analysis")),
        base_cptl_config=str(_required(analysis, "base_cptl_config", "analysis")),
        baseline_weather_timeseries=str(
            _required(analysis, "baseline_weather_timeseries", "analysis")
        ),
        baseline_thermal_timeseries=str(
            _required(analysis, "baseline_thermal_timeseries", "analysis")
        ),
        baseline_routes_geopackage=str(
            _required(analysis, "baseline_routes_geopackage", "analysis")
        ),
        baseline_routes_layer=str(
            _required(analysis, "baseline_routes_layer", "analysis")
        ),
        od_sample=str(_required(analysis, "od_sample", "analysis")),
        output_stem=output_stem,
        thermal_source_status=status,
        temperature_deltas_deg_c=temperatures,
        humidity_deltas_percentage_points=humidities,
        wind_speed_multipliers=winds,
        radiation_multipliers=radiations,
        detour_limits=limits,
        baseline_temperature_delta_deg_c=base_temperature,
        baseline_humidity_delta_percentage_points=base_humidity,
        baseline_wind_speed_multiplier=base_wind,
        baseline_radiation_multiplier=base_radiation,
        weather_root=str(_required(outputs, "weather_root", "outputs")),
        heat_root=str(_required(outputs, "heat_root", "outputs")),
        routing_root=str(_required(outputs, "routing_root", "outputs")),
        table_root=str(_required(outputs, "table_root", "outputs")),
    )


def _value_slug(value: float) -> str:
    return f"{value:g}".replace("-", "minus_").replace(".", "p")


def build_weather_variants(
    config: WeatherSensitivityConfig,
) -> tuple[WeatherVariant, ...]:
    """Return the baseline once and every non-baseline OFAT perturbation."""

    variants = [
        WeatherVariant(
            variant_id="baseline",
            varied_parameter="baseline",
            varied_value=0.0,
            air_temperature_delta_deg_c=config.baseline_temperature_delta_deg_c,
            relative_humidity_delta_percentage_points=(
                config.baseline_humidity_delta_percentage_points
            ),
            wind_speed_multiplier=config.baseline_wind_speed_multiplier,
            global_radiation_multiplier=config.baseline_radiation_multiplier,
        )
    ]
    definitions = (
        (
            "air_temperature_delta_deg_c",
            config.temperature_deltas_deg_c,
            config.baseline_temperature_delta_deg_c,
        ),
        (
            "relative_humidity_delta_percentage_points",
            config.humidity_deltas_percentage_points,
            config.baseline_humidity_delta_percentage_points,
        ),
        (
            "wind_speed_multiplier",
            config.wind_speed_multipliers,
            config.baseline_wind_speed_multiplier,
        ),
        (
            "global_radiation_multiplier",
            config.radiation_multipliers,
            config.baseline_radiation_multiplier,
        ),
    )
    for parameter, values, baseline_value in definitions:
        for value in values:
            if value == baseline_value:
                continue
            kwargs = {
                "air_temperature_delta_deg_c": config.baseline_temperature_delta_deg_c,
                "relative_humidity_delta_percentage_points": (
                    config.baseline_humidity_delta_percentage_points
                ),
                "wind_speed_multiplier": config.baseline_wind_speed_multiplier,
                "global_radiation_multiplier": config.baseline_radiation_multiplier,
            }
            kwargs[parameter] = value
            variants.append(
                WeatherVariant(
                    variant_id=f"{parameter}_{_value_slug(value)}",
                    varied_parameter=parameter,
                    varied_value=value,
                    **kwargs,
                )
            )
    return tuple(variants)


def apply_weather_variant(
    baseline_weather: pd.DataFrame, variant: WeatherVariant
) -> pd.DataFrame:
    """Apply one transparent perturbation to the complete baseline weather series."""

    required = {
        "timestamp_sgt",
        "air_temperature_deg_c",
        "relative_humidity_percent",
        "wind_speed_m_s",
        *RADIATION_FIELDS,
    }
    missing = required.difference(baseline_weather.columns)
    if missing:
        raise ValueError(f"Baseline weather is missing fields: {sorted(missing)}")
    result = baseline_weather.copy()
    result["air_temperature_deg_c"] = (
        result["air_temperature_deg_c"].astype(float)
        + variant.air_temperature_delta_deg_c
    )
    result["relative_humidity_percent"] = (
        result["relative_humidity_percent"].astype(float)
        + variant.relative_humidity_delta_percentage_points
    )
    result["wind_speed_m_s"] = (
        result["wind_speed_m_s"].astype(float) * variant.wind_speed_multiplier
    )
    for field in RADIATION_FIELDS:
        result[field] = (
            result[field].astype(float) * variant.global_radiation_multiplier
        )
    numeric = [
        "air_temperature_deg_c",
        "relative_humidity_percent",
        "wind_speed_m_s",
        *RADIATION_FIELDS,
    ]
    if not np.isfinite(result[numeric].to_numpy(dtype=float)).all():
        raise ValueError("Weather variant contains non-finite values")
    if not result["relative_humidity_percent"].between(0, 100).all():
        raise ValueError("Relative humidity perturbation leaves the physical range")
    if (result["wind_speed_m_s"] <= 0).any() or (result[list(RADIATION_FIELDS)] <= 0).any().any():
        raise ValueError("Weather wind speed and daytime radiation must stay positive")
    result["weather_scenario_id"] = variant.variant_id
    result["weather_sensitivity_design"] = "one_factor_at_a_time_not_observed_weather"
    return result


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def summarize_thermal_variant(
    baseline: pd.DataFrame,
    changed: pd.DataFrame,
    variant: WeatherVariant,
) -> dict[str, Any]:
    """Summarize paired road-time thermal differences from baseline."""

    keys = ["segment_id", "timestamp_sgt", "height_scenario"]
    if not baseline[keys].equals(changed[keys]):
        raise ValueError(f"Thermal keys differ for {variant.variant_id}")
    row: dict[str, Any] = {**variant.__dict__, "road_time_record_count": len(changed)}
    for field in (
        "road_mean_tmrt_deg_c",
        "modeled_utci_deg_c",
        "road_mean_sun_fraction",
    ):
        delta = changed[field].astype(float) - baseline[field].astype(float)
        row[f"mean_delta_{field}"] = float(delta.mean())
        row[f"median_delta_{field}"] = float(delta.median())
        row[f"q05_delta_{field}"] = float(delta.quantile(0.05))
        row[f"q95_delta_{field}"] = float(delta.quantile(0.95))
    return row


def summarize_weather_routes(routes: pd.DataFrame) -> pd.DataFrame:
    """Summarize CPTL benefit for every weather variant and detour cap."""

    rows: list[dict[str, Any]] = []
    for (variant_id, cap), frame in routes.groupby(
        ["variant_id", "detour_limit_fraction"], sort=False
    ):
        reductions = frame["primary_cptl_reduction_vs_shortest_percent"].astype(float)
        rows.append(
            {
                "variant_id": variant_id,
                "varied_parameter": frame["varied_parameter"].iloc[0],
                "varied_value": float(frame["varied_value"].iloc[0]),
                "detour_limit_fraction": float(cap),
                "case_count": len(frame),
                "median_route_cptl_deg_c_min": float(
                    frame["cptl_above_26_deg_c_min"].median()
                ),
                "median_cptl_reduction_percent": float(reductions.median()),
                "q25_cptl_reduction_percent": float(reductions.quantile(0.25)),
                "q75_cptl_reduction_percent": float(reductions.quantile(0.75)),
                "positive_reduction_share_percent": float(
                    100 * reductions.gt(1e-9).mean()
                ),
                "median_distance_increase_percent": float(
                    100 * (frame["distance_ratio_to_shortest"].median() - 1)
                ),
            }
        )
    return pd.DataFrame(rows)


def compare_routes_to_baseline(routes: pd.DataFrame) -> pd.DataFrame:
    """Pair every route with its baseline-weather route and compare conclusions."""

    keys = ["od_id", "departure_time_sgt", "detour_limit_fraction"]
    baseline = routes.loc[
        routes["variant_id"].eq("baseline"),
        keys
        + [
            "route_id",
            "primary_cptl_reduction_vs_shortest_percent",
            "distance_ratio_to_shortest",
        ],
    ].rename(
        columns={
            "route_id": "baseline_route_id",
            "primary_cptl_reduction_vs_shortest_percent": (
                "baseline_cptl_reduction_percent"
            ),
            "distance_ratio_to_shortest": "baseline_distance_ratio_to_shortest",
        }
    )
    if baseline.duplicated(keys).any():
        raise ValueError("Baseline routes are not unique by OD, departure, and cap")
    comparison = routes.merge(baseline, on=keys, how="left", validate="many_to_one")
    comparison["route_changed_vs_baseline"] = comparison["route_id"].ne(
        comparison["baseline_route_id"]
    )
    comparison["positive_reduction_status_matches_baseline"] = (
        comparison["primary_cptl_reduction_vs_shortest_percent"].gt(1e-9)
        == comparison["baseline_cptl_reduction_percent"].gt(1e-9)
    )
    comparison["cptl_reduction_delta_percentage_points"] = (
        comparison["primary_cptl_reduction_vs_shortest_percent"]
        - comparison["baseline_cptl_reduction_percent"]
    )
    return comparison


def summarize_route_stability(comparison: pd.DataFrame) -> pd.DataFrame:
    """Aggregate exact-route and benefit-direction stability by scenario and cap."""

    rows: list[dict[str, Any]] = []
    for (variant_id, cap), frame in comparison.groupby(
        ["variant_id", "detour_limit_fraction"], sort=False
    ):
        rows.append(
            {
                "variant_id": variant_id,
                "varied_parameter": frame["varied_parameter"].iloc[0],
                "varied_value": float(frame["varied_value"].iloc[0]),
                "detour_limit_fraction": float(cap),
                "case_count": len(frame),
                "exact_route_share_vs_baseline_percent": float(
                    100 * (~frame["route_changed_vs_baseline"]).mean()
                ),
                "benefit_direction_agreement_vs_baseline_percent": float(
                    100
                    * frame[
                        "positive_reduction_status_matches_baseline"
                    ].mean()
                ),
                "median_cptl_reduction_delta_percentage_points": float(
                    frame["cptl_reduction_delta_percentage_points"].median()
                ),
            }
        )
    return pd.DataFrame(rows)


def _thermal_cache_valid(
    thermal_path: Path,
    summary_path: Path,
    variant: WeatherVariant,
    expected_rows: int,
) -> bool:
    if not thermal_path.exists() or not summary_path.exists():
        return False
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    return (
        summary.get("variant_id") == variant.variant_id
        and summary.get("row_count") == expected_rows
        and summary.get("road_timeseries_sha256") == _sha256(thermal_path)
    )


def run_weather_sensitivity(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Run/resume nine SOLWEIG weather variants and matched dynamic CPTL routes."""

    sensitivity = load_weather_sensitivity_config(config_path)
    variants = build_weather_variants(sensitivity)
    base_solweig = load_representative_solweig_timeseries_config(
        project_root / sensitivity.base_solweig_config
    )
    base_cptl = load_representative_cptl_config(
        project_root / sensitivity.base_cptl_config
    )
    if len(base_solweig.regions) != 1 or len(base_cptl.regions) != 1:
        raise ValueError("Raffles Place sensitivity requires one matching region")
    thermal_region = base_solweig.regions[0]
    route_region = base_cptl.regions[0]
    if (
        thermal_region.region_id != "raffles_place_mrt"
        or route_region.region_id != thermal_region.region_id
    ):
        raise ValueError("Weather sensitivity is restricted to the Raffles Place model")

    baseline_weather_path = project_root / sensitivity.baseline_weather_timeseries
    baseline_thermal_path = project_root / sensitivity.baseline_thermal_timeseries
    baseline_weather = pd.read_csv(baseline_weather_path)
    baseline_thermal = pd.read_csv(baseline_thermal_path)
    expected_rows = len(baseline_thermal)
    if expected_rows != 19002 * 37:
        raise ValueError("Baseline thermal table does not contain 19,002 × 37 rows")
    timestamps = pd.DatetimeIndex(pd.to_datetime(baseline_weather["timestamp_sgt"]))
    if len(timestamps) != 37 or timestamps.duplicated().any():
        raise ValueError("Baseline weather must contain 37 unique timestamps")

    registry = gpd.read_file(
        project_root / base_solweig.registry_path, layer=base_solweig.registry_layer
    )
    registry_row = registry.loc[registry["region_id"].eq(thermal_region.region_id)]
    if len(registry_row) != 1:
        raise ValueError("Expected one Raffles Place registry record")
    latitude = float(registry_row.iloc[0]["latitude"])
    longitude = float(registry_row.iloc[0]["longitude"])
    network_path = project_root / thermal_region.network_path
    building_path = project_root / thermal_region.building_dsm_path
    canopy_path = project_root / thermal_region.canopy_dsm_path
    validate_surface_pair(building_path, canopy_path, base_solweig.analysis_crs)
    edges = gpd.read_file(network_path, layer="edges").to_crs(base_solweig.analysis_crs)
    fingerprint = f"{_sha256(building_path)[:10]}_{_sha256(canopy_path)[:10]}"
    surface = solweig.SurfaceData.prepare(
        dsm=building_path,
        working_dir=(
            project_root
            / "data/interim/solweig"
            / f"{thermal_region.region_id}_{fingerprint}_5m_precomputed"
        ),
        cdsm=canopy_path,
        trunk_ratio=base_solweig.canopy_trunk_ratio,
        dsm_relative=False,
        cdsm_relative=True,
        force_recompute=False,
    )
    weather_root = project_root / sensitivity.weather_root
    heat_root = project_root / sensitivity.heat_root
    weather_root.mkdir(parents=True, exist_ok=True)
    heat_root.mkdir(parents=True, exist_ok=True)
    interim_run_root = project_root / "data/interim/solweig/raffles_place_weather_sensitivity"
    interim_run_root.mkdir(parents=True, exist_ok=True)

    thermal_sources: dict[str, tuple[Path, str]] = {
        "baseline": (baseline_thermal_path, base_solweig.thermal_source_status)
    }
    thermal_rows = [
        summarize_thermal_variant(baseline_thermal, baseline_thermal, variants[0])
    ]
    for index, variant in enumerate(variants[1:], start=1):
        weather = apply_weather_variant(baseline_weather, variant)
        weather_path = weather_root / f"{variant.variant_id}.csv"
        weather.to_csv(weather_path, index=False)
        thermal_path = heat_root / f"{variant.variant_id}_road_thermal_timeseries.csv.gz"
        summary_path = heat_root / f"{variant.variant_id}_road_thermal_timeseries_summary.json"
        if _thermal_cache_valid(thermal_path, summary_path, variant, expected_rows):
            print(f"[SOLWEIG {index}/8] reuse {variant.variant_id}", flush=True)
        else:
            print(f"[SOLWEIG {index}/8] run {variant.variant_id}", flush=True)
            with tempfile.TemporaryDirectory(
                prefix=f"{variant.variant_id}_", dir=interim_run_root
            ) as temporary:
                output_directory = Path(temporary)
                solweig_weather = [
                    solweig.Weather(
                        datetime=pd.Timestamp(row.timestamp_sgt)
                        .tz_localize(None)
                        .to_pydatetime(),
                        ta=float(row.air_temperature_deg_c),
                        rh=float(row.relative_humidity_percent),
                        global_rad=float(row.clear_sky_ghi_w_m2),
                        ws=float(row.wind_speed_m_s),
                        timestep_minutes=base_solweig.interval_minutes,
                    )
                    for row in weather.itertuples(index=False)
                ]
                result = solweig.calculate(
                    surface,
                    solweig_weather,
                    solweig.Location(
                        latitude=latitude, longitude=longitude, utc_offset=8
                    ),
                    output_dir=output_directory,
                    use_anisotropic_sky=base_solweig.use_anisotropic_sky,
                    max_shadow_distance_m=base_solweig.max_shadow_distance_m,
                    outputs=["tmrt", "utci", "shadow"],
                )
                roads, sampling = sample_solweig_to_roads(
                    edges,
                    building_path,
                    output_directory,
                    timestamps,
                    base_solweig.edge_sampling_interval_m,
                    sensitivity.thermal_source_status,
                )
                roads.insert(0, "weather_scenario_id", variant.variant_id)
                roads.to_csv(thermal_path, index=False, compression="gzip")
                thermal_record = {
                    "analysis_id": sensitivity.analysis_id,
                    "variant_id": variant.variant_id,
                    "variant": variant.__dict__,
                    "weather_timeseries_path": str(weather_path.relative_to(project_root)),
                    "weather_timeseries_sha256": _sha256(weather_path),
                    "road_timeseries_path": str(thermal_path.relative_to(project_root)),
                    "road_timeseries_sha256": _sha256(thermal_path),
                    "row_count": len(roads),
                    "solweig_timesteps": int(result.n_timesteps),
                    "thermal_source_status": sensitivity.thermal_source_status,
                    **sampling,
                }
                summary_path.write_text(
                    json.dumps(thermal_record, indent=2, ensure_ascii=False),
                    encoding="utf-8",
                )
        changed = pd.read_csv(thermal_path)
        thermal_rows.append(summarize_thermal_variant(baseline_thermal, changed, variant))
        thermal_sources[variant.variant_id] = (
            thermal_path,
            sensitivity.thermal_source_status,
        )
    thermal_summary = pd.DataFrame(thermal_rows)

    nodes = gpd.read_file(network_path, layer="nodes").to_crs(base_cptl.output_crs)
    route_edges = gpd.read_file(network_path, layer="edges").to_crs(base_cptl.output_crs)
    graph = _routing_graph(nodes, route_edges, base_cptl.output_crs)
    od_sample = pd.read_csv(project_root / sensitivity.od_sample)
    required_od = {"od_id", "origin_node", "destination_node", "distance_band_rank"}
    if required_od.difference(od_sample.columns) or od_sample["od_id"].duplicated().any():
        raise ValueError("Raffles Place OD sample is invalid")
    route_frames: list[gpd.GeoDataFrame] = []
    baseline_routes = gpd.read_file(
        project_root / sensitivity.baseline_routes_geopackage,
        layer=sensitivity.baseline_routes_layer,
    )
    baseline_routes.insert(0, "variant_id", "baseline")
    baseline_routes.insert(1, "varied_parameter", "baseline")
    baseline_routes.insert(2, "varied_value", 0.0)
    for field, value in variants[0].__dict__.items():
        if field not in {"variant_id", "varied_parameter", "varied_value"}:
            baseline_routes[field] = value
    route_frames.append(baseline_routes)

    route_interim = project_root / "data/interim/routing/raffles_place_weather_sensitivity"
    route_interim.mkdir(parents=True, exist_ok=True)
    base_dynamic = _dynamic_config(base_cptl, route_region)
    for variant_index, variant in enumerate(variants[1:], start=1):
        thermal_path, status = thermal_sources[variant.variant_id]
        thermal_hash = _sha256(thermal_path)
        interim_path = route_interim / f"{variant.variant_id}.gpkg"
        metadata_path = route_interim / f"{variant.variant_id}.json"
        expected_routes = len(od_sample) * len(base_cptl.departure_times) * len(
            sensitivity.detour_limits
        )
        reuse = False
        if interim_path.exists() and metadata_path.exists():
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            existing = gpd.read_file(interim_path, layer="routes")
            reuse = (
                metadata.get("thermal_sha256") == thermal_hash
                and metadata.get("route_count") == expected_routes
                and len(existing) == expected_routes
            )
        if reuse:
            print(f"[ROUTING {variant_index}/8] reuse {variant.variant_id}", flush=True)
            route_frames.append(existing)
            continue
        thermal = TimeVaryingUTCI(pd.read_csv(thermal_path), "central", status)
        run_config = replace(
            base_dynamic,
            analysis_id=f"{sensitivity.analysis_id}|{variant.variant_id}",
            detour_limits=sensitivity.detour_limits,
            thermal_source_status=status,
            dynamic_thermal_path=str(thermal_path.relative_to(project_root)),
        )
        variant_frames: list[gpd.GeoDataFrame] = []
        for od_index, od in enumerate(od_sample.itertuples(index=False), start=1):
            print(
                f"[ROUTING {variant_index}/8 {variant.variant_id}] "
                f"OD {od_index}/{len(od_sample)} {od.od_id}",
                flush=True,
            )
            routes, _, _ = compute_time_dependent_cptl_routes(
                nodes,
                route_edges,
                thermal,
                int(od.origin_node),
                int(od.destination_node),
                run_config,
                routing_graph=graph,
            )
            routes.insert(0, "variant_id", variant.variant_id)
            routes.insert(1, "varied_parameter", variant.varied_parameter)
            routes.insert(2, "varied_value", variant.varied_value)
            routes.insert(3, "air_temperature_delta_deg_c", variant.air_temperature_delta_deg_c)
            routes.insert(
                4,
                "relative_humidity_delta_percentage_points",
                variant.relative_humidity_delta_percentage_points,
            )
            routes.insert(5, "wind_speed_multiplier", variant.wind_speed_multiplier)
            routes.insert(6, "global_radiation_multiplier", variant.global_radiation_multiplier)
            routes.insert(7, "od_id", od.od_id)
            routes.insert(8, "origin_node", int(od.origin_node))
            routes.insert(9, "destination_node", int(od.destination_node))
            routes.insert(10, "distance_band_rank", int(od.distance_band_rank))
            variant_frames.append(routes)
        variant_routes = gpd.GeoDataFrame(
            pd.concat(variant_frames, ignore_index=True),
            geometry="geometry",
            crs=base_cptl.output_crs,
        )
        if interim_path.exists():
            interim_path.unlink()
        variant_routes.to_file(interim_path, layer="routes", driver="GPKG")
        metadata_path.write_text(
            json.dumps(
                {
                    "variant_id": variant.variant_id,
                    "thermal_sha256": thermal_hash,
                    "route_count": len(variant_routes),
                },
                indent=2,
            ),
            encoding="utf-8",
        )
        route_frames.append(variant_routes)

    all_routes = gpd.GeoDataFrame(
        pd.concat(route_frames, ignore_index=True),
        geometry="geometry",
        crs=base_cptl.output_crs,
    )
    expected_total = len(variants) * len(od_sample) * len(base_cptl.departure_times) * len(
        sensitivity.detour_limits
    )
    route_keys = [
        "variant_id",
        "od_id",
        "departure_time_sgt",
        "detour_limit_fraction",
    ]
    cap_violations = all_routes["distance_ratio_to_shortest"].gt(
        1 + all_routes["detour_limit_fraction"] + 1e-8
    )
    if (
        len(all_routes) != expected_total
        or all_routes.duplicated(route_keys).any()
        or all_routes["cptl_above_26_deg_c_min"].lt(0).any()
        or all_routes["primary_cptl_reduction_vs_shortest_percent"].lt(-1e-8).any()
        or cap_violations.any()
    ):
        raise ValueError("Weather-sensitivity route quality gates failed")
    route_summary = summarize_weather_routes(all_routes)
    comparison = compare_routes_to_baseline(all_routes)
    stability = summarize_route_stability(comparison)

    routing_root = project_root / sensitivity.routing_root
    table_root = project_root / sensitivity.table_root
    routing_root.mkdir(parents=True, exist_ok=True)
    table_root.mkdir(parents=True, exist_ok=True)
    output_gpkg = routing_root / f"{sensitivity.output_stem}.gpkg"
    if output_gpkg.exists():
        output_gpkg.unlink()
    all_routes.to_file(output_gpkg, layer="weather_sensitivity_routes", driver="GPKG")
    all_routes.drop(columns="geometry").to_csv(
        routing_root / f"{sensitivity.output_stem}_routes.csv", index=False
    )
    comparison.drop(columns="geometry").to_csv(
        routing_root / f"{sensitivity.output_stem}_comparison.csv", index=False
    )
    route_summary.to_csv(
        routing_root / f"{sensitivity.output_stem}_route_summary.csv", index=False
    )
    stability.to_csv(
        routing_root / f"{sensitivity.output_stem}_stability_summary.csv", index=False
    )
    thermal_summary.to_csv(
        heat_root / f"{sensitivity.output_stem}_thermal_summary.csv", index=False
    )
    for frame, suffix in (
        (thermal_summary, "thermal_summary"),
        (route_summary, "route_summary"),
        (stability, "stability_summary"),
    ):
        frame.to_csv(table_root / f"{sensitivity.output_stem}_{suffix}.csv", index=False)

    five = route_summary.loc[route_summary["detour_limit_fraction"].eq(0.05)]
    five_stability = stability.loc[
        stability["detour_limit_fraction"].eq(0.05)
        & stability["variant_id"].ne("baseline")
    ]
    result = {
        "analysis_id": sensitivity.analysis_id,
        "design": sensitivity.design,
        "variant_count": len(variants),
        "new_solweig_run_count": len(variants) - 1,
        "road_time_rows_per_variant": expected_rows,
        "od_count": int(od_sample["od_id"].nunique()),
        "route_scenario_count": len(all_routes),
        "quality_gates": {
            "duplicate_route_keys": int(all_routes.duplicated(route_keys).sum()),
            "negative_cptl": int(all_routes["cptl_above_26_deg_c_min"].lt(0).sum()),
            "negative_reduction": int(
                all_routes["primary_cptl_reduction_vs_shortest_percent"].lt(-1e-8).sum()
            ),
            "distance_cap_violations": int(cap_violations.sum()),
        },
        "five_percent_cap": {
            "median_reduction_range_percent": [
                float(five["median_cptl_reduction_percent"].min()),
                float(five["median_cptl_reduction_percent"].max()),
            ],
            "positive_share_range_percent": [
                float(five["positive_reduction_share_percent"].min()),
                float(five["positive_reduction_share_percent"].max()),
            ],
            "exact_route_share_vs_baseline_range_percent": [
                float(five_stability["exact_route_share_vs_baseline_percent"].min()),
                float(five_stability["exact_route_share_vs_baseline_percent"].max()),
            ],
            "benefit_direction_agreement_range_percent": [
                float(
                    five_stability[
                        "benefit_direction_agreement_vs_baseline_percent"
                    ].min()
                ),
                float(
                    five_stability[
                        "benefit_direction_agreement_vs_baseline_percent"
                    ].max()
                ),
            ],
        },
        "thermal_sources": {
            key: {
                "path": str(path.relative_to(project_root)),
                "sha256": _sha256(path),
                "thermal_source_status": status,
            }
            for key, (path, status) in thermal_sources.items()
        },
        "interpretation_limit": (
            "OFAT perturbations are design stress tests around one repeated S50 station "
            "snapshot and modeled clear-sky radiation. They are not observed weather "
            "regimes, probabilities, interactions, local CBD meteorology, or field validation."
        ),
        "outputs": {
            "geopackage": str(output_gpkg.relative_to(project_root)),
            "routes_csv": str(
                (routing_root / f"{sensitivity.output_stem}_routes.csv").relative_to(
                    project_root
                )
            ),
            "comparison_csv": str(
                (routing_root / f"{sensitivity.output_stem}_comparison.csv").relative_to(
                    project_root
                )
            ),
            "route_summary_csv": str(
                (
                    routing_root / f"{sensitivity.output_stem}_route_summary.csv"
                ).relative_to(project_root)
            ),
            "stability_summary_csv": str(
                (
                    routing_root / f"{sensitivity.output_stem}_stability_summary.csv"
                ).relative_to(project_root)
            ),
            "thermal_summary_csv": str(
                (
                    heat_root / f"{sensitivity.output_stem}_thermal_summary.csv"
                ).relative_to(project_root)
            ),
        },
    }
    result_path = routing_root / f"{sensitivity.output_stem}.json"
    result_path.write_text(
        json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/raffles_place_weather_sensitivity.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(run_weather_sensitivity(args.config), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
