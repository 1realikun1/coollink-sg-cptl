"""Audit Raffles Place network, building heights, and SOLWEIG raster readiness."""

from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import geopandas as gpd
import networkx as nx
import numpy as np
import pandas as pd
import rasterio
import yaml
from pyproj import CRS

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class RafflesPlaceInputAuditConfig:
    """Validated paths and gates for one input-readiness audit."""

    analysis_id: str
    region_id: str
    analysis_crs: str
    raster_resolution_m: float
    required_core_tile_count: int
    required_canopy_source_coverage_fraction: float
    readiness_status: str
    raw_snapshot_directory: str
    network_path: str
    buildings_path: str
    solweig_input_readiness_path: str
    building_dsm_path: str
    canopy_dsm_path: str
    canopy_source_path: str
    output_json_path: str
    output_csv_path: str


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    if key not in mapping:
        raise ValueError(f"Missing required field {section}.{key}")
    return mapping[key]


def load_raffles_place_input_audit_config(
    path: str | Path,
) -> RafflesPlaceInputAuditConfig:
    """Load explicit readiness gates without hardcoded scientific parameters."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Raffles Place input audit configuration must be a mapping")
    model = _required(payload, "raffles_place_input_audit", "root")
    inputs = _required(payload, "inputs", "root")
    outputs = _required(payload, "outputs", "root")
    crs = str(_required(model, "analysis_crs", "audit"))
    if not CRS.from_user_input(crs).is_projected:
        raise ValueError("analysis_crs must be projected")
    resolution = float(_required(model, "raster_resolution_m", "audit"))
    tile_count = int(_required(model, "required_core_tile_count", "audit"))
    coverage = float(
        _required(model, "required_canopy_source_coverage_fraction", "audit")
    )
    if resolution <= 0 or tile_count <= 0 or not 0 < coverage <= 1:
        raise ValueError("Resolution, tile count, and coverage gates must be positive")
    return RafflesPlaceInputAuditConfig(
        analysis_id=str(_required(model, "analysis_id", "audit")),
        region_id=str(_required(model, "region_id", "audit")),
        analysis_crs=crs,
        raster_resolution_m=resolution,
        required_core_tile_count=tile_count,
        required_canopy_source_coverage_fraction=coverage,
        readiness_status=str(_required(model, "readiness_status", "audit")),
        raw_snapshot_directory=str(_required(inputs, "raw_snapshot_directory", "inputs")),
        network_path=str(_required(inputs, "network", "inputs")),
        buildings_path=str(_required(inputs, "buildings", "inputs")),
        solweig_input_readiness_path=str(
            _required(inputs, "solweig_input_readiness", "inputs")
        ),
        building_dsm_path=str(_required(inputs, "building_dsm", "inputs")),
        canopy_dsm_path=str(_required(inputs, "canopy_dsm", "inputs")),
        canopy_source_path=str(_required(inputs, "canopy_source", "inputs")),
        output_json_path=str(_required(outputs, "json", "outputs")),
        output_csv_path=str(_required(outputs, "csv", "outputs")),
    )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def audit_raster_pair(
    building_dsm_path: Path,
    canopy_dsm_path: Path,
    expected_crs: str,
    expected_resolution_m: float,
) -> dict[str, Any]:
    """Require identical nonnegative relative-height grids with zero canopy overlap."""

    with rasterio.open(building_dsm_path) as building_source:
        building = building_source.read(1)
        building_profile = {
            "crs": building_source.crs,
            "shape": building.shape,
            "transform": building_source.transform,
            "bounds": tuple(float(value) for value in building_source.bounds),
            "resolution": tuple(float(value) for value in building_source.res),
            "nodata": building_source.nodata,
            "tags": building_source.tags(),
        }
    with rasterio.open(canopy_dsm_path) as canopy_source:
        canopy = canopy_source.read(1)
        canopy_profile = {
            "crs": canopy_source.crs,
            "shape": canopy.shape,
            "transform": canopy_source.transform,
            "bounds": tuple(float(value) for value in canopy_source.bounds),
            "resolution": tuple(float(value) for value in canopy_source.res),
            "nodata": canopy_source.nodata,
            "tags": canopy_source.tags(),
        }
    grid_fields = ("crs", "shape", "transform", "bounds", "resolution")
    if any(building_profile[field] != canopy_profile[field] for field in grid_fields):
        raise ValueError("Building DSM and canopy CDSM grids are not identical")
    if str(building_profile["crs"]) != expected_crs:
        raise ValueError("Raster CRS does not match the configured analysis CRS")
    if building_profile["resolution"] != (expected_resolution_m, expected_resolution_m):
        raise ValueError("Raster resolution does not match the configured value")
    if not np.isfinite(building).all() or not np.isfinite(canopy).all():
        raise ValueError("Relative-height rasters must not contain non-finite cells")
    if float(building.min()) < 0 or float(canopy.min()) < 0:
        raise ValueError("Relative-height rasters must be nonnegative")
    if canopy_profile["nodata"] != -9999.0:
        raise ValueError("Canopy CDSM must reserve -9999 for NoData")
    if canopy_profile["tags"].get("zero_value_semantics") != "valid_no_canopy":
        raise ValueError("Canopy zero-value semantics are missing")
    overlap = int(np.count_nonzero((building > 0) & (canopy > 0)))
    if overlap:
        raise ValueError(f"Building and canopy positive cells overlap: {overlap}")
    return {
        "crs": expected_crs,
        "width": int(building.shape[1]),
        "height": int(building.shape[0]),
        "resolution_m": expected_resolution_m,
        "bounds": building_profile["bounds"],
        "building_nodata": building_profile["nodata"],
        "canopy_nodata": canopy_profile["nodata"],
        "building_positive_pixel_count": int(np.count_nonzero(building > 0)),
        "canopy_positive_pixel_count": int(np.count_nonzero(canopy > 0)),
        "positive_overlap_pixel_count": overlap,
        "maximum_building_height_m": float(building.max()),
        "maximum_canopy_height_m": float(canopy.max()),
    }


def audit_raffles_place_inputs(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Run every configured input gate and write a provenance-aware audit."""

    config = load_raffles_place_input_audit_config(config_path)
    raw_root = project_root / config.raw_snapshot_directory
    manifest_path = raw_root / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("region_ids") != [config.region_id]:
        raise ValueError("Raw manifest does not contain exactly the configured region")
    raw_paths = {
        "manifest": manifest_path,
        "walk_graphml": raw_root / config.region_id / "walk_raw.graphml",
        "walk_geopackage": raw_root / config.region_id / "walk_raw.gpkg",
        "built_environment_geopackage": (
            raw_root / config.region_id / "built_environment_raw.gpkg"
        ),
    }
    if missing := [name for name, path in raw_paths.items() if not path.exists()]:
        raise FileNotFoundError(f"Raw snapshot artifacts are missing: {missing}")

    network_path = project_root / config.network_path
    nodes = gpd.read_file(network_path, layer="nodes")
    edges = gpd.read_file(network_path, layer="edges")
    buildings = gpd.read_file(
        project_root / config.buildings_path, layer="building_heights"
    )
    for name, frame in (("nodes", nodes), ("edges", edges), ("buildings", buildings)):
        if str(frame.crs) != config.analysis_crs:
            raise ValueError(f"{name} CRS does not match {config.analysis_crs}")
        if frame.empty or frame.geometry.is_empty.any() or frame.geometry.isna().any():
            raise ValueError(f"{name} contains missing or empty geometry")
    if edges["segment_id"].isna().any() or edges["segment_id"].duplicated().any():
        raise ValueError("Network segment_id values must be complete and unique")
    if not np.isfinite(edges["length_m"]).all() or not edges["length_m"].gt(0).all():
        raise ValueError("Every network edge must have a positive finite metric length")
    node_ids = set(nodes["osmid"].astype(int))
    edge_node_ids = set(edges["u"].astype(int)) | set(edges["v"].astype(int))
    if not edge_node_ids.issubset(node_ids):
        raise ValueError("Every edge endpoint must be present in the node layer")
    graph = nx.MultiDiGraph()
    graph.add_nodes_from(node_ids)
    graph.add_edges_from(
        (int(row.u), int(row.v), int(row.key)) for row in edges.itertuples(index=False)
    )
    weak_components = list(nx.weakly_connected_components(graph))
    strong_components = list(nx.strongly_connected_components(graph))
    if buildings["building_id"].isna().any() or buildings["building_id"].duplicated().any():
        raise ValueError("Building IDs must be complete and unique")
    height_fields = ["height_low_m", "height_central_m", "height_high_m"]
    heights = buildings[height_fields].to_numpy(dtype=float)
    if not np.isfinite(heights).all() or not (heights > 0).all():
        raise ValueError("Building heights must be complete, finite, and positive")
    if not ((heights[:, 0] <= heights[:, 1]) & (heights[:, 1] <= heights[:, 2])).all():
        raise ValueError("Building height scenarios must be ordered")

    readiness = json.loads(
        (project_root / config.solweig_input_readiness_path).read_text(encoding="utf-8")
    )
    if readiness["required_core_tile_count"] != config.required_core_tile_count:
        raise ValueError("Required core-tile count does not match the configured gate")
    coverage = float(readiness["canopy_source_coverage_fraction"])
    if coverage < config.required_canopy_source_coverage_fraction:
        raise ValueError("Canopy source coverage is below the configured gate")
    building_dsm = project_root / config.building_dsm_path
    canopy_dsm = project_root / config.canopy_dsm_path
    raster_audit = audit_raster_pair(
        building_dsm,
        canopy_dsm,
        config.analysis_crs,
        config.raster_resolution_m,
    )
    source_paths = {
        **raw_paths,
        "canopy_source": project_root / config.canopy_source_path,
    }
    result = {
        "analysis_id": config.analysis_id,
        "region_id": config.region_id,
        "readiness_status": config.readiness_status,
        "all_quality_gates_passed": True,
        "raw_snapshot": {
            "snapshot_id": manifest["snapshot_id"],
            "retrieved_at_utc": manifest["retrieved_at_utc"],
            "source": manifest["source"],
            "artifact_sha256": {
                name: _sha256(path) for name, path in source_paths.items()
            },
        },
        "network": {
            "crs": config.analysis_crs,
            "node_count": len(nodes),
            "directed_edge_count": len(edges),
            "unique_segment_id_count": int(edges["segment_id"].nunique()),
            "total_directed_edge_length_km": float(edges["length_m"].sum() / 1000),
            "minimum_edge_length_m": float(edges["length_m"].min()),
            "maximum_edge_length_m": float(edges["length_m"].max()),
            "weakly_connected_component_count": len(weak_components),
            "largest_weak_component_node_share": float(
                max(map(len, weak_components)) / len(nodes)
            ),
            "strongly_connected_component_count": len(strong_components),
            "largest_strong_component_node_share": float(
                max(map(len, strong_components)) / len(nodes)
            ),
        },
        "buildings": {
            "crs": config.analysis_crs,
            "building_count": len(buildings),
            "complete_height_count": int(np.isfinite(heights).all(axis=1).sum()),
            "direct_osm_height_count": int(
                buildings["height_is_direct_osm_observation"].astype(bool).sum()
            ),
            "estimated_height_count": int(
                (~buildings["height_is_direct_osm_observation"].astype(bool)).sum()
            ),
            "median_central_height_m": float(buildings["height_central_m"].median()),
            "maximum_central_height_m": float(buildings["height_central_m"].max()),
        },
        "rasters": {
            **raster_audit,
            "required_core_tile_count": readiness["required_core_tile_count"],
            "canopy_source_coverage_fraction": coverage,
            "building_dsm_sha256": _sha256(building_dsm),
            "canopy_dsm_sha256": _sha256(canopy_dsm),
        },
        "interpretation_limit": (
            "Input readiness is not field validation. CHMv2 is predicted canopy; only "
            "direct OSM heights are source observations, and the remaining building "
            "heights are provenance-labelled estimates or imputations."
        ),
    }
    output_json = project_root / config.output_json_path
    output_csv = project_root / config.output_csv_path
    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    pd.DataFrame(
        [
            {
                "analysis_id": config.analysis_id,
                "region_id": config.region_id,
                "readiness_status": config.readiness_status,
                "all_quality_gates_passed": True,
                **result["network"],
                **{f"building_{key}": value for key, value in result["buildings"].items()},
                **{f"raster_{key}": value for key, value in result["rasters"].items()},
            }
        ]
    ).to_csv(output_csv, index=False)
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/raffles_place_input_audit.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(audit_raffles_place_inputs(args.config), ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
