"""Register representative Singapore areas for staged model expansion.

The registry deliberately separates a geographic expansion plan from completed
thermal modelling.  It identifies the exact national 2 km tiles required for
each 2 km-radius study area and reports whether tile inputs already exist.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import geopandas as gpd
import yaml
from pyproj import CRS
from shapely.geometry import Point

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class RepresentativeRegionsConfig:
    """Validated settings for the staged representative-area expansion."""

    analysis_id: str
    geographic_crs: str
    analysis_crs: str
    study_radius_m: float
    tile_index_path: str
    tile_index_layer: str
    tile_inputs_root: str
    geopackage_path: str
    csv_path: str
    summary_path: str
    source: dict[str, Any]
    regions: tuple[dict[str, Any], ...]


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    try:
        return mapping[key]
    except KeyError as exc:
        raise ValueError(f"Missing required field '{section}.{key}'") from exc


def load_representative_regions_config(
    path: str | Path,
) -> RepresentativeRegionsConfig:
    """Load the representative-region registry configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Representative-region configuration must be a YAML mapping")
    model = _required(payload, "representative_regions", "root")
    inputs = _required(payload, "inputs", "root")
    outputs = _required(payload, "outputs", "root")
    geographic_crs = str(_required(model, "geographic_crs", "representative_regions"))
    analysis_crs = str(_required(model, "analysis_crs", "representative_regions"))
    if not CRS.from_user_input(geographic_crs).is_geographic:
        raise ValueError("representative_regions.geographic_crs must be geographic")
    if not CRS.from_user_input(analysis_crs).is_projected:
        raise ValueError("representative_regions.analysis_crs must be projected")
    radius = float(_required(model, "study_radius_m", "representative_regions"))
    regions = _required(payload, "regions", "root")
    if radius <= 0 or not isinstance(regions, list) or len(regions) < 2:
        raise ValueError("A positive radius and at least two regions are required")
    required_region_keys = {
        "region_id", "display_name", "urban_typology", "rationale", "latitude",
        "longitude", "easting_m", "northing_m", "coordinate_query", "thermal_model_status",
    }
    ids: set[str] = set()
    validated: list[dict[str, Any]] = []
    for item in regions:
        if not isinstance(item, dict) or required_region_keys - set(item):
            raise ValueError("Every region must provide all registry attributes")
        region_id = str(item["region_id"])
        if region_id in ids:
            raise ValueError("region_id values must be unique")
        ids.add(region_id)
        validated.append(dict(item))
    tile_index = _required(inputs, "national_tile_index", "inputs")
    return RepresentativeRegionsConfig(
        analysis_id=str(_required(model, "analysis_id", "representative_regions")),
        geographic_crs=geographic_crs,
        analysis_crs=analysis_crs,
        study_radius_m=radius,
        tile_index_path=str(_required(tile_index, "path", "inputs.national_tile_index")),
        tile_index_layer=str(_required(tile_index, "layer", "inputs.national_tile_index")),
        tile_inputs_root=str(_required(inputs, "tile_inputs_root", "inputs")),
        geopackage_path=str(_required(outputs, "geopackage", "outputs")),
        csv_path=str(_required(outputs, "csv", "outputs")),
        summary_path=str(_required(outputs, "summary", "outputs")),
        source=dict(_required(payload, "source", "root")),
        regions=tuple(validated),
    )


def assign_regions_to_tiles(
    regions: gpd.GeoDataFrame,
    tiles: gpd.GeoDataFrame,
    tile_inputs_root: Path,
) -> gpd.GeoDataFrame:
    """Attach intersecting core-tile IDs and input readiness to each region."""

    if regions.crs != tiles.crs:
        raise ValueError("Regions and tiles must use the same explicit CRS")
    records: list[dict[str, Any]] = []
    for _, region in regions.iterrows():
        matches = tiles.loc[tiles.geometry.intersects(region.geometry)].copy()
        ids = sorted(matches["tile_id"].astype(str).tolist())
        existing = sorted(
            tile_id
            for tile_id in ids
            if (tile_inputs_root / tile_id / "input_readiness.json").exists()
        )
        record = region.drop(labels="geometry").to_dict()
        record["required_core_tile_count"] = len(ids)
        record["required_core_tile_ids"] = ";".join(ids)
        record["ready_tile_count"] = len(existing)
        record["ready_tile_ids"] = ";".join(existing)
        record["input_readiness"] = (
            "complete" if len(existing) == len(ids) else "partial" if existing else "pending"
        )
        record["geometry"] = region.geometry
        records.append(record)
    return gpd.GeoDataFrame(records, geometry="geometry", crs=regions.crs)


def build_representative_regions(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Materialise the expansion registry against the national tile index."""

    config = load_representative_regions_config(config_path)
    points = gpd.GeoDataFrame(
        [
            {
                **region,
                "geometry": Point(float(region["easting_m"]), float(region["northing_m"])),
            }
            for region in config.regions
        ],
        crs=config.analysis_crs,
    )
    regions = points.copy()
    regions["geometry"] = points.geometry.buffer(config.study_radius_m)
    regions["study_radius_m"] = config.study_radius_m
    tiles = gpd.read_file(
        project_root / config.tile_index_path, layer=config.tile_index_layer
    ).to_crs(config.analysis_crs)
    registry = assign_regions_to_tiles(
        regions, tiles, project_root / config.tile_inputs_root
    )

    geopackage = project_root / config.geopackage_path
    csv_path = project_root / config.csv_path
    summary_path = project_root / config.summary_path
    geopackage.parent.mkdir(parents=True, exist_ok=True)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    if geopackage.exists():
        geopackage.unlink()
    registry.to_file(geopackage, layer="representative_regions", driver="GPKG")
    points.to_file(geopackage, layer="region_centres", driver="GPKG", mode="a")
    registry.drop(columns="geometry").to_csv(csv_path, index=False)
    status_counts = registry["thermal_model_status"].value_counts().to_dict()
    summary = {
        "analysis_id": config.analysis_id,
        "study_radius_m": config.study_radius_m,
        "region_count": int(len(registry)),
        "urban_typologies": registry["urban_typology"].tolist(),
        "thermal_model_status_counts": {str(k): int(v) for k, v in status_counts.items()},
        "all_required_core_tiles": sorted(
            {
                tile_id
                for value in registry["required_core_tile_ids"]
                for tile_id in value.split(";")
                if tile_id
            }
        ),
        "ready_region_count": int((registry["input_readiness"] == "complete").sum()),
        "regions": registry.drop(columns="geometry").to_dict(orient="records"),
        "coordinate_source": config.source,
        "interpretation": (
            "This is a staged expansion registry, not evidence that every region has "
            "been thermally modelled. Only records explicitly marked completed should "
            "be used in cross-area thermal results."
        ),
    }
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build the representative-region expansion registry."
    )
    parser.add_argument(
        "--config", type=Path, default=PROJECT_ROOT / "config/representative_regions.yaml"
    )
    args = parser.parse_args()
    print(json.dumps(build_representative_regions(args.config), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
