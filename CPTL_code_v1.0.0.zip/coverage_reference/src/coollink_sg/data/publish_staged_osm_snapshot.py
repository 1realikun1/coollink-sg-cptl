"""Validate and publish completed OSM staging directories as immutable raw data."""

from __future__ import annotations

import argparse
import json
import shutil
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import geopandas as gpd
import osmnx as ox
import yaml

from coollink_sg.data.representative_osm_acquisition import (
    load_region_query_geometries,
    load_representative_osm_config,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class OSMRecoveryConfig:
    """Validated recovery settings for one completed OSM staging snapshot."""

    analysis_id: str
    snapshot_id: str
    completed_region_ids: tuple[str, ...]
    source_acquisition_config: str
    staging_directory: str
    raw_snapshot_directory: str


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    try:
        return mapping[key]
    except KeyError as exc:
        raise ValueError(f"Missing required field '{section}.{key}'") from exc


def load_osm_recovery_config(path: str | Path) -> OSMRecoveryConfig:
    """Load and validate recovery configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("OSM recovery configuration must be a YAML mapping")
    model = _required(payload, "osm_snapshot_recovery", "root")
    inputs = _required(payload, "inputs", "root")
    output = _required(payload, "output", "root")
    region_ids = tuple(str(value) for value in _required(model, "completed_region_ids", "root"))
    if not region_ids or len(region_ids) != len(set(region_ids)):
        raise ValueError("completed_region_ids must be a non-empty unique list")
    return OSMRecoveryConfig(
        analysis_id=str(_required(model, "analysis_id", "root")),
        snapshot_id=str(_required(model, "snapshot_id", "root")),
        completed_region_ids=region_ids,
        source_acquisition_config=str(
            _required(inputs, "source_acquisition_config", "inputs")
        ),
        staging_directory=str(_required(inputs, "staging_directory", "inputs")),
        raw_snapshot_directory=str(_required(output, "raw_snapshot_directory", "output")),
    )


def validate_staged_region(directory: Path) -> dict[str, Any]:
    """Ensure all raw artifacts exist and can be read before immutable publication."""

    graphml = directory / "walk_raw.graphml"
    graph_gpkg = directory / "walk_raw.gpkg"
    features_gpkg = directory / "built_environment_raw.gpkg"
    required = (graphml, graph_gpkg, features_gpkg)
    missing = [path.name for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Incomplete staged region {directory.name}: {missing}")
    graph = ox.io.load_graphml(graphml)
    if graph.number_of_nodes() == 0 or graph.number_of_edges() == 0:
        raise ValueError(f"Empty staged network for {directory.name}")
    network_layers = gpd.list_layers(graph_gpkg)["name"].tolist()
    feature_layers = gpd.list_layers(features_gpkg)["name"].tolist()
    if not network_layers or not feature_layers:
        raise ValueError(f"A staged GeoPackage has no layers for {directory.name}")
    feature_count = sum(len(gpd.read_file(features_gpkg, layer=layer)) for layer in feature_layers)
    if feature_count == 0:
        raise ValueError(f"No staged built-environment features for {directory.name}")
    return {
        "region_id": directory.name,
        "raw_graph": {
            "node_count": int(graph.number_of_nodes()),
            "directed_edge_count": int(graph.number_of_edges()),
            "geopackage_layers": [str(layer) for layer in network_layers],
        },
        "built_environment": {
            "feature_count": int(feature_count),
            "geopackage_layers": [str(layer) for layer in feature_layers],
        },
    }


def publish_staged_osm_snapshot(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Publish a validated completed staging batch without modifying its data files."""

    config = load_osm_recovery_config(config_path)
    source_config = load_representative_osm_config(
        project_root / config.source_acquisition_config
    )
    unknown = set(config.completed_region_ids) - set(source_config.region_ids)
    if unknown:
        raise ValueError(f"Recovered regions absent from acquisition configuration: {unknown}")
    staging = project_root / config.staging_directory
    raw_directory = project_root / config.raw_snapshot_directory
    if raw_directory.exists():
        raise FileExistsError(f"Raw snapshot already exists and is immutable: {raw_directory}")
    if not staging.exists():
        raise FileNotFoundError(f"Staging directory does not exist: {staging}")
    staged_names = {path.name for path in staging.iterdir() if path.is_dir()}
    missing_regions = set(config.completed_region_ids) - staged_names
    if missing_regions:
        raise ValueError(f"Completed regions missing from staging: {sorted(missing_regions)}")
    validation = [
        validate_staged_region(staging / region_id)
        for region_id in config.completed_region_ids
    ]
    geometries = load_region_query_geometries(source_config, project_root)
    for record in validation:
        network_area, building_area, tile_ids = geometries[record["region_id"]]
        record["network_area_km2"] = float(network_area.geometry.iloc[0].area / 1_000_000)
        record["building_query_area_km2"] = float(
            building_area.geometry.iloc[0].area / 1_000_000
        )
        record["required_core_tile_ids"] = list(tile_ids)
    publication_staging = staging.parent / f"{config.snapshot_id}_publication_staging"
    if publication_staging.exists():
        raise FileExistsError(f"Publication staging already exists: {publication_staging}")
    publication_staging.mkdir(parents=True)
    for region_id in config.completed_region_ids:
        shutil.copytree(staging / region_id, publication_staging / region_id)
    manifest = {
        "analysis_id": config.analysis_id,
        "snapshot_id": config.snapshot_id,
        "published_at_utc": datetime.now(UTC).isoformat(),
        "retrieval_status": "recovered_from_completed_staging_after_batch_interruption",
        "completed_region_ids": list(config.completed_region_ids),
        "source_acquisition_config": config.source_acquisition_config,
        "source_staging_directory": config.staging_directory,
        "network": source_config.network,
        "source": source_config.source,
        "software": {"osmnx": ox.__version__},
        "regions": validation,
        "exclusion": (
            "Raffles Place was not published because its batch acquisition did not "
            "complete; it requires a separate immutable snapshot."
        ),
    }
    publication_staging.joinpath("manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    raw_directory.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(publication_staging), str(raw_directory))
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/representative_osm_recovery.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(publish_staged_osm_snapshot(args.config), indent=2))


if __name__ == "__main__":
    main()
