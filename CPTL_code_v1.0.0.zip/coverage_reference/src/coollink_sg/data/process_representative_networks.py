"""Standardise immutable multi-region OSM walk networks for thermal routing."""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import geopandas as gpd
import networkx as nx
import osmnx as ox
import pandas as pd
import yaml
from pyproj import CRS

from coollink_sg.data.pedestrian_network import annotate_projected_network

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class RepresentativeNetworkProcessingConfig:
    """Validated multi-region pedestrian-network processing settings."""

    analysis_id: str
    analysis_crs: str
    region_ids: tuple[str, ...]
    raw_snapshot_directory: str
    regions_path: str
    regions_layer: str
    output_directory: str
    summary_path: str


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    try:
        return mapping[key]
    except KeyError as exc:
        raise ValueError(f"Missing required field '{section}.{key}'") from exc


def load_representative_network_processing_config(
    path: str | Path,
) -> RepresentativeNetworkProcessingConfig:
    """Load and validate representative-network processing settings."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Representative network configuration must be a YAML mapping")
    model = _required(payload, "representative_network_processing", "root")
    inputs = _required(payload, "inputs", "root")
    outputs = _required(payload, "outputs", "root")
    crs = str(_required(model, "analysis_crs", "representative_network_processing"))
    if not CRS.from_user_input(crs).is_projected:
        raise ValueError("representative_network_processing.analysis_crs must be projected")
    region_ids = tuple(str(value) for value in _required(model, "region_ids", "root"))
    if not region_ids or len(region_ids) != len(set(region_ids)):
        raise ValueError("region_ids must be a non-empty unique list")
    regions = _required(inputs, "representative_regions", "inputs")
    return RepresentativeNetworkProcessingConfig(
        analysis_id=str(_required(model, "analysis_id", "root")),
        analysis_crs=crs,
        region_ids=region_ids,
        raw_snapshot_directory=str(_required(inputs, "raw_snapshot_directory", "inputs")),
        regions_path=str(_required(regions, "path", "inputs.representative_regions")),
        regions_layer=str(_required(regions, "layer", "inputs.representative_regions")),
        output_directory=str(_required(outputs, "directory", "outputs")),
        summary_path=str(_required(outputs, "summary", "outputs")),
    )


def _summarize_network(
    region_id: str,
    graph: Any,
    nodes: gpd.GeoDataFrame,
    edges: gpd.GeoDataFrame,
) -> dict[str, Any]:
    """Return metrics required to audit a processed directed walk network."""

    return {
        "region_id": region_id,
        "node_count": int(len(nodes)),
        "directed_edge_count": int(len(edges)),
        "total_directed_edge_length_km": float(edges["length_m"].sum() / 1000),
        "minimum_edge_length_m": float(edges["length_m"].min()),
        "maximum_edge_length_m": float(edges["length_m"].max()),
        "weakly_connected_components": int(len(list(nx.weakly_connected_components(graph)))),
    }


def process_representative_networks(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Project, metrically annotate, and export all configured raw OSM networks."""

    config = load_representative_network_processing_config(config_path)
    regions = gpd.read_file(
        project_root / config.regions_path, layer=config.regions_layer
    ).to_crs(config.analysis_crs)
    if set(config.region_ids) - set(regions["region_id"]):
        raise ValueError("One or more processed regions are missing from the registry")
    raw_root = project_root / config.raw_snapshot_directory
    output_directory = project_root / config.output_directory
    summary_path = project_root / config.summary_path
    output_directory.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, Any]] = []
    for region_id in config.region_ids:
        raw_graphml = raw_root / region_id / "walk_raw.graphml"
        if not raw_graphml.exists():
            raise FileNotFoundError(f"Missing raw GraphML for {region_id}: {raw_graphml}")
        graph, nodes, edges = annotate_projected_network(
            ox.io.load_graphml(raw_graphml), config.analysis_crs
        )
        graph.graph["region_id"] = region_id
        graph.graph["analysis_id"] = config.analysis_id
        graph_path = output_directory / f"{region_id}_pedestrian_network.graphml"
        gpkg_path = output_directory / f"{region_id}_pedestrian_network.gpkg"
        ox.io.save_graphml(graph, graph_path)
        ox.io.save_graph_geopackage(graph, gpkg_path, directed=True)
        study_area = regions.loc[regions["region_id"].eq(region_id)].copy()
        study_area.to_file(gpkg_path, layer="study_area", driver="GPKG", mode="a")
        records.append(_summarize_network(region_id, graph, nodes, edges))
    summary = pd.DataFrame(records).sort_values("region_id")
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary.to_csv(summary_path, index=False)
    return {
        "analysis_id": config.analysis_id,
        "region_count": len(records),
        "summary_path": config.summary_path,
        "regions": records,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/representative_network_processing.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(process_representative_networks(args.config), indent=2))


if __name__ == "__main__":
    main()
