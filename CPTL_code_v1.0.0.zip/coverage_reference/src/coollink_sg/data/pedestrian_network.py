"""Acquire, validate, and export the Clementi pedestrian network."""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import networkx as nx
import osmnx as ox
import pandas as pd
from folium.features import GeoJsonTooltip
from shapely.geometry import Point

from coollink_sg.config import StudyAreaConfig, load_study_area_config

PROJECT_ROOT = Path(__file__).resolve().parents[3]


def create_study_area(
    config: StudyAreaConfig,
) -> tuple[gpd.GeoDataFrame, gpd.GeoDataFrame]:
    """Create center-point and circular study-area layers in the analysis CRS."""

    center_wgs84 = gpd.GeoDataFrame(
        {"name": [config.name]},
        geometry=[Point(config.longitude, config.latitude)],
        crs=config.geographic_crs,
    )
    center_projected = center_wgs84.to_crs(config.analysis_crs)
    area_projected = gpd.GeoDataFrame(
        {
            "name": [config.name],
            "radius_m": [config.radius_m],
        },
        geometry=center_projected.geometry.buffer(config.radius_m),
        crs=config.analysis_crs,
    )
    return center_projected, area_projected


def download_walk_network(
    config: StudyAreaConfig,
    area_projected: gpd.GeoDataFrame,
) -> nx.MultiDiGraph:
    """Download the configured public walkable network from OpenStreetMap."""

    area_wgs84 = area_projected.to_crs(config.geographic_crs)
    polygon = area_wgs84.geometry.iloc[0]
    graph = ox.graph.graph_from_polygon(
        polygon,
        network_type=config.network.network_type,
        simplify=config.network.simplify,
        retain_all=config.network.retain_all,
        truncate_by_edge=config.network.truncate_by_edge,
    )
    graph.graph["study_area_name"] = config.name
    graph.graph["study_area_radius_m"] = config.radius_m
    return graph


def annotate_projected_network(
    graph: nx.MultiDiGraph,
    analysis_crs: str,
) -> tuple[nx.MultiDiGraph, gpd.GeoDataFrame, gpd.GeoDataFrame]:
    """Project a graph, add stable edge identifiers, and calculate metric lengths."""

    projected = ox.projection.project_graph(graph, to_crs=analysis_crs)
    nodes, edges = ox.convert.graph_to_gdfs(
        projected,
        nodes=True,
        edges=True,
        node_geometry=True,
        fill_edge_geometry=True,
    )

    if nodes.empty or edges.empty:
        raise ValueError("The pedestrian network contains no nodes or edges")
    if nodes.crs is None or edges.crs is None:
        raise ValueError("The pedestrian network must have an explicit CRS")
    if nodes.crs != edges.crs:
        raise ValueError("Node and edge CRS values do not match")
    if not nodes.geometry.notna().all() or not edges.geometry.notna().all():
        raise ValueError("The pedestrian network contains missing geometries")
    if not nodes.geometry.is_valid.all() or not edges.geometry.is_valid.all():
        raise ValueError("The pedestrian network contains invalid geometries")
    if edges.geometry.is_empty.any():
        raise ValueError("The pedestrian network contains empty edge geometries")

    edges = edges.copy()
    edges["segment_id"] = [
        f"osm:{u}:{v}:{key}" for u, v, key in edges.index.to_list()
    ]
    edges["length_m"] = edges.geometry.length.astype(float)

    if edges["segment_id"].duplicated().any():
        raise ValueError("Generated segment_id values are not unique")
    if (edges["length_m"] <= 0).any():
        raise ValueError("Every pedestrian edge must have positive length_m")

    for (u, v, key), row in edges[["segment_id", "length_m"]].iterrows():
        projected.edges[u, v, key]["segment_id"] = row["segment_id"]
        projected.edges[u, v, key]["length_m"] = float(row["length_m"])

    return projected, nodes, edges


def summarize_network(
    graph: nx.MultiDiGraph,
    nodes: gpd.GeoDataFrame,
    edges: gpd.GeoDataFrame,
    config: StudyAreaConfig,
) -> dict[str, Any]:
    """Return auditable network quality and coverage metrics."""

    component_sizes = sorted(
        (len(component) for component in nx.weakly_connected_components(graph)),
        reverse=True,
    )
    largest_share = component_sizes[0] / len(nodes) if component_sizes else 0.0
    return {
        "study_area_name": config.name,
        "center_latitude": config.latitude,
        "center_longitude": config.longitude,
        "radius_m": config.radius_m,
        "network_type": config.network.network_type,
        "analysis_crs": str(edges.crs),
        "node_count": int(len(nodes)),
        "directed_edge_count": int(len(edges)),
        "weakly_connected_components": int(len(component_sizes)),
        "largest_component_node_share": round(float(largest_share), 6),
        "total_directed_edge_length_km": round(float(edges["length_m"].sum() / 1000), 3),
        "minimum_edge_length_m": round(float(edges["length_m"].min()), 3),
        "maximum_edge_length_m": round(float(edges["length_m"].max()), 3),
    }


def _raw_metadata(config: StudyAreaConfig, graph: nx.MultiDiGraph) -> dict[str, Any]:
    return {
        "retrieved_at_utc": datetime.now(UTC).isoformat(),
        "study_area": {
            "name": config.name,
            "latitude": config.latitude,
            "longitude": config.longitude,
            "radius_m": config.radius_m,
            "geographic_crs": config.geographic_crs,
        },
        "network": asdict(config.network),
        "source": config.source_metadata,
        "software": {"osmnx": ox.__version__},
        "raw_graph": {
            "crs": str(graph.graph.get("crs")),
            "node_count": graph.number_of_nodes(),
            "directed_edge_count": graph.number_of_edges(),
        },
    }


def load_or_download_raw_network(
    config: StudyAreaConfig,
    area_projected: gpd.GeoDataFrame,
    raw_directory: Path,
) -> tuple[nx.MultiDiGraph, bool]:
    """Load an immutable raw GraphML file, or create raw artifacts once."""

    raw_graphml = raw_directory / "clementi_walk_raw.graphml"
    raw_geopackage = raw_directory / "clementi_walk_raw.gpkg"
    raw_metadata = raw_directory / "clementi_walk_raw_metadata.json"

    if raw_graphml.exists():
        return ox.io.load_graphml(raw_graphml), False

    raw_directory.mkdir(parents=True, exist_ok=True)
    graph = download_walk_network(config, area_projected)
    ox.io.save_graphml(graph, raw_graphml)
    ox.io.save_graph_geopackage(graph, raw_geopackage, directed=True)
    raw_metadata.write_text(
        json.dumps(_raw_metadata(config, graph), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return graph, True


def save_study_area_layers(
    center: gpd.GeoDataFrame,
    area: gpd.GeoDataFrame,
    output_path: Path,
) -> None:
    """Save center and boundary layers to a single GeoPackage."""

    output_path.parent.mkdir(parents=True, exist_ok=True)
    if output_path.exists():
        output_path.unlink()
    area.to_file(output_path, layer="study_area", driver="GPKG")
    center.to_file(output_path, layer="center", driver="GPKG", mode="a")


def create_network_map(
    config: StudyAreaConfig,
    area_projected: gpd.GeoDataFrame,
    edges_projected: gpd.GeoDataFrame,
    output_path: Path,
) -> None:
    """Create an interactive QA map of the study area and pedestrian edges."""

    area_wgs84 = area_projected.to_crs(config.geographic_crs)
    edges_wgs84 = edges_projected.to_crs(config.geographic_crs)
    display_edges = edges_wgs84[["segment_id", "length_m", "geometry"]].copy()
    display_edges["length_m"] = display_edges["length_m"].round(1)

    network_map = folium.Map(
        location=[config.latitude, config.longitude],
        zoom_start=14,
        tiles="OpenStreetMap",
        control_scale=True,
    )
    folium.GeoJson(
        area_wgs84.to_json(),
        name="2 km study area",
        style_function=lambda _feature: {
            "color": "#2563eb",
            "weight": 2,
            "fillColor": "#60a5fa",
            "fillOpacity": 0.08,
        },
    ).add_to(network_map)
    folium.GeoJson(
        display_edges.to_json(),
        name="Pedestrian network",
        style_function=lambda _feature: {
            "color": "#0f766e",
            "weight": 2,
            "opacity": 0.75,
        },
        tooltip=GeoJsonTooltip(
            fields=["segment_id", "length_m"],
            aliases=["Segment", "Length (m)"],
            sticky=False,
        ),
    ).add_to(network_map)
    folium.Marker(
        location=[config.latitude, config.longitude],
        tooltip="Clementi MRT study-area center",
        icon=folium.Icon(color="red", icon="train", prefix="fa"),
    ).add_to(network_map)
    folium.LayerControl(collapsed=False).add_to(network_map)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    network_map.save(output_path)


def build_pedestrian_network(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Run the complete Part 2 network acquisition and export pipeline."""

    config = load_study_area_config(config_path)
    center, area = create_study_area(config)

    raw_directory = project_root / "data/raw/osm"
    processed_directory = project_root / "data/processed/network"
    map_path = project_root / "outputs/maps/clementi_pedestrian_network.html"
    table_path = project_root / "outputs/tables/clementi_network_summary.csv"

    raw_graph, downloaded = load_or_download_raw_network(config, area, raw_directory)
    processed_graph, nodes, edges = annotate_projected_network(
        raw_graph,
        config.analysis_crs,
    )
    summary = summarize_network(processed_graph, nodes, edges, config)
    summary["raw_downloaded_this_run"] = downloaded

    processed_directory.mkdir(parents=True, exist_ok=True)
    ox.io.save_graphml(
        processed_graph,
        processed_directory / "clementi_pedestrian_network.graphml",
    )
    ox.io.save_graph_geopackage(
        processed_graph,
        processed_directory / "clementi_pedestrian_network.gpkg",
        directed=True,
    )
    save_study_area_layers(
        center,
        area,
        processed_directory / "clementi_study_area.gpkg",
    )
    (processed_directory / "clementi_network_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    table_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame([summary]).to_csv(table_path, index=False)
    create_network_map(config, area, edges, map_path)
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(
        description="Build the Clementi pedestrian-network dataset and QA map."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/study_area.yaml",
        help="Path to the study-area YAML file.",
    )
    args = parser.parse_args()
    summary = build_pedestrian_network(args.config)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

