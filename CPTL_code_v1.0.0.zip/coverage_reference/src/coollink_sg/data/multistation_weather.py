"""Acquire and interpolate multi-station NEA weather for the four study regions."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import shutil
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import pvlib
import requests
import yaml
from pyproj import CRS, Transformer

PROJECT_ROOT = Path(__file__).resolve().parents[3]
KNOTS_TO_METRES_PER_SECOND = 0.514444
METRICS = ("air_temperature", "relative_humidity", "wind_speed")


@dataclass(frozen=True)
class Endpoint:
    metric: str
    url: str
    source_unit: str
    output_unit: str
    conversion: str | None


@dataclass(frozen=True)
class Region:
    region_id: str
    label: str
    latitude: float
    longitude: float


@dataclass(frozen=True)
class MultiStationConfig:
    analysis_id: str
    timezone: str
    start_sgt: str
    end_sgt: str
    interval_minutes: int
    interpolation_method: str
    nearest_station_count: int
    inverse_distance_power: float
    minimum_distance_m: float
    analysis_crs: str
    raw_snapshot_id: str
    endpoints: tuple[Endpoint, ...]
    regions: tuple[Region, ...]
    outputs: dict[str, str]
    source: dict[str, Any]


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    if key not in mapping:
        raise ValueError(f"Missing required field '{section}.{key}'")
    return mapping[key]


def load_config(path: str | Path) -> MultiStationConfig:
    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Multi-station weather configuration must be a mapping")
    model = _required(payload, "multistation_weather", "root")
    endpoint_payload = _required(payload, "endpoints", "root")
    endpoints = tuple(
        Endpoint(
            metric=metric,
            url=str(_required(endpoint_payload[metric], "url", f"endpoints.{metric}")),
            source_unit=str(
                _required(endpoint_payload[metric], "source_unit", f"endpoints.{metric}")
            ),
            output_unit=str(
                _required(endpoint_payload[metric], "output_unit", f"endpoints.{metric}")
            ),
            conversion=endpoint_payload[metric].get("conversion"),
        )
        for metric in METRICS
    )
    regions = tuple(
        Region(
            region_id=str(_required(item, "region_id", "regions")),
            label=str(_required(item, "label", "regions")),
            latitude=float(_required(item, "latitude", "regions")),
            longitude=float(_required(item, "longitude", "regions")),
        )
        for item in _required(payload, "regions", "root")
    )
    if len({item.region_id for item in regions}) != len(regions):
        raise ValueError("Region identifiers must be unique")
    analysis_crs = str(_required(model, "analysis_crs", "multistation_weather"))
    if not CRS.from_user_input(analysis_crs).is_projected:
        raise ValueError("analysis_crs must be projected")
    start = str(_required(model, "start_sgt", "multistation_weather"))
    end = str(_required(model, "end_sgt", "multistation_weather"))
    if pd.Timestamp(start).tzinfo is None or pd.Timestamp(end).tzinfo is None:
        raise ValueError("Weather bounds must be timezone-aware")
    interval = int(_required(model, "interval_minutes", "multistation_weather"))
    station_count = int(
        _required(model, "nearest_station_count", "multistation_weather")
    )
    power = float(_required(model, "inverse_distance_power", "multistation_weather"))
    minimum_distance = float(_required(model, "minimum_distance_m", "multistation_weather"))
    if interval <= 0 or station_count < 2 or power <= 0 or minimum_distance <= 0:
        raise ValueError("Interval, station count, power, and minimum distance are invalid")
    method = str(_required(model, "interpolation_method", "multistation_weather"))
    if method != "inverse_distance_weighting":
        raise ValueError("Only inverse_distance_weighting is supported")
    return MultiStationConfig(
        analysis_id=str(_required(model, "analysis_id", "multistation_weather")),
        timezone=str(_required(model, "timezone", "multistation_weather")),
        start_sgt=start,
        end_sgt=end,
        interval_minutes=interval,
        interpolation_method=method,
        nearest_station_count=station_count,
        inverse_distance_power=power,
        minimum_distance_m=minimum_distance,
        analysis_crs=analysis_crs,
        raw_snapshot_id=str(_required(model, "raw_snapshot_id", "multistation_weather")),
        endpoints=endpoints,
        regions=regions,
        outputs={str(k): str(v) for k, v in _required(payload, "outputs", "root").items()},
        source=dict(_required(payload, "source", "root")),
    )


def model_timestamps(config: MultiStationConfig) -> pd.DatetimeIndex:
    timestamps = pd.date_range(
        config.start_sgt,
        config.end_sgt,
        freq=pd.to_timedelta(config.interval_minutes, unit="min"),
    )
    if len(timestamps) < 2 or timestamps[-1] != pd.Timestamp(config.end_sgt):
        raise ValueError("Configured interval must divide the requested period")
    return timestamps


def _sha256_bytes(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest().upper()


def _fetch_one(endpoint: Endpoint, timestamp: pd.Timestamp) -> tuple[str, str, bytes]:
    query_timestamp = timestamp.strftime("%Y-%m-%dT%H:%M:%S")
    response = None
    for attempt in range(6):
        response = requests.get(
            endpoint.url,
            params={"date": query_timestamp},
            headers={"User-Agent": "CoolLink-SG/0.1 academic-research"},
            timeout=60,
        )
        if response.status_code != 429:
            break
        retry_after = response.headers.get("Retry-After")
        delay = float(retry_after) if retry_after else min(30.0, 2.0**attempt)
        time.sleep(delay)
    assert response is not None
    response.raise_for_status()
    time.sleep(0.35)
    payload = response.json()
    if payload.get("code") != 0:
        raise ValueError(f"NEA API error for {endpoint.metric} at {query_timestamp}")
    readings = payload.get("data", {}).get("readings", [])
    if len(readings) != 1:
        raise ValueError(f"Expected one reading block for {endpoint.metric} at {query_timestamp}")
    returned = pd.Timestamp(readings[0]["timestamp"])
    age_minutes = (timestamp - returned).total_seconds() / 60
    if age_minutes < 0 or age_minutes > 5:
        raise ValueError(
            f"NEA returned {returned.isoformat()} for requested {timestamp.isoformat()} "
            f"(age {age_minutes:.1f} minutes)"
        )
    return endpoint.metric, timestamp.strftime("%Y%m%d_%H%M"), response.content


def acquire_snapshot(config: MultiStationConfig, project_root: Path) -> Path:
    raw_root = project_root / config.outputs["raw_root"]
    target = raw_root / config.raw_snapshot_id
    if target.exists():
        manifest = target / "manifest.json"
        if not manifest.exists():
            raise ValueError(f"Existing raw snapshot lacks a manifest: {target}")
        return target
    staging = project_root / "data/interim/weather_multistation_acquisition" / (
        f"{config.raw_snapshot_id}.partial"
    )
    if staging.exists():
        shutil.rmtree(staging)
    staging.mkdir(parents=True)
    tasks = [
        (endpoint, timestamp)
        for timestamp in model_timestamps(config)
        for endpoint in config.endpoints
    ]
    records: list[dict[str, Any]] = []
    try:
        with ThreadPoolExecutor(max_workers=1) as executor:
            futures = {
                executor.submit(_fetch_one, endpoint, timestamp): (endpoint, timestamp)
                for endpoint, timestamp in tasks
            }
            for future in as_completed(futures):
                endpoint, timestamp = futures[future]
                metric, stamp, content = future.result()
                filename = f"{metric}_{stamp}.json"
                (staging / filename).write_bytes(content)
                records.append(
                    {
                        "metric": metric,
                        "query_timestamp_sgt": timestamp.isoformat(),
                        "filename": filename,
                        "sha256": _sha256_bytes(content),
                        "source_url": endpoint.url,
                    }
                )
        records.sort(key=lambda item: (item["query_timestamp_sgt"], item["metric"]))
        manifest = {
            "snapshot_id": config.raw_snapshot_id,
            "retrieved_at_utc": datetime.now(UTC).isoformat(),
            "request_count": len(records),
            "expected_request_count": len(tasks),
            "records": records,
            "source": config.source,
        }
        if len(records) != len(tasks):
            raise ValueError("Raw acquisition did not return every configured request")
        (staging / "manifest.json").write_text(
            json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        raw_root.mkdir(parents=True, exist_ok=True)
        # The project may place interim data on a junction-backed volume while
        # keeping immutable raw snapshots on the project volume.
        shutil.move(str(staging), str(target))
    except Exception:
        raise
    return target


def _convert(value: float, endpoint: Endpoint) -> float:
    if endpoint.conversion is None:
        return value
    if endpoint.conversion == "knots_to_mps":
        return value * KNOTS_TO_METRES_PER_SECOND
    raise ValueError(f"Unsupported conversion: {endpoint.conversion}")


def normalize_snapshot(snapshot: Path, config: MultiStationConfig) -> pd.DataFrame:
    endpoint_by_metric = {endpoint.metric: endpoint for endpoint in config.endpoints}
    rows: list[dict[str, Any]] = []
    for timestamp in model_timestamps(config):
        stamp = timestamp.strftime("%Y%m%d_%H%M")
        for metric in METRICS:
            endpoint = endpoint_by_metric[metric]
            payload = json.loads((snapshot / f"{metric}_{stamp}.json").read_text("utf-8"))
            data = payload["data"]
            if str(data.get("readingUnit")) != endpoint.source_unit:
                raise ValueError(f"Unexpected unit for {metric}: {data.get('readingUnit')}")
            stations = {str(item["id"]): item for item in data.get("stations", [])}
            block = data["readings"][0]
            observed = pd.Timestamp(block["timestamp"])
            age_minutes = (timestamp - observed).total_seconds() / 60
            if age_minutes < 0 or age_minutes > 5:
                raise ValueError(
                    f"Observation age is invalid for {metric} at {timestamp.isoformat()}"
                )
            for item in block.get("data", []):
                station_id = str(item["stationId"])
                station = stations.get(station_id)
                if station is None:
                    continue
                location = station.get("location", {})
                raw_value = float(item["value"])
                rows.append(
                    {
                        "snapshot_id": config.raw_snapshot_id,
                        "timestamp_sgt": timestamp.isoformat(),
                        "observed_at_sgt": observed.isoformat(),
                        "observation_age_minutes": age_minutes,
                        "metric": metric,
                        "station_id": station_id,
                        "station_name": str(station.get("name", station_id)),
                        "latitude": float(location["latitude"]),
                        "longitude": float(location["longitude"]),
                        "source_value": raw_value,
                        "source_unit": endpoint.source_unit,
                        "value": _convert(raw_value, endpoint),
                        "unit": endpoint.output_unit,
                        "quality_flag": "valid",
                        "source_endpoint": endpoint.url,
                    }
                )
    result = pd.DataFrame(rows)
    expected_blocks = len(model_timestamps(config)) * len(METRICS)
    if result.groupby(["timestamp_sgt", "metric"]).ngroups != expected_blocks:
        raise ValueError("Normalized observations are missing timestamp-metric blocks")
    if result.duplicated(["timestamp_sgt", "metric", "station_id"]).any():
        raise ValueError("Normalized observations contain duplicate station readings")
    return result.sort_values(["timestamp_sgt", "metric", "station_id"]).reset_index(
        drop=True
    )


def _project_points(
    longitude: pd.Series | np.ndarray,
    latitude: pd.Series | np.ndarray,
    analysis_crs: str,
) -> tuple[np.ndarray, np.ndarray]:
    transformer = Transformer.from_crs("EPSG:4326", analysis_crs, always_xy=True)
    x, y = transformer.transform(
        np.asarray(longitude, dtype=float), np.asarray(latitude, dtype=float)
    )
    return np.asarray(x, dtype=float), np.asarray(y, dtype=float)


def idw_estimate(
    values: np.ndarray,
    distances_m: np.ndarray,
    station_count: int,
    power: float,
    minimum_distance_m: float,
) -> tuple[float, np.ndarray, np.ndarray]:
    if len(values) < station_count:
        raise ValueError("Insufficient stations for configured IDW estimate")
    order = np.argsort(distances_m, kind="stable")[:station_count]
    selected_distances = np.maximum(distances_m[order], minimum_distance_m)
    raw_weights = 1.0 / np.power(selected_distances, power)
    weights = raw_weights / raw_weights.sum()
    return float(np.dot(values[order], weights)), order, weights


def interpolate_regions(
    observations: pd.DataFrame,
    config: MultiStationConfig,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for region in config.regions:
        region_x, region_y = _project_points(
            np.asarray([region.longitude]), np.asarray([region.latitude]), config.analysis_crs
        )
        for (timestamp, metric), frame in observations.groupby(
            ["timestamp_sgt", "metric"], sort=True
        ):
            station_x, station_y = _project_points(
                frame["longitude"], frame["latitude"], config.analysis_crs
            )
            distances = np.hypot(station_x - region_x[0], station_y - region_y[0])
            values = frame["value"].to_numpy(dtype=float)
            estimate, order, weights = idw_estimate(
                values,
                distances,
                config.nearest_station_count,
                config.inverse_distance_power,
                config.minimum_distance_m,
            )
            selected = frame.iloc[order]
            selected_values = values[order]
            rows.append(
                {
                    "analysis_id": config.analysis_id,
                    "region_id": region.region_id,
                    "region_label": region.label,
                    "region_latitude": region.latitude,
                    "region_longitude": region.longitude,
                    "timestamp_sgt": timestamp,
                    "metric": metric,
                    "value": estimate,
                    "unit": str(selected.iloc[0]["unit"]),
                    "station_count": len(order),
                    "station_ids": ";".join(selected["station_id"].astype(str)),
                    "station_names": ";".join(selected["station_name"].astype(str)),
                    "station_distances_km": ";".join(
                        f"{distances[index] / 1000:.3f}" for index in order
                    ),
                    "station_weights": ";".join(f"{weight:.6f}" for weight in weights),
                    "station_min": float(selected_values.min()),
                    "station_max": float(selected_values.max()),
                    "station_sd": float(selected_values.std(ddof=0)),
                    "nearest_station_id": str(selected.iloc[0]["station_id"]),
                    "nearest_station_value": float(selected_values[0]),
                    "maximum_station_weight": float(weights.max()),
                    "effective_station_count": float(1.0 / np.square(weights).sum()),
                    "interpolation_method": config.interpolation_method,
                    "inverse_distance_power": config.inverse_distance_power,
                }
            )
    return pd.DataFrame(rows).sort_values(
        ["region_id", "timestamp_sgt", "metric"]
    ).reset_index(drop=True)


def leave_one_station_out(
    observations: pd.DataFrame,
    config: MultiStationConfig,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for (timestamp, metric), frame in observations.groupby(
        ["timestamp_sgt", "metric"], sort=True
    ):
        station_x, station_y = _project_points(
            frame["longitude"], frame["latitude"], config.analysis_crs
        )
        values = frame["value"].to_numpy(dtype=float)
        for target in range(len(frame)):
            candidates = np.arange(len(frame)) != target
            distances = np.hypot(
                station_x[candidates] - station_x[target],
                station_y[candidates] - station_y[target],
            )
            estimate, order, weights = idw_estimate(
                values[candidates],
                distances,
                config.nearest_station_count,
                config.inverse_distance_power,
                config.minimum_distance_m,
            )
            candidate_indices = np.flatnonzero(candidates)[order]
            observed = float(values[target])
            rows.append(
                {
                    "timestamp_sgt": timestamp,
                    "metric": metric,
                    "station_id": str(frame.iloc[target]["station_id"]),
                    "station_name": str(frame.iloc[target]["station_name"]),
                    "observed": observed,
                    "predicted": estimate,
                    "error": estimate - observed,
                    "absolute_error": abs(estimate - observed),
                    "squared_error": (estimate - observed) ** 2,
                    "source_station_ids": ";".join(
                        frame.iloc[candidate_indices]["station_id"].astype(str)
                    ),
                    "maximum_station_weight": float(weights.max()),
                }
            )
    return pd.DataFrame(rows)


def summarize_cv(cv: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for metric, frame in cv.groupby("metric", sort=True):
        observed = frame["observed"].to_numpy(dtype=float)
        predicted = frame["predicted"].to_numpy(dtype=float)
        correlation = float(np.corrcoef(observed, predicted)[0, 1])
        rows.append(
            {
                "metric": metric,
                "evaluation_count": len(frame),
                "station_count": int(frame["station_id"].nunique()),
                "timestamp_count": int(frame["timestamp_sgt"].nunique()),
                "mean_bias": float(frame["error"].mean()),
                "mae": float(frame["absolute_error"].mean()),
                "rmse": float(math.sqrt(frame["squared_error"].mean())),
                "pearson_correlation": correlation,
            }
        )
    return pd.DataFrame(rows)


def build_regional_weather_timeseries(
    regional_long: pd.DataFrame,
    config: MultiStationConfig,
) -> pd.DataFrame:
    values = regional_long.pivot(
        index=["region_id", "region_label", "region_latitude", "region_longitude", "timestamp_sgt"],
        columns="metric",
        values="value",
    ).reset_index()
    metadata = regional_long.pivot(
        index=["region_id", "timestamp_sgt"], columns="metric", values="station_ids"
    ).reset_index()
    metadata = metadata.rename(
        columns={metric: f"{metric}_station_ids" for metric in METRICS}
    )
    result = values.merge(metadata, on=["region_id", "timestamp_sgt"], validate="one_to_one")
    result = result.rename(
        columns={
            "air_temperature": "air_temperature_deg_c",
            "relative_humidity": "relative_humidity_percent",
            "wind_speed": "wind_speed_m_s",
        }
    )
    frames = []
    for _region, frame in result.groupby("region_id", sort=True):
        latitude = float(frame.iloc[0]["region_latitude"])
        longitude = float(frame.iloc[0]["region_longitude"])
        timestamps = pd.DatetimeIndex(pd.to_datetime(frame["timestamp_sgt"]))
        location = pvlib.location.Location(latitude, longitude, tz=config.timezone)
        solar = location.get_solarposition(timestamps)
        clear_sky = location.get_clearsky(timestamps, model="ineichen")
        frame = frame.copy()
        frame["clear_sky_ghi_w_m2"] = clear_sky["ghi"].to_numpy(dtype=float)
        frame["clear_sky_dni_w_m2"] = clear_sky["dni"].to_numpy(dtype=float)
        frame["clear_sky_dhi_w_m2"] = clear_sky["dhi"].to_numpy(dtype=float)
        frame["solar_apparent_elevation_deg"] = solar[
            "apparent_elevation"
        ].to_numpy(dtype=float)
        frame["solar_azimuth_deg"] = solar["azimuth"].to_numpy(dtype=float)
        frame["weather_temporal_status"] = "quarter_hour_multistation_idw"
        frame["solar_radiation_status"] = "pvlib_ineichen_clear_sky_model_not_observed"
        frames.append(frame)
    combined = pd.concat(frames, ignore_index=True)
    weather_fields = [
        "air_temperature_deg_c",
        "relative_humidity_percent",
        "wind_speed_m_s",
    ]
    if combined[weather_fields].isna().any().any():
        raise ValueError("Regional weather time series contains missing values")
    return combined.sort_values(["region_id", "timestamp_sgt"]).reset_index(drop=True)


def summarize_regions(regional_long: pd.DataFrame) -> pd.DataFrame:
    return (
        regional_long.groupby(["region_id", "region_label", "metric"], as_index=False)
        .agg(
            timestamp_count=("timestamp_sgt", "nunique"),
            mean_value=("value", "mean"),
            minimum_value=("value", "min"),
            maximum_value=("value", "max"),
            mean_station_sd=("station_sd", "mean"),
            maximum_station_weight=("maximum_station_weight", "max"),
            minimum_effective_station_count=("effective_station_count", "min"),
            contributing_station_ids=(
                "station_ids",
                lambda values: ";".join(
                    sorted({item for value in values for item in value.split(";")})
                ),
            ),
        )
    )


def compare_to_old_s50(regional_long: pd.DataFrame, observations: pd.DataFrame) -> pd.DataFrame:
    old_time = "2026-08-17T12:59:00+08:00"
    old = observations.loc[
        observations["timestamp_sgt"].eq(old_time) & observations["station_id"].eq("S50")
    ]
    if old.empty:
        # The enhanced acquisition is quarter-hourly; retain the immutable old baseline values.
        old_values = {
            "air_temperature": 32.2,
            "relative_humidity": 64.8,
            "wind_speed": 2.0063316,
        }
    else:
        old_values = old.set_index("metric")["value"].astype(float).to_dict()
    target = regional_long.loc[
        regional_long["timestamp_sgt"].eq("2026-08-17T13:00:00+08:00")
    ].copy()
    target["old_s50_value"] = target["metric"].map(old_values)
    target["difference_from_old_s50"] = target["value"] - target["old_s50_value"]
    return target[
        [
            "region_id",
            "region_label",
            "metric",
            "unit",
            "value",
            "old_s50_value",
            "difference_from_old_s50",
            "station_ids",
            "station_weights",
        ]
    ]


def build_multistation_weather(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    config = load_config(config_path)
    snapshot = acquire_snapshot(config, project_root)
    observations = normalize_snapshot(snapshot, config)
    regional_long = interpolate_regions(observations, config)
    regional_timeseries = build_regional_weather_timeseries(regional_long, config)
    cv = leave_one_station_out(observations, config)
    cv_summary = summarize_cv(cv)
    regional_summary = summarize_regions(regional_long)
    old_comparison = compare_to_old_s50(regional_long, observations)

    paths = {
        key: project_root / value
        for key, value in config.outputs.items()
        if key != "raw_root"
    }
    for path in paths.values():
        path.parent.mkdir(parents=True, exist_ok=True)
    observations.to_csv(paths["observations"], index=False)
    regional_long.to_csv(paths["regional_long"], index=False)
    regional_timeseries.to_csv(paths["regional_timeseries"], index=False)
    cv.to_csv(paths["station_cv"], index=False)
    cv_summary.to_csv(paths["station_cv_summary"], index=False)
    regional_summary.to_csv(paths["regional_summary"], index=False)
    old_comparison.to_csv(paths["comparison_to_old_baseline"], index=False)
    provenance = {
        "analysis_id": config.analysis_id,
        "raw_snapshot": str(snapshot.relative_to(project_root)),
        "timestamp_count": len(model_timestamps(config)),
        "region_count": len(config.regions),
        "station_count_by_metric": observations.groupby("metric")["station_id"].nunique().to_dict(),
        "interpolation": {
            "method": config.interpolation_method,
            "nearest_station_count": config.nearest_station_count,
            "inverse_distance_power": config.inverse_distance_power,
            "minimum_distance_m": config.minimum_distance_m,
            "analysis_crs": config.analysis_crs,
        },
        "source": config.source,
        "interpretation_warning": (
            "Multi-station IDW estimates a regional mesoscale background. It does not "
            "resolve pedestrian-height street-canyon wind or microscale air temperature."
        ),
    }
    paths["provenance"].write_text(
        json.dumps(provenance, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return provenance


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/multistation_weather.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(build_multistation_weather(args.config), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
