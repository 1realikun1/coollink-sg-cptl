"""Create an immutable multi-region OSM snapshot for model expansion."""

from __future__ import annotations

import argparse
import json
import shutil
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import geopandas as gpd
import osmnx as ox
import yaml
from pyproj import CRS

from coollink_sg.features.built_environment import _safe_frame

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class RepresentativeOsmConfig:
    """Validated settings for one immutable multi-region OSM acquisition."""

    analysis_id: str
    snapshot_id: str
    geographic_crs: str
    analysis_crs: str
    shadow_buffer_m: float
    region_ids: tuple[str, ...]
    regions_path: str
    regions_layer: str
    tile_index_path: str
    tile_index_layer: str
    network: dict[str, Any]
    source: dict[str, Any]
    raw_snapshot_directory: str


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    try:
        return mapping[key]
    except KeyError as exc:
        raise ValueError(f"Missing required field '{section}.{key}'") from exc


def load_representative_osm_config(path: str | Path) -> RepresentativeOsmConfig:
    """Load and validate the multi-region OSM acquisition configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Representative OSM configuration must be a YAML mapping")
    model = _required(payload, "representative_osm_acquisition", "root")
    inputs = _required(payload, "inputs", "root")
    network = _required(payload, "network", "root")
    source = _required(payload, "source", "root")
    output = _required(payload, "output", "root")
    geographic_crs = str(_required(model, "geographic_crs", "representative_osm_acquisition"))
    analysis_crs = str(_required(model, "analysis_crs", "representative_osm_acquisition"))
    if not CRS.from_user_input(geographic_crs).is_geographic:
        raise ValueError("representative_osm_acquisition.geographic_crs must be geographic")
    if not CRS.from_user_input(analysis_crs).is_projected:
        raise ValueError("representative_osm_acquisition.analysis_crs must be projected")
    region_ids = tuple(str(value) for value in _required(model, "region_ids", "root"))
    if not region_ids or len(set(region_ids)) != len(region_ids):
        raise ValueError("At least one unique region_id is required")
    required_network = {"network_type", "simplify", "retain_all", "truncate_by_edge"}
    if required_network - set(network):
        raise ValueError("Network configuration is incomplete")
    if not isinstance(source.get("building_query_tags"), dict):
        raise ValueError("source.building_query_tags must be a mapping")
    regions = _required(inputs, "representative_regions", "inputs")
    tiles = _required(inputs, "national_tile_index", "inputs")
    shadow_buffer_m = float(_required(model, "shadow_buffer_m", "root"))
    if shadow_buffer_m < 0:
        raise ValueError("shadow_buffer_m must be non-negative")
    return RepresentativeOsmConfig(
        analysis_id=str(_required(model, "analysis_id", "root")),
        snapshot_id=str(_required(model, "snapshot_id", "root")),
        geographic_crs=geographic_crs,
        analysis_crs=analysis_crs,
        shadow_buffer_m=shadow_buffer_m,
        region_ids=region_ids,
        regions_path=str(_required(regions, "path", "inputs.representative_regions")),
        regions_layer=str(_required(regions, "layer", "inputs.representative_regions")),
        tile_index_path=str(_required(tiles, "path", "inputs.national_tile_index")),
        tile_index_layer=str(_required(tiles, "layer", "inputs.national_tile_index")),
        network=dict(network),
        source=dict(source),
        raw_snapshot_directory=str(_required(output, "raw_snapshot_directory", "output")),
    )


def load_region_query_geometries(
    config: RepresentativeOsmConfig,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, tuple[gpd.GeoDataFrame, gpd.GeoDataFrame, tuple[str, ...]]]:
    """Return network and buffered-building query polygons for every configured region."""

    regions = gpd.read_file(
        project_root / config.regions_path, layer=config.regions_layer
    ).to_crs(config.analysis_crs)
    selected_regions = regions.loc[regions["region_id"].isin(config.region_ids)].copy()
    if len(selected_regions) != len(config.region_ids):
        raise ValueError("One or more requested region_ids are absent from the registry")
    tiles = gpd.read_file(
        project_root / config.tile_index_path, layer=config.tile_index_layer
    ).to_crs(config.analysis_crs)
    result: dict[str, tuple[gpd.GeoDataFrame, gpd.GeoDataFrame, tuple[str, ...]]] = {}
    for region_id in config.region_ids:
        region = selected_regions.loc[selected_regions["region_id"].eq(region_id)].copy()
        tile_ids = tuple(
            value
            for value in str(region.iloc[0]["required_core_tile_ids"]).split(";")
            if value
        )
        required_tiles = tiles.loc[tiles["tile_id"].isin(tile_ids)].copy()
        if len(required_tiles) != len(tile_ids):
            raise ValueError(f"Missing national tile for {region_id}")
        if not (required_tiles["buffer_m"].astype(float) == config.shadow_buffer_m).all():
            raise ValueError(f"Shadow buffer mismatch for {region_id}")
        building_area = gpd.GeoDataFrame(
            {"region_id": [region_id]},
            geometry=[required_tiles.geometry.buffer(config.shadow_buffer_m).union_all()],
            crs=config.analysis_crs,
        )
        result[region_id] = (region, building_area, tile_ids)
    return result


def _write_feature_snapshot(features: gpd.GeoDataFrame, path: Path) -> dict[str, int]:
    """Write OSM features by homogeneous geometry type for GeoPackage compatibility."""

    groups = {
        "points": features.geometry.geom_type.isin(["Point", "MultiPoint"]),
        "lines": features.geometry.geom_type.isin(["LineString", "MultiLineString"]),
        "polygons": features.geometry.geom_type.isin(["Polygon", "MultiPolygon"]),
    }
    counts: dict[str, int] = {}
    first = True
    for layer_name, mask in groups.items():
        layer = features.loc[mask].copy()
        if layer.empty:
            continue
        _safe_frame(layer).to_file(
            path,
            layer=layer_name,
            driver="GPKG",
            mode="w" if first else "a",
        )
        counts[layer_name] = int(len(layer))
        first = False
    if not counts:
        raise ValueError("OSM returned no supported building-feature geometries")
    return counts


def _existing_feature_counts(path: Path) -> dict[str, int]:
    """Read feature layer counts from a complete resumable staging GeoPackage."""

    layers = gpd.list_layers(path)["name"].tolist()
    if not layers:
        raise ValueError(f"Staged feature GeoPackage has no layers: {path}")
    return {str(layer): int(len(gpd.read_file(path, layer=layer))) for layer in layers}


def _acquire_one_region(
    region_id: str,
    network_area: gpd.GeoDataFrame,
    building_area: gpd.GeoDataFrame,
    tile_ids: tuple[str, ...],
    config: RepresentativeOsmConfig,
    staging_root: Path,
) -> dict[str, Any]:
    """Fetch and save one region's walk network and built-environment snapshot."""

    region_directory = staging_root / region_id
    region_directory.mkdir(parents=True, exist_ok=True)
    network_polygon = network_area.to_crs(config.geographic_crs).geometry.iloc[0]
    building_polygon = building_area.to_crs(config.geographic_crs).geometry.iloc[0]
    graphml_path = region_directory / "walk_raw.graphml"
    graph_gpkg_path = region_directory / "walk_raw.gpkg"
    if graphml_path.exists() and graph_gpkg_path.exists():
        graph = ox.io.load_graphml(graphml_path)
    else:
        graph = ox.graph.graph_from_polygon(
            network_polygon,
            network_type=str(config.network["network_type"]),
            simplify=bool(config.network["simplify"]),
            retain_all=bool(config.network["retain_all"]),
            truncate_by_edge=bool(config.network["truncate_by_edge"]),
        )
        ox.io.save_graphml(graph, graphml_path)
        ox.io.save_graph_geopackage(graph, graph_gpkg_path, directed=True)
    if graph.number_of_nodes() == 0 or graph.number_of_edges() == 0:
        raise ValueError(f"OSM returned an empty pedestrian network for {region_id}")
    features_path = region_directory / "built_environment_raw.gpkg"
    if features_path.exists():
        counts = _existing_feature_counts(features_path)
    else:
        features = ox.features.features_from_polygon(
            building_polygon, config.source["building_query_tags"]
        ).reset_index()
        if features.empty:
            raise ValueError(f"OSM returned no built-environment features for {region_id}")
        if features.crs is None:
            features = features.set_crs(config.geographic_crs)
        counts = _write_feature_snapshot(features, features_path)
    return {
        "region_id": region_id,
        "network_area_km2": float(network_area.geometry.iloc[0].area / 1_000_000),
        "building_query_area_km2": float(building_area.geometry.iloc[0].area / 1_000_000),
        "required_core_tile_ids": list(tile_ids),
        "raw_graph": {
            "node_count": int(graph.number_of_nodes()),
            "directed_edge_count": int(graph.number_of_edges()),
        },
        "built_environment_feature_counts_by_geometry_layer": counts,
    }


def acquire_representative_osm_snapshot(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Acquire all configured OSM regions atomically into one raw snapshot."""

    config = load_representative_osm_config(config_path)
    raw_directory = project_root / config.raw_snapshot_directory
    if raw_directory.exists():
        raise FileExistsError(f"Raw snapshot already exists and is immutable: {raw_directory}")
    staging = project_root / "work" / "representative_osm_acquisition" / config.snapshot_id
    staging.mkdir(parents=True, exist_ok=True)
    geometries = load_region_query_geometries(config, project_root)
    region_records = [
        _acquire_one_region(region_id, *geometries[region_id], config, staging)
        for region_id in config.region_ids
    ]
    manifest = {
        "analysis_id": config.analysis_id,
        "snapshot_id": config.snapshot_id,
        "retrieved_at_utc": datetime.now(UTC).isoformat(),
        "region_ids": list(config.region_ids),
        "network": config.network,
        "source": config.source,
        "software": {"osmnx": ox.__version__},
        "regions": region_records,
    }
    staging.joinpath("manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    raw_directory.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(staging), str(raw_directory))
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/representative_osm_acquisition.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(acquire_representative_osm_snapshot(args.config), indent=2))


if __name__ == "__main__":
    main()
