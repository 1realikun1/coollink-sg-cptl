"""Fetch and standardize official Singapore weather and WBGT observations."""

from __future__ import annotations

import argparse
import json
import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import pandas as pd
import requests
from shapely.geometry import Point

from coollink_sg.config import (
    StudyAreaConfig,
    WeatherConfig,
    WeatherEndpointConfig,
    load_study_area_config,
    load_weather_config,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]
KNOTS_TO_METRES_PER_SECOND = 0.514444
OBSERVATION_COLUMNS = [
    "snapshot_id",
    "retrieved_at_utc",
    "metric",
    "station_id",
    "station_name",
    "station_context",
    "latitude",
    "longitude",
    "observed_at_sgt",
    "observed_at_utc",
    "source_updated_at_sgt",
    "source_value",
    "source_unit",
    "value",
    "unit",
    "reading_type",
    "heat_stress",
    "age_minutes_at_retrieval",
    "quality_flag",
    "source_endpoint",
]


def _parse_number(value: Any) -> float | None:
    if value is None:
        return None
    if isinstance(value, str) and value.strip().upper() in {"", "NA", "N/A", "NULL"}:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _convert_value(value: float | None, conversion: str | None) -> float | None:
    if value is None:
        return None
    if conversion is None:
        return value
    if conversion == "knots_to_mps":
        return value * KNOTS_TO_METRES_PER_SECOND
    raise ValueError(f"Unsupported weather conversion: {conversion}")


def _timestamps(
    timestamp: str,
    timezone_name: str,
    retrieved_at_utc: datetime,
) -> tuple[str, str, float]:
    observed = pd.Timestamp(timestamp)
    if observed.tzinfo is None:
        observed = observed.tz_localize(timezone_name)
    observed_utc = observed.tz_convert("UTC")
    retrieved = pd.Timestamp(retrieved_at_utc).tz_convert("UTC")
    age_minutes = (retrieved - observed_utc).total_seconds() / 60
    return observed.isoformat(), observed_utc.isoformat(), float(age_minutes)


def _quality_flag(
    value: float | None,
    age_minutes: float,
    max_age_minutes: float,
    has_station_metadata: bool,
) -> str:
    flags: list[str] = []
    if value is None:
        flags.append("missing_value")
    if not has_station_metadata:
        flags.append("missing_station_metadata")
    if age_minutes > max_age_minutes:
        flags.append("stale")
    if age_minutes < -5:
        flags.append("future_timestamp")
    return ";".join(flags) if flags else "valid"


def _validate_api_payload(payload: dict[str, Any], metric: str) -> dict[str, Any]:
    if payload.get("code") != 0:
        message = payload.get("errorMsg") or "unknown API error"
        raise ValueError(f"data.gov.sg returned an error for {metric}: {message}")
    data = payload.get("data")
    if not isinstance(data, dict):
        raise ValueError(f"data.gov.sg response for {metric} has no data object")
    return data


def normalize_station_readings(
    payload: dict[str, Any],
    endpoint: WeatherEndpointConfig,
    retrieved_at_utc: datetime,
    snapshot_id: str,
    timezone_name: str,
) -> pd.DataFrame:
    """Normalize temperature, humidity, or wind station readings."""

    data = _validate_api_payload(payload, endpoint.metric)
    actual_unit = str(data.get("readingUnit", ""))
    if actual_unit != endpoint.source_unit:
        raise ValueError(
            f"Unexpected source unit for {endpoint.metric}: "
            f"expected {endpoint.source_unit!r}, got {actual_unit!r}"
        )

    stations = {station["id"]: station for station in data.get("stations", [])}
    rows: list[dict[str, Any]] = []
    for reading in data.get("readings", []):
        observed_sgt, observed_utc, age_minutes = _timestamps(
            str(reading["timestamp"]),
            timezone_name,
            retrieved_at_utc,
        )
        for item in reading.get("data", []):
            station_id = str(item["stationId"])
            station = stations.get(station_id)
            location = station.get("location", {}) if station else {}
            source_value = item.get("value")
            numeric_value = _parse_number(source_value)
            standard_value = _convert_value(numeric_value, endpoint.conversion)
            rows.append(
                {
                    "snapshot_id": snapshot_id,
                    "retrieved_at_utc": retrieved_at_utc.isoformat(),
                    "metric": endpoint.metric,
                    "station_id": station_id,
                    "station_name": station.get("name") if station else None,
                    "station_context": None,
                    "latitude": _parse_number(location.get("latitude")),
                    "longitude": _parse_number(location.get("longitude")),
                    "observed_at_sgt": observed_sgt,
                    "observed_at_utc": observed_utc,
                    "source_updated_at_sgt": None,
                    "source_value": str(source_value),
                    "source_unit": actual_unit,
                    "value": standard_value,
                    "unit": endpoint.standard_unit,
                    "reading_type": data.get("readingType"),
                    "heat_stress": None,
                    "age_minutes_at_retrieval": age_minutes,
                    "quality_flag": _quality_flag(
                        standard_value,
                        age_minutes,
                        endpoint.max_age_minutes,
                        station is not None,
                    ),
                    "source_endpoint": endpoint.url,
                }
            )
    if not rows:
        raise ValueError(f"No station observations found for {endpoint.metric}")
    return pd.DataFrame(rows, columns=OBSERVATION_COLUMNS)


def normalize_wbgt_records(
    payload: dict[str, Any],
    endpoint: WeatherEndpointConfig,
    retrieved_at_utc: datetime,
    snapshot_id: str,
    timezone_name: str,
) -> pd.DataFrame:
    """Normalize NEA 15-minute-average WBGT records."""

    data = _validate_api_payload(payload, endpoint.metric)
    rows: list[dict[str, Any]] = []
    for record in data.get("records", []):
        observed_sgt, observed_utc, age_minutes = _timestamps(
            str(record["datetime"]),
            timezone_name,
            retrieved_at_utc,
        )
        item = record.get("item", {})
        updated_timestamp = item.get("updatedTimestamp")
        for reading in item.get("readings", []):
            station = reading.get("station", {})
            location = reading.get("location", {})
            source_value = reading.get("wbgt")
            numeric_value = _parse_number(source_value)
            rows.append(
                {
                    "snapshot_id": snapshot_id,
                    "retrieved_at_utc": retrieved_at_utc.isoformat(),
                    "metric": endpoint.metric,
                    "station_id": str(station.get("id", "")),
                    "station_name": station.get("name"),
                    "station_context": station.get("townCenter"),
                    "latitude": _parse_number(location.get("latitude")),
                    "longitude": _parse_number(location.get("longitude")),
                    "observed_at_sgt": observed_sgt,
                    "observed_at_utc": observed_utc,
                    "source_updated_at_sgt": updated_timestamp,
                    "source_value": str(source_value),
                    "source_unit": endpoint.source_unit,
                    "value": numeric_value,
                    "unit": endpoint.standard_unit,
                    "reading_type": "WBGT 15-minute average",
                    "heat_stress": reading.get("heatStress"),
                    "age_minutes_at_retrieval": age_minutes,
                    "quality_flag": _quality_flag(
                        numeric_value,
                        age_minutes,
                        endpoint.max_age_minutes,
                        bool(station.get("id")),
                    ),
                    "source_endpoint": f"{endpoint.url}?api=wbgt",
                }
            )
    if not rows:
        raise ValueError("No WBGT observations found")
    return pd.DataFrame(rows, columns=OBSERVATION_COLUMNS)


def normalize_payload(
    payload: dict[str, Any],
    endpoint: WeatherEndpointConfig,
    retrieved_at_utc: datetime,
    snapshot_id: str,
    timezone_name: str,
) -> pd.DataFrame:
    """Dispatch a raw response to its configured schema normalizer."""

    if endpoint.response_family == "station_readings":
        return normalize_station_readings(
            payload,
            endpoint,
            retrieved_at_utc,
            snapshot_id,
            timezone_name,
        )
    if endpoint.response_family == "wbgt_records":
        return normalize_wbgt_records(
            payload,
            endpoint,
            retrieved_at_utc,
            snapshot_id,
            timezone_name,
        )
    raise ValueError(f"Unsupported response family: {endpoint.response_family}")


def _fetch_endpoint(
    session: requests.Session,
    endpoint: WeatherEndpointConfig,
    headers: dict[str, str],
    timeout_seconds: float,
) -> tuple[dict[str, Any], bytes, str]:
    response = session.get(
        endpoint.url,
        params=endpoint.params,
        headers=headers,
        timeout=timeout_seconds,
    )
    try:
        response.raise_for_status()
    except requests.HTTPError as exc:
        raise RuntimeError(
            f"Weather API request failed for {endpoint.metric} with HTTP "
            f"{response.status_code}"
        ) from exc
    try:
        payload = response.json()
    except requests.JSONDecodeError as exc:
        raise RuntimeError(
            f"Weather API returned invalid JSON for {endpoint.metric}"
        ) from exc
    _validate_api_payload(payload, endpoint.metric)
    return payload, response.content, response.url


def fetch_weather_payloads(
    config: WeatherConfig,
) -> tuple[dict[str, dict[str, Any]], datetime]:
    """Fetch every configured endpoint without writing partial raw snapshots."""

    api_key = os.getenv(config.api_key_environment_variable)
    headers = {"x-api-key": api_key} if api_key else {}
    results: dict[str, dict[str, Any]] = {}
    retrieved_at_utc = datetime.now(UTC)
    with requests.Session() as session:
        for endpoint in config.endpoints:
            payload, raw_bytes, request_url = _fetch_endpoint(
                session,
                endpoint,
                headers,
                config.request_timeout_seconds,
            )
            results[endpoint.metric] = {
                "payload": payload,
                "raw_bytes": raw_bytes,
                "request_url": request_url,
            }
    return results, retrieved_at_utc


def save_raw_snapshot(
    fetched: dict[str, dict[str, Any]],
    retrieved_at_utc: datetime,
    config: WeatherConfig,
    raw_root: Path,
) -> Path:
    """Write one complete immutable raw snapshot and manifest."""

    snapshot_id = retrieved_at_utc.strftime("%Y%m%dT%H%M%S%fZ")
    snapshot_directory = raw_root / snapshot_id
    snapshot_directory.mkdir(parents=True, exist_ok=False)
    for metric, result in fetched.items():
        with (snapshot_directory / f"{metric}.json").open("xb") as file_handle:
            file_handle.write(result["raw_bytes"])

    manifest = {
        "snapshot_id": snapshot_id,
        "retrieved_at_utc": retrieved_at_utc.isoformat(),
        "source": config.source_metadata,
        "requests": {
            metric: {"url": result["request_url"]} for metric, result in fetched.items()
        },
    }
    with (snapshot_directory / "manifest.json").open("x", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2, ensure_ascii=False)
    return snapshot_directory


def load_raw_snapshot(
    snapshot_directory: Path,
    config: WeatherConfig,
) -> tuple[dict[str, dict[str, Any]], datetime, str]:
    """Load a previously saved immutable snapshot for reproducible processing."""

    manifest = json.loads(
        (snapshot_directory / "manifest.json").read_text(encoding="utf-8")
    )
    retrieved_at_utc = datetime.fromisoformat(manifest["retrieved_at_utc"])
    snapshot_id = str(manifest["snapshot_id"])
    payloads: dict[str, dict[str, Any]] = {}
    for endpoint in config.endpoints:
        raw_path = snapshot_directory / f"{endpoint.metric}.json"
        payloads[endpoint.metric] = json.loads(raw_path.read_text(encoding="utf-8"))
    return payloads, retrieved_at_utc, snapshot_id


def normalize_snapshot(
    payloads: dict[str, dict[str, Any]],
    retrieved_at_utc: datetime,
    snapshot_id: str,
    config: WeatherConfig,
) -> pd.DataFrame:
    """Normalize all configured metrics into one explicit long table."""

    frames = [
        normalize_payload(
            payloads[endpoint.metric],
            endpoint,
            retrieved_at_utc,
            snapshot_id,
            config.timezone,
        )
        for endpoint in config.endpoints
    ]
    observations = pd.concat(frames, ignore_index=True)
    observations["value"] = pd.to_numeric(observations["value"], errors="coerce")
    observations["latitude"] = pd.to_numeric(
        observations["latitude"], errors="coerce"
    )
    observations["longitude"] = pd.to_numeric(
        observations["longitude"], errors="coerce"
    )
    return observations


def nearest_observations_to_study_area(
    observations: pd.DataFrame,
    study_area: StudyAreaConfig,
) -> pd.DataFrame:
    """Select the nearest non-missing observation for each metric."""

    valid = observations.dropna(subset=["value", "latitude", "longitude"]).copy()
    if valid.empty:
        raise ValueError("No weather observations have values and coordinates")
    valid["observed_at_utc_parsed"] = pd.to_datetime(
        valid["observed_at_utc"], utc=True
    )
    valid = valid.sort_values("observed_at_utc_parsed").drop_duplicates(
        ["metric", "station_id"], keep="last"
    )
    stations = gpd.GeoDataFrame(
        valid,
        geometry=gpd.points_from_xy(valid["longitude"], valid["latitude"]),
        crs=study_area.geographic_crs,
    ).to_crs(study_area.analysis_crs)
    center = gpd.GeoSeries(
        [Point(study_area.longitude, study_area.latitude)],
        crs=study_area.geographic_crs,
    ).to_crs(study_area.analysis_crs)
    stations["distance_to_study_center_m"] = stations.geometry.distance(center.iloc[0])
    nearest = (
        stations.sort_values("distance_to_study_center_m")
        .groupby("metric", as_index=False)
        .first()
    )
    nearest["inside_study_area"] = (
        nearest["distance_to_study_center_m"] <= study_area.radius_m
    )
    columns = [
        "metric",
        "station_id",
        "station_name",
        "station_context",
        "latitude",
        "longitude",
        "observed_at_sgt",
        "value",
        "unit",
        "heat_stress",
        "quality_flag",
        "distance_to_study_center_m",
        "inside_study_area",
    ]
    result = pd.DataFrame(nearest[columns])
    result["distance_to_study_center_m"] = result[
        "distance_to_study_center_m"
    ].round(1)
    return result


def summarize_weather(
    observations: pd.DataFrame,
    nearest: pd.DataFrame,
) -> tuple[dict[str, Any], pd.DataFrame]:
    """Summarize row counts, missingness, freshness, and nearest stations."""

    nearest_index = nearest.set_index("metric")
    records: list[dict[str, Any]] = []
    for metric, group in observations.groupby("metric", sort=True):
        quality = group["quality_flag"].fillna("")
        closest = nearest_index.loc[metric]
        records.append(
            {
                "metric": metric,
                "observation_count": int(len(group)),
                "valid_value_count": int(group["value"].notna().sum()),
                "missing_value_count": int(group["value"].isna().sum()),
                "stale_count": int(quality.str.contains("stale").sum()),
                "observation_time_min_sgt": str(group["observed_at_sgt"].min()),
                "observation_time_max_sgt": str(group["observed_at_sgt"].max()),
                "nearest_station_id": closest["station_id"],
                "nearest_station_name": closest["station_name"],
                "nearest_station_distance_m": float(
                    closest["distance_to_study_center_m"]
                ),
                "nearest_station_inside_study_area": bool(
                    closest["inside_study_area"]
                ),
            }
        )
    table = pd.DataFrame(records)
    summary = {
        "snapshot_id": str(observations["snapshot_id"].iloc[0]),
        "retrieved_at_utc": str(observations["retrieved_at_utc"].iloc[0]),
        "total_observations": int(len(observations)),
        "metrics": records,
        "warning": (
            "Metrics retain their own station and timestamp. They have not been "
            "merged into a synthetic co-located observation."
        ),
    }
    return summary, table


def create_weather_station_map(
    observations: pd.DataFrame,
    nearest: pd.DataFrame,
    study_area: StudyAreaConfig,
    output_path: Path,
) -> None:
    """Create an interactive QA map of stations and nearest observations."""

    station_map = folium.Map(
        location=[study_area.latitude, study_area.longitude],
        zoom_start=12,
        tiles="OpenStreetMap",
        control_scale=True,
    )
    folium.Circle(
        location=[study_area.latitude, study_area.longitude],
        radius=study_area.radius_m,
        color="#2563eb",
        weight=2,
        fill=True,
        fill_color="#60a5fa",
        fill_opacity=0.08,
        tooltip="Clementi MRT 2 km study area",
    ).add_to(station_map)
    folium.Marker(
        [study_area.latitude, study_area.longitude],
        tooltip="Clementi MRT study-area center",
        icon=folium.Icon(color="red", icon="train", prefix="fa"),
    ).add_to(station_map)

    colours = {
        "air_temperature": "#dc2626",
        "relative_humidity": "#2563eb",
        "wind_speed": "#059669",
        "wbgt": "#d97706",
    }
    nearest_pairs = set(zip(nearest["metric"], nearest["station_id"], strict=False))
    latest = observations.sort_values("observed_at_utc").drop_duplicates(
        ["metric", "station_id"], keep="last"
    )
    for metric, group in latest.groupby("metric", sort=True):
        layer = folium.FeatureGroup(name=metric, show=True)
        for row in group.itertuples(index=False):
            if pd.isna(row.latitude) or pd.isna(row.longitude):
                continue
            is_nearest = (metric, row.station_id) in nearest_pairs
            value_text = "NA" if pd.isna(row.value) else f"{row.value:.2f} {row.unit}"
            popup = (
                f"<b>{row.station_name or row.station_id}</b><br>"
                f"Metric: {metric}<br>Value: {value_text}<br>"
                f"Observed: {row.observed_at_sgt}<br>Quality: {row.quality_flag}"
            )
            folium.CircleMarker(
                location=[row.latitude, row.longitude],
                radius=8 if is_nearest else 4,
                color=colours.get(metric, "#4b5563"),
                weight=3 if is_nearest else 1,
                fill=True,
                fill_opacity=0.8,
                tooltip=f"{metric}: {row.station_name or row.station_id}",
                popup=folium.Popup(popup, max_width=320),
            ).add_to(layer)
        layer.add_to(station_map)
    folium.LayerControl(collapsed=False).add_to(station_map)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    station_map.save(output_path)


def save_processed_weather(
    observations: pd.DataFrame,
    nearest: pd.DataFrame,
    summary: dict[str, Any],
    summary_table: pd.DataFrame,
    study_area: StudyAreaConfig,
    project_root: Path,
) -> None:
    """Save processed tables, spatial stations, summary, and QA map."""

    processed_directory = project_root / "data/processed/weather"
    table_directory = project_root / "outputs/tables"
    map_directory = project_root / "outputs/maps"
    processed_directory.mkdir(parents=True, exist_ok=True)
    table_directory.mkdir(parents=True, exist_ok=True)

    observations.to_csv(
        processed_directory / "weather_observations_latest.csv",
        index=False,
    )
    nearest.to_csv(
        processed_directory / "nearest_weather_stations_to_clementi.csv",
        index=False,
    )
    weather_points = observations.dropna(subset=["latitude", "longitude"]).copy()
    weather_gdf = gpd.GeoDataFrame(
        weather_points,
        geometry=gpd.points_from_xy(
            weather_points["longitude"], weather_points["latitude"]
        ),
        crs="EPSG:4326",
    )
    geopackage = processed_directory / "weather_observations_latest.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    weather_gdf.to_file(geopackage, layer="observations", driver="GPKG")
    (processed_directory / "weather_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    summary_table.to_csv(table_directory / "weather_summary.csv", index=False)
    nearest.to_csv(
        table_directory / "nearest_weather_stations_to_clementi.csv",
        index=False,
    )
    create_weather_station_map(
        observations,
        nearest,
        study_area,
        map_directory / "clementi_weather_stations.html",
    )


def build_weather_snapshot(
    weather_config_path: Path,
    study_area_config_path: Path,
    project_root: Path = PROJECT_ROOT,
    raw_snapshot: Path | None = None,
) -> dict[str, Any]:
    """Fetch or reload a snapshot, normalize it, and create Part 3 outputs."""

    weather_config = load_weather_config(weather_config_path)
    study_area = load_study_area_config(study_area_config_path)

    if raw_snapshot is None:
        fetched, retrieved_at_utc = fetch_weather_payloads(weather_config)
        snapshot_directory = save_raw_snapshot(
            fetched,
            retrieved_at_utc,
            weather_config,
            project_root / "data/raw/weather",
        )
        snapshot_id = snapshot_directory.name
        payloads = {
            metric: result["payload"] for metric, result in fetched.items()
        }
    else:
        snapshot_directory = raw_snapshot.resolve()
        payloads, retrieved_at_utc, snapshot_id = load_raw_snapshot(
            snapshot_directory,
            weather_config,
        )

    observations = normalize_snapshot(
        payloads,
        retrieved_at_utc,
        snapshot_id,
        weather_config,
    )
    nearest = nearest_observations_to_study_area(observations, study_area)
    summary, summary_table = summarize_weather(observations, nearest)
    summary["raw_snapshot_directory"] = str(snapshot_directory)
    summary["raw_snapshot_reused"] = raw_snapshot is not None
    save_processed_weather(
        observations,
        nearest,
        summary,
        summary_table,
        study_area,
        project_root,
    )
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(
        description="Fetch and standardize official Singapore weather observations."
    )
    parser.add_argument(
        "--weather-config",
        type=Path,
        default=PROJECT_ROOT / "config/weather.yaml",
    )
    parser.add_argument(
        "--study-area-config",
        type=Path,
        default=PROJECT_ROOT / "config/study_area.yaml",
    )
    parser.add_argument(
        "--raw-snapshot",
        type=Path,
        default=None,
        help="Reuse an existing immutable raw snapshot instead of calling the APIs.",
    )
    args = parser.parse_args()
    summary = build_weather_snapshot(
        args.weather_config,
        args.study_area_config,
        raw_snapshot=args.raw_snapshot,
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

