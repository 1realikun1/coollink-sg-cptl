"""Build the tiled national modelling domain and audit 3D-source readiness."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import pandas as pd
import requests
import yaml
from pyproj import CRS
from shapely.geometry import Point, box

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class NationalDomainConfig:
    """Validated national tiling and source-assessment settings."""

    analysis_id: str
    geographic_crs: str
    analysis_crs: str
    core_tile_size_m: float
    shadow_buffer_m: float
    target_raster_resolution_m: float
    solweig_timestep_count: int
    boundary_dataset_id: str
    boundary_snapshot_id: str
    clementi_longitude: float
    clementi_latitude: float
    planning_areas_path: str
    current_clementi_buildings_path: str
    current_clementi_buildings_layer: str
    national_boundary_path: str
    tile_grid_path: str
    tile_grid_csv_path: str
    readiness_path: str
    source_assessment_path: str
    tile_map_path: str
    replacement_gate: tuple[str, ...]
    building_precedence: tuple[str, ...]
    source_policy_rule: str
    sources: dict[str, dict[str, Any]]
    boundary_source: dict[str, Any]


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    try:
        return mapping[key]
    except KeyError as exc:
        raise ValueError(f"Missing required field '{section}.{key}'") from exc


def load_national_domain_config(path: str | Path) -> NationalDomainConfig:
    """Load and validate national-domain configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("National 3D configuration must be a YAML mapping")
    model = _required(payload, "national_3d_model", "root")
    inputs = _required(payload, "inputs", "root")
    outputs = _required(payload, "outputs", "root")
    policy = _required(payload, "source_policy", "root")
    sources = _required(payload, "sources", "root")
    reference = _required(model, "clementi_reference_point", "national_3d_model")
    current_buildings = _required(inputs, "current_clementi_buildings", "inputs")

    geographic_crs = str(_required(model, "geographic_crs", "national_3d_model"))
    analysis_crs = str(_required(model, "analysis_crs", "national_3d_model"))
    if not CRS.from_user_input(geographic_crs).is_geographic:
        raise ValueError("national_3d_model.geographic_crs must be geographic")
    if not CRS.from_user_input(analysis_crs).is_projected:
        raise ValueError("national_3d_model.analysis_crs must be projected")

    tile_size = float(_required(model, "core_tile_size_m", "national_3d_model"))
    buffer_m = float(_required(model, "shadow_buffer_m", "national_3d_model"))
    resolution = float(
        _required(model, "target_raster_resolution_m", "national_3d_model")
    )
    timestep_count = int(
        _required(model, "solweig_timestep_count", "national_3d_model")
    )
    if min(tile_size, resolution, timestep_count) <= 0 or buffer_m < 0:
        raise ValueError("Tile size, resolution, and timestep count must be positive")
    if tile_size % resolution or (tile_size + 2 * buffer_m) % resolution:
        raise ValueError("Tile and buffered widths must be divisible by raster resolution")
    gate = tuple(str(value) for value in _required(policy, "replacement_gate", "source_policy"))
    precedence = tuple(
        str(value) for value in _required(policy, "building_precedence", "source_policy")
    )
    if not gate or not precedence or not isinstance(sources, dict):
        raise ValueError("Source gate, precedence, and sources must be non-empty")

    return NationalDomainConfig(
        analysis_id=str(_required(model, "analysis_id", "national_3d_model")),
        geographic_crs=geographic_crs,
        analysis_crs=analysis_crs,
        core_tile_size_m=tile_size,
        shadow_buffer_m=buffer_m,
        target_raster_resolution_m=resolution,
        solweig_timestep_count=timestep_count,
        boundary_dataset_id=str(
            _required(model, "boundary_dataset_id", "national_3d_model")
        ),
        boundary_snapshot_id=str(
            _required(model, "boundary_snapshot_id", "national_3d_model")
        ),
        clementi_longitude=float(_required(reference, "longitude", "reference")),
        clementi_latitude=float(_required(reference, "latitude", "reference")),
        planning_areas_path=str(_required(inputs, "planning_areas_geojson", "inputs")),
        current_clementi_buildings_path=str(
            _required(current_buildings, "path", "inputs.current_clementi_buildings")
        ),
        current_clementi_buildings_layer=str(
            _required(current_buildings, "layer", "inputs.current_clementi_buildings")
        ),
        national_boundary_path=str(_required(outputs, "national_boundary", "outputs")),
        tile_grid_path=str(_required(outputs, "tile_grid", "outputs")),
        tile_grid_csv_path=str(_required(outputs, "tile_grid_csv", "outputs")),
        readiness_path=str(_required(outputs, "readiness", "outputs")),
        source_assessment_path=str(
            _required(outputs, "source_assessment", "outputs")
        ),
        tile_map_path=str(_required(outputs, "tile_map", "outputs")),
        replacement_gate=gate,
        building_precedence=precedence,
        source_policy_rule=str(_required(policy, "rule", "source_policy")),
        sources={str(key): dict(value) for key, value in sources.items()},
        boundary_source=dict(_required(payload, "boundary_source", "root")),
    )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def acquire_ura_boundary(
    config: NationalDomainConfig,
    project_root: Path = PROJECT_ROOT,
    timeout_seconds: float = 120,
) -> dict[str, Any]:
    """Download one immutable data.gov.sg boundary snapshot."""

    target = project_root / config.planning_areas_path
    snapshot_directory = target.parent
    if target.exists() or snapshot_directory.joinpath("manifest.json").exists():
        raise FileExistsError(f"Raw snapshot already exists and is immutable: {target}")
    snapshot_directory.mkdir(parents=True, exist_ok=True)
    api_url = str(config.boundary_source["api_url"])
    response = requests.get(api_url, timeout=timeout_seconds)
    response.raise_for_status()
    poll_payload = response.json()
    if poll_payload.get("code") != 0 or not poll_payload.get("data", {}).get("url"):
        raise ValueError("data.gov.sg did not return a boundary download URL")
    poll_path = snapshot_directory / "poll-download.json"
    poll_path.write_text(json.dumps(poll_payload, indent=2), encoding="utf-8")
    download = requests.get(poll_payload["data"]["url"], timeout=timeout_seconds)
    download.raise_for_status()
    target.write_bytes(download.content)
    manifest = {
        "snapshot_id": config.boundary_snapshot_id,
        "dataset_id": config.boundary_dataset_id,
        "title": config.boundary_source["title"],
        "publisher": config.boundary_source["publisher"],
        "retrieval_date": "2026-08-19",
        "temporal_coverage": config.boundary_source["temporal_coverage"],
        "source_crs": config.boundary_source["source_crs"],
        "format": config.boundary_source["format"],
        "licence": config.boundary_source["licence"],
        "dataset_url": config.boundary_source["dataset_url"],
        "api_url": api_url,
        "file": target.name,
        "size_bytes": target.stat().st_size,
        "sha256": _sha256(target),
    }
    snapshot_directory.joinpath("manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )
    return manifest


def build_tile_grid(
    planning_areas: gpd.GeoDataFrame,
    analysis_crs: str,
    tile_size_m: float,
    shadow_buffer_m: float,
    raster_resolution_m: float,
    timestep_count: int,
) -> tuple[gpd.GeoDataFrame, gpd.GeoDataFrame]:
    """Dissolve land polygons and create fixed, buffered analysis tiles."""

    if planning_areas.crs is None:
        raise ValueError("Planning-area boundary must have an explicit CRS")
    if planning_areas.empty:
        raise ValueError("Planning-area boundary is empty")
    projected = planning_areas.to_crs(analysis_crs)
    valid = projected.loc[projected.geometry.notna() & ~projected.geometry.is_empty].copy()
    if valid.empty:
        raise ValueError("Planning-area boundary has no valid geometry")
    land_geometry = valid.geometry.union_all()
    boundary = gpd.GeoDataFrame(
        {"domain_id": ["singapore_land_no_sea"], "geometry": [land_geometry]},
        crs=analysis_crs,
    )

    min_x, min_y, max_x, max_y = land_geometry.bounds
    start_x = math.floor(min_x / tile_size_m) * tile_size_m
    start_y = math.floor(min_y / tile_size_m) * tile_size_m
    end_x = math.ceil(max_x / tile_size_m) * tile_size_m
    end_y = math.ceil(max_y / tile_size_m) * tile_size_m
    core_cells = int(round(tile_size_m / raster_resolution_m)) ** 2
    buffered_width = tile_size_m + 2 * shadow_buffer_m
    buffered_cells = int(round(buffered_width / raster_resolution_m)) ** 2

    records: list[dict[str, Any]] = []
    for y in _coordinate_steps(start_y, end_y, tile_size_m):
        for x in _coordinate_steps(start_x, end_x, tile_size_m):
            geometry = box(x, y, x + tile_size_m, y + tile_size_m)
            intersection = geometry.intersection(land_geometry)
            if intersection.is_empty or intersection.area <= 0:
                continue
            tile_id = f"SG3414_E{int(x):06d}_N{int(y):06d}"
            records.append(
                {
                    "tile_id": tile_id,
                    "xmin_m": x,
                    "ymin_m": y,
                    "xmax_m": x + tile_size_m,
                    "ymax_m": y + tile_size_m,
                    "buffer_m": shadow_buffer_m,
                    "buffer_xmin_m": x - shadow_buffer_m,
                    "buffer_ymin_m": y - shadow_buffer_m,
                    "buffer_xmax_m": x + tile_size_m + shadow_buffer_m,
                    "buffer_ymax_m": y + tile_size_m + shadow_buffer_m,
                    "land_area_km2": intersection.area / 1_000_000,
                    "land_fraction": intersection.area / geometry.area,
                    "core_raster_cells": core_cells,
                    "buffered_raster_cells": buffered_cells,
                    "solweig_timesteps": timestep_count,
                    "estimated_cell_timesteps": buffered_cells * timestep_count,
                    "model_status": "domain_ready_inputs_pending",
                    "geometry": geometry,
                }
            )
    tiles = gpd.GeoDataFrame(records, geometry="geometry", crs=analysis_crs)
    if tiles.empty or tiles["tile_id"].duplicated().any():
        raise ValueError("National tile grid must be non-empty with unique tile IDs")
    return boundary, tiles.sort_values("tile_id").reset_index(drop=True)


def _coordinate_steps(start: float, end: float, step: float) -> list[float]:
    count = int(round((end - start) / step))
    return [start + index * step for index in range(count)]


def summarize_current_building_baseline(buildings: gpd.GeoDataFrame) -> dict[str, Any]:
    """Summarize current evidence without treating estimates as ground truth."""

    required = {"height_central_m", "height_method"}
    missing = required.difference(buildings.columns)
    if missing:
        raise ValueError(f"Current building baseline is missing: {sorted(missing)}")
    heights = pd.to_numeric(buildings["height_central_m"], errors="coerce")
    if heights.isna().any() or (heights <= 0).any():
        raise ValueError("Current building baseline must have complete positive heights")
    counts = buildings["height_method"].value_counts().sort_index()
    return {
        "scope": "Clementi 2 km only",
        "building_count": len(buildings),
        "height_central_min_m": float(heights.min()),
        "height_central_median_m": float(heights.median()),
        "height_central_max_m": float(heights.max()),
        "height_central_above_open_buildings_cap_count": int((heights > 100).sum()),
        "height_method_counts": {str(key): int(value) for key, value in counts.items()},
        "interpretation": (
            "These are provenance-labelled observations and estimates, not validation truth. "
            "The count above 100 m shows why a capped prediction cannot overwrite the "
            "baseline blindly."
        ),
    }


def assess_3d_sources(
    config: NationalDomainConfig,
    current_baseline: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Apply the explicit replacement gate without inventing empirical quality."""

    gate_to_field = {
        "is_analysis_dataset": "artifact_type",
        "nationwide_coverage": "nationwide_coverage",
        "data_accessible": "data_accessible",
        "reuse_rights_confirmed": "reuse_rights_confirmed",
        "height_semantics_documented": "height_semantics_documented",
        "singapore_validation_passed": "singapore_validation_passed",
    }
    results: dict[str, Any] = {}
    building_candidates = {
        "sla_national_3d",
        "nus_voxcity",
        "google_open_buildings_2_5d_2023",
    }
    for source_id, source in config.sources.items():
        if source_id not in building_candidates:
            results[source_id] = {
                "label": source.get("label"),
                "intended_role": source.get("intended_role"),
                "building_replacement_gate_applicable": False,
                "configured_status": source.get("status"),
            }
            continue
        checks: dict[str, bool] = {}
        for gate in config.replacement_gate:
            field = gate_to_field.get(gate)
            if field is None:
                raise ValueError(f"Unsupported replacement gate: {gate}")
            checks[gate] = (
                source.get(field) == "dataset"
                if gate == "is_analysis_dataset"
                else bool(source.get(field, False))
            )
        eligible = all(checks.values())
        results[source_id] = {
            "label": source.get("label"),
            "intended_role": source.get("intended_role"),
            "building_replacement_gate_applicable": True,
            "checks": checks,
            "replacement_eligible": eligible,
            "failed_checks": [key for key, passed in checks.items() if not passed],
            "configured_status": source.get("status"),
        }
    direct_replacement = any(
        results[source]["replacement_eligible"] for source in building_candidates
    )
    report = {
        "analysis_id": config.analysis_id,
        "assessment_date": "2026-08-19",
        "question": "Should SLA 3D or VoxCity directly replace the current building model?",
        "direct_replacement_approved": direct_replacement,
        "decision": (
            "direct_replacement"
            if direct_replacement
            else "hybrid_national_expansion_without_direct_building_replacement"
        ),
        "reason": (
            "No assessed candidate currently passes accessibility, reuse-rights, "
            "documented-height-semantics, and Singapore-validation gates together."
        ),
        "building_precedence": list(config.building_precedence),
        "source_policy_rule": config.source_policy_rule,
        "sources": results,
    }
    if current_baseline is not None:
        report["current_clementi_baseline"] = current_baseline
    return report


def render_tile_index_map(
    boundary: gpd.GeoDataFrame,
    tiles: gpd.GeoDataFrame,
    clementi_tile_id: str,
    output_path: Path,
) -> None:
    """Write a lightweight national tile-index map for visual verification."""

    boundary_wgs84 = boundary.to_crs("EPSG:4326")
    tiles_wgs84 = tiles.to_crs("EPSG:4326").copy()
    tiles_wgs84["is_clementi"] = tiles_wgs84["tile_id"].eq(clementi_tile_id)
    tiles_wgs84["land_area_km2"] = tiles_wgs84["land_area_km2"].round(3)
    tiles_wgs84["geometry"] = tiles_wgs84.geometry.simplify(0.00001)
    center = boundary_wgs84.geometry.union_all().centroid
    map_object = folium.Map(
        location=[center.y, center.x],
        zoom_start=11,
        tiles="CartoDB positron",
        control_scale=True,
    )
    folium.GeoJson(
        boundary_wgs84,
        name="Singapore land domain",
        style_function=lambda _feature: {
            "fillColor": "#d9efe2",
            "color": "#237a57",
            "weight": 2,
            "fillOpacity": 0.35,
        },
    ).add_to(map_object)
    folium.GeoJson(
        tiles_wgs84[
            ["tile_id", "land_area_km2", "land_fraction", "model_status", "is_clementi", "geometry"]
        ],
        name="2 km SOLWEIG tiles",
        style_function=lambda feature: {
            "fillColor": "#e6550d" if feature["properties"]["is_clementi"] else "#3182bd",
            "color": "#a63603" if feature["properties"]["is_clementi"] else "#08519c",
            "weight": 2.5 if feature["properties"]["is_clementi"] else 0.7,
            "fillOpacity": 0.35 if feature["properties"]["is_clementi"] else 0.08,
        },
        tooltip=folium.GeoJsonTooltip(
            fields=["tile_id", "land_area_km2", "land_fraction", "model_status"],
            aliases=["Tile", "Land area (km²)", "Land fraction", "Status"],
        ),
    ).add_to(map_object)
    bounds = boundary_wgs84.total_bounds
    map_object.fit_bounds([[bounds[1], bounds[0]], [bounds[3], bounds[2]]])
    folium.LayerControl(collapsed=False).add_to(map_object)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    map_object.save(output_path)


def build_national_domain(
    config: NationalDomainConfig,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Create national land, tile, readiness, and source-assessment artifacts."""

    raw_path = project_root / config.planning_areas_path
    if not raw_path.exists():
        raise FileNotFoundError(f"Acquire the configured boundary first: {raw_path}")
    planning_areas = gpd.read_file(raw_path)
    boundary, tiles = build_tile_grid(
        planning_areas,
        config.analysis_crs,
        config.core_tile_size_m,
        config.shadow_buffer_m,
        config.target_raster_resolution_m,
        config.solweig_timestep_count,
    )
    reference = gpd.GeoSeries(
        [Point(config.clementi_longitude, config.clementi_latitude)],
        crs=config.geographic_crs,
    ).to_crs(config.analysis_crs).iloc[0]
    reference_tiles = tiles.loc[tiles.geometry.covers(reference), "tile_id"].tolist()
    if len(reference_tiles) != 1:
        raise ValueError("Clementi reference point must fall in exactly one national tile")

    boundary_path = project_root / config.national_boundary_path
    tile_path = project_root / config.tile_grid_path
    csv_path = project_root / config.tile_grid_csv_path
    readiness_path = project_root / config.readiness_path
    assessment_path = project_root / config.source_assessment_path
    tile_map_path = project_root / config.tile_map_path
    for path in (
        boundary_path,
        tile_path,
        csv_path,
        readiness_path,
        assessment_path,
        tile_map_path,
    ):
        path.parent.mkdir(parents=True, exist_ok=True)
    boundary.to_file(boundary_path, layer="national_land", driver="GPKG")
    tiles.to_file(tile_path, layer="solweig_tiles", driver="GPKG")
    pd.DataFrame(tiles.drop(columns="geometry")).to_csv(csv_path, index=False)
    building_path = project_root / config.current_clementi_buildings_path
    current_baseline = summarize_current_building_baseline(
        gpd.read_file(building_path, layer=config.current_clementi_buildings_layer)
    )
    assessment = assess_3d_sources(config, current_baseline=current_baseline)
    assessment_path.write_text(json.dumps(assessment, indent=2), encoding="utf-8")
    render_tile_index_map(boundary, tiles, reference_tiles[0], tile_map_path)
    readiness = {
        "analysis_id": config.analysis_id,
        "status": "national_domain_ready_source_tiles_pending",
        "scope": "Singapore land represented by URA planning areas without sea",
        "analysis_crs": config.analysis_crs,
        "tile_count": len(tiles),
        "land_area_km2": float(boundary.geometry.area.sum() / 1_000_000),
        "tiled_land_area_km2": float(tiles["land_area_km2"].sum()),
        "core_tile_size_m": config.core_tile_size_m,
        "shadow_buffer_m": config.shadow_buffer_m,
        "target_raster_resolution_m": config.target_raster_resolution_m,
        "solweig_timestep_count": config.solweig_timestep_count,
        "clementi_reference_tile": reference_tiles[0],
        "tile_index_map": config.tile_map_path,
        "direct_3d_replacement_approved": assessment["direct_replacement_approved"],
        "source_decision": assessment["decision"],
        "ready_components": ["national_land_boundary", "national_tile_index"],
        "pending_components": [
            "per_tile_buildings",
            "per_tile_canopy_height",
            "per_tile_terrain",
            "per_tile_land_cover",
            "national_pedestrian_network",
            "per_tile_solweig_runs",
            "cross_tile_routing_graph",
        ],
        "boundary_input_sha256": _sha256(raw_path),
    }
    readiness_path.write_text(json.dumps(readiness, indent=2), encoding="utf-8")
    return readiness


def main() -> None:
    """Run immutable acquisition and/or national-domain generation."""

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        default="config/national_3d_model.yaml",
        help="National 3D YAML configuration relative to the project root",
    )
    parser.add_argument("--acquire", action="store_true", help="Acquire raw URA boundary")
    parser.add_argument("--build", action="store_true", help="Build national tiled domain")
    args = parser.parse_args()
    if not args.acquire and not args.build:
        parser.error("Select --acquire and/or --build")
    config = load_national_domain_config(PROJECT_ROOT / args.config)
    result: dict[str, Any] = {}
    if args.acquire:
        result["acquisition"] = acquire_ura_boundary(config)
    if args.build:
        result["national_domain"] = build_national_domain(config)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
