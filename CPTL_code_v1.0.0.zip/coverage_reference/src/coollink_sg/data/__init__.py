"""Data acquisition and normalization modules."""

