"""Audit whether existing national open rasters cover a representative region."""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import geopandas as gpd
import pandas as pd
import rasterio
import yaml
from pyproj import CRS
from rasterio.warp import transform_bounds
from shapely.geometry import box
from shapely.ops import unary_union

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class RegionalInputAuditConfig:
    """Validated shared-raster coverage audit configuration."""

    analysis_id: str
    region_id: str
    analysis_crs: str
    shadow_buffer_m: float
    regions_path: str
    regions_layer: str
    tile_index_path: str
    tile_index_layer: str
    sources: tuple[dict[str, Any], ...]
    csv_path: str
    summary_path: str


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    try:
        return mapping[key]
    except KeyError as exc:
        raise ValueError(f"Missing required field '{section}.{key}'") from exc


def load_regional_input_audit_config(path: str | Path) -> RegionalInputAuditConfig:
    """Load one representative-region raster coverage audit configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Regional input audit configuration must be a YAML mapping")
    model = _required(payload, "regional_input_audit", "root")
    inputs = _required(payload, "inputs", "root")
    outputs = _required(payload, "outputs", "root")
    regions = _required(inputs, "representative_regions", "inputs")
    tiles = _required(inputs, "national_tile_index", "inputs")
    crs = str(_required(model, "analysis_crs", "regional_input_audit"))
    if not CRS.from_user_input(crs).is_projected:
        raise ValueError("regional_input_audit.analysis_crs must be projected")
    sources = _required(inputs, "source_rasters", "inputs")
    if not isinstance(sources, list) or not sources:
        raise ValueError("inputs.source_rasters must be a non-empty list")
    seen: set[str] = set()
    validated_sources: list[dict[str, Any]] = []
    for source in sources:
        if not isinstance(source, dict):
            raise ValueError("Each source raster must be a mapping")
        source_id = str(_required(source, "source_id", "inputs.source_rasters"))
        if source_id in seen:
            raise ValueError("source_id values must be unique")
        seen.add(source_id)
        paths = _required(source, "paths", "inputs.source_rasters")
        if not isinstance(paths, list) or not paths:
            raise ValueError("Every source raster must provide a non-empty paths list")
        validated_sources.append(
            {
                "source_id": source_id,
                "role": str(_required(source, "role", "inputs.source_rasters")),
                "paths": tuple(str(value) for value in paths),
            }
        )
    buffer_m = float(_required(model, "shadow_buffer_m", "regional_input_audit"))
    if buffer_m < 0:
        raise ValueError("regional_input_audit.shadow_buffer_m must be non-negative")
    return RegionalInputAuditConfig(
        analysis_id=str(_required(model, "analysis_id", "regional_input_audit")),
        region_id=str(_required(model, "region_id", "regional_input_audit")),
        analysis_crs=crs,
        shadow_buffer_m=buffer_m,
        regions_path=str(_required(regions, "path", "inputs.representative_regions")),
        regions_layer=str(_required(regions, "layer", "inputs.representative_regions")),
        tile_index_path=str(_required(tiles, "path", "inputs.national_tile_index")),
        tile_index_layer=str(_required(tiles, "layer", "inputs.national_tile_index")),
        sources=tuple(validated_sources),
        csv_path=str(_required(outputs, "csv", "outputs")),
        summary_path=str(_required(outputs, "summary", "outputs")),
    )


def coverage_fraction(
    target_bounds: tuple[float, float, float, float],
    source_bounds: tuple[float, float, float, float],
) -> float:
    """Return the area fraction of target rectangle covered by source rectangle."""

    target = box(*target_bounds)
    source = box(*source_bounds)
    if target.is_empty or target.area <= 0:
        raise ValueError("Target bounds must form a positive-area rectangle")
    return float(target.intersection(source).area / target.area)


def raster_bounds_in_analysis_crs(
    path: Path, analysis_crs: str
) -> tuple[float, float, float, float]:
    """Read a raster extent and transform its envelope into the analysis CRS."""

    with rasterio.open(path) as dataset:
        if dataset.crs is None:
            raise ValueError(f"Raster has no CRS: {path}")
        return tuple(
            float(value)
            for value in transform_bounds(
                dataset.crs, analysis_crs, *dataset.bounds, densify_pts=21
            )
        )


def source_coverage_fraction(
    target_bounds: tuple[float, float, float, float],
    source_bounds: tuple[tuple[float, float, float, float], ...],
) -> float:
    """Return coverage by the union of one or more raster envelopes."""

    if not source_bounds:
        raise ValueError("At least one source envelope is required")
    target = box(*target_bounds)
    if target.is_empty or target.area <= 0:
        raise ValueError("Target bounds must form a positive-area rectangle")
    union = unary_union([box(*bounds) for bounds in source_bounds])
    return float(target.intersection(union).area / target.area)


def audit_regional_input_coverage(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Assess source coverage for every buffered core tile of one region."""

    config = load_regional_input_audit_config(config_path)
    regions = gpd.read_file(
        project_root / config.regions_path, layer=config.regions_layer
    ).to_crs(config.analysis_crs)
    region = regions.loc[regions["region_id"].eq(config.region_id)]
    if len(region) != 1:
        raise ValueError(f"Expected exactly one region with ID {config.region_id}")
    tile_ids = [
        value for value in str(region.iloc[0]["required_core_tile_ids"]).split(";") if value
    ]
    tiles = gpd.read_file(
        project_root / config.tile_index_path, layer=config.tile_index_layer
    ).to_crs(config.analysis_crs)
    selected_tiles = tiles.loc[tiles["tile_id"].isin(tile_ids)].copy()
    if len(selected_tiles) != len(tile_ids):
        raise ValueError("Representative registry references tiles absent from tile index")
    if not (selected_tiles["buffer_m"].astype(float) == config.shadow_buffer_m).all():
        raise ValueError("Configured shadow buffer does not match national tile index")

    source_bounds: dict[str, tuple[tuple[float, float, float, float], ...]] = {}
    for source in config.sources:
        source_paths = tuple(project_root / path for path in source["paths"])
        missing = [path for path in source_paths if not path.exists()]
        if missing:
            raise FileNotFoundError(f"Configured source raster is missing: {missing[0]}")
        source_bounds[source["source_id"]] = tuple(
            raster_bounds_in_analysis_crs(source_path, config.analysis_crs)
            for source_path in source_paths
        )

    records: list[dict[str, Any]] = []
    for _, tile in selected_tiles.sort_values("tile_id").iterrows():
        target_bounds = (
            float(tile["buffer_xmin_m"]), float(tile["buffer_ymin_m"]),
            float(tile["buffer_xmax_m"]), float(tile["buffer_ymax_m"]),
        )
        for source in config.sources:
            fraction = source_coverage_fraction(
                target_bounds, source_bounds[source["source_id"]]
            )
            records.append(
                {
                    "region_id": config.region_id,
                    "tile_id": str(tile["tile_id"]),
                    "source_id": source["source_id"],
                    "role": source["role"],
                    "coverage_fraction": fraction,
                    "full_buffer_coverage": bool(fraction >= 1 - 1e-9),
                }
            )
    table = pd.DataFrame(records).sort_values(["tile_id", "source_id"])
    csv_path = project_root / config.csv_path
    summary_path = project_root / config.summary_path
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    table.to_csv(csv_path, index=False)
    minimum_by_source = table.groupby("source_id")["coverage_fraction"].min().to_dict()
    summary = {
        "analysis_id": config.analysis_id,
        "region_id": config.region_id,
        "core_tile_count": len(tile_ids),
        "shadow_buffer_m": config.shadow_buffer_m,
        "source_count": len(config.sources),
        "minimum_buffer_coverage_by_source": {
            str(key): float(value) for key, value in minimum_by_source.items()
        },
        "all_shared_rasters_cover_all_required_buffers": bool(
            table["full_buffer_coverage"].all()
        ),
        "source_bounds_epsg3414": {
            source_id: [list(bounds) for bounds in source_extents]
            for source_id, source_extents in source_bounds.items()
        },
        "next_status": "shared_open_rasters_ready_building_network_inputs_pending",
        "scope_warning": (
            "Coverage of fallback open rasters does not validate building heights, "
            "create a pedestrian network, or complete a SOLWEIG/UTCI/CPTL model."
        ),
    }
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/jurong_east_regional_input_audit.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(audit_regional_input_coverage(args.config), indent=2))


if __name__ == "__main__":
    main()
