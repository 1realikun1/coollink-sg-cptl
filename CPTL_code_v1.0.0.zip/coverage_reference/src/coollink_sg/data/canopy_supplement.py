"""Acquire only the CHMv2 tiles missing from a representative-region buffer."""

from __future__ import annotations

import argparse
import json
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import geopandas as gpd
import yaml
from pyproj import CRS

from coollink_sg.features.enhanced_tile_inputs import (
    _download_with_resume,
    _sha256,
    select_meta_tiles,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class CanopySupplementConfig:
    """Validated immutable CHMv2 supplement configuration."""

    analysis_id: str
    region_id: str
    snapshot_id: str
    geographic_crs: str
    analysis_crs: str
    shadow_buffer_m: float
    regions_path: str
    regions_layer: str
    tile_index_path: str
    tile_index_layer: str
    chmv2_index_path: str
    existing_chmv2_directory: str
    tile_url_template: str
    source: dict[str, Any]
    raw_snapshot_directory: str


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    try:
        return mapping[key]
    except KeyError as exc:
        raise ValueError(f"Missing required field '{section}.{key}'") from exc


def load_canopy_supplement_config(path: str | Path) -> CanopySupplementConfig:
    """Load one canopy supplement configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Canopy supplement configuration must be a YAML mapping")
    model = _required(payload, "canopy_supplement", "root")
    inputs = _required(payload, "inputs", "root")
    source = _required(payload, "source", "root")
    output = _required(payload, "output", "root")
    geographic_crs = str(_required(model, "geographic_crs", "canopy_supplement"))
    analysis_crs = str(_required(model, "analysis_crs", "canopy_supplement"))
    if not CRS.from_user_input(geographic_crs).is_geographic:
        raise ValueError("canopy_supplement.geographic_crs must be geographic")
    if not CRS.from_user_input(analysis_crs).is_projected:
        raise ValueError("canopy_supplement.analysis_crs must be projected")
    buffer_m = float(_required(model, "shadow_buffer_m", "canopy_supplement"))
    if buffer_m < 0:
        raise ValueError("canopy_supplement.shadow_buffer_m must be non-negative")
    regions = _required(inputs, "representative_regions", "inputs")
    tiles = _required(inputs, "national_tile_index", "inputs")
    return CanopySupplementConfig(
        analysis_id=str(_required(model, "analysis_id", "canopy_supplement")),
        region_id=str(_required(model, "region_id", "canopy_supplement")),
        snapshot_id=str(_required(model, "snapshot_id", "canopy_supplement")),
        geographic_crs=geographic_crs,
        analysis_crs=analysis_crs,
        shadow_buffer_m=buffer_m,
        regions_path=str(_required(regions, "path", "inputs.representative_regions")),
        regions_layer=str(_required(regions, "layer", "inputs.representative_regions")),
        tile_index_path=str(_required(tiles, "path", "inputs.national_tile_index")),
        tile_index_layer=str(_required(tiles, "layer", "inputs.national_tile_index")),
        chmv2_index_path=str(_required(inputs, "chmv2_index", "inputs")),
        existing_chmv2_directory=str(_required(inputs, "existing_chmv2_directory", "inputs")),
        tile_url_template=str(_required(source, "tile_url_template", "source")),
        source=dict(source),
        raw_snapshot_directory=str(_required(output, "raw_snapshot_directory", "output")),
    )


def required_region_canopy_tiles(
    config: CanopySupplementConfig,
    project_root: Path = PROJECT_ROOT,
) -> tuple[str, ...]:
    """Select CHMv2 quadkeys that intersect all buffered core tiles of a region."""

    regions = gpd.read_file(
        project_root / config.regions_path, layer=config.regions_layer
    ).to_crs(config.analysis_crs)
    region = regions.loc[regions["region_id"].eq(config.region_id)]
    if len(region) != 1:
        raise ValueError(f"Expected exactly one region with ID {config.region_id}")
    tile_ids = [
        value for value in str(region.iloc[0]["required_core_tile_ids"]).split(";") if value
    ]
    tiles = gpd.read_file(
        project_root / config.tile_index_path, layer=config.tile_index_layer
    ).to_crs(config.analysis_crs)
    selected = tiles.loc[tiles["tile_id"].isin(tile_ids)].copy()
    if len(selected) != len(tile_ids):
        raise ValueError("Representative registry references tiles absent from tile index")
    if not (selected["buffer_m"].astype(float) == config.shadow_buffer_m).all():
        raise ValueError("Configured shadow buffer does not match national tile index")
    region_buffer = gpd.GeoDataFrame(
        {"region_id": [config.region_id]},
        geometry=[selected.geometry.buffer(config.shadow_buffer_m).union_all()],
        crs=config.analysis_crs,
    )
    index = gpd.read_file(project_root / config.chmv2_index_path)
    return select_meta_tiles(index, region_buffer, config.geographic_crs)


def acquire_canopy_supplement(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Download missing CHMv2 tiles into a new immutable raw snapshot."""

    config = load_canopy_supplement_config(config_path)
    raw_directory = project_root / config.raw_snapshot_directory
    if raw_directory.exists():
        raise FileExistsError(f"Raw snapshot already exists and is immutable: {raw_directory}")
    existing_directory = project_root / config.existing_chmv2_directory
    existing = {path.stem for path in existing_directory.glob("*.tif")}
    required = required_region_canopy_tiles(config, project_root)
    missing = tuple(tile_id for tile_id in required if tile_id not in existing)
    staging = project_root / "work" / "canopy_supplement" / config.snapshot_id
    staging.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, Any]] = []
    for tile_id in missing:
        target = staging / "chm" / f"{tile_id}.tif"
        url = config.tile_url_template.format(tile=tile_id)
        _download_with_resume(url, target)
        records.append(
            {
                "source_id": "meta_chmv2",
                "tile_id": tile_id,
                "relative_path": target.relative_to(staging).as_posix(),
                "url": url,
                "size_bytes": target.stat().st_size,
                "sha256": _sha256(target),
            }
        )
    manifest = {
        "analysis_id": config.analysis_id,
        "snapshot_id": config.snapshot_id,
        "retrieval_date": "2026-08-19",
        "region_id": config.region_id,
        "required_chmv2_tile_ids": list(required),
        "previously_available_chmv2_tile_ids": sorted(existing),
        "acquired_chmv2_tile_ids": list(missing),
        "source_records": records,
        "source_metadata": config.source,
    }
    staging.joinpath("manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )
    raw_directory.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(staging), str(raw_directory))
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/jurong_east_chmv2_supplement.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(acquire_canopy_supplement(args.config), indent=2))


if __name__ == "__main__":
    main()
