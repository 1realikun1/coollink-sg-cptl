"""Manuscript tables and publication-figure builders."""
