"""Map and figure generation modules."""

