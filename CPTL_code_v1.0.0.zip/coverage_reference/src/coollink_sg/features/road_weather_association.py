"""Associate roads with nearest valid weather stations separately by metric."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import pandas as pd
from shapely.geometry import mapping

from coollink_sg.config import (
    RoadWeatherAssociationConfig,
    load_road_weather_association_config,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]

REQUIRED_OBSERVATION_FIELDS = {
    "snapshot_id",
    "retrieved_at_utc",
    "metric",
    "station_id",
    "station_name",
    "station_context",
    "latitude",
    "longitude",
    "observed_at_sgt",
    "observed_at_utc",
    "value",
    "unit",
    "heat_stress",
    "age_minutes_at_retrieval",
    "quality_flag",
}


def _latest_valid_stations(
    observations: pd.DataFrame,
    metric: str,
    config: RoadWeatherAssociationConfig,
    study_area_wgs84: gpd.GeoDataFrame,
) -> gpd.GeoDataFrame:
    subset = observations.loc[
        observations["metric"].eq(metric)
        & observations["quality_flag"].isin(config.accepted_quality_flags)
    ].dropna(subset=["value", "latitude", "longitude", "station_id"])
    if subset.empty:
        raise ValueError(f"No accepted non-missing station observation for {metric}")
    subset = subset.copy()
    subset["observed_at_utc_parsed"] = pd.to_datetime(
        subset["observed_at_utc"], utc=True, errors="raise"
    )
    subset = subset.sort_values(
        ["observed_at_utc_parsed", "station_id"]
    ).drop_duplicates("station_id", keep="last")
    stations = gpd.GeoDataFrame(
        subset,
        geometry=gpd.points_from_xy(subset["longitude"], subset["latitude"]),
        crs=config.geographic_crs,
    )
    area = study_area_wgs84.to_crs(config.geographic_crs).geometry.union_all()
    stations["source_station_inside_study_area"] = stations.geometry.apply(area.covers)
    return stations


def associate_weather_stations_to_roads(
    roads: gpd.GeoDataFrame,
    observations: pd.DataFrame,
    study_area: gpd.GeoDataFrame,
    config: RoadWeatherAssociationConfig,
) -> gpd.GeoDataFrame:
    """Create a long road-by-metric nearest-station context table."""

    if roads.crs is None or study_area.crs is None:
        raise ValueError("Roads and study area must have explicit CRS values")
    if "segment_id" not in roads or roads["segment_id"].isna().any():
        raise ValueError("Roads must contain complete segment_id values")
    if not roads["segment_id"].is_unique:
        raise ValueError("Road segment_id values must be unique")
    missing = REQUIRED_OBSERVATION_FIELDS.difference(observations.columns)
    if missing:
        raise ValueError(f"Weather observations are missing fields: {sorted(missing)}")
    available_metrics = set(observations["metric"].dropna())
    absent_metrics = set(config.required_metrics).difference(available_metrics)
    if absent_metrics:
        raise ValueError(f"Required weather metrics are absent: {sorted(absent_metrics)}")

    roads_projected = roads.to_crs(config.analysis_crs)[
        ["segment_id", "geometry"]
    ].copy()
    reference_points = gpd.GeoDataFrame(
        roads_projected[["segment_id"]].copy(),
        geometry=roads_projected.geometry.interpolate(0.5, normalized=True),
        crs=config.analysis_crs,
    )
    rows = []
    for metric in config.required_metrics:
        stations = _latest_valid_stations(
            observations, metric, config, study_area
        ).to_crs(config.analysis_crs)
        station_fields = stations[
            [
                "station_id",
                "station_name",
                "station_context",
                "latitude",
                "longitude",
                "observed_at_sgt",
                "observed_at_utc",
                "value",
                "unit",
                "heat_stress",
                "age_minutes_at_retrieval",
                "quality_flag",
                "source_station_inside_study_area",
                "snapshot_id",
                "retrieved_at_utc",
                "geometry",
            ]
        ].rename(
            columns={
                "station_id": "source_station_id",
                "station_name": "source_station_name",
                "station_context": "source_station_context",
                "latitude": "source_station_latitude",
                "longitude": "source_station_longitude",
                "value": "source_value",
                "unit": "source_unit",
                "heat_stress": "source_heat_stress",
                "quality_flag": "source_quality_flag",
                "snapshot_id": "weather_snapshot_id",
                "retrieved_at_utc": "weather_retrieved_at_utc",
            }
        )
        joined = gpd.sjoin_nearest(
            reference_points,
            station_fields,
            how="left",
            distance_col="road_midpoint_to_station_distance_m",
        )
        joined = joined.sort_values(
            [
                "segment_id",
                "road_midpoint_to_station_distance_m",
                "source_station_id",
            ]
        ).drop_duplicates("segment_id", keep="first")
        joined["metric"] = metric
        joined["analysis_id"] = config.analysis_id
        joined["assignment_method"] = config.assignment_method
        joined["road_reference_point"] = config.road_reference_point
        joined["association_status"] = "context_only_not_road_observation"
        joined["road_midpoint_to_station_distance_m"] = joined[
            "road_midpoint_to_station_distance_m"
        ].round(6)
        rows.append(joined.drop(columns=["geometry", "index_right"]))

    attributes = pd.concat(rows, ignore_index=True)
    expected = len(roads_projected) * len(config.required_metrics)
    if len(attributes) != expected:
        raise ValueError("Road-weather association output has incomplete metric coverage")
    if attributes.duplicated(["segment_id", "metric"]).any():
        raise ValueError("Road-weather associations must be unique by segment and metric")
    result = attributes.merge(
        roads_projected,
        on="segment_id",
        how="left",
        validate="many_to_one",
        sort=False,
    )
    return gpd.GeoDataFrame(result, geometry="geometry", crs=config.analysis_crs)


def summarize_road_weather_associations(
    associations: gpd.GeoDataFrame,
    config: RoadWeatherAssociationConfig,
) -> tuple[dict[str, Any], pd.DataFrame]:
    """Summarize source distances and temporal mismatch without interpolation."""

    records = []
    for metric, group in associations.groupby("metric", sort=True):
        distances = group["road_midpoint_to_station_distance_m"]
        station_counts = group["source_station_id"].value_counts().sort_index()
        records.append(
            {
                "metric": metric,
                "road_count": len(group),
                "distinct_assigned_station_count": int(group["source_station_id"].nunique()),
                "assigned_station_ids": ",".join(station_counts.index.astype(str)),
                "minimum_station_distance_m": round(float(distances.min()), 3),
                "median_station_distance_m": round(float(distances.median()), 3),
                "maximum_station_distance_m": round(float(distances.max()), 3),
                "observation_times_sgt": ",".join(
                    sorted(group["observed_at_sgt"].astype(str).unique())
                ),
                "source_stations_inside_study_area": int(
                    group.loc[
                        group["source_station_inside_study_area"],
                        "source_station_id",
                    ].nunique()
                ),
            }
        )
    times = pd.to_datetime(associations["observed_at_utc"], utc=True)
    unique_sources = associations.drop_duplicates(["metric", "source_station_id"])
    summary = {
        "analysis_id": config.analysis_id,
        "weather_snapshot_id": str(associations["weather_snapshot_id"].iloc[0]),
        "segment_count": int(associations["segment_id"].nunique()),
        "metric_count": int(associations["metric"].nunique()),
        "association_row_count": len(associations),
        "assignment_method": config.assignment_method,
        "road_reference_point": config.road_reference_point,
        "accepted_quality_flags": list(config.accepted_quality_flags),
        "cross_metric_observation_time_span_minutes": round(
            float((times.max() - times.min()).total_seconds() / 60), 3
        ),
        "distinct_source_station_count": int(
            unique_sources["source_station_id"].nunique()
        ),
        "source_station_metric_pair_count": len(unique_sources),
        "source_stations_inside_study_area_count": int(
            unique_sources.loc[
                unique_sources["source_station_inside_study_area"],
                "source_station_id",
            ].nunique()
        ),
        "metric_summaries": records,
        "spatial_interpolation_performed": False,
        "heat_model_input_generated": False,
        "warning": (
            "Each metric is associated separately with its nearest accepted station "
            "from the preserved snapshot. Values are station context, not road "
            "observations; no co-located weather record or spatial interpolation is "
            "created."
        ),
    }
    return summary, pd.DataFrame(records)


def create_road_weather_map(
    associations: gpd.GeoDataFrame,
    study_area: gpd.GeoDataFrame,
    summary: dict[str, Any],
    output_path: Path,
) -> None:
    """Map WBGT station associations and all used source stations."""

    wbgt = associations.loc[associations["metric"].eq("wbgt")].to_crs(
        "EPSG:4326"
    ).copy()
    wbgt["distance_m"] = wbgt["road_midpoint_to_station_distance_m"].round(1)
    wbgt["value_display"] = wbgt["source_value"].round(1)
    station_ids = sorted(wbgt["source_station_id"].unique())
    palette = ["#dc2626", "#2563eb", "#059669", "#d97706", "#7c3aed", "#0891b2"]
    colours = {
        station_id: palette[index % len(palette)]
        for index, station_id in enumerate(station_ids)
    }
    center = study_area.to_crs("EPSG:4326").geometry.union_all().centroid
    map_object = folium.Map(
        location=[center.y, center.x], zoom_start=13, tiles="OpenStreetMap", control_scale=True
    )
    folium.GeoJson(
        wbgt[
            [
                "segment_id",
                "source_station_id",
                "source_station_name",
                "observed_at_sgt",
                "value_display",
                "distance_m",
                "geometry",
            ]
        ].to_json(),
        name="Nearest WBGT station by road midpoint",
        style_function=lambda feature: {
            "color": colours[feature["properties"]["source_station_id"]],
            "weight": 3,
            "opacity": 0.8,
        },
        tooltip=folium.GeoJsonTooltip(
            fields=[
                "segment_id",
                "source_station_id",
                "source_station_name",
                "observed_at_sgt",
                "value_display",
                "distance_m",
            ],
            aliases=[
                "Segment",
                "WBGT station",
                "Station name",
                "Observed SGT",
                "Station WBGT °C",
                "Road-midpoint distance m",
            ],
        ),
    ).add_to(map_object)
    area_geojson = mapping(
        study_area.to_crs("EPSG:4326").geometry.union_all()
    )
    folium.GeoJson(
        area_geojson,
        name="Study area",
        style_function=lambda _feature: {
            "color": "#111827",
            "weight": 2,
            "fillOpacity": 0,
        },
    ).add_to(map_object)
    sources = associations.drop_duplicates(["metric", "source_station_id"])
    sources = sources.sort_values(["metric", "source_station_id"])
    for row in sources.itertuples(index=False):
        folium.CircleMarker(
            location=[row.source_station_latitude, row.source_station_longitude],
            radius=6,
            color="#111827",
            fill=True,
            fill_opacity=0.85,
            tooltip=(
                f"{row.metric}: {row.source_station_id} "
                f"{row.source_station_name or ''}"
            ),
        ).add_to(map_object)
    time_span = summary["cross_metric_observation_time_span_minutes"]
    note = f"""
    <div style="position:fixed;bottom:30px;left:30px;z-index:9999;background:white;
      padding:10px;border:1px solid #777;font-size:12px;max-width:410px">
      <b>Road–station association QA</b><br>
      Roads show nearest WBGT source station by geometry midpoint.<br>
      Weather snapshot: {summary["weather_snapshot_id"]}<br>
      Cross-metric timestamp span: {time_span:.0f} min<br>
      <small>Context only: not a road observation, interpolation, or Heat Score input.</small>
    </div>
    """
    map_object.get_root().html.add_child(folium.Element(note))
    folium.LayerControl().add_to(map_object)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    map_object.save(output_path)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def build_road_weather_associations(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Build and export the configured metric-separated station associations."""

    config = load_road_weather_association_config(config_path)
    road_path = project_root / config.roads.path
    observation_path = project_root / config.observations_path
    study_path = project_root / config.study_area.path
    roads = gpd.read_file(road_path, layer=config.roads.layer)
    observations = pd.read_csv(observation_path)
    study_area = gpd.read_file(study_path, layer=config.study_area.layer)
    associations = associate_weather_stations_to_roads(
        roads, observations, study_area, config
    )
    summary, summary_table = summarize_road_weather_associations(
        associations, config
    )
    summary["input_sha256"] = {
        "roads": _sha256(road_path),
        "observations": _sha256(observation_path),
        "study_area": _sha256(study_path),
    }
    processed = project_root / "data/processed/weather"
    tables = project_root / "outputs/tables"
    maps = project_root / "outputs/maps"
    geopackage = processed / "road_weather_station_associations.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    associations.to_file(
        geopackage, layer="road_weather_associations", driver="GPKG"
    )
    associations.drop(columns="geometry").to_csv(
        processed / "road_weather_station_associations.csv", index=False
    )
    (processed / "road_weather_station_association_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    summary_table.to_csv(
        tables / "road_weather_station_association_summary.csv", index=False
    )
    create_road_weather_map(
        associations,
        study_area,
        summary,
        maps / "clementi_road_weather_station_associations.html",
    )
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(
        description="Associate each road with a nearest valid station by metric."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/road_weather_association.yaml",
    )
    args = parser.parse_args()
    print(
        json.dumps(
            build_road_weather_associations(args.config),
            indent=2,
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
