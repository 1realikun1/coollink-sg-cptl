"""Complete building heights with explicit provenance and sensitivity bounds."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import pandas as pd

from coollink_sg.config import BuildingHeightConfig, load_building_height_config
from coollink_sg.features.built_environment import load_raw_built_environment_snapshot
from coollink_sg.features.solar_shade import parse_metric_height

PROJECT_ROOT = Path(__file__).resolve().parents[3]


def parse_positive_levels(value: Any) -> float | None:
    """Parse one unambiguous positive level count without splitting lists/ranges."""

    if value is None or (isinstance(value, float) and math.isnan(value)):
        return None
    try:
        levels = float(str(value).strip())
    except ValueError:
        return None
    return levels if math.isfinite(levels) and levels > 0 else None


def load_hdb3d_height_attributes(path: Path) -> dict[str, dict[str, Any]]:
    """Read only provenance and height attributes from the preserved CityJSON."""

    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("type") != "CityJSON" or "CityObjects" not in payload:
        raise ValueError("HDB 3D source is not a supported CityJSON document")
    result: dict[str, dict[str, Any]] = {}
    for object_id, city_object in payload["CityObjects"].items():
        attributes = city_object.get("attributes", {})
        height = parse_metric_height(attributes.get("height"))
        if height is None:
            continue
        result[str(object_id)] = {
            "height_m": height,
            "hdb_max_floor_lvl": parse_positive_levels(
                attributes.get("hdb_max_floor_lvl")
            ),
            "hdb_blk_no": attributes.get("hdb_blk_no"),
            "hdb_street": attributes.get("hdb_street"),
        }
    return result


def _quantiles(
    values: pd.Series,
    probabilities: tuple[float, float, float],
) -> tuple[float, float, float]:
    clean = pd.to_numeric(values, errors="coerce").dropna()
    if clean.empty:
        raise ValueError("Cannot derive quantiles from an empty sample")
    return tuple(float(clean.quantile(probability)) for probability in probabilities)


def complete_building_heights(
    source_features: gpd.GeoDataFrame,
    hdb_heights: dict[str, dict[str, Any]],
    config: BuildingHeightConfig,
) -> tuple[gpd.GeoDataFrame, dict[str, Any]]:
    """Apply a strict evidence hierarchy and retain every estimation method."""

    if source_features.crs is None:
        raise ValueError("Built-environment source must have an explicit CRS")
    required = {"element", "id", "building", config.height_field, config.levels_field}
    missing = required.difference(source_features.columns)
    if missing:
        raise ValueError(f"Built-environment source is missing: {sorted(missing)}")
    polygon = source_features.geometry.geom_type.isin(["Polygon", "MultiPolygon"])
    buildings = source_features.loc[polygon & source_features["building"].notna()].copy()
    buildings = buildings.to_crs(config.analysis_crs)
    buildings["building_id"] = (
        buildings["element"].astype(str) + "/" + buildings["id"].astype(str)
    )
    if buildings["building_id"].duplicated().any():
        raise ValueError("Current OSM building identifiers must be unique")
    buildings["osm_height_m"] = buildings[config.height_field].map(parse_metric_height)
    buildings["osm_levels"] = buildings[config.levels_field].map(parse_positive_levels)
    calibration = buildings.dropna(subset=["osm_height_m", "osm_levels"]).copy()
    calibration["floor_height_ratio_m"] = (
        calibration["osm_height_m"] / calibration["osm_levels"]
    )
    if len(calibration) < 3:
        raise ValueError("At least three explicit height-and-level buildings are required")
    floor_low, floor_central, floor_high = _quantiles(
        calibration["floor_height_ratio_m"], config.floor_height_quantiles
    )
    known_levels = buildings.dropna(subset=["osm_levels"]).copy()
    global_level_low, global_level_central, global_level_high = _quantiles(
        known_levels["osm_levels"], config.floor_height_quantiles
    )
    type_stats = (
        known_levels.groupby("building", dropna=False)["osm_levels"]
        .agg(
            sample_count="count",
            low=lambda values: values.quantile(config.floor_height_quantiles[0]),
            central=lambda values: values.quantile(config.floor_height_quantiles[1]),
            high=lambda values: values.quantile(config.floor_height_quantiles[2]),
        )
        .to_dict("index")
    )

    records: list[dict[str, Any]] = []
    for _, row in buildings.iterrows():
        building_id = str(row["building_id"])
        direct_height = row["osm_height_m"]
        levels = row["osm_levels"]
        hdb = hdb_heights.get(building_id)
        hdb_height = hdb["height_m"] if hdb else None
        hdb_levels = hdb["hdb_max_floor_lvl"] if hdb else None
        type_stat = type_stats.get(row["building"], {})
        if pd.notna(direct_height):
            central = low = high = float(direct_height)
            method = "osm_explicit_positive_height"
            confidence = "highest_available"
            levels_used = float(levels) if pd.notna(levels) else None
            direct = True
        elif hdb_height is not None:
            central = float(hdb_height)
            if hdb_levels is not None:
                alternatives = [
                    central,
                    float(hdb_levels) * floor_low,
                    float(hdb_levels) * floor_high,
                ]
                low, high = min(alternatives), max(alternatives)
            else:
                low = high = central
            method = "hdb3d_storey_estimate_osm_id_match"
            confidence = "medium_external_estimate"
            levels_used = float(hdb_levels) if hdb_levels is not None else None
            direct = False
        elif pd.notna(levels):
            levels_used = float(levels)
            low = levels_used * floor_low
            central = levels_used * floor_central
            high = levels_used * floor_high
            method = "osm_levels_times_local_floor_height"
            confidence = "medium_low_local_estimate"
            direct = False
        elif int(type_stat.get("sample_count", 0)) >= config.minimum_type_level_sample:
            levels_used = float(type_stat["central"])
            low = float(type_stat["low"]) * floor_low
            central = levels_used * floor_central
            high = float(type_stat["high"]) * floor_high
            method = "building_type_level_quantiles_times_local_floor_height"
            confidence = "low_type_imputation"
            direct = False
        else:
            levels_used = global_level_central
            low = global_level_low * floor_low
            central = global_level_central * floor_central
            high = global_level_high * floor_high
            method = "global_level_quantiles_times_local_floor_height"
            confidence = "very_low_global_imputation"
            direct = False
        if not (0 < low <= central <= high):
            raise ValueError(f"Invalid height sensitivity bounds for {building_id}")
        records.append(
            {
                "building_id": building_id,
                "osm_height_raw": row[config.height_field],
                "osm_levels_raw": row[config.levels_field],
                "hdb3d_matched": hdb is not None,
                "hdb3d_height_m": hdb_height,
                "hdb_max_floor_lvl": hdb_levels,
                "levels_used": levels_used,
                "height_low_m": low,
                "height_central_m": central,
                "height_high_m": high,
                "height_method": method,
                "height_confidence": confidence,
                "height_is_direct_osm_observation": direct,
            }
        )
    attributes = pd.DataFrame(records)
    keep = buildings[["building_id", "element", "id", "building", "geometry"]]
    result = keep.merge(attributes, on="building_id", validate="one_to_one", how="left")
    result = gpd.GeoDataFrame(result, geometry="geometry", crs=config.analysis_crs)
    numeric = result[["height_low_m", "height_central_m", "height_high_m"]]
    if numeric.isna().any().any() or (numeric <= 0).any().any():
        raise ValueError("Every building must receive positive complete height bounds")
    counts = result["height_method"].value_counts().sort_index().to_dict()
    diagnostics = {
        "building_count": len(result),
        "height_method_counts": {str(key): int(value) for key, value in counts.items()},
        "calibration_sample_count": len(calibration),
        "floor_height_low_m": floor_low,
        "floor_height_central_m": floor_central,
        "floor_height_high_m": floor_high,
        "known_level_sample_count": len(known_levels),
        "global_level_low": global_level_low,
        "global_level_central": global_level_central,
        "global_level_high": global_level_high,
        "hdb3d_current_osm_id_match_count": int(result["hdb3d_matched"].sum()),
    }
    return result, diagnostics


def summarize_building_heights(
    heights: gpd.GeoDataFrame,
    diagnostics: dict[str, Any],
    config: BuildingHeightConfig,
) -> dict[str, Any]:
    """Summarize completeness while separating observations from estimates."""

    return {
        "model_id": config.model_id,
        "analysis_crs": config.analysis_crs,
        **diagnostics,
        "complete_height_count": int(heights["height_central_m"].notna().sum()),
        "direct_osm_height_count": int(
            heights["height_is_direct_osm_observation"].sum()
        ),
        "estimated_height_count": int(
            (~heights["height_is_direct_osm_observation"]).sum()
        ),
        "minimum_central_height_m": round(float(heights["height_central_m"].min()), 6),
        "median_central_height_m": round(float(heights["height_central_m"].median()), 6),
        "maximum_central_height_m": round(float(heights["height_central_m"].max()), 6),
        "warning": (
            "Only osm_explicit_positive_height is a direct source height. HDB3D "
            "values are upstream storey-based estimates; all remaining values are "
            "local statistical imputations. Sensitivity bounds are scenario inputs, "
            "not confidence intervals or measured uncertainty."
        ),
    }


def create_building_height_map(
    heights: gpd.GeoDataFrame,
    output_path: Path,
) -> None:
    """Create a QA map coloured by height provenance hierarchy."""

    centre = heights.to_crs("EPSG:4326").geometry.union_all().centroid
    map_object = folium.Map(
        location=[centre.y, centre.x], zoom_start=14, tiles="OpenStreetMap", control_scale=True
    )
    display = heights.to_crs("EPSG:4326").copy()
    display["height_central_m"] = display["height_central_m"].round(2)
    colours = {
        "osm_explicit_positive_height": "#1d4ed8",
        "hdb3d_storey_estimate_osm_id_match": "#0891b2",
        "osm_levels_times_local_floor_height": "#65a30d",
        "building_type_level_quantiles_times_local_floor_height": "#f59e0b",
        "global_level_quantiles_times_local_floor_height": "#dc2626",
    }

    def style(feature: dict[str, Any]) -> dict[str, Any]:
        colour = colours[feature["properties"]["height_method"]]
        return {"color": colour, "weight": 1, "fillColor": colour, "fillOpacity": 0.35}

    folium.GeoJson(
        display[
            [
                "building_id",
                "building",
                "height_central_m",
                "height_method",
                "height_confidence",
                "geometry",
            ]
        ].to_json(),
        name="Building height source/method",
        style_function=style,
        tooltip=folium.GeoJsonTooltip(
            fields=[
                "building_id",
                "building",
                "height_central_m",
                "height_method",
                "height_confidence",
            ]
        ),
    ).add_to(map_object)
    note = """
    <div style="position:fixed;left:18px;bottom:28px;z-index:9999;background:white;
    padding:10px;border:1px solid #64748b;font-size:12px;max-width:360px">
    <b>Building-height provenance</b><br>
    Blue: explicit OSM height · Cyan: HDB3D storey estimate<br>
    Green: OSM levels · Orange/red: type/global imputation<br>
    <b>Estimated values are not measured heights.</b><br>
    <small>© OpenStreetMap contributors · NUS UAL · HDB · OneMap</small></div>
    """
    map_object.get_root().html.add_child(folium.Element(note))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    map_object.save(output_path)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def build_building_heights(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Build provenance-labelled complete building-height scenarios."""

    config = load_building_height_config(config_path)
    built_snapshot = project_root / config.built_environment_raw_snapshot
    hdb_path = project_root / config.hdb3d_cityjson_path
    source = load_raw_built_environment_snapshot(built_snapshot)
    hdb_heights = load_hdb3d_height_attributes(hdb_path)
    heights, diagnostics = complete_building_heights(source, hdb_heights, config)
    summary = summarize_building_heights(heights, diagnostics, config)
    summary["input_sha256"] = {
        "current_osm_built_environment": _sha256(
            built_snapshot / "osm_built_environment_features.gpkg"
        ),
        "hdb3d_cityjson": _sha256(hdb_path),
    }
    processed = project_root / "data/processed/features"
    tables = project_root / "outputs/tables"
    maps = project_root / "outputs/maps"
    processed.mkdir(parents=True, exist_ok=True)
    tables.mkdir(parents=True, exist_ok=True)
    output = processed / "building_height_estimates.gpkg"
    if output.exists():
        output.unlink()
    heights.to_file(output, layer="building_heights", driver="GPKG")
    heights.drop(columns="geometry").to_csv(
        processed / "building_height_estimates.csv", index=False
    )
    (processed / "building_height_estimates_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    flat = {key: value for key, value in summary.items() if key != "input_sha256"}
    pd.DataFrame([flat]).to_csv(tables / "building_height_estimates_summary.csv", index=False)
    create_building_height_map(heights, maps / "clementi_building_height_methods.html")
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(description="Complete building heights with provenance.")
    parser.add_argument(
        "--config", type=Path, default=PROJECT_ROOT / "config/building_height.yaml"
    )
    args = parser.parse_args()
    print(json.dumps(build_building_heights(args.config), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
