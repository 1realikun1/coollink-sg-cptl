"""Complete provenance-labelled building heights for multiple expansion regions."""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import geopandas as gpd
import pandas as pd
import yaml
from pyproj import CRS

from coollink_sg.config import BuildingHeightConfig
from coollink_sg.features.building_height import (
    complete_building_heights,
    load_hdb3d_height_attributes,
    summarize_building_heights,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class RepresentativeBuildingHeightConfig:
    """Validated multi-region building-height completion settings."""

    analysis_id: str
    region_ids: tuple[str, ...]
    building_config: BuildingHeightConfig
    raw_snapshot_directory: str
    hdb3d_cityjson: str
    output_directory: str
    summary_path: str


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    try:
        return mapping[key]
    except KeyError as exc:
        raise ValueError(f"Missing required field '{section}.{key}'") from exc


def load_representative_building_height_config(
    path: str | Path,
) -> RepresentativeBuildingHeightConfig:
    """Load a batch building-height configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Representative building-height configuration must be a YAML mapping")
    model = _required(payload, "representative_building_height", "root")
    inputs = _required(payload, "inputs", "root")
    outputs = _required(payload, "outputs", "root")
    analysis_crs = str(_required(model, "analysis_crs", "representative_building_height"))
    if not CRS.from_user_input(analysis_crs).is_projected:
        raise ValueError("representative_building_height.analysis_crs must be projected")
    region_ids = tuple(str(value) for value in _required(model, "region_ids", "root"))
    if not region_ids or len(region_ids) != len(set(region_ids)):
        raise ValueError("region_ids must be a non-empty unique list")
    quantiles = tuple(
        float(value)
        for value in _required(model, "floor_height_quantiles", "representative_building_height")
    )
    if len(quantiles) != 3 or not 0 < quantiles[0] <= quantiles[1] <= quantiles[2] < 1:
        raise ValueError("floor_height_quantiles must be three ordered probabilities")
    building_config = BuildingHeightConfig(
        model_id=str(_required(model, "analysis_id", "representative_building_height")),
        height_field=str(_required(model, "height_field", "representative_building_height")),
        levels_field=str(_required(model, "levels_field", "representative_building_height")),
        floor_height_quantiles=quantiles,
        minimum_type_level_sample=int(
            _required(model, "minimum_type_level_sample", "representative_building_height")
        ),
        analysis_crs=analysis_crs,
        built_environment_raw_snapshot=str(
            _required(inputs, "raw_snapshot_directory", "inputs")
        ),
        hdb3d_cityjson_path=str(_required(inputs, "hdb3d_cityjson", "inputs")),
    )
    return RepresentativeBuildingHeightConfig(
        analysis_id=str(_required(model, "analysis_id", "representative_building_height")),
        region_ids=region_ids,
        building_config=building_config,
        raw_snapshot_directory=building_config.built_environment_raw_snapshot,
        hdb3d_cityjson=building_config.hdb3d_cityjson_path,
        output_directory=str(_required(outputs, "directory", "outputs")),
        summary_path=str(_required(outputs, "summary", "outputs")),
    )


def load_region_built_environment(path: Path) -> gpd.GeoDataFrame:
    """Load all homogeneous-geometry layers from a published regional raw snapshot."""

    layers = gpd.list_layers(path)["name"].tolist()
    if not layers:
        raise ValueError(f"Raw building GeoPackage has no layers: {path}")
    frames = [gpd.read_file(path, layer=layer) for layer in layers]
    return gpd.GeoDataFrame(
        pd.concat(frames, ignore_index=True, sort=False), geometry="geometry", crs=frames[0].crs
    )


def prepare_unique_buildings_for_height_completion(
    source: gpd.GeoDataFrame,
    height_field: str,
    levels_field: str,
) -> tuple[gpd.GeoDataFrame, dict[str, int]]:
    """Keep one exact OSM record per building ID while rejecting conflicting duplicates."""

    required = {"element", "id", "building", height_field, levels_field}
    missing = required - set(source.columns)
    if missing:
        raise ValueError(f"Raw building source is missing: {sorted(missing)}")
    polygons = source.geometry.geom_type.isin(["Polygon", "MultiPolygon"])
    buildings = source.loc[polygons & source["building"].notna()].copy()
    buildings["_source_building_id"] = (
        buildings["element"].astype(str) + "/" + buildings["id"].astype(str)
    )
    duplicate_ids = buildings.loc[
        buildings["_source_building_id"].duplicated(keep=False), "_source_building_id"
    ].unique()
    duplicate_rows = buildings.loc[
        buildings["_source_building_id"].isin(duplicate_ids)
    ]
    for _, group in duplicate_rows.groupby("_source_building_id", sort=False):
        geometry_wkb = {geometry.wkb for geometry in group.geometry}
        attributes = {
            (
                str(row["building"]),
                str(row[height_field]),
                str(row[levels_field]),
            )
            for _, row in group.iterrows()
        }
        if len(geometry_wkb) != 1 or len(attributes) != 1:
            raise ValueError(
                "Conflicting duplicate OSM building records cannot be automatically "
                f"merged: {group['_source_building_id'].iloc[0]}"
            )
    unique = buildings.drop_duplicates("_source_building_id", keep="first").drop(
        columns="_source_building_id"
    )
    return unique, {
        "raw_building_polygon_count": int(len(buildings)),
        "unique_building_polygon_count": int(len(unique)),
        "duplicate_building_id_count": int(len(duplicate_ids)),
        "duplicate_building_rows_removed": int(len(buildings) - len(unique)),
    }


def build_representative_building_heights(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Run evidence-hierarchy building-height completion for every configured region."""

    config = load_representative_building_height_config(config_path)
    raw_root = project_root / config.raw_snapshot_directory
    hdb_heights = load_hdb3d_height_attributes(project_root / config.hdb3d_cityjson)
    output_directory = project_root / config.output_directory
    summary_path = project_root / config.summary_path
    output_directory.mkdir(parents=True, exist_ok=True)
    summaries: list[dict[str, Any]] = []
    for region_id in config.region_ids:
        target = output_directory / f"{region_id}_building_heights.gpkg"
        csv_target = output_directory / f"{region_id}_building_heights.csv"
        json_target = output_directory / f"{region_id}_building_heights_summary.json"
        if target.exists() and csv_target.exists() and json_target.exists():
            existing = json.loads(json_target.read_text(encoding="utf-8"))
            layers = gpd.list_layers(target)["name"].tolist()
            if "building_heights" not in layers:
                raise ValueError(f"Existing building-height GeoPackage is incomplete: {target}")
            count = len(gpd.read_file(target, layer="building_heights"))
            if count != int(existing["complete_height_count"]):
                raise ValueError(f"Existing building-height count mismatch: {target}")
            summaries.append(existing)
            continue
        raw_path = raw_root / region_id / "built_environment_raw.gpkg"
        if not raw_path.exists():
            raise FileNotFoundError(f"Missing raw building features for {region_id}: {raw_path}")
        height_source, deduplication = prepare_unique_buildings_for_height_completion(
            load_region_built_environment(raw_path),
            config.building_config.height_field,
            config.building_config.levels_field,
        )
        heights, diagnostics = complete_building_heights(
            height_source, hdb_heights, config.building_config
        )
        summary = summarize_building_heights(heights, diagnostics, config.building_config)
        summary["region_id"] = region_id
        summary["analysis_id"] = config.analysis_id
        summary["deduplication"] = deduplication
        if target.exists():
            target.unlink()
        heights.to_file(target, layer="building_heights", driver="GPKG")
        heights.drop(columns="geometry").to_csv(csv_target, index=False)
        json_target.write_text(json.dumps(summary, indent=2), encoding="utf-8")
        summaries.append(summary)
    table = pd.DataFrame(summaries).sort_values("region_id")
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    table.to_csv(summary_path, index=False)
    return {
        "analysis_id": config.analysis_id,
        "region_count": len(summaries),
        "summary_path": config.summary_path,
        "regions": summaries,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/representative_building_height.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(build_representative_building_heights(args.config), indent=2))


if __name__ == "__main__":
    main()
