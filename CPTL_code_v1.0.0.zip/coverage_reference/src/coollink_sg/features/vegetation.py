"""Build transparent road-level vegetation proxy features from OpenStreetMap."""

from __future__ import annotations

import argparse
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import osmnx as ox
import pandas as pd

from coollink_sg.config import (
    StudyAreaConfig,
    VegetationConfig,
    load_study_area_config,
    load_vegetation_config,
)
from coollink_sg.data.pedestrian_network import create_study_area

PROJECT_ROOT = Path(__file__).resolve().parents[3]


def combined_query_tags(config: VegetationConfig) -> dict[str, list[str]]:
    """Merge configured green-area and tree tags for one union-style OSM query."""

    merged: dict[str, list[str]] = {}
    for tag_group in (config.green_area_tags, config.tree_tags):
        for key, values in tag_group.items():
            merged.setdefault(key, [])
            for value in values:
                if value not in merged[key]:
                    merged[key].append(value)
    return merged


def fetch_osm_vegetation_features(
    vegetation_config: VegetationConfig,
    study_area_config: StudyAreaConfig,
) -> gpd.GeoDataFrame:
    """Fetch configured OSM vegetation features around the study boundary."""

    _, area = create_study_area(study_area_config)
    query_area = area.copy()
    query_area.geometry = area.geometry.buffer(
        vegetation_config.boundary_query_margin_m
    )
    polygon_wgs84 = query_area.to_crs(vegetation_config.geographic_crs).geometry.iloc[0]
    features = ox.features.features_from_polygon(
        polygon_wgs84,
        combined_query_tags(vegetation_config),
    )
    if features.empty:
        raise ValueError("OpenStreetMap returned no configured vegetation features")
    features = features.reset_index()
    if features.crs is None:
        features = features.set_crs(vegetation_config.geographic_crs)
    return features


def _tag_matches(value: Any, accepted: list[str]) -> bool:
    if isinstance(value, (list, tuple, set)):
        return any(str(item) in accepted for item in value)
    return value is not None and str(value) in accepted


def _tag_mask(
    features: gpd.GeoDataFrame,
    tags: dict[str, list[str]],
) -> pd.Series:
    mask = pd.Series(False, index=features.index)
    for key, values in tags.items():
        if key in features.columns:
            mask |= features[key].map(
                lambda value, accepted=values: _tag_matches(value, accepted)
            )
    return mask


def classify_vegetation_features(
    features: gpd.GeoDataFrame,
    config: VegetationConfig,
) -> tuple[gpd.GeoDataFrame, gpd.GeoDataFrame, gpd.GeoDataFrame]:
    """Separate mapped green areas, individual trees, and tree rows by geometry."""

    if features.crs is None:
        raise ValueError("OSM vegetation features must have an explicit CRS")
    features = features.copy()
    features.geometry = features.geometry.make_valid()
    features = features[features.geometry.notna() & ~features.geometry.is_empty].copy()

    geometry_type = features.geometry.geom_type
    green_mask = _tag_mask(features, config.green_area_tags)
    tree_mask = (
        features.get("natural", pd.Series(index=features.index, dtype=object))
        .map(lambda value: _tag_matches(value, ["tree"]))
        .fillna(False)
    )
    tree_row_mask = (
        features.get("natural", pd.Series(index=features.index, dtype=object))
        .map(lambda value: _tag_matches(value, ["tree_row"]))
        .fillna(False)
    )

    green_areas = features[
        green_mask & geometry_type.isin(["Polygon", "MultiPolygon"])
    ].copy()
    tree_points = features[
        tree_mask & geometry_type.isin(["Point", "MultiPoint"])
    ].copy()
    tree_rows = features[
        tree_row_mask & geometry_type.isin(["LineString", "MultiLineString"])
    ].copy()

    if not green_areas.empty:
        green_areas = green_areas.explode(index_parts=False).reset_index(drop=True)
    if not tree_points.empty:
        tree_points = tree_points.explode(index_parts=False).reset_index(drop=True)
    if not tree_rows.empty:
        tree_rows = tree_rows.explode(index_parts=False).reset_index(drop=True)
    return green_areas, tree_points, tree_rows


def _serialize_value(value: Any) -> Any:
    if isinstance(value, (list, tuple, set, dict)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True)
    return value


def _safe_geopackage_frame(frame: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    safe = frame.copy()
    for column in safe.columns:
        if column != safe.geometry.name and safe[column].dtype == object:
            safe[column] = safe[column].map(_serialize_value)
    return safe


def save_raw_vegetation_snapshot(
    features: gpd.GeoDataFrame,
    retrieved_at_utc: datetime,
    vegetation_config: VegetationConfig,
    study_area_config: StudyAreaConfig,
    raw_root: Path,
) -> Path:
    """Save a timestamped immutable OSMnx-extracted source snapshot."""

    snapshot_id = retrieved_at_utc.strftime("%Y%m%dT%H%M%S%fZ")
    snapshot_directory = raw_root / snapshot_id
    snapshot_directory.mkdir(parents=True, exist_ok=False)
    geopackage = snapshot_directory / "osm_vegetation_features.gpkg"

    geometry_groups = {
        "points": features.geometry.geom_type.isin(["Point", "MultiPoint"]),
        "lines": features.geometry.geom_type.isin(["LineString", "MultiLineString"]),
        "polygons": features.geometry.geom_type.isin(["Polygon", "MultiPolygon"]),
    }
    layer_counts: dict[str, int] = {}
    first_layer = True
    for layer_name, mask in geometry_groups.items():
        layer = features[mask].copy()
        if layer.empty:
            continue
        layer_counts[layer_name] = int(len(layer))
        safe_layer = _safe_geopackage_frame(layer)
        safe_layer.to_file(
            geopackage,
            layer=layer_name,
            driver="GPKG",
            mode="w" if first_layer else "a",
        )
        first_layer = False
    if not layer_counts:
        raise ValueError("No supported OSM vegetation geometries were returned")

    manifest = {
        "snapshot_id": snapshot_id,
        "retrieved_at_utc": retrieved_at_utc.isoformat(),
        "study_area": {
            "name": study_area_config.name,
            "center_latitude": study_area_config.latitude,
            "center_longitude": study_area_config.longitude,
            "radius_m": study_area_config.radius_m,
            "query_margin_m": vegetation_config.boundary_query_margin_m,
        },
        "query_tags": combined_query_tags(vegetation_config),
        "source": vegetation_config.source_metadata,
        "software": {"osmnx": ox.__version__},
        "feature_counts_by_geometry_layer": layer_counts,
        "note": (
            "GeoPackage layers preserve OSMnx-extracted features. Non-scalar tag "
            "values are JSON-serialized for GeoPackage compatibility."
        ),
    }
    with (snapshot_directory / "manifest.json").open("x", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2, ensure_ascii=False)
    return snapshot_directory


def load_raw_vegetation_snapshot(snapshot_directory: Path) -> gpd.GeoDataFrame:
    """Load every geometry layer from an immutable vegetation snapshot."""

    geopackage = snapshot_directory / "osm_vegetation_features.gpkg"
    layer_names = gpd.list_layers(geopackage)["name"].tolist()
    frames = [gpd.read_file(geopackage, layer=layer) for layer in layer_names]
    features = gpd.GeoDataFrame(
        pd.concat(frames, ignore_index=True, sort=False),
        geometry="geometry",
        crs=frames[0].crs,
    )
    return features


def _tree_counts_by_segment(
    tree_points: gpd.GeoDataFrame,
    buffers: gpd.GeoDataFrame,
) -> pd.Series:
    if tree_points.empty:
        return pd.Series(dtype="int64")
    joined = gpd.sjoin(
        tree_points[["geometry"]],
        buffers[["segment_id", "geometry"]],
        how="inner",
        predicate="intersects",
    )
    return joined.groupby("segment_id").size().astype("int64")


def _tree_row_lengths_by_segment(
    tree_rows: gpd.GeoDataFrame,
    buffers: gpd.GeoDataFrame,
) -> pd.Series:
    if tree_rows.empty:
        return pd.Series(dtype="float64")
    joined = gpd.sjoin(
        tree_rows[["geometry"]],
        buffers[["segment_id", "geometry"]],
        how="inner",
        predicate="intersects",
    )
    joined["clipped_length_m"] = [
        geometry.intersection(buffers.geometry.loc[buffer_index]).length
        for geometry, buffer_index in zip(
            joined.geometry,
            joined["index_right"],
            strict=True,
        )
    ]
    return joined.groupby("segment_id")["clipped_length_m"].sum()


def compute_road_vegetation_features(
    edges: gpd.GeoDataFrame,
    source_features: gpd.GeoDataFrame,
    config: VegetationConfig,
) -> tuple[gpd.GeoDataFrame, dict[str, int]]:
    """Calculate road-buffer green-area, tree-count, and tree-row proxies."""

    required_edge_fields = {"segment_id", "length_m", "geometry"}
    missing = required_edge_fields.difference(edges.columns)
    if missing:
        raise ValueError(f"Pedestrian edges are missing fields: {sorted(missing)}")
    if edges["segment_id"].duplicated().any():
        raise ValueError("Pedestrian segment_id values must be unique")
    if edges.crs is None or source_features.crs is None:
        raise ValueError("Edges and source vegetation features must have explicit CRS")

    edges_projected = edges.to_crs(config.analysis_crs).copy()
    source_projected = source_features.to_crs(config.analysis_crs).copy()
    green_areas, tree_points, tree_rows = classify_vegetation_features(
        source_projected,
        config,
    )

    buffers = edges_projected[["segment_id", "geometry"]].copy()
    buffers.geometry = edges_projected.geometry.buffer(config.road_context_buffer_m)
    buffers["buffer_area_m2"] = buffers.geometry.area

    if green_areas.empty:
        green_area_m2 = pd.Series(0.0, index=buffers.index)
    else:
        green_union = green_areas.geometry.union_all()
        green_area_m2 = buffers.geometry.intersection(green_union).area

    tree_counts = _tree_counts_by_segment(tree_points, buffers)
    tree_row_lengths = _tree_row_lengths_by_segment(tree_rows, buffers)

    result = edges_projected[["segment_id", "length_m", "geometry"]].copy()
    result["context_buffer_m"] = config.road_context_buffer_m
    result["context_buffer_area_m2"] = buffers["buffer_area_m2"].to_numpy()
    result["mapped_green_area_m2"] = green_area_m2.to_numpy()
    result[config.output_metric_name] = (
        result["mapped_green_area_m2"] / result["context_buffer_area_m2"]
    ).clip(0, 1)
    result["mapped_tree_count"] = (
        result["segment_id"].map(tree_counts).fillna(0).astype("int64")
    )
    result["mapped_tree_density_per_ha"] = result["mapped_tree_count"] / (
        result["context_buffer_area_m2"] / 10_000
    )
    result["mapped_tree_row_length_m"] = (
        result["segment_id"].map(tree_row_lengths).fillna(0.0)
    )

    metric_columns = [
        "context_buffer_area_m2",
        "mapped_green_area_m2",
        config.output_metric_name,
        "mapped_tree_count",
        "mapped_tree_density_per_ha",
        "mapped_tree_row_length_m",
    ]
    if result[metric_columns].isna().any().any():
        raise ValueError("Vegetation proxy output contains missing metric values")
    if not result[config.output_metric_name].between(0, 1).all():
        raise ValueError("green_area_proxy_ratio must be between 0 and 1")
    if (result["mapped_tree_count"] < 0).any():
        raise ValueError("mapped_tree_count cannot be negative")

    source_counts = {
        "mapped_green_polygon_count": int(len(green_areas)),
        "mapped_tree_point_count": int(len(tree_points)),
        "mapped_tree_row_count": int(len(tree_rows)),
    }
    return result, source_counts


def summarize_vegetation_features(
    features: gpd.GeoDataFrame,
    source_counts: dict[str, int],
    config: VegetationConfig,
    snapshot_id: str,
) -> dict[str, Any]:
    """Create an auditable vegetation-proxy quality summary."""

    ratio = features[config.output_metric_name]
    return {
        "snapshot_id": snapshot_id,
        "road_context_buffer_m": config.road_context_buffer_m,
        "segment_count": int(len(features)),
        **source_counts,
        "mean_green_area_proxy_ratio": round(float(ratio.mean()), 6),
        "median_green_area_proxy_ratio": round(float(ratio.median()), 6),
        "segments_with_zero_green_area_proxy": int((ratio == 0).sum()),
        "segments_with_mapped_trees": int((features["mapped_tree_count"] > 0).sum()),
        "segments_with_mapped_tree_rows": int(
            (features["mapped_tree_row_length_m"] > 0).sum()
        ),
        "minimum_green_area_proxy_ratio": round(float(ratio.min()), 6),
        "maximum_green_area_proxy_ratio": round(float(ratio.max()), 6),
        "warning": (
            "green_area_proxy_ratio represents mapped OSM green-area polygons "
            "within road buffers. It is not measured canopy cover or shade."
        ),
    }


def _ratio_colour(value: float) -> str:
    value = max(0.0, min(1.0, float(value)))
    red = round(210 - 170 * value)
    green = round(70 + 100 * value)
    blue = round(70 - 25 * value)
    return f"#{red:02x}{green:02x}{blue:02x}"


def create_vegetation_proxy_map(
    road_features: gpd.GeoDataFrame,
    source_features: gpd.GeoDataFrame,
    vegetation_config: VegetationConfig,
    study_area_config: StudyAreaConfig,
    output_path: Path,
) -> None:
    """Create an interactive QA map of road-level vegetation proxies."""

    green_areas, _, _ = classify_vegetation_features(
        source_features.to_crs(vegetation_config.analysis_crs),
        vegetation_config,
    )
    map_object = folium.Map(
        location=[study_area_config.latitude, study_area_config.longitude],
        zoom_start=14,
        tiles="OpenStreetMap",
        control_scale=True,
    )
    folium.Circle(
        [study_area_config.latitude, study_area_config.longitude],
        radius=study_area_config.radius_m,
        color="#2563eb",
        weight=2,
        fill=False,
        tooltip="Clementi MRT 2 km study area",
    ).add_to(map_object)

    if not green_areas.empty:
        folium.GeoJson(
            green_areas.to_crs(vegetation_config.geographic_crs)[["geometry"]].to_json(),
            name="Mapped OSM green areas",
            style_function=lambda _feature: {
                "color": "#15803d",
                "weight": 1,
                "fillColor": "#86efac",
                "fillOpacity": 0.22,
            },
        ).add_to(map_object)

    display = road_features.to_crs(vegetation_config.geographic_crs)[
        [
            "segment_id",
            vegetation_config.output_metric_name,
            "mapped_tree_count",
            "mapped_tree_row_length_m",
            "geometry",
        ]
    ].copy()
    display[vegetation_config.output_metric_name] = display[
        vegetation_config.output_metric_name
    ].round(3)
    display["mapped_tree_row_length_m"] = display["mapped_tree_row_length_m"].round(1)
    folium.GeoJson(
        display.to_json(),
        name="Road vegetation proxy",
        style_function=lambda feature: {
            "color": _ratio_colour(
                feature["properties"][vegetation_config.output_metric_name]
            ),
            "weight": 3,
            "opacity": 0.85,
        },
        tooltip=folium.GeoJsonTooltip(
            fields=[
                "segment_id",
                vegetation_config.output_metric_name,
                "mapped_tree_count",
                "mapped_tree_row_length_m",
            ],
            aliases=[
                "Segment",
                "Mapped green-area proxy",
                "Mapped tree count",
                "Mapped tree-row length (m)",
            ],
            sticky=False,
        ),
    ).add_to(map_object)
    legend = """
    <div style="position: fixed; bottom: 30px; left: 30px; z-index: 9999;
      background: white; padding: 10px; border: 1px solid #777; font-size: 12px;">
      <b>Mapped green-area proxy</b><br>
      <span style="color:#d24646">●</span> 0.0
      &nbsp;→&nbsp;
      <span style="color:#28aa2d">●</span> 1.0<br>
      <small>OSM proxy, not canopy or shade</small>
    </div>
    """
    map_object.get_root().html.add_child(folium.Element(legend))
    folium.LayerControl(collapsed=False).add_to(map_object)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    map_object.save(output_path)


def save_processed_vegetation(
    road_features: gpd.GeoDataFrame,
    source_features: gpd.GeoDataFrame,
    summary: dict[str, Any],
    vegetation_config: VegetationConfig,
    study_area_config: StudyAreaConfig,
    project_root: Path,
) -> None:
    """Save road vegetation features, summary tables, and QA map."""

    processed_directory = project_root / "data/processed/features"
    table_directory = project_root / "outputs/tables"
    map_directory = project_root / "outputs/maps"
    processed_directory.mkdir(parents=True, exist_ok=True)
    table_directory.mkdir(parents=True, exist_ok=True)

    output_geopackage = processed_directory / "road_vegetation_features.gpkg"
    if output_geopackage.exists():
        output_geopackage.unlink()
    road_features.to_file(output_geopackage, layer="road_vegetation", driver="GPKG")
    road_features.drop(columns="geometry").to_csv(
        processed_directory / "road_vegetation_features.csv",
        index=False,
    )
    (processed_directory / "vegetation_proxy_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    pd.DataFrame([summary]).to_csv(
        table_directory / "vegetation_proxy_summary.csv",
        index=False,
    )
    create_vegetation_proxy_map(
        road_features,
        source_features,
        vegetation_config,
        study_area_config,
        map_directory / "clementi_vegetation_proxy.html",
    )


def build_vegetation_features(
    vegetation_config_path: Path,
    study_area_config_path: Path,
    project_root: Path = PROJECT_ROOT,
    raw_snapshot: Path | None = None,
) -> dict[str, Any]:
    """Fetch or reload OSM vegetation and create road-level proxy features."""

    vegetation_config = load_vegetation_config(vegetation_config_path)
    study_area_config = load_study_area_config(study_area_config_path)
    if raw_snapshot is None:
        retrieved_at_utc = datetime.now(UTC)
        source_features = fetch_osm_vegetation_features(
            vegetation_config,
            study_area_config,
        )
        snapshot_directory = save_raw_vegetation_snapshot(
            source_features,
            retrieved_at_utc,
            vegetation_config,
            study_area_config,
            project_root / "data/raw/vegetation",
        )
    else:
        snapshot_directory = raw_snapshot.resolve()
        source_features = load_raw_vegetation_snapshot(snapshot_directory)

    edges = gpd.read_file(
        project_root / "data/processed/network/clementi_pedestrian_network.gpkg",
        layer="edges",
    )
    road_features, source_counts = compute_road_vegetation_features(
        edges,
        source_features,
        vegetation_config,
    )
    summary = summarize_vegetation_features(
        road_features,
        source_counts,
        vegetation_config,
        snapshot_directory.name,
    )
    summary["raw_snapshot_directory"] = str(snapshot_directory)
    summary["raw_snapshot_reused"] = raw_snapshot is not None
    save_processed_vegetation(
        road_features,
        source_features,
        summary,
        vegetation_config,
        study_area_config,
        project_root,
    )
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(
        description="Build OSM-based road vegetation proxy features for Clementi."
    )
    parser.add_argument(
        "--vegetation-config",
        type=Path,
        default=PROJECT_ROOT / "config/vegetation.yaml",
    )
    parser.add_argument(
        "--study-area-config",
        type=Path,
        default=PROJECT_ROOT / "config/study_area.yaml",
    )
    parser.add_argument(
        "--raw-snapshot",
        type=Path,
        default=None,
        help="Reuse an immutable raw vegetation snapshot instead of querying Overpass.",
    )
    args = parser.parse_args()
    summary = build_vegetation_features(
        args.vegetation_config,
        args.study_area_config,
        raw_snapshot=args.raw_snapshot,
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
