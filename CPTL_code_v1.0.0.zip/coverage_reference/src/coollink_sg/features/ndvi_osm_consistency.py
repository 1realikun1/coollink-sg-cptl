"""Compare Sentinel-2 NDVI context with mapped OSM green-area context."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import numpy as np
import pandas as pd
from pyproj import CRS

from coollink_sg.config import (
    NDVIOSMConsistencyConfig,
    load_ndvi_osm_consistency_config,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]


def _correlation(frame: pd.DataFrame, first: str, second: str) -> tuple[float, float]:
    """Return Pearson and average-rank Spearman correlations."""

    if len(frame) < 2 or frame[first].nunique() < 2 or frame[second].nunique() < 2:
        return float("nan"), float("nan")
    pearson = float(frame[[first, second]].corr(method="pearson").iloc[0, 1])
    ranks = frame[[first, second]].rank(method="average")
    spearman = float(ranks.corr(method="pearson").iloc[0, 1])
    return pearson, spearman


def compute_ndvi_osm_consistency(
    features: gpd.GeoDataFrame,
    config: NDVIOSMConsistencyConfig,
) -> gpd.GeoDataFrame:
    """Calculate pairwise-complete rank diagnostics without imputing cloud gaps."""

    fields = [
        config.ndvi_field,
        config.ndvi_valid_fraction_field,
        config.osm_green_proxy_field,
    ]
    required = {"segment_id", "geometry", *fields}
    missing = required.difference(features.columns)
    if missing:
        raise ValueError(f"Unified road table is missing fields: {sorted(missing)}")
    if features.crs is None:
        raise ValueError("Unified road table must have an explicit CRS")
    if CRS.from_user_input(features.crs) != CRS.from_user_input(config.output_crs):
        raise ValueError(f"Unified road table CRS must equal {config.output_crs}")
    if features["segment_id"].isna().any() or not features["segment_id"].is_unique:
        raise ValueError("segment_id values must be complete and unique")

    values = features[fields].apply(pd.to_numeric, errors="raise")
    if values[config.osm_green_proxy_field].isna().any():
        raise ValueError("OSM green-area proxy cannot be missing")
    if not values[config.osm_green_proxy_field].between(0, 1).all():
        raise ValueError("OSM green-area proxy must be within 0–1")
    if not values[config.ndvi_valid_fraction_field].between(0, 1).all():
        raise ValueError("NDVI valid fraction must be within 0–1")
    ndvi = values[config.ndvi_field]
    if not ndvi.dropna().between(-1, 1).all():
        raise ValueError("Finite NDVI values must be within -1 to 1")
    if not ndvi.isna().equals(values[config.ndvi_valid_fraction_field].eq(0)):
        raise ValueError("NDVI must be missing exactly when valid fraction is zero")

    result = features[["segment_id", *fields, "geometry"]].copy()
    complete = ndvi.notna()
    result["analysis_pair_complete"] = complete
    result["osm_green_rank_percentile"] = np.nan
    result["sentinel2_ndvi_rank_percentile"] = np.nan
    result.loc[complete, "osm_green_rank_percentile"] = values.loc[
        complete, config.osm_green_proxy_field
    ].rank(method="average", pct=True)
    result.loc[complete, "sentinel2_ndvi_rank_percentile"] = values.loc[
        complete, config.ndvi_field
    ].rank(method="average", pct=True)
    result["ndvi_minus_osm_rank_percentile"] = (
        result["sentinel2_ndvi_rank_percentile"]
        - result["osm_green_rank_percentile"]
    )
    result["absolute_rank_disagreement"] = result[
        "ndvi_minus_osm_rank_percentile"
    ].abs()
    result["analysis_id"] = config.analysis_id
    return gpd.GeoDataFrame(result, geometry="geometry", crs=features.crs)


def summarize_ndvi_osm_consistency(
    result: gpd.GeoDataFrame,
    config: NDVIOSMConsistencyConfig,
) -> dict[str, Any]:
    """Summarize association and coverage without claiming validation."""

    complete = result.loc[result["analysis_pair_complete"]].copy()
    full_coverage = complete.loc[
        np.isclose(complete[config.ndvi_valid_fraction_field], 1.0)
    ]
    pearson, spearman = _correlation(
        complete, config.ndvi_field, config.osm_green_proxy_field
    )
    full_pearson, full_spearman = _correlation(
        full_coverage, config.ndvi_field, config.osm_green_proxy_field
    )
    osm_zero = complete[config.osm_green_proxy_field].eq(0)
    return {
        "analysis_id": config.analysis_id,
        "segment_count": len(result),
        "pairwise_complete_segment_count": len(complete),
        "missing_ndvi_segment_count": int((~result["analysis_pair_complete"]).sum()),
        "pairwise_complete_fraction": round(float(len(complete) / len(result)), 6),
        "pearson_correlation": round(pearson, 6),
        "spearman_rank_correlation": round(spearman, 6),
        "full_valid_fraction_segment_count": len(full_coverage),
        "full_valid_fraction_pearson_correlation": round(full_pearson, 6),
        "full_valid_fraction_spearman_correlation": round(full_spearman, 6),
        "osm_green_zero_among_complete_count": int(osm_zero.sum()),
        "osm_green_zero_among_complete_fraction": round(float(osm_zero.mean()), 6),
        "median_ndvi_where_osm_green_zero": round(
            float(complete.loc[osm_zero, config.ndvi_field].median()), 6
        ),
        "median_ndvi_where_osm_green_positive": round(
            float(complete.loc[~osm_zero, config.ndvi_field].median()), 6
        ),
        "mean_absolute_rank_disagreement": round(
            float(complete["absolute_rank_disagreement"].mean()), 6
        ),
        "median_absolute_rank_disagreement": round(
            float(complete["absolute_rank_disagreement"].median()), 6
        ),
        "missing_value_policy": config.missing_value_policy,
        "directed_edge_weighting": True,
        "heat_score_generated": False,
        "warning": (
            "Association between two road-context proxies is not validation of "
            "canopy, shade, cooling, thermal comfort, or Heat Score. Directed "
            "reciprocal edges may represent the same physical walkway."
        ),
    }


def _disagreement_colour(value: Any) -> str:
    if value is None or pd.isna(value):
        return "#9ca3af"
    bounded = max(0.0, min(1.0, float(value)))
    red = round(50 + 200 * bounded)
    green = round(125 - 80 * bounded)
    blue = round(210 - 140 * bounded)
    return f"#{red:02x}{green:02x}{blue:02x}"


def create_ndvi_osm_consistency_map(
    result: gpd.GeoDataFrame,
    summary: dict[str, Any],
    output_path: Path,
) -> None:
    """Map absolute rank disagreement and missing satellite coverage."""

    display = result.to_crs("EPSG:4326").copy()
    numeric = [
        config_field
        for config_field in (
            "sentinel2_ndvi_mean",
            "sentinel2_ndvi_valid_pixel_fraction",
            "green_area_proxy_ratio",
            "ndvi_minus_osm_rank_percentile",
            "absolute_rank_disagreement",
        )
        if config_field in display.columns
    ]
    display[numeric] = display[numeric].round(3)
    center = display.geometry.union_all().centroid
    map_object = folium.Map(
        location=[center.y, center.x], zoom_start=14, tiles="OpenStreetMap", control_scale=True
    )
    folium.GeoJson(
        display[["segment_id", *numeric, "geometry"]].to_json(),
        name="NDVI versus OSM green-context rank disagreement",
        style_function=lambda feature: {
            "color": _disagreement_colour(
                feature["properties"]["absolute_rank_disagreement"]
            ),
            "weight": 3,
            "opacity": 0.8,
        },
        tooltip=folium.GeoJsonTooltip(
            fields=["segment_id", *numeric],
            aliases=[
                "Segment",
                "Mean masked NDVI",
                "Valid NDVI fraction",
                "Mapped OSM green ratio",
                "NDVI rank minus OSM rank",
                "Absolute rank disagreement",
            ],
        ),
    ).add_to(map_object)
    complete_count = summary["pairwise_complete_segment_count"]
    segment_count = summary["segment_count"]
    legend = f"""
    <div style="position:fixed;bottom:30px;left:30px;z-index:9999;background:white;
      padding:10px;border:1px solid #777;font-size:12px;max-width:390px">
      <b>NDVI–OSM rank disagreement</b><br>
      Blue: lower &nbsp; Red: higher &nbsp; Grey: missing NDVI<br>
      Pairwise complete: {complete_count:,} / {segment_count:,}<br>
      Spearman: {summary["spearman_rank_correlation"]:.3f}<br>
      <small>Context-proxy comparison only; not canopy, shade, cooling, or Heat Score.</small>
    </div>
    """
    map_object.get_root().html.add_child(folium.Element(legend))
    folium.LayerControl().add_to(map_object)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    map_object.save(output_path)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def build_ndvi_osm_consistency(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Run and export configured NDVI/OSM consistency diagnostics."""

    config = load_ndvi_osm_consistency_config(config_path)
    input_path = project_root / config.input_path
    features = gpd.read_file(input_path, layer=config.input_layer)
    result = compute_ndvi_osm_consistency(features, config)
    summary = summarize_ndvi_osm_consistency(result, config)
    summary["input_path"] = str(input_path)
    summary["input_sha256"] = _sha256(input_path)

    processed = project_root / "data/processed/features"
    tables = project_root / "outputs/tables"
    maps = project_root / "outputs/maps"
    geopackage = processed / "ndvi_osm_green_consistency.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    result.to_file(geopackage, layer="ndvi_osm_consistency", driver="GPKG")
    result.drop(columns="geometry").to_csv(
        processed / "ndvi_osm_green_consistency.csv", index=False
    )
    (processed / "ndvi_osm_green_consistency_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    pd.DataFrame([summary]).to_csv(
        tables / "ndvi_osm_green_consistency_summary.csv", index=False
    )
    create_ndvi_osm_consistency_map(
        result, summary, maps / "clementi_ndvi_osm_green_consistency.html"
    )
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(
        description="Compare Sentinel-2 NDVI with mapped OSM green context."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/ndvi_osm_consistency.yaml",
    )
    args = parser.parse_args()
    print(
        json.dumps(
            build_ndvi_osm_consistency(args.config), indent=2, ensure_ascii=False
        )
    )


if __name__ == "__main__":
    main()
