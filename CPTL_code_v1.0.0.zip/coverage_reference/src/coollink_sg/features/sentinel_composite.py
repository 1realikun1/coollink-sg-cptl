"""Build a fixed-rule multi-date Sentinel-2 L2A NDVI median composite."""

from __future__ import annotations

import argparse
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
from pyproj import CRS
from rasterio.features import geometry_mask
from rasterio.transform import Affine
from rasterio.warp import Resampling, reproject, transform_geom
from shapely.geometry import mapping, shape

from coollink_sg.config import (
    SentinelCompositeConfig,
    load_sentinel_composite_config,
)
from coollink_sg.features.sentinel_ndvi import (
    _native_asset_window,
    _sha256_file,
    calculate_masked_ndvi,
    road_ndvi_statistics,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]


def select_composite_items(
    response_bytes: bytes,
    study_area_wgs84: gpd.GeoDataFrame,
    config: SentinelCompositeConfig,
) -> list[dict[str, Any]]:
    """Select fixed-count lowest-cloud, full-coverage, unique-date items."""

    payload = json.loads(response_bytes)
    area_geometry = study_area_wgs84.geometry.union_all()
    required_assets = {config.asset_red, config.asset_nir, config.asset_scl}
    eligible = [
        item
        for item in payload.get("features", [])
        if required_assets.issubset(item.get("assets", {}))
        and shape(item["geometry"]).covers(area_geometry)
    ]
    eligible.sort(
        key=lambda item: (
            float(item["properties"].get("eo:cloud_cover", 1000)),
            str(item["properties"].get("datetime", "")),
            str(item.get("id", "")),
        )
    )
    selected = []
    dates: set[str] = set()
    for item in eligible:
        date = str(item["properties"]["datetime"])[:10]
        if date in dates:
            continue
        selected.append(item)
        dates.add(date)
        if len(selected) == config.scene_count:
            break
    if len(selected) != config.scene_count:
        raise ValueError(
            f"Only {len(selected)} eligible unique-date scenes; "
            f"{config.scene_count} required"
        )
    return selected


def _fetch_selected_windows(
    items: list[dict[str, Any]],
    study_area_wgs84: gpd.GeoDataFrame,
    config: SentinelCompositeConfig,
) -> dict[str, dict[str, tuple[np.ndarray, dict[str, Any]]]]:
    """Fetch every selected source window before creating a raw directory."""

    result = {}
    for item in items:
        result[item["id"]] = {
            name: _native_asset_window(item["assets"][asset], study_area_wgs84)
            for name, asset in (
                ("red", config.asset_red),
                ("nir", config.asset_nir),
                ("scl", config.asset_scl),
            )
        }
    return result


def save_raw_composite_snapshot(
    response_bytes: bytes,
    source_stac_path: Path,
    selected_items: list[dict[str, Any]],
    windows: dict[str, dict[str, tuple[np.ndarray, dict[str, Any]]]],
    retrieved_at_utc: datetime,
    config: SentinelCompositeConfig,
    raw_root: Path,
) -> Path:
    """Save immutable native windows and a complete selection manifest."""

    snapshot_id = retrieved_at_utc.strftime("%Y%m%dT%H%M%S%fZ")
    directory = raw_root / snapshot_id
    directory.mkdir(parents=True, exist_ok=False)
    (directory / "selected_items.json").write_text(
        json.dumps(selected_items, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    scene_records = []
    for index, item in enumerate(selected_items, start=1):
        scene_name = f"{index:02d}_{item['id']}"
        scene_directory = directory / scene_name
        scene_directory.mkdir()
        band_records = {}
        for name, (data, profile) in windows[item["id"]].items():
            path = scene_directory / f"{name}_native_window.tif"
            with rasterio.open(path, "w", **profile) as output:
                output.write(data, 1)
            band_records[name] = {
                "path": str(path.relative_to(directory)),
                "shape": list(data.shape),
                "dtype": str(data.dtype),
                "crs": str(profile["crs"]),
                "transform": list(profile["transform"]),
                "sha256": _sha256_file(path),
            }
        scene_records.append(
            {
                "scene_directory": scene_name,
                "item_id": item["id"],
                "datetime": item["properties"]["datetime"],
                "scene_cloud_cover_percent": item["properties"].get(
                    "eo:cloud_cover"
                ),
                "bands": band_records,
            }
        )
    manifest = {
        "snapshot_id": snapshot_id,
        "retrieved_at_utc": retrieved_at_utc.isoformat(),
        "source_stac_snapshot": str(source_stac_path),
        "source_stac_sha256": _sha256_file(source_stac_path),
        "selection_rule": config.selection_rule,
        "scene_count": config.scene_count,
        "composite_statistic": config.composite_statistic,
        "valid_scl_classes": list(config.valid_scl_classes),
        "selection_note": (
            "Scenes were selected by catalog scene-cloud percentage before NDVI "
            "processing; local NDVI values did not influence selection."
        ),
        "window_note": (
            "GeoTIFFs contain native source pixels in rectangular study-area "
            "windows, not complete Sentinel-2 granules."
        ),
        "scenes": scene_records,
        "source": config.source_metadata,
    }
    with (directory / "manifest.json").open("x", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2, ensure_ascii=False)
    return directory


def acquire_composite_snapshot(
    config: SentinelCompositeConfig,
    study_area_wgs84: gpd.GeoDataFrame,
    project_root: Path,
) -> Path:
    """Select scenes from the preserved catalog response and acquire windows."""

    source_path = project_root / config.source_stac_snapshot
    response_bytes = source_path.read_bytes()
    selected = select_composite_items(response_bytes, study_area_wgs84, config)
    windows = _fetch_selected_windows(selected, study_area_wgs84, config)
    return save_raw_composite_snapshot(
        response_bytes,
        source_path,
        selected,
        windows,
        datetime.now(UTC),
        config,
        project_root / "data/raw/sentinel2_composite",
    )


def _calibration(item: dict[str, Any], asset_key: str) -> tuple[float, float]:
    band = item["assets"][asset_key]["raster:bands"][0]
    return float(band.get("scale", 1)), float(band.get("offset", 0))


def median_ndvi_composite(ndvi_scenes: list[np.ndarray]) -> tuple[np.ndarray, np.ndarray]:
    """Return a pixelwise missing-aware median and contributing-scene count."""

    if len(ndvi_scenes) < 2:
        raise ValueError("A multi-date composite requires at least two scenes")
    shapes = {scene.shape for scene in ndvi_scenes}
    if len(shapes) != 1:
        raise ValueError("All NDVI scenes must share a shape")
    stack = np.stack(ndvi_scenes)
    observation_count = np.isfinite(stack).sum(axis=0).astype("uint8")
    composite = np.ma.median(np.ma.masked_invalid(stack), axis=0).filled(np.nan)
    return np.asarray(composite, dtype="float32"), observation_count


def process_composite_snapshot(
    snapshot: Path,
    config: SentinelCompositeConfig,
) -> tuple[np.ndarray, np.ndarray, Affine, CRS, dict[str, Any], np.ndarray]:
    """Calculate per-scene masked NDVI and a pixelwise median composite."""

    items = json.loads((snapshot / "selected_items.json").read_text(encoding="utf-8"))
    manifest = json.loads((snapshot / "manifest.json").read_text(encoding="utf-8"))
    if len(items) != config.scene_count or len(manifest["scenes"]) != config.scene_count:
        raise ValueError("Raw composite snapshot scene count differs from configuration")
    ndvi_scenes = []
    reference_transform = None
    reference_crs = None
    reference_shape = None
    item_by_id = {item["id"]: item for item in items}
    for scene in manifest["scenes"]:
        item = item_by_id[scene["item_id"]]
        scene_directory = snapshot / scene["scene_directory"]
        with rasterio.open(scene_directory / "red_native_window.tif") as source:
            red = source.read(1)
            transform = source.transform
            crs = source.crs
        with rasterio.open(scene_directory / "nir_native_window.tif") as source:
            nir = source.read(1)
            if source.transform != transform or source.crs != crs or source.shape != red.shape:
                raise ValueError("A scene's native red and NIR windows must align")
        if reference_transform is None:
            reference_transform = transform
            reference_crs = crs
            reference_shape = red.shape
        elif (
            transform != reference_transform
            or crs != reference_crs
            or red.shape != reference_shape
        ):
            raise ValueError("All selected scenes must share the same 10 m grid")
        with rasterio.open(scene_directory / "scl_native_window.tif") as source:
            scl = source.read(1)
            scl_aligned = np.zeros(red.shape, dtype="uint8")
            reproject(
                source=scl,
                destination=scl_aligned,
                src_transform=source.transform,
                src_crs=source.crs,
                src_nodata=source.nodata,
                dst_transform=transform,
                dst_crs=crs,
                dst_nodata=0,
                resampling=Resampling.nearest,
            )
        red_scale, red_offset = _calibration(item, config.asset_red)
        nir_scale, nir_offset = _calibration(item, config.asset_nir)
        ndvi, _ = calculate_masked_ndvi(
            red,
            nir,
            scl_aligned,
            red_scale,
            red_offset,
            nir_scale,
            nir_offset,
            config.valid_scl_classes,
        )
        ndvi_scenes.append(ndvi)
    composite, observation_count = median_ndvi_composite(ndvi_scenes)
    stack = np.stack(ndvi_scenes)
    metadata = {
        "selected_items": [
            {
                "item_id": item["id"],
                "datetime": item["properties"]["datetime"],
                "scene_cloud_cover_percent": item["properties"].get("eo:cloud_cover"),
            }
            for item in items
        ],
        "valid_scl_classes": list(config.valid_scl_classes),
        "composite_statistic": config.composite_statistic,
    }
    if reference_transform is None or reference_crs is None:
        raise ValueError("Composite snapshot contains no scenes")
    return (
        composite,
        observation_count,
        reference_transform,
        reference_crs,
        metadata,
        np.isfinite(stack),
    )


def create_composite_map(
    roads: gpd.GeoDataFrame,
    summary: dict[str, Any],
    output_path: Path,
) -> None:
    """Create an interactive composite NDVI and temporal-support QA map."""

    display = roads.to_crs("EPSG:4326").copy()
    numeric = [
        "sentinel2_ndvi_mean",
        "sentinel2_ndvi_valid_pixel_fraction",
        "sentinel2_ndvi_observation_count_mean",
    ]
    display[numeric] = display[numeric].round(3)
    center = display.geometry.union_all().centroid
    map_object = folium.Map(
        location=[center.y, center.x], zoom_start=14, tiles="OpenStreetMap", control_scale=True
    )

    def colour(value: Any) -> str:
        if value is None or pd.isna(value):
            return "#9ca3af"
        bounded = max(0.0, min(1.0, (float(value) + 0.2)))
        return f"#{round(190 - 150 * bounded):02x}{round(80 + 100 * bounded):02x}35"

    folium.GeoJson(
        display[["segment_id", *numeric, "geometry"]].to_json(),
        name="Multi-date median NDVI",
        style_function=lambda feature: {
            "color": colour(feature["properties"]["sentinel2_ndvi_mean"]),
            "weight": 3,
            "opacity": 0.8,
        },
        tooltip=folium.GeoJsonTooltip(
            fields=["segment_id", *numeric],
            aliases=[
                "Segment",
                "Composite mean NDVI",
                "Valid composite pixel fraction",
                "Mean contributing scenes",
            ],
        ),
    ).add_to(map_object)
    legend = f"""
    <div style="position:fixed;bottom:30px;left:30px;z-index:9999;background:white;
      padding:10px;border:1px solid #777;font-size:12px;max-width:390px">
      <b>Sentinel-2 multi-date median NDVI</b><br>
      Selected scenes: {summary["scene_count"]}<br>
      Study-area valid coverage: {summary["study_area_valid_pixel_fraction"]:.1%}<br>
      Brown: lower NDVI &nbsp; Green: higher NDVI &nbsp; Grey: no valid pixels<br>
      <small>Not canopy cover, shade, cooling, or a thermal measurement.</small>
    </div>
    """
    map_object.get_root().html.add_child(folium.Element(legend))
    folium.LayerControl().add_to(map_object)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    map_object.save(output_path)


def _write_raster(
    path: Path,
    data: np.ndarray,
    transform: Affine,
    crs: CRS,
    dtype: str,
    nodata: int | float,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with rasterio.open(
        path,
        "w",
        driver="GTiff",
        height=data.shape[0],
        width=data.shape[1],
        count=1,
        dtype=dtype,
        crs=crs,
        transform=transform,
        nodata=nodata,
        compress="deflate",
    ) as output:
        output.write(data.astype(dtype), 1)


def build_sentinel_composite(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
    raw_snapshot: Path | None = None,
) -> dict[str, Any]:
    """Acquire or reload selected scenes and build road-level median NDVI."""

    config = load_sentinel_composite_config(config_path)
    study_area = gpd.read_file(
        project_root / "data/processed/network/clementi_study_area.gpkg",
        layer="study_area",
    ).to_crs(config.geographic_crs)
    snapshot = (
        acquire_composite_snapshot(config, study_area, project_root)
        if raw_snapshot is None
        else raw_snapshot.resolve()
    )
    composite, observation_count, transform, raster_crs, metadata, valid_stack = (
        process_composite_snapshot(snapshot, config)
    )
    study_geometry = transform_geom(
        study_area.crs, raster_crs, mapping(study_area.geometry.union_all())
    )
    area_mask = geometry_mask(
        [study_geometry], out_shape=composite.shape, transform=transform, invert=True
    )
    composite[~area_mask] = np.nan
    observation_count[~area_mask] = 0
    valid_in_area = np.isfinite(composite) & area_mask
    per_scene_valid = [
        round(float((scene_valid & area_mask).sum() / area_mask.sum()), 6)
        for scene_valid in valid_stack
    ]
    edges = gpd.read_file(
        project_root / "data/processed/network/clementi_pedestrian_network.gpkg",
        layer="edges",
    )
    road_features = road_ndvi_statistics(
        edges,
        composite,
        transform,
        raster_crs,
        config.road_context_buffer_m,
        observation_count=observation_count,
    )
    counts_in_area = observation_count[valid_in_area]
    summary = {
        "snapshot_id": snapshot.name,
        "raw_snapshot_reused": raw_snapshot is not None,
        "scene_count": config.scene_count,
        "selection_rule": config.selection_rule,
        "composite_statistic": config.composite_statistic,
        "selected_items": metadata["selected_items"],
        "per_scene_study_area_valid_pixel_fraction": per_scene_valid,
        "valid_scl_classes": metadata["valid_scl_classes"],
        "raster_crs": str(raster_crs),
        "raster_resolution_m": abs(transform.a),
        "study_area_pixel_count": int(area_mask.sum()),
        "study_area_valid_pixel_count": int(valid_in_area.sum()),
        "study_area_valid_pixel_fraction": round(
            float(valid_in_area.sum() / area_mask.sum()), 6
        ),
        "study_area_observation_count_mean": round(float(counts_in_area.mean()), 6),
        "study_area_observation_count_median": round(
            float(np.median(counts_in_area)), 6
        ),
        "study_area_observation_count_min": int(counts_in_area.min()),
        "study_area_observation_count_max": int(counts_in_area.max()),
        "road_segment_count": len(road_features),
        "roads_without_valid_ndvi": int(
            road_features["sentinel2_ndvi_mean"].isna().sum()
        ),
        "mean_road_context_ndvi": round(
            float(road_features["sentinel2_ndvi_mean"].mean()), 6
        ),
        "warning": (
            "The multi-date median is SCL-masked reflectance context. It is not "
            "canopy cover, shade, cooling, WBGT, UTCI, or Heat Score."
        ),
    }
    processed_rasters = project_root / "data/processed/rasters"
    processed_features = project_root / "data/processed/features"
    tables = project_root / "outputs/tables"
    maps = project_root / "outputs/maps"
    _write_raster(
        processed_rasters / "clementi_sentinel2_ndvi_composite.tif",
        np.where(np.isfinite(composite), composite, -9999),
        transform,
        raster_crs,
        "float32",
        -9999,
    )
    _write_raster(
        processed_rasters / "clementi_sentinel2_observation_count.tif",
        observation_count,
        transform,
        raster_crs,
        "uint8",
        0,
    )
    geopackage = processed_features / "road_sentinel2_ndvi_composite.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    road_features.to_file(geopackage, layer="road_ndvi_composite", driver="GPKG")
    road_features.drop(columns="geometry").to_csv(
        processed_features / "road_sentinel2_ndvi_composite.csv", index=False
    )
    (processed_features / "sentinel2_ndvi_composite_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    flat = {key: value for key, value in summary.items() if key != "selected_items"}
    pd.DataFrame([flat]).to_csv(
        tables / "sentinel2_ndvi_composite_summary.csv", index=False
    )
    create_composite_map(
        road_features,
        summary,
        maps / "clementi_sentinel2_ndvi_composite.html",
    )
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(
        description="Build a fixed-rule multi-date Sentinel-2 NDVI median composite."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/sentinel_composite.yaml",
    )
    parser.add_argument("--raw-snapshot", type=Path)
    args = parser.parse_args()
    print(
        json.dumps(
            build_sentinel_composite(args.config, raw_snapshot=args.raw_snapshot),
            indent=2,
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
