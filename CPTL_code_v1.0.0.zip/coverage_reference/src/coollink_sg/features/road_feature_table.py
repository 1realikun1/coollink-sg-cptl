"""Assemble the validated, unified road-segment feature table."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import geopandas as gpd
import numpy as np
import pandas as pd
from pyproj import CRS

from coollink_sg.config import (
    RoadFeatureTableConfig,
    load_road_feature_table_config,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]


def _require_source(
    frame: gpd.GeoDataFrame,
    name: str,
    join_key: str,
    required_fields: tuple[str, ...],
    output_crs: str,
    require_length: bool = True,
) -> None:
    required = {join_key, "geometry", *required_fields}
    if require_length:
        required.add("length_m")
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"{name} is missing fields: {sorted(missing)}")
    if frame.crs is None:
        raise ValueError(f"{name} must have an explicit CRS")
    if CRS.from_user_input(frame.crs) != CRS.from_user_input(output_crs):
        raise ValueError(f"{name} CRS must equal configured {output_crs}")
    if frame[join_key].isna().any():
        raise ValueError(f"{name} contains missing {join_key} values")
    if frame[join_key].duplicated().any():
        raise ValueError(f"{name} {join_key} values must be unique")


def _require_same_keys(
    network: gpd.GeoDataFrame,
    source: gpd.GeoDataFrame,
    name: str,
    join_key: str,
) -> None:
    network_keys = set(network[join_key])
    source_keys = set(source[join_key])
    if network_keys != source_keys:
        missing = len(network_keys - source_keys)
        extra = len(source_keys - network_keys)
        raise ValueError(
            f"{name} key coverage differs from network: {missing} missing, {extra} extra"
        )


def _require_matching_numeric_field(
    network: gpd.GeoDataFrame,
    source: gpd.GeoDataFrame,
    source_name: str,
    join_key: str,
    field: str,
) -> None:
    left = network.set_index(join_key)[field].sort_index()
    right = source.set_index(join_key)[field].sort_index()
    if not np.allclose(left.to_numpy(), right.to_numpy(), rtol=1e-9, atol=1e-6):
        raise ValueError(f"{source_name}.{field} does not match network.{field}")


def _require_valid_sentinel_values(
    sentinel2_ndvi: gpd.GeoDataFrame,
    config: RoadFeatureTableConfig,
) -> None:
    """Validate explicit satellite gaps without treating them as zeros."""

    non_nullable = set(config.sentinel2_ndvi_fields).difference(
        config.sentinel2_ndvi_nullable_fields
    )
    if sentinel2_ndvi[list(non_nullable)].isna().any().any():
        raise ValueError("Sentinel-2 non-nullable coverage fields cannot be missing")
    count = pd.to_numeric(
        sentinel2_ndvi["sentinel2_ndvi_valid_pixel_count"], errors="raise"
    )
    total = pd.to_numeric(
        sentinel2_ndvi["sentinel2_ndvi_buffer_pixel_count"], errors="raise"
    )
    fraction = pd.to_numeric(
        sentinel2_ndvi["sentinel2_ndvi_valid_pixel_fraction"], errors="raise"
    )
    if (count < 0).any() or (total <= 0).any() or (count > total).any():
        raise ValueError("Sentinel-2 pixel counts are invalid")
    if not np.allclose(fraction, count / total, rtol=0, atol=1e-12):
        raise ValueError("Sentinel-2 valid fraction does not match pixel counts")
    for field in config.sentinel2_ndvi_nullable_fields:
        values = pd.to_numeric(sentinel2_ndvi[field], errors="raise")
        if not values.isna().equals(count.eq(0)):
            raise ValueError(f"{field} must be missing exactly when valid count is zero")
        finite = values.dropna()
        if field in {"sentinel2_ndvi_mean", "sentinel2_ndvi_median"} and not finite.between(
            -1, 1
        ).all():
            raise ValueError(f"{field} must be within the NDVI range -1 to 1")
        if field == "sentinel2_ndvi_observation_count_mean" and (finite < 1).any():
            raise ValueError(f"{field} must be at least one where NDVI is valid")


def _require_valid_solar_shade_values(
    shade: gpd.GeoDataFrame,
    config: RoadFeatureTableConfig,
) -> None:
    """Validate partial shade-evidence bounds without promoting it to validation."""

    if shade[list(config.solar_shade_fields)].isna().any().any():
        raise ValueError("Solar-shade evidence fields cannot be missing")
    fractions = [
        "building_shadow_fraction_low",
        "building_shadow_fraction_central",
        "building_shadow_fraction_high",
        "direct_mapped_cover_fraction",
        "combined_shade_evidence_fraction",
    ]
    lengths = [
        "building_shadow_length_low_m",
        "building_shadow_length_central_m",
        "building_shadow_length_high_m",
        "direct_mapped_cover_length_m",
        "combined_shade_evidence_length_m",
    ]
    numeric_fractions = shade[fractions].apply(pd.to_numeric, errors="raise")
    numeric_lengths = shade[lengths].apply(pd.to_numeric, errors="raise")
    if not numeric_fractions.apply(lambda column: column.between(0, 1)).all().all():
        raise ValueError("Solar-shade evidence fractions must be within 0–1")
    if (numeric_lengths < 0).any().any():
        raise ValueError("Solar-shade evidence lengths cannot be negative")
    road_length = pd.to_numeric(shade["length_m"], errors="raise")
    if (numeric_lengths.gt(road_length, axis=0) & ~np.isclose(
        numeric_lengths, road_length.to_numpy()[:, None], rtol=0, atol=1e-6
    )).any().any():
        raise ValueError("Solar-shade evidence length cannot exceed road length")
    if not (
        numeric_fractions["building_shadow_fraction_low"]
        <= numeric_fractions["building_shadow_fraction_central"] + 1e-9
    ).all() or not (
        numeric_fractions["building_shadow_fraction_central"]
        <= numeric_fractions["building_shadow_fraction_high"] + 1e-9
    ).all():
        raise ValueError("Building-shadow sensitivity fractions must be ordered")
    combined = numeric_fractions["combined_shade_evidence_fraction"]
    components = numeric_fractions[
        ["building_shadow_fraction_central", "direct_mapped_cover_fraction"]
    ]
    if (combined + 1e-9 < components.max(axis=1)).any():
        raise ValueError("Combined shade evidence cannot be below either component")
    if not shade["shade_model_status"].eq(
        "estimated_building_heights_and_mapped_cover_not_validated"
    ).all():
        raise ValueError("Solar-shade rows must retain their non-validated status")


def assemble_road_feature_table(
    network: gpd.GeoDataFrame,
    vegetation: gpd.GeoDataFrame,
    built_environment: gpd.GeoDataFrame,
    sentinel2_ndvi: gpd.GeoDataFrame,
    solar_shade: gpd.GeoDataFrame,
    config: RoadFeatureTableConfig,
) -> gpd.GeoDataFrame:
    """Strictly join the processed feature sources by stable segment identifier."""

    _require_source(network, "network", config.join_key, (), config.output_crs)
    _require_source(
        vegetation,
        "vegetation",
        config.join_key,
        config.vegetation_fields,
        config.output_crs,
    )
    _require_source(
        built_environment,
        "built_environment",
        config.join_key,
        config.built_environment_fields,
        config.output_crs,
    )
    _require_source(
        sentinel2_ndvi,
        "sentinel2_ndvi",
        config.join_key,
        config.sentinel2_ndvi_fields,
        config.output_crs,
        require_length=False,
    )
    _require_source(
        solar_shade,
        "solar_shade",
        config.join_key,
        config.solar_shade_fields,
        config.output_crs,
    )
    for name, source in (
        ("vegetation", vegetation),
        ("built_environment", built_environment),
        ("sentinel2_ndvi", sentinel2_ndvi),
        ("solar_shade", solar_shade),
    ):
        _require_same_keys(network, source, name, config.join_key)
    for name, source in (
        ("vegetation", vegetation),
        ("built_environment", built_environment),
        ("solar_shade", solar_shade),
    ):
        _require_matching_numeric_field(
            network, source, name, config.join_key, "length_m"
        )
    _require_valid_sentinel_values(sentinel2_ndvi, config)
    _require_valid_solar_shade_values(solar_shade, config)

    for field in ("context_buffer_m", "context_buffer_area_m2"):
        _require_matching_numeric_field(
            vegetation,
            built_environment,
            "built_environment",
            config.join_key,
            field,
        )

    vegetation_columns = [config.join_key, *config.vegetation_fields]
    built_columns = [config.join_key, *config.built_environment_fields]
    sentinel_columns = [config.join_key, *config.sentinel2_ndvi_fields]
    shade_columns = [config.join_key, *config.solar_shade_fields]
    result = network.copy().merge(
        vegetation[vegetation_columns],
        on=config.join_key,
        how="left",
        validate="one_to_one",
        sort=False,
    )
    result = result.merge(
        built_environment[built_columns],
        on=config.join_key,
        how="left",
        validate="one_to_one",
        sort=False,
    )
    result = result.merge(
        sentinel2_ndvi[sentinel_columns],
        on=config.join_key,
        how="left",
        validate="one_to_one",
        sort=False,
    )
    result = result.merge(
        solar_shade[shade_columns],
        on=config.join_key,
        how="left",
        validate="one_to_one",
        sort=False,
    )
    result = gpd.GeoDataFrame(result, geometry="geometry", crs=config.output_crs)
    feature_fields = [
        *config.vegetation_fields,
        *config.built_environment_fields,
        *config.solar_shade_fields,
    ]
    if result[feature_fields].isna().any().any():
        raise ValueError("Unified road feature table contains missing proxy values")
    if len(result) != len(network) or not result[config.join_key].is_unique:
        raise ValueError("Unified road feature table violates the one-row-per-segment rule")
    return result


def summarize_road_feature_table(
    features: gpd.GeoDataFrame,
    config: RoadFeatureTableConfig,
    vegetation_snapshot_id: str,
    built_environment_snapshot_id: str,
    sentinel2_ndvi_snapshot_id: str,
    solar_shade_model_id: str,
) -> dict[str, Any]:
    """Summarize table integrity and source lineage without inventing a score."""

    feature_fields = [*config.vegetation_fields, *config.built_environment_fields]
    return {
        "segment_count": len(features),
        "unique_segment_count": int(features[config.join_key].nunique()),
        "column_count": len(features.columns),
        "proxy_feature_count": len(feature_fields),
        "sentinel2_ndvi_feature_count": len(config.sentinel2_ndvi_fields),
        "solar_shade_evidence_feature_count": len(config.solar_shade_fields),
        "output_crs": str(features.crs),
        "missing_proxy_value_count": int(features[feature_fields].isna().sum().sum()),
        "vegetation_snapshot_id": vegetation_snapshot_id,
        "built_environment_snapshot_id": built_environment_snapshot_id,
        "sentinel2_ndvi_snapshot_id": sentinel2_ndvi_snapshot_id,
        "solar_shade_model_id": solar_shade_model_id,
        "roads_without_valid_sentinel2_ndvi": int(
            features["sentinel2_ndvi_mean"].isna().sum()
        ),
        "weather_assignment": "separate_context_table_not_joined",
        "heat_score": "not_implemented",
        "warning": (
            "The table combines mapped proxies and SCL-masked Sentinel-2 NDVI "
            "context plus building-height sensitivity shadows and mapped-cover evidence. "
            "Only ten building heights are direct OSM source values; all other "
            "building heights are external estimates or statistical imputations. "
            "It contains no validated shade fraction, road-level weather observation, "
            "canopy measurement, or heat score."
        ),
    }


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def _snapshot_id(project_root: Path, filename: str) -> str:
    payload = json.loads(
        (project_root / "data/processed/features" / filename).read_text(
            encoding="utf-8"
        )
    )
    return str(payload["snapshot_id"])


def build_road_feature_table(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Load processed sources, validate them, and save the unified table."""

    config = load_road_feature_table_config(config_path)

    def load(source) -> tuple[gpd.GeoDataFrame, Path]:
        path = project_root / source.path
        return gpd.read_file(path, layer=source.layer), path

    network, network_path = load(config.network)
    vegetation, vegetation_path = load(config.vegetation)
    built, built_path = load(config.built_environment)
    sentinel2_ndvi, sentinel2_ndvi_path = load(config.sentinel2_ndvi)
    solar_shade, solar_shade_path = load(config.solar_shade)
    features = assemble_road_feature_table(
        network, vegetation, built, sentinel2_ndvi, solar_shade, config
    )
    summary = summarize_road_feature_table(
        features,
        config,
        _snapshot_id(project_root, "vegetation_proxy_summary.json"),
        _snapshot_id(project_root, "built_environment_proxy_summary.json"),
        _snapshot_id(project_root, "sentinel2_ndvi_composite_summary.json"),
        str(
            json.loads(
                (
                    project_root
                    / "data/processed/features/solar_shade_evidence_summary.json"
                ).read_text(encoding="utf-8")
            )["model_id"]
        ),
    )
    summary["input_sha256"] = {
        "network": _sha256(network_path),
        "vegetation": _sha256(vegetation_path),
        "built_environment": _sha256(built_path),
        "sentinel2_ndvi": _sha256(sentinel2_ndvi_path),
        "solar_shade": _sha256(solar_shade_path),
    }

    output_directory = project_root / "data/processed/features"
    table_directory = project_root / "outputs/tables"
    output_directory.mkdir(parents=True, exist_ok=True)
    table_directory.mkdir(parents=True, exist_ok=True)
    geopackage = output_directory / "clementi_road_feature_table.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    features.to_file(geopackage, layer="road_features", driver="GPKG")
    features.drop(columns="geometry").to_csv(
        output_directory / "clementi_road_feature_table.csv", index=False
    )
    (output_directory / "road_feature_table_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    flat_summary = {key: value for key, value in summary.items() if key != "input_sha256"}
    pd.DataFrame([flat_summary]).to_csv(
        table_directory / "road_feature_table_summary.csv", index=False
    )
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(
        description="Assemble the validated Clementi road-segment feature table."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/road_feature_table.yaml",
    )
    args = parser.parse_args()
    print(
        json.dumps(
            build_road_feature_table(args.config), indent=2, ensure_ascii=False
        )
    )


if __name__ == "__main__":
    main()
