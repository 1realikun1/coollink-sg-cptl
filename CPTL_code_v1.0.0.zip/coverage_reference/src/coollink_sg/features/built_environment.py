"""Build road-level OSM building and artificial-cover proxy features."""

from __future__ import annotations

import argparse
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import osmnx as ox
import pandas as pd

from coollink_sg.config import (
    BuiltEnvironmentConfig,
    StudyAreaConfig,
    load_built_environment_config,
    load_study_area_config,
)
from coollink_sg.data.pedestrian_network import create_study_area

PROJECT_ROOT = Path(__file__).resolve().parents[3]
QUERY_TAGS: dict[str, bool | list[str]] = {
    "building": True,
    "covered": True,
    "amenity": ["shelter"],
    "shelter": True,
}


def fetch_osm_built_environment_features(
    config: BuiltEnvironmentConfig,
    study_area: StudyAreaConfig,
) -> gpd.GeoDataFrame:
    """Fetch a union of mapped buildings and artificial-cover features."""

    _, area = create_study_area(study_area)
    query_area = area.copy()
    query_area.geometry = area.geometry.buffer(config.boundary_query_margin_m)
    polygon = query_area.to_crs(config.geographic_crs).geometry.iloc[0]
    features = ox.features.features_from_polygon(polygon, QUERY_TAGS).reset_index()
    if features.empty:
        raise ValueError("OpenStreetMap returned no built-environment features")
    if features.crs is None:
        features = features.set_crs(config.geographic_crs)
    return features


def _tag_matches(value: Any, accepted: tuple[str, ...]) -> bool:
    if isinstance(value, (list, tuple, set)):
        return any(str(item) in accepted for item in value)
    return value is not None and str(value) in accepted


def classify_built_environment_features(
    features: gpd.GeoDataFrame,
    config: BuiltEnvironmentConfig,
) -> tuple[gpd.GeoDataFrame, gpd.GeoDataFrame, gpd.GeoDataFrame, gpd.GeoDataFrame]:
    """Classify enclosed buildings, roofs, covered ways, and shelters."""

    if features.crs is None:
        raise ValueError("OSM built-environment features must have an explicit CRS")
    source = features.copy()
    source.geometry = source.geometry.make_valid()
    source = source[source.geometry.notna() & ~source.geometry.is_empty].copy()
    geometry_type = source.geometry.geom_type
    building = source.get("building", pd.Series(index=source.index, dtype=object))
    covered = source.get("covered", pd.Series(index=source.index, dtype=object))
    amenity = source.get("amenity", pd.Series(index=source.index, dtype=object))
    shelter = source.get("shelter", pd.Series(index=source.index, dtype=object))

    roof_mask = building.map(
        lambda value: _tag_matches(value, config.roof_building_values)
    ).fillna(False)
    building_mask = building.notna() & ~roof_mask
    covered_mask = covered.map(
        lambda value: _tag_matches(value, config.accepted_covered_values)
    ).fillna(False)
    shelter_mask = (
        amenity.map(lambda value: _tag_matches(value, ("shelter",))).fillna(False)
        | shelter.map(
            lambda value: _tag_matches(value, config.shelter_values)
        ).fillna(False)
    )

    polygons = geometry_type.isin(["Polygon", "MultiPolygon"])
    lines = geometry_type.isin(["LineString", "MultiLineString"])
    buildings = source[building_mask & polygons].copy()
    roofs = source[roof_mask & polygons].copy()
    covered_ways = source[covered_mask & lines].copy()
    shelters = source[shelter_mask].copy()
    return buildings, roofs, covered_ways, shelters


def _serialize_value(value: Any) -> Any:
    if isinstance(value, (list, tuple, set, dict)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True)
    return value


def _safe_frame(frame: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    safe = frame.copy()
    for column in safe.columns:
        if column != safe.geometry.name and safe[column].dtype == object:
            safe[column] = safe[column].map(_serialize_value)
    return safe


def save_raw_built_environment_snapshot(
    features: gpd.GeoDataFrame,
    retrieved_at_utc: datetime,
    config: BuiltEnvironmentConfig,
    study_area: StudyAreaConfig,
    raw_root: Path,
) -> Path:
    """Write a new immutable, timestamped OSM feature snapshot."""

    snapshot_id = retrieved_at_utc.strftime("%Y%m%dT%H%M%S%fZ")
    directory = raw_root / snapshot_id
    directory.mkdir(parents=True, exist_ok=False)
    geopackage = directory / "osm_built_environment_features.gpkg"
    groups = {
        "points": features.geometry.geom_type.isin(["Point", "MultiPoint"]),
        "lines": features.geometry.geom_type.isin(["LineString", "MultiLineString"]),
        "polygons": features.geometry.geom_type.isin(["Polygon", "MultiPolygon"]),
    }
    counts: dict[str, int] = {}
    first = True
    for name, mask in groups.items():
        layer = features[mask].copy()
        if layer.empty:
            continue
        counts[name] = len(layer)
        _safe_frame(layer).to_file(
            geopackage,
            layer=name,
            driver="GPKG",
            mode="w" if first else "a",
        )
        first = False
    if not counts:
        raise ValueError("No supported built-environment geometries were returned")
    manifest = {
        "snapshot_id": snapshot_id,
        "retrieved_at_utc": retrieved_at_utc.isoformat(),
        "study_area": {
            "name": study_area.name,
            "center_latitude": study_area.latitude,
            "center_longitude": study_area.longitude,
            "radius_m": study_area.radius_m,
            "query_margin_m": config.boundary_query_margin_m,
        },
        "query_tags": QUERY_TAGS,
        "source": config.source_metadata,
        "software": {"osmnx": ox.__version__},
        "feature_counts_by_geometry_layer": counts,
        "note": "Non-scalar OSM tags are JSON-serialized for GeoPackage compatibility.",
    }
    with (directory / "manifest.json").open("x", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2, ensure_ascii=False)
    return directory


def load_raw_built_environment_snapshot(directory: Path) -> gpd.GeoDataFrame:
    """Load all geometry layers from an immutable source snapshot."""

    geopackage = directory / "osm_built_environment_features.gpkg"
    layers = gpd.list_layers(geopackage)["name"].tolist()
    frames = [gpd.read_file(geopackage, layer=layer) for layer in layers]
    return gpd.GeoDataFrame(
        pd.concat(frames, ignore_index=True, sort=False),
        geometry="geometry",
        crs=frames[0].crs,
    )


def _intersection_lengths(
    lines: gpd.GeoDataFrame,
    buffers: gpd.GeoDataFrame,
) -> pd.Series:
    if lines.empty:
        return pd.Series(dtype="float64")
    joined = gpd.sjoin(
        lines[["geometry"]],
        buffers[["segment_id", "geometry"]],
        how="inner",
        predicate="intersects",
    )
    joined["clipped_length_m"] = [
        geometry.intersection(buffers.geometry.loc[index]).length
        for geometry, index in zip(joined.geometry, joined["index_right"], strict=True)
    ]
    return joined.groupby("segment_id")["clipped_length_m"].sum()


def _feature_counts(
    features: gpd.GeoDataFrame,
    buffers: gpd.GeoDataFrame,
) -> pd.Series:
    if features.empty:
        return pd.Series(dtype="int64")
    source = features[["geometry"]].copy()
    source["source_feature_id"] = range(len(source))
    joined = gpd.sjoin(
        source,
        buffers[["segment_id", "geometry"]],
        how="inner",
        predicate="intersects",
    )
    return joined.groupby("segment_id")["source_feature_id"].nunique().astype("int64")


def _nearest_building_distances(
    edges: gpd.GeoDataFrame,
    buildings: gpd.GeoDataFrame,
) -> pd.Series:
    if buildings.empty:
        return pd.Series(dtype="float64")
    joined = gpd.sjoin_nearest(
        edges[["segment_id", "geometry"]],
        buildings[["geometry"]],
        how="left",
        distance_col="distance_m",
    )
    return joined.groupby("segment_id")["distance_m"].min()


def compute_road_built_environment_features(
    edges: gpd.GeoDataFrame,
    source_features: gpd.GeoDataFrame,
    config: BuiltEnvironmentConfig,
) -> tuple[gpd.GeoDataFrame, dict[str, int]]:
    """Calculate separate building-context and mapped artificial-cover proxies."""

    required = {"segment_id", "length_m", "geometry"}
    missing = required.difference(edges.columns)
    if missing:
        raise ValueError(f"Pedestrian edges are missing fields: {sorted(missing)}")
    if edges["segment_id"].duplicated().any():
        raise ValueError("Pedestrian segment_id values must be unique")
    if edges.crs is None or source_features.crs is None:
        raise ValueError("Edges and source features must have explicit CRS")

    roads = edges.to_crs(config.analysis_crs).copy()
    source = source_features.to_crs(config.analysis_crs).copy()
    buildings, roofs, covered_ways, shelters = classify_built_environment_features(
        source, config
    )
    buffers = roads[["segment_id", "geometry"]].copy()
    buffers.geometry = roads.geometry.buffer(config.road_context_buffer_m)
    buffer_area = buffers.geometry.area

    building_area = (
        buffers.geometry.intersection(buildings.geometry.union_all()).area
        if not buildings.empty
        else pd.Series(0.0, index=buffers.index)
    )
    roof_area = (
        buffers.geometry.intersection(roofs.geometry.union_all()).area
        if not roofs.empty
        else pd.Series(0.0, index=buffers.index)
    )
    covered_lengths = _intersection_lengths(covered_ways, buffers)
    shelter_counts = _feature_counts(shelters, buffers)
    nearest_distances = _nearest_building_distances(roads, buildings)
    tunnel = roads.get("tunnel", pd.Series(index=roads.index, dtype=object))
    passage = tunnel.map(
        lambda value: _tag_matches(value, config.building_passage_values)
    ).fillna(False)

    result = roads[["segment_id", "length_m", "geometry"]].copy()
    result["context_buffer_m"] = config.road_context_buffer_m
    result["context_buffer_area_m2"] = buffer_area.to_numpy()
    result["mapped_building_area_m2"] = building_area.to_numpy()
    result["building_footprint_proxy_ratio"] = (
        result["mapped_building_area_m2"] / result["context_buffer_area_m2"]
    ).clip(0, 1)
    result["nearest_mapped_building_distance_m"] = result["segment_id"].map(
        nearest_distances
    )
    result["mapped_roof_area_m2"] = roof_area.to_numpy()
    result["mapped_covered_way_length_m"] = (
        result["segment_id"].map(covered_lengths).fillna(0.0)
    )
    result["mapped_shelter_count"] = (
        result["segment_id"].map(shelter_counts).fillna(0).astype("int64")
    )
    result["building_passage_length_m"] = result["length_m"].where(passage, 0.0)
    result["building_passage_flag"] = passage.astype("int8")

    nonnegative = [
        "mapped_building_area_m2",
        "mapped_roof_area_m2",
        "mapped_covered_way_length_m",
        "mapped_shelter_count",
        "building_passage_length_m",
    ]
    if (result[nonnegative] < 0).any().any():
        raise ValueError("Built-environment proxy metrics cannot be negative")
    if not result["building_footprint_proxy_ratio"].between(0, 1).all():
        raise ValueError("building_footprint_proxy_ratio must be between 0 and 1")

    counts = {
        "mapped_building_polygon_count": len(buildings),
        "mapped_roof_polygon_count": len(roofs),
        "mapped_covered_way_count": len(covered_ways),
        "mapped_shelter_feature_count": len(shelters),
    }
    return result, counts


def summarize_built_environment_features(
    features: gpd.GeoDataFrame,
    source_counts: dict[str, int],
    config: BuiltEnvironmentConfig,
    snapshot_id: str,
) -> dict[str, Any]:
    """Create an auditable built-environment proxy summary."""

    ratio = features["building_footprint_proxy_ratio"]
    return {
        "snapshot_id": snapshot_id,
        "road_context_buffer_m": config.road_context_buffer_m,
        "segment_count": len(features),
        **source_counts,
        "mean_building_footprint_proxy_ratio": round(float(ratio.mean()), 6),
        "median_building_footprint_proxy_ratio": round(float(ratio.median()), 6),
        "segments_with_zero_building_proxy": int((ratio == 0).sum()),
        "segments_tagged_building_passage": int(
            (features["building_passage_flag"] == 1).sum()
        ),
        "segments_with_mapped_covered_way_in_context": int(
            (features["mapped_covered_way_length_m"] > 0).sum()
        ),
        "segments_with_mapped_roof_in_context": int(
            (features["mapped_roof_area_m2"] > 0).sum()
        ),
        "segments_with_mapped_shelter_in_context": int(
            (features["mapped_shelter_count"] > 0).sum()
        ),
        "warning": (
            "These are OSM building-context and mapped-cover proxies, not simulated "
            "solar shade, thermal comfort, or field-observed weather protection."
        ),
    }


def create_built_environment_map(
    road_features: gpd.GeoDataFrame,
    source_features: gpd.GeoDataFrame,
    config: BuiltEnvironmentConfig,
    study_area: StudyAreaConfig,
    output_path: Path,
) -> None:
    """Create an interactive QA map of the separate proxy layers."""

    buildings, roofs, covered_ways, shelters = classify_built_environment_features(
        source_features.to_crs(config.analysis_crs), config
    )
    map_object = folium.Map(
        location=[study_area.latitude, study_area.longitude],
        zoom_start=14,
        tiles="OpenStreetMap",
        control_scale=True,
    )
    for layer, name, colour in [
        (buildings, "Mapped buildings", "#64748b"),
        (roofs, "Mapped building roofs", "#0ea5e9"),
        (covered_ways, "Mapped covered ways", "#7c3aed"),
        (shelters, "Mapped shelters", "#ea580c"),
    ]:
        if not layer.empty:
            folium.GeoJson(
                layer.to_crs(config.geographic_crs)[["geometry"]].to_json(),
                name=name,
                style_function=lambda _feature, selected=colour: {
                    "color": selected,
                    "weight": 2,
                    "fillColor": selected,
                    "fillOpacity": 0.18,
                },
                marker=folium.CircleMarker(radius=3, color=colour, fill=True),
            ).add_to(map_object)

    display = road_features.to_crs(config.geographic_crs).copy()
    display["building_footprint_proxy_ratio"] = display[
        "building_footprint_proxy_ratio"
    ].round(3)
    display["nearest_mapped_building_distance_m"] = display[
        "nearest_mapped_building_distance_m"
    ].round(1)
    display["mapped_covered_way_length_m"] = display[
        "mapped_covered_way_length_m"
    ].round(1)
    folium.GeoJson(
        display[
            [
                "segment_id",
                "building_footprint_proxy_ratio",
                "nearest_mapped_building_distance_m",
                "mapped_covered_way_length_m",
                "mapped_shelter_count",
                "building_passage_flag",
                "geometry",
            ]
        ].to_json(),
        name="Road building context",
        style_function=lambda feature: {
            "color": "#7c3aed"
            if feature["properties"]["building_passage_flag"]
            else "#334155",
            "weight": 3,
            "opacity": 0.75,
        },
        tooltip=folium.GeoJsonTooltip(
            fields=[
                "segment_id",
                "building_footprint_proxy_ratio",
                "nearest_mapped_building_distance_m",
                "mapped_covered_way_length_m",
                "mapped_shelter_count",
                "building_passage_flag",
            ],
            aliases=[
                "Segment",
                "Building-footprint proxy",
                "Nearest mapped building (m)",
                "Covered-way length in context (m)",
                "Shelters in context",
                "Building-passage tag",
            ],
        ),
    ).add_to(map_object)
    legend = """
    <div style="position:fixed;bottom:30px;left:30px;z-index:9999;background:white;
      padding:10px;border:1px solid #777;font-size:12px"><b>OSM proxy layers</b><br>
      Purple road: tunnel=building_passage<br><small>Not simulated or measured shade</small></div>
    """
    map_object.get_root().html.add_child(folium.Element(legend))
    folium.LayerControl(collapsed=False).add_to(map_object)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    map_object.save(output_path)


def save_processed_built_environment(
    road_features: gpd.GeoDataFrame,
    source_features: gpd.GeoDataFrame,
    summary: dict[str, Any],
    config: BuiltEnvironmentConfig,
    study_area: StudyAreaConfig,
    project_root: Path,
) -> None:
    """Save processed tables, summary, and interactive QA map."""

    processed = project_root / "data/processed/features"
    tables = project_root / "outputs/tables"
    processed.mkdir(parents=True, exist_ok=True)
    tables.mkdir(parents=True, exist_ok=True)
    geopackage = processed / "road_built_environment_features.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    road_features.to_file(geopackage, layer="road_built_environment", driver="GPKG")
    road_features.drop(columns="geometry").to_csv(
        processed / "road_built_environment_features.csv", index=False
    )
    (processed / "built_environment_proxy_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    pd.DataFrame([summary]).to_csv(
        tables / "built_environment_proxy_summary.csv", index=False
    )
    create_built_environment_map(
        road_features,
        source_features,
        config,
        study_area,
        project_root / "outputs/maps/clementi_built_environment_proxy.html",
    )


def build_built_environment_features(
    config_path: Path,
    study_area_path: Path,
    project_root: Path = PROJECT_ROOT,
    raw_snapshot: Path | None = None,
) -> dict[str, Any]:
    """Fetch or reload OSM features and build road-level proxy features."""

    config = load_built_environment_config(config_path)
    study_area = load_study_area_config(study_area_path)
    if raw_snapshot is None:
        source = fetch_osm_built_environment_features(config, study_area)
        snapshot = save_raw_built_environment_snapshot(
            source,
            datetime.now(UTC),
            config,
            study_area,
            project_root / "data/raw/built_environment",
        )
    else:
        snapshot = raw_snapshot.resolve()
        source = load_raw_built_environment_snapshot(snapshot)
    edges = gpd.read_file(
        project_root / "data/processed/network/clementi_pedestrian_network.gpkg",
        layer="edges",
    )
    road_features, source_counts = compute_road_built_environment_features(
        edges, source, config
    )
    summary = summarize_built_environment_features(
        road_features, source_counts, config, snapshot.name
    )
    summary["raw_snapshot_directory"] = str(snapshot)
    summary["raw_snapshot_reused"] = raw_snapshot is not None
    save_processed_built_environment(
        road_features, source, summary, config, study_area, project_root
    )
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(
        description="Build OSM building and artificial-cover proxy features."
    )
    parser.add_argument(
        "--config", type=Path, default=PROJECT_ROOT / "config/built_environment.yaml"
    )
    parser.add_argument(
        "--study-area-config",
        type=Path,
        default=PROJECT_ROOT / "config/study_area.yaml",
    )
    parser.add_argument(
        "--raw-snapshot",
        type=Path,
        default=None,
        help="Reuse an immutable raw snapshot instead of querying Overpass.",
    )
    args = parser.parse_args()
    summary = build_built_environment_features(
        args.config, args.study_area_config, raw_snapshot=args.raw_snapshot
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
