"""Compare CHMv2 canopy support with multi-date Sentinel-2 NDVI in Clementi."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import geopandas as gpd
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
import yaml
from rasterio.enums import Resampling
from rasterio.features import geometry_mask
from rasterio.warp import reproject, transform_geom
from shapely.geometry import mapping
from sklearn.metrics import roc_auc_score

PROJECT_ROOT = Path(__file__).resolve().parents[3]


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    if key not in mapping:
        raise ValueError(f"Missing required field '{section}.{key}'")
    return mapping[key]


def summarize_pairs(
    ndvi: np.ndarray,
    canopy_fraction: np.ndarray,
    presence_threshold: float,
) -> dict[str, Any]:
    if ndvi.shape != canopy_fraction.shape:
        raise ValueError("NDVI and canopy fraction must share a shape")
    valid = np.isfinite(ndvi) & np.isfinite(canopy_fraction)
    if valid.sum() < 2:
        raise ValueError("At least two paired pixels are required")
    x = ndvi[valid].astype(float)
    y = canopy_fraction[valid].astype(float)
    presence = y >= presence_threshold
    if presence.all() or (~presence).all():
        raise ValueError("Both canopy-presence classes are required")
    return {
        "paired_pixel_count": int(valid.sum()),
        "spearman_rank_correlation": float(pd.Series(x).corr(pd.Series(y), method="spearman")),
        "pearson_correlation": float(np.corrcoef(x, y)[0, 1]),
        "ndvi_auc_for_chmv2_canopy_presence": float(roc_auc_score(presence, x)),
        "canopy_presence_pixel_fraction": float(presence.mean()),
        "median_ndvi_canopy_present": float(np.median(x[presence])),
        "median_ndvi_canopy_absent": float(np.median(x[~presence])),
        "median_ndvi_difference": float(
            np.median(x[presence]) - np.median(x[~presence])
        ),
    }


def _plot_pairs(
    pairs: pd.DataFrame,
    summary: dict[str, Any],
    png_path: Path,
    svg_path: Path,
) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(8.4, 3.5), constrained_layout=True)
    hexbin = axes[0].hexbin(
        pairs["sentinel2_ndvi"],
        pairs["chmv2_canopy_fraction"],
        gridsize=45,
        mincnt=1,
        cmap="viridis",
    )
    axes[0].set_xlabel("Sentinel-2 median NDVI")
    axes[0].set_ylabel("CHMv2 canopy fraction")
    axes[0].set_title("Pixel-level cross-product consistency")
    fig.colorbar(hexbin, ax=axes[0], label="Pixel count")

    threshold = float(summary["canopy_presence_fraction_threshold"])
    present = pairs.loc[pairs["chmv2_canopy_fraction"].ge(threshold), "sentinel2_ndvi"]
    absent = pairs.loc[pairs["chmv2_canopy_fraction"].lt(threshold), "sentinel2_ndvi"]
    axes[1].boxplot(
        [absent, present],
        tick_labels=["CHMv2 absent", "CHMv2 present"],
        showfliers=False,
        patch_artist=True,
        boxprops={"facecolor": "#cbd5e1"},
        medianprops={"color": "#0f172a", "linewidth": 1.5},
    )
    axes[1].set_ylabel("Sentinel-2 median NDVI")
    axes[1].set_title(
        f"AUC={summary['ndvi_auc_for_chmv2_canopy_presence']:.3f}; "
        f"Spearman={summary['spearman_rank_correlation']:.3f}"
    )
    for path in (png_path, svg_path):
        path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def build_canopy_ndvi_consistency(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    payload = yaml.safe_load(Path(config_path).read_text(encoding="utf-8"))
    model = _required(payload, "canopy_ndvi_consistency", "root")
    inputs = _required(payload, "inputs", "root")
    outputs = _required(payload, "outputs", "root")
    presence_threshold = float(
        _required(
            model,
            "canopy_presence_fraction_threshold",
            "canopy_ndvi_consistency",
        )
    )
    minimum_height = float(
        _required(model, "minimum_canopy_height_m", "canopy_ndvi_consistency")
    )
    if not 0 < presence_threshold <= 1 or minimum_height < 0:
        raise ValueError("Canopy thresholds are invalid")

    ndvi_path = project_root / str(_required(inputs, "sentinel2_ndvi", "inputs"))
    canopy_path = project_root / str(_required(inputs, "canopy_dsm", "inputs"))
    with rasterio.open(ndvi_path) as source:
        ndvi = source.read(1).astype("float32")
        if source.nodata is not None:
            ndvi[np.isclose(ndvi, source.nodata)] = np.nan
        target_crs = source.crs
        target_transform = source.transform
        target_shape = source.shape
    with rasterio.open(canopy_path) as source:
        canopy_height = source.read(1)
        canopy_valid = np.isfinite(canopy_height)
        if source.nodata is not None:
            canopy_valid &= ~np.isclose(canopy_height, source.nodata)
        canopy_binary = np.where(
            canopy_valid & (canopy_height >= minimum_height), 1.0, 0.0
        ).astype("float32")
        canopy_fraction = np.zeros(target_shape, dtype="float32")
        reproject(
            source=canopy_binary,
            destination=canopy_fraction,
            src_transform=source.transform,
            src_crs=source.crs,
            dst_transform=target_transform,
            dst_crs=target_crs,
            src_nodata=None,
            dst_nodata=np.nan,
            resampling=Resampling.average,
        )

    study = _required(inputs, "study_area", "inputs")
    area = gpd.read_file(
        project_root / str(_required(study, "path", "inputs.study_area")),
        layer=str(_required(study, "layer", "inputs.study_area")),
    )
    geometry = transform_geom(area.crs, target_crs, mapping(area.geometry.union_all()))
    mask = geometry_mask(
        [geometry], out_shape=target_shape, transform=target_transform, invert=True
    )
    ndvi[~mask] = np.nan
    canopy_fraction[~mask] = np.nan
    valid = np.isfinite(ndvi) & np.isfinite(canopy_fraction)
    pairs = pd.DataFrame(
        {
            "sentinel2_ndvi": ndvi[valid],
            "chmv2_canopy_fraction": canopy_fraction[valid],
        }
    )
    summary = summarize_pairs(ndvi, canopy_fraction, presence_threshold)
    summary.update(
        {
            "analysis_id": str(_required(model, "analysis_id", "model")),
            "canopy_presence_fraction_threshold": presence_threshold,
            "minimum_canopy_height_m": minimum_height,
            "interpretation_warning": str(_required(model, "interpretation", "model")),
            "remote_sensing_role": (
                "CHMv2 supplies canopy height directly to SOLWEIG; Sentinel-2 NDVI "
                "provides an independent cross-product vegetation consistency check."
            ),
        }
    )
    paths = {key: project_root / str(value) for key, value in outputs.items()}
    for path in paths.values():
        path.parent.mkdir(parents=True, exist_ok=True)
    pairs.to_csv(paths["paired_pixels"], index=False)
    paths["summary_json"].write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    pd.DataFrame([summary]).to_csv(paths["summary_table"], index=False)
    _plot_pairs(pairs, summary, paths["figure_png"], paths["figure_svg"])
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/canopy_ndvi_consistency.yaml",
    )
    args = parser.parse_args()
    print(
        json.dumps(
            build_canopy_ndvi_consistency(args.config),
            indent=2,
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
