"""Acquire Sentinel-2 L2A windows and derive road-context NDVI proxies."""

from __future__ import annotations

import argparse
import hashlib
import json
import threading
import time
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
import requests
from pyproj import CRS
from rasterio.features import geometry_mask
from rasterio.transform import Affine
from rasterio.warp import Resampling, reproject, transform_geom
from rasterio.windows import Window, from_bounds
from shapely.geometry import mapping, shape

from coollink_sg.config import (
    SentinelNDVIConfig,
    load_sentinel_ndvi_config,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]


def _fetch_asset_response(method: str, url: str, headers: dict[str, str]) -> requests.Response:
    """Fetch one COG range atomically, retrying only transient transport failures.

    GDAL may request a small byte range multiple times.  Buffering a range before
    emitting its local HTTP response prevents a dropped upstream chunk from being
    presented to GDAL as a corrupt GeoTIFF response.
    """

    last_error: requests.RequestException | None = None
    for attempt in range(3):
        try:
            response = requests.request(method, url, headers=headers, timeout=120)
            response.raise_for_status()
            return response
        except requests.RequestException as error:
            last_error = error
            if attempt < 2:
                time.sleep(0.5 * (attempt + 1))
    assert last_error is not None
    raise last_error


class _RangeProxyHandler(BaseHTTPRequestHandler):
    """Forward local GDAL range requests through Python Requests HTTPS."""

    server: Any

    def _request(self, method: str) -> None:
        headers = {}
        if self.headers.get("Range"):
            headers["Range"] = self.headers["Range"]
        try:
            response = _fetch_asset_response(method, self.server.asset_url, headers)
        except requests.RequestException as error:
            self.send_error(502, f"upstream COG request failed: {error}")
            return
        self.send_response(response.status_code)
        for key in ("Content-Length", "Content-Range", "Content-Type", "ETag"):
            if response.headers.get(key):
                self.send_header(key, response.headers[key])
        self.send_header("Accept-Ranges", "bytes")
        self.end_headers()
        if method == "GET":
            self.wfile.write(response.content)

    def do_HEAD(self) -> None:  # noqa: N802
        self._request("HEAD")

    def do_GET(self) -> None:  # noqa: N802
        self._request("GET")

    def log_message(self, _format: str, *_args: Any) -> None:
        return


@contextmanager
def _range_proxy(asset_url: str) -> Iterator[str]:
    server = ThreadingHTTPServer(("127.0.0.1", 0), _RangeProxyHandler)
    server.asset_url = asset_url
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{server.server_port}/asset.tif"
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)


def search_stac_items(
    config: SentinelNDVIConfig,
    study_area_wgs84: gpd.GeoDataFrame,
) -> tuple[bytes, dict[str, Any], dict[str, Any]]:
    """Search and select the lowest-cloud item that fully covers the study area."""

    bbox = study_area_wgs84.total_bounds.tolist()
    query = {
        "collections": [config.collection],
        "bbox": bbox,
        "datetime": config.datetime_range,
        "limit": config.max_items,
    }
    response = requests.post(
        f"{config.stac_url}/search", json=query, timeout=60
    )
    response.raise_for_status()
    payload = response.json()
    features = payload.get("features", [])
    if not features:
        raise ValueError("Earth Search returned no Sentinel-2 items")
    area_geometry = study_area_wgs84.geometry.union_all()
    required_assets = {config.asset_red, config.asset_nir, config.asset_scl}
    eligible = [
        item
        for item in features
        if required_assets.issubset(item.get("assets", {}))
        and shape(item["geometry"]).covers(area_geometry)
    ]
    if not eligible:
        raise ValueError("No returned Sentinel-2 item fully covers the study area")
    eligible.sort(
        key=lambda item: (
            float(item["properties"].get("eo:cloud_cover", 1000)),
            str(item["properties"].get("datetime", "")),
        )
    )
    return response.content, eligible[0], query


def _native_asset_window(
    asset: dict[str, Any],
    study_area_wgs84: gpd.GeoDataFrame,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Read the native study window, retrying a failed GDAL range-read session."""

    last_error: rasterio.errors.RasterioIOError | None = None
    for attempt in range(5):
        try:
            return _read_native_asset_window_once(asset, study_area_wgs84)
        except rasterio.errors.RasterioIOError as error:
            last_error = error
            if attempt < 4:
                time.sleep(1.0 * (attempt + 1))
    assert last_error is not None
    raise last_error


def _read_native_asset_window_once(
    asset: dict[str, Any],
    study_area_wgs84: gpd.GeoDataFrame,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Read one native rectangular pixel window enclosing the study area."""

    with _range_proxy(asset["href"]) as local_url:
        with rasterio.Env(GDAL_DISABLE_READDIR_ON_OPEN="EMPTY_DIR"):
            with rasterio.open(local_url) as source:
                geometry = transform_geom(
                    study_area_wgs84.crs,
                    source.crs,
                    mapping(study_area_wgs84.geometry.union_all()),
                )
                bounds = shape(geometry).bounds
                window = from_bounds(*bounds, transform=source.transform)
                window = window.round_offsets().round_lengths()
                window = window.intersection(Window(0, 0, source.width, source.height))
                data = source.read(1, window=window)
                profile = source.profile.copy()
                profile.update(
                    driver="GTiff",
                    width=data.shape[1],
                    height=data.shape[0],
                    transform=source.window_transform(window),
                    count=1,
                    compress="deflate",
                )
    return data, profile


def acquire_sentinel_snapshot(
    config: SentinelNDVIConfig,
    study_area_wgs84: gpd.GeoDataFrame,
) -> tuple[bytes, dict[str, Any], dict[str, Any], dict[str, tuple[np.ndarray, dict[str, Any]]]]:
    """Fetch STAC metadata and native red, NIR, and SCL study windows."""

    response_bytes, item, query = search_stac_items(config, study_area_wgs84)
    windows = {
        name: _native_asset_window(item["assets"][asset_key], study_area_wgs84)
        for name, asset_key in (
            ("red", config.asset_red),
            ("nir", config.asset_nir),
            ("scl", config.asset_scl),
        )
    }
    return response_bytes, item, query, windows


def _sha256_bytes(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest().upper()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def save_raw_sentinel_snapshot(
    response_bytes: bytes,
    selected_item: dict[str, Any],
    query: dict[str, Any],
    windows: dict[str, tuple[np.ndarray, dict[str, Any]]],
    retrieved_at_utc: datetime,
    config: SentinelNDVIConfig,
    raw_root: Path,
) -> Path:
    """Save immutable STAC metadata and unchanged native pixel windows."""

    snapshot_id = retrieved_at_utc.strftime("%Y%m%dT%H%M%S%fZ")
    directory = raw_root / snapshot_id
    directory.mkdir(parents=True, exist_ok=False)
    (directory / "stac_search_response.json").write_bytes(response_bytes)
    (directory / "selected_item.json").write_text(
        json.dumps(selected_item, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    band_metadata = {}
    for name, (data, profile) in windows.items():
        path = directory / f"{name}_native_window.tif"
        with rasterio.open(path, "w", **profile) as output:
            output.write(data, 1)
        band_metadata[name] = {
            "path": path.name,
            "shape": list(data.shape),
            "dtype": str(data.dtype),
            "crs": str(profile["crs"]),
            "transform": list(profile["transform"]),
            "sha256": _sha256_file(path),
        }
    manifest = {
        "snapshot_id": snapshot_id,
        "retrieved_at_utc": retrieved_at_utc.isoformat(),
        "query": query,
        "selection_rule": "lowest eo:cloud_cover among full-coverage items; datetime tie-break",
        "selected_item_id": selected_item["id"],
        "selected_datetime": selected_item["properties"]["datetime"],
        "selected_scene_cloud_cover_percent": selected_item["properties"].get(
            "eo:cloud_cover"
        ),
        "search_response_sha256": _sha256_bytes(response_bytes),
        "window_note": (
            "GeoTIFFs contain native source pixel values in the rectangular windows "
            "enclosing the study area; they are not full Sentinel-2 granules."
        ),
        "bands": band_metadata,
        "source": config.source_metadata,
    }
    with (directory / "manifest.json").open("x", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2, ensure_ascii=False)
    return directory


def calculate_masked_ndvi(
    red_raw: np.ndarray,
    nir_raw: np.ndarray,
    scl_aligned: np.ndarray,
    red_scale: float,
    red_offset: float,
    nir_scale: float,
    nir_offset: float,
    valid_scl_classes: tuple[int, ...],
) -> tuple[np.ndarray, np.ndarray]:
    """Apply reflectance metadata and SCL mask, returning NDVI and valid mask."""

    if red_raw.shape != nir_raw.shape or red_raw.shape != scl_aligned.shape:
        raise ValueError("Red, NIR, and aligned SCL arrays must share a shape")
    red = red_raw.astype("float32") * red_scale + red_offset
    nir = nir_raw.astype("float32") * nir_scale + nir_offset
    denominator = nir + red
    valid = (
        (red_raw != 0)
        & (nir_raw != 0)
        & np.isin(scl_aligned, valid_scl_classes)
        & np.isfinite(denominator)
        & (np.abs(denominator) > 1e-6)
    )
    ndvi = np.full(red.shape, np.nan, dtype="float32")
    ndvi[valid] = np.clip(
        (nir[valid] - red[valid]) / denominator[valid], -1, 1
    )
    return ndvi, valid


def process_raw_sentinel_snapshot(
    snapshot: Path,
    config: SentinelNDVIConfig,
) -> tuple[np.ndarray, Affine, CRS, np.ndarray, dict[str, Any]]:
    """Align SCL to the 10 m grid and calculate masked NDVI."""

    item = json.loads((snapshot / "selected_item.json").read_text(encoding="utf-8"))
    with rasterio.open(snapshot / "red_native_window.tif") as source:
        red = source.read(1)
        transform = source.transform
        crs = source.crs
        profile = source.profile.copy()
    with rasterio.open(snapshot / "nir_native_window.tif") as source:
        nir = source.read(1)
        if source.transform != transform or source.crs != crs or source.shape != red.shape:
            raise ValueError("Native red and NIR windows must be aligned")
    with rasterio.open(snapshot / "scl_native_window.tif") as source:
        scl = source.read(1)
        scl_aligned = np.zeros(red.shape, dtype="uint8")
        reproject(
            source=scl,
            destination=scl_aligned,
            src_transform=source.transform,
            src_crs=source.crs,
            src_nodata=source.nodata,
            dst_transform=transform,
            dst_crs=crs,
            dst_nodata=0,
            resampling=Resampling.nearest,
        )

    def calibration(asset_key: str) -> tuple[float, float]:
        band = item["assets"][asset_key]["raster:bands"][0]
        return float(band.get("scale", 1)), float(band.get("offset", 0))

    red_scale, red_offset = calibration(config.asset_red)
    nir_scale, nir_offset = calibration(config.asset_nir)
    ndvi, valid = calculate_masked_ndvi(
        red,
        nir,
        scl_aligned,
        red_scale,
        red_offset,
        nir_scale,
        nir_offset,
        config.valid_scl_classes,
    )
    metadata = {
        "item_id": item["id"],
        "acquired_at": item["properties"]["datetime"],
        "scene_cloud_cover_percent": item["properties"].get("eo:cloud_cover"),
        "red_scale": red_scale,
        "red_offset": red_offset,
        "nir_scale": nir_scale,
        "nir_offset": nir_offset,
        "valid_scl_classes": list(config.valid_scl_classes),
        "profile": profile,
    }
    return ndvi, transform, crs, valid, metadata


def road_ndvi_statistics(
    edges: gpd.GeoDataFrame,
    ndvi: np.ndarray,
    transform: Affine,
    raster_crs: CRS,
    road_buffer_m: float,
    observation_count: np.ndarray | None = None,
) -> gpd.GeoDataFrame:
    """Calculate per-edge NDVI statistics inside metric road buffers."""

    if edges.crs is None:
        raise ValueError("Road edges must have an explicit CRS")
    if edges["segment_id"].isna().any() or not edges["segment_id"].is_unique:
        raise ValueError("Road segment_id values must be complete and unique")
    if observation_count is not None and observation_count.shape != ndvi.shape:
        raise ValueError("Observation-count raster must match the NDVI shape")
    projected = edges.to_crs(raster_crs)[["segment_id", "geometry"]].copy()
    buffers = projected.geometry.buffer(road_buffer_m)
    height, width = ndvi.shape
    cache: dict[bytes, tuple[float, float, int, int, float, float]] = {}
    rows = []
    for segment_id, geometry in zip(projected["segment_id"], buffers, strict=True):
        key = geometry.wkb
        stats = cache.get(key)
        if stats is None:
            raw_window = from_bounds(*geometry.bounds, transform=transform)
            col_start = max(0, int(np.floor(raw_window.col_off)))
            row_start = max(0, int(np.floor(raw_window.row_off)))
            col_stop = min(width, int(np.ceil(raw_window.col_off + raw_window.width)))
            row_stop = min(height, int(np.ceil(raw_window.row_off + raw_window.height)))
            if col_stop <= col_start or row_stop <= row_start:
                stats = (np.nan, np.nan, 0, 0, 0.0, np.nan)
            else:
                window = Window(
                    col_start, row_start, col_stop - col_start, row_stop - row_start
                )
                subset = ndvi[row_start:row_stop, col_start:col_stop]
                inside = geometry_mask(
                    [mapping(geometry)],
                    out_shape=subset.shape,
                    transform=rasterio.windows.transform(window, transform),
                    invert=True,
                )
                values = subset[inside & np.isfinite(subset)]
                observation_mean = np.nan
                if observation_count is not None and values.size:
                    observation_subset = observation_count[
                        row_start:row_stop, col_start:col_stop
                    ]
                    observation_mean = float(
                        observation_subset[inside & np.isfinite(subset)].mean()
                    )
                total = int(inside.sum())
                valid_count = int(values.size)
                stats = (
                    float(values.mean()) if valid_count else np.nan,
                    float(np.median(values)) if valid_count else np.nan,
                    valid_count,
                    total,
                    valid_count / total if total else 0.0,
                    observation_mean,
                )
            cache[key] = stats
        rows.append((segment_id, *stats))
    table = pd.DataFrame(
        rows,
        columns=[
            "segment_id",
            "sentinel2_ndvi_mean",
            "sentinel2_ndvi_median",
            "sentinel2_ndvi_valid_pixel_count",
            "sentinel2_ndvi_buffer_pixel_count",
            "sentinel2_ndvi_valid_pixel_fraction",
            "sentinel2_ndvi_observation_count_mean",
        ],
    )
    if observation_count is None:
        table = table.drop(columns="sentinel2_ndvi_observation_count_mean")
    result = edges[["segment_id", "geometry"]].merge(
        table, on="segment_id", how="left", validate="one_to_one", sort=False
    )
    return gpd.GeoDataFrame(result, geometry="geometry", crs=edges.crs)


def create_ndvi_map(
    road_features: gpd.GeoDataFrame,
    output_path: Path,
    summary: dict[str, Any],
) -> None:
    """Create an interactive road-context NDVI QA map."""

    display = road_features.to_crs("EPSG:4326").copy()
    display["ndvi_display"] = display["sentinel2_ndvi_mean"].round(3)
    display["valid_fraction"] = display[
        "sentinel2_ndvi_valid_pixel_fraction"
    ].round(3)
    center = display.geometry.union_all().centroid
    map_object = folium.Map(
        location=[center.y, center.x], zoom_start=14, tiles="OpenStreetMap", control_scale=True
    )

    def colour(value: Any) -> str:
        if value is None or pd.isna(value):
            return "#9ca3af"
        normalized = max(0.0, min(1.0, (float(value) + 0.2) / 1.0))
        red = round(190 - 150 * normalized)
        green = round(80 + 100 * normalized)
        blue = round(60 - 15 * normalized)
        return f"#{red:02x}{green:02x}{blue:02x}"

    folium.GeoJson(
        display[
            ["segment_id", "ndvi_display", "valid_fraction", "geometry"]
        ].to_json(),
        name="Sentinel-2 road-context NDVI",
        style_function=lambda feature: {
            "color": colour(feature["properties"]["ndvi_display"]),
            "weight": 3,
            "opacity": 0.8,
        },
        tooltip=folium.GeoJsonTooltip(
            fields=["segment_id", "ndvi_display", "valid_fraction"],
            aliases=["Segment", "Mean masked NDVI", "Valid pixel fraction"],
        ),
    ).add_to(map_object)
    legend = """
    <div style="position:fixed;bottom:30px;left:30px;z-index:9999;background:white;
      padding:10px;border:1px solid #777;font-size:12px"><b>Sentinel-2 NDVI proxy</b><br>
      Brown: lower NDVI &nbsp; Green: higher NDVI &nbsp; Grey: no valid pixels<br>
      <small>Not canopy cover or shade</small></div>
    """
    map_object.get_root().html.add_child(folium.Element(legend))
    traceability = f"""
    <div style="position:fixed;top:10px;right:10px;z-index:9999;background:white;
      padding:10px;border:1px solid #777;font-size:12px;max-width:340px">
      <b>Sentinel-2 source</b><br>
      Item: {summary["item_id"]}<br>
      Acquired: {summary["acquired_at"]}<br>
      Study-area valid pixels: {summary["study_area_valid_pixel_fraction"]:.1%}<br>
      <small>Cloud/SCL gaps remain missing; grey roads have no valid NDVI.<br>
      NDVI is not canopy cover, shade, or a thermal measurement.</small></div>
    """
    map_object.get_root().html.add_child(folium.Element(traceability))
    folium.LayerControl().add_to(map_object)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    map_object.save(output_path)


def build_sentinel_ndvi(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
    raw_snapshot: Path | None = None,
) -> dict[str, Any]:
    """Acquire or reload Sentinel-2 and build road-context NDVI features."""

    config = load_sentinel_ndvi_config(config_path)
    study_area = gpd.read_file(
        project_root / "data/processed/network/clementi_study_area.gpkg",
        layer="study_area",
    ).to_crs(config.geographic_crs)
    if raw_snapshot is None:
        response, item, query, windows = acquire_sentinel_snapshot(config, study_area)
        snapshot = save_raw_sentinel_snapshot(
            response,
            item,
            query,
            windows,
            datetime.now(UTC),
            config,
            project_root / "data/raw/sentinel2",
        )
    else:
        snapshot = raw_snapshot.resolve()

    ndvi, transform, raster_crs, valid, metadata = process_raw_sentinel_snapshot(
        snapshot, config
    )
    edges = gpd.read_file(
        project_root / "data/processed/network/clementi_pedestrian_network.gpkg",
        layer="edges",
    )
    road_features = road_ndvi_statistics(
        edges, ndvi, transform, raster_crs, config.road_context_buffer_m
    )
    study_geometry = transform_geom(
        study_area.crs, raster_crs, mapping(study_area.geometry.union_all())
    )
    area_mask = geometry_mask(
        [study_geometry], out_shape=ndvi.shape, transform=transform, invert=True
    )
    valid_in_area = valid & area_mask
    summary = {
        "snapshot_id": snapshot.name,
        "raw_snapshot_reused": raw_snapshot is not None,
        "item_id": metadata["item_id"],
        "acquired_at": metadata["acquired_at"],
        "scene_cloud_cover_percent": metadata["scene_cloud_cover_percent"],
        "valid_scl_classes": metadata["valid_scl_classes"],
        "raster_crs": str(raster_crs),
        "raster_resolution_m": abs(transform.a),
        "study_area_pixel_count": int(area_mask.sum()),
        "study_area_valid_pixel_count": int(valid_in_area.sum()),
        "study_area_valid_pixel_fraction": round(
            float(valid_in_area.sum() / area_mask.sum()), 6
        ),
        "road_segment_count": len(road_features),
        "roads_without_valid_ndvi": int(
            road_features["sentinel2_ndvi_mean"].isna().sum()
        ),
        "mean_road_context_ndvi": round(
            float(road_features["sentinel2_ndvi_mean"].mean()), 6
        ),
        "median_road_context_ndvi": round(
            float(road_features["sentinel2_ndvi_mean"].median()), 6
        ),
        "warning": (
            "NDVI is SCL-masked Sentinel-2 surface-reflectance context. It is "
            "not canopy cover, tree shade, or a thermal measurement."
        ),
    }
    processed_rasters = project_root / "data/processed/rasters"
    processed_features = project_root / "data/processed/features"
    tables = project_root / "outputs/tables"
    processed_rasters.mkdir(parents=True, exist_ok=True)
    processed_features.mkdir(parents=True, exist_ok=True)
    tables.mkdir(parents=True, exist_ok=True)
    ndvi_path = processed_rasters / "clementi_sentinel2_ndvi.tif"
    output_array = np.where(np.isfinite(ndvi), ndvi, -9999).astype("float32")
    with rasterio.open(
        ndvi_path,
        "w",
        driver="GTiff",
        height=ndvi.shape[0],
        width=ndvi.shape[1],
        count=1,
        dtype="float32",
        crs=raster_crs,
        transform=transform,
        nodata=-9999,
        compress="deflate",
    ) as output:
        output.write(output_array, 1)
    geopackage = processed_features / "road_sentinel2_ndvi.gpkg"
    if geopackage.exists():
        geopackage.unlink()
    road_features.to_file(geopackage, layer="road_ndvi", driver="GPKG")
    road_features.drop(columns="geometry").to_csv(
        processed_features / "road_sentinel2_ndvi.csv", index=False
    )
    (processed_features / "sentinel2_ndvi_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    pd.DataFrame([summary]).to_csv(tables / "sentinel2_ndvi_summary.csv", index=False)
    create_ndvi_map(
        road_features,
        project_root / "outputs/maps/clementi_sentinel2_ndvi.html",
        summary,
    )
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(
        description="Build Sentinel-2 L2A road-context NDVI features."
    )
    parser.add_argument(
        "--config", type=Path, default=PROJECT_ROOT / "config/sentinel_ndvi.yaml"
    )
    parser.add_argument("--raw-snapshot", type=Path, default=None)
    args = parser.parse_args()
    print(
        json.dumps(
            build_sentinel_ndvi(args.config, raw_snapshot=args.raw_snapshot),
            indent=2,
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
