"""Partial road-shade evidence from explicit OSM heights and mapped cover."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import numpy as np
import pandas as pd
from shapely.affinity import translate
from shapely.geometry import Polygon
from shapely.geometry.base import BaseGeometry
from shapely.ops import unary_union

from coollink_sg.config import (
    SolarShadeConfig,
    load_built_environment_config,
    load_solar_shade_config,
    load_study_area_config,
)
from coollink_sg.features.built_environment import (
    classify_built_environment_features,
    load_raw_built_environment_snapshot,
)

PROJECT_ROOT = Path(__file__).resolve().parents[3]
_METRIC_HEIGHT = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*(?:m|metres?|meters?)?\s*$", re.I)


def parse_metric_height(value: Any) -> float | None:
    """Parse one unambiguous positive metric OSM height without inference."""

    if value is None or (isinstance(value, float) and math.isnan(value)):
        return None
    if isinstance(value, (int, float)):
        height = float(value)
    else:
        match = _METRIC_HEIGHT.fullmatch(str(value))
        if match is None:
            return None
        height = float(match.group(1))
    return height if math.isfinite(height) and height > 0 else None


def solar_position_noaa(
    local_time: datetime,
    latitude_deg: float,
    longitude_deg: float,
) -> tuple[float, float]:
    """Approximate solar elevation and north-clockwise azimuth using NOAA equations."""

    if local_time.tzinfo is None or local_time.utcoffset() is None:
        raise ValueError("Solar-position time must be timezone-aware")
    if not -90 <= latitude_deg <= 90 or not -180 <= longitude_deg <= 180:
        raise ValueError("Latitude or longitude is outside its valid range")
    utc_time = local_time.astimezone(UTC)
    day = utc_time.timetuple().tm_yday
    utc_fractional_hour = (
        utc_time.hour
        + utc_time.minute / 60
        + utc_time.second / 3600
        + utc_time.microsecond / 3_600_000_000
    )
    local_fractional_hour = (
        local_time.hour
        + local_time.minute / 60
        + local_time.second / 3600
        + local_time.microsecond / 3_600_000_000
    )
    gamma = 2 * math.pi / 365 * (day - 1 + (utc_fractional_hour - 12) / 24)
    equation_of_time = 229.18 * (
        0.000075
        + 0.001868 * math.cos(gamma)
        - 0.032077 * math.sin(gamma)
        - 0.014615 * math.cos(2 * gamma)
        - 0.040849 * math.sin(2 * gamma)
    )
    declination = (
        0.006918
        - 0.399912 * math.cos(gamma)
        + 0.070257 * math.sin(gamma)
        - 0.006758 * math.cos(2 * gamma)
        + 0.000907 * math.sin(2 * gamma)
        - 0.002697 * math.cos(3 * gamma)
        + 0.00148 * math.sin(3 * gamma)
    )
    utc_offset_hours = local_time.utcoffset().total_seconds() / 3600
    time_offset = equation_of_time + 4 * longitude_deg - 60 * utc_offset_hours
    true_solar_minutes = (local_fractional_hour * 60 + time_offset) % 1440
    hour_angle_deg = true_solar_minutes / 4 - 180
    latitude = math.radians(latitude_deg)
    hour_angle = math.radians(hour_angle_deg)
    cos_zenith = (
        math.sin(latitude) * math.sin(declination)
        + math.cos(latitude) * math.cos(declination) * math.cos(hour_angle)
    )
    zenith = math.acos(max(-1.0, min(1.0, cos_zenith)))
    elevation_deg = 90 - math.degrees(zenith)
    azimuth_deg = (
        math.degrees(
            math.atan2(
                math.sin(hour_angle),
                math.cos(hour_angle) * math.sin(latitude)
                - math.tan(declination) * math.cos(latitude),
            )
        )
        + 180
    ) % 360
    return elevation_deg, azimuth_deg


def shadow_offset_m(
    height_m: float,
    solar_elevation_deg: float,
    solar_azimuth_deg: float,
) -> tuple[float, float, float]:
    """Return east/north shadow displacement and horizontal length."""

    if height_m <= 0:
        raise ValueError("Building height must be positive")
    if solar_elevation_deg <= 0:
        raise ValueError("The sun must be above the horizon")
    shadow_length = height_m / math.tan(math.radians(solar_elevation_deg))
    shadow_azimuth = math.radians((solar_azimuth_deg + 180) % 360)
    return (
        shadow_length * math.sin(shadow_azimuth),
        shadow_length * math.cos(shadow_azimuth),
        shadow_length,
    )


def _swept_shadow(
    geometry: BaseGeometry,
    offset_x: float,
    offset_y: float,
) -> BaseGeometry:
    """Create the continuous vector sweep from footprint boundary quadrilaterals."""

    translated = translate(geometry, xoff=offset_x, yoff=offset_y)
    parts: list[BaseGeometry] = [geometry, translated]
    polygons = list(geometry.geoms) if geometry.geom_type == "MultiPolygon" else [geometry]
    for polygon in polygons:
        for ring in [polygon.exterior, *polygon.interiors]:
            coordinates = list(ring.coords)
            for start, end in zip(coordinates[:-1], coordinates[1:], strict=True):
                quadrilateral = Polygon(
                    [
                        start,
                        end,
                        (end[0] + offset_x, end[1] + offset_y),
                        (start[0] + offset_x, start[1] + offset_y),
                    ]
                )
                if not quadrilateral.is_empty and quadrilateral.area > 0:
                    parts.append(quadrilateral)
    return unary_union(parts)


def project_building_shadows(
    source_features: gpd.GeoDataFrame,
    height_field: str,
    solar_elevation_deg: float,
    solar_azimuth_deg: float,
) -> gpd.GeoDataFrame:
    """Project shadows for polygon buildings using one explicit scenario height field."""

    if source_features.crs is None:
        raise ValueError("Built-environment source must have an explicit CRS")
    if height_field not in source_features.columns:
        raise ValueError(f"Built-environment source has no {height_field} field")
    if solar_elevation_deg <= 0:
        raise ValueError("Scenario sun is not above the horizon")
    is_polygon = source_features.geometry.geom_type.isin(["Polygon", "MultiPolygon"])
    is_building = source_features.get(
        "building", pd.Series(index=source_features.index, dtype=object)
    ).notna()
    selected = source_features.loc[is_polygon & is_building].copy()
    selected["height_m"] = selected[height_field].map(parse_metric_height)
    selected = selected.loc[selected["height_m"].notna()].copy()
    shadows: list[BaseGeometry] = []
    lengths: list[float] = []
    for geometry, height in zip(selected.geometry, selected["height_m"], strict=True):
        offset_x, offset_y, length = shadow_offset_m(
            float(height), solar_elevation_deg, solar_azimuth_deg
        )
        shadows.append(_swept_shadow(geometry, offset_x, offset_y))
        lengths.append(length)
    selected["shadow_length_m"] = lengths
    selected["geometry"] = shadows
    keep = [
        column
        for column in [
            "building_id",
            "element",
            "id",
            "building",
            "height_method",
            "height_confidence",
            height_field,
            "height_m",
            "shadow_length_m",
        ]
        if column in selected.columns
    ]
    return gpd.GeoDataFrame(selected[keep + ["geometry"]], geometry="geometry", crs=selected.crs)


def build_structural_cover_geometry(
    source_features: gpd.GeoDataFrame,
    built_config,
    match_tolerance_m: float,
) -> BaseGeometry:
    """Build mapped direct-cover geometry without assigning point shelters an area."""

    _, roofs, covered_ways, shelters = classify_built_environment_features(
        source_features, built_config
    )
    parts: list[BaseGeometry] = []
    if not roofs.empty:
        parts.extend(roofs.geometry.tolist())
    if not covered_ways.empty:
        if match_tolerance_m > 0:
            parts.extend(covered_ways.geometry.buffer(match_tolerance_m).tolist())
        else:
            parts.extend(covered_ways.geometry.tolist())
    shelter_polygons = shelters.loc[
        shelters.geometry.geom_type.isin(["Polygon", "MultiPolygon"])
    ]
    if not shelter_polygons.empty:
        parts.extend(shelter_polygons.geometry.tolist())
    return unary_union(parts) if parts else unary_union([])


def calculate_road_shade_evidence(
    roads: gpd.GeoDataFrame,
    shadow_geometry_low: BaseGeometry,
    shadow_geometry_central: BaseGeometry,
    shadow_geometry_high: BaseGeometry,
    structural_cover_geometry: BaseGeometry,
    building_passage_values: tuple[str, ...],
    scenario_time_sgt: str,
    solar_elevation_deg: float,
    solar_azimuth_deg: float,
) -> gpd.GeoDataFrame:
    """Calculate separate and combined line fractions for each stable road segment."""

    required = {"segment_id", "length_m", "geometry"}
    missing = required.difference(roads.columns)
    if missing:
        raise ValueError(f"Roads are missing fields: {sorted(missing)}")
    if roads.crs is None:
        raise ValueError("Roads must have an explicit CRS")
    if roads["segment_id"].duplicated().any():
        raise ValueError("Road segment_id values must be unique")
    result = roads[["segment_id", "length_m", "geometry"]].copy()
    tunnel = roads.get("tunnel", pd.Series(index=roads.index, dtype=object))
    normalized_passages = {value.casefold() for value in building_passage_values}
    passage = tunnel.map(
        lambda value: str(value).strip().casefold() in normalized_passages
        if pd.notna(value)
        else False
    )
    def intersection_length(geometry: BaseGeometry) -> pd.Series:
        return (
            result.geometry.intersection(geometry).length
            if not geometry.is_empty
            else pd.Series(0.0, index=result.index)
        )

    shadow_lengths = {
        "low": intersection_length(shadow_geometry_low),
        "central": intersection_length(shadow_geometry_central),
        "high": intersection_length(shadow_geometry_high),
    }
    structural_length = (
        result.geometry.intersection(structural_cover_geometry).length
        if not structural_cover_geometry.is_empty
        else pd.Series(0.0, index=result.index)
    )
    structural_length = structural_length.where(~passage, result.geometry.length)
    shadow_geometries = {
        "low": shadow_geometry_low,
        "central": shadow_geometry_central,
        "high": shadow_geometry_high,
    }
    combined_lengths: dict[str, pd.Series] = {}
    for scenario, shadow_geometry in shadow_geometries.items():
        combined_geometry = unary_union([shadow_geometry, structural_cover_geometry])
        combined = (
            result.geometry.intersection(combined_geometry).length
            if not combined_geometry.is_empty
            else pd.Series(0.0, index=result.index)
        )
        combined_lengths[scenario] = combined.where(~passage, result.geometry.length)
    denominator = pd.to_numeric(result["length_m"], errors="raise")
    if (denominator <= 0).any():
        raise ValueError("Road length_m must be positive")
    result["scenario_time_sgt"] = scenario_time_sgt
    result["solar_elevation_deg"] = solar_elevation_deg
    result["solar_azimuth_deg"] = solar_azimuth_deg
    for scenario, values in shadow_lengths.items():
        length_field = f"building_shadow_length_{scenario}_m"
        fraction_field = f"building_shadow_fraction_{scenario}"
        result[length_field] = np.minimum(values, denominator)
        result[fraction_field] = (result[length_field] / denominator).clip(0, 1)
    result["direct_mapped_cover_length_m"] = np.minimum(structural_length, denominator)
    result["direct_mapped_cover_fraction"] = (
        result["direct_mapped_cover_length_m"] / denominator
    ).clip(0, 1)
    for scenario, values in combined_lengths.items():
        length_field = f"combined_shade_evidence_length_{scenario}_m"
        fraction_field = f"combined_shade_evidence_fraction_{scenario}"
        result[length_field] = np.minimum(values, denominator)
        result[fraction_field] = (result[length_field] / denominator).clip(0, 1)
    # Preserve the established central-scenario field names for compatibility.
    result["combined_shade_evidence_length_m"] = result[
        "combined_shade_evidence_length_central_m"
    ]
    result["combined_shade_evidence_fraction"] = result[
        "combined_shade_evidence_fraction_central"
    ]
    has_shadow = result["building_shadow_fraction_central"] > 0
    has_cover = result["direct_mapped_cover_fraction"] > 0
    result["shade_evidence_class"] = np.select(
        [has_shadow & has_cover, has_shadow, has_cover],
        [
            "building_shadow_and_direct_cover",
            "building_shadow_only",
            "direct_mapped_cover_only",
        ],
        default="none_observed_in_incomplete_sources",
    )
    result["shade_model_status"] = (
        "estimated_building_heights_and_mapped_cover_not_validated"
    )
    return gpd.GeoDataFrame(result, geometry="geometry", crs=roads.crs)


def summarize_solar_shade(
    road_evidence: gpd.GeoDataFrame,
    shadow_scenarios: dict[str, gpd.GeoDataFrame],
    height_features: gpd.GeoDataFrame,
    config: SolarShadeConfig,
    solar_elevation_deg: float,
    solar_azimuth_deg: float,
) -> dict[str, Any]:
    """Summarize evidence coverage and explicitly retain model incompleteness."""

    method_counts = height_features["height_method"].value_counts().sort_index()
    return {
        "model_id": config.model_id,
        "scenario_time_sgt": config.scenario_time_sgt,
        "source_weather_snapshot_id": config.source_weather_snapshot_id,
        "solar_position_method": config.solar_position_method,
        "solar_elevation_deg": round(solar_elevation_deg, 6),
        "solar_azimuth_deg": round(solar_azimuth_deg, 6),
        "analysis_crs": config.analysis_crs,
        "segment_count": len(road_evidence),
        "mapped_building_polygon_count": int(len(height_features)),
        "building_height_method_counts": {
            str(key): int(value) for key, value in method_counts.items()
        },
        "direct_osm_height_count": int(
            height_features["height_is_direct_osm_observation"].sum()
        ),
        "estimated_height_count": int(
            (~height_features["height_is_direct_osm_observation"]).sum()
        ),
        "building_level_height_conversion_performed": True,
        "projected_shadow_feature_count_per_scenario": {
            key: len(value) for key, value in shadow_scenarios.items()
        },
        "direct_cover_match_tolerance_m": config.direct_cover_match_tolerance_m,
        "shadow_projection_method": config.shadow_projection_method,
        "segments_with_building_shadow_low": int(
            (road_evidence["building_shadow_fraction_low"] > 0).sum()
        ),
        "segments_with_building_shadow_central": int(
            (road_evidence["building_shadow_fraction_central"] > 0).sum()
        ),
        "segments_with_building_shadow_high": int(
            (road_evidence["building_shadow_fraction_high"] > 0).sum()
        ),
        "segments_with_direct_mapped_cover": int(
            (road_evidence["direct_mapped_cover_fraction"] > 0).sum()
        ),
        "segments_with_any_combined_evidence": int(
            (road_evidence["combined_shade_evidence_fraction"] > 0).sum()
        ),
        "mean_building_shadow_fraction_low": round(
            float(road_evidence["building_shadow_fraction_low"].mean()), 6
        ),
        "mean_building_shadow_fraction_central": round(
            float(road_evidence["building_shadow_fraction_central"].mean()), 6
        ),
        "mean_building_shadow_fraction_high": round(
            float(road_evidence["building_shadow_fraction_high"].mean()), 6
        ),
        "mean_direct_mapped_cover_fraction": round(
            float(road_evidence["direct_mapped_cover_fraction"].mean()), 6
        ),
        "mean_combined_shade_evidence_fraction": round(
            float(road_evidence["combined_shade_evidence_fraction"].mean()), 6
        ),
        "validated_shade_fraction_generated": False,
        "heat_model_input_generated": False,
        "warning": (
            "This is scenario-specific sensitivity evidence, not validated shade. "
            "Most building heights are estimates or imputations; tree-crown shadows "
            "and diffuse radiation are absent, and mapped cover geometry may be "
            "incomplete or misaligned."
        ),
    }


def create_solar_shade_map(
    road_evidence: gpd.GeoDataFrame,
    shadows: gpd.GeoDataFrame,
    latitude: float,
    longitude: float,
    config: SolarShadeConfig,
    output_path: Path,
) -> None:
    """Create an interactive structural QA map for the partial evidence model."""

    map_object = folium.Map(
        location=[latitude, longitude], zoom_start=14, tiles="OpenStreetMap", control_scale=True
    )
    if not shadows.empty:
        folium.GeoJson(
            shadows.to_crs(config.geographic_crs).to_json(),
            name="Projected central-height building shadows",
            style_function=lambda _feature: {
                "color": "#4338ca",
                "weight": 1,
                "fillColor": "#6366f1",
                "fillOpacity": 0.25,
            },
        ).add_to(map_object)
    display = road_evidence.to_crs(config.geographic_crs).copy()
    for field in [
        "building_shadow_fraction_low",
        "building_shadow_fraction_central",
        "building_shadow_fraction_high",
        "direct_mapped_cover_fraction",
        "combined_shade_evidence_fraction",
    ]:
        display[field] = display[field].round(3)

    def style(feature: dict[str, Any]) -> dict[str, Any]:
        fraction = float(feature["properties"]["combined_shade_evidence_fraction"])
        colour = "#166534" if fraction >= 0.75 else "#65a30d" if fraction > 0 else "#cbd5e1"
        return {"color": colour, "weight": 3 if fraction > 0 else 1, "opacity": 0.85}

    folium.GeoJson(
        display[
            [
                "segment_id",
                "building_shadow_fraction_low",
                "building_shadow_fraction_central",
                "building_shadow_fraction_high",
                "direct_mapped_cover_fraction",
                "combined_shade_evidence_fraction",
                "shade_evidence_class",
                "geometry",
            ]
        ].to_json(),
        name="Road shade evidence",
        style_function=style,
        tooltip=folium.GeoJsonTooltip(
            fields=[
                "segment_id",
                "building_shadow_fraction_low",
                "building_shadow_fraction_central",
                "building_shadow_fraction_high",
                "direct_mapped_cover_fraction",
                "combined_shade_evidence_fraction",
                "shade_evidence_class",
            ],
            aliases=[
                "Segment",
                "Building shadow (low)",
                "Building shadow (central)",
                "Building shadow (high)",
                "Mapped cover",
                "Combined evidence",
                "Class",
            ],
        ),
    ).add_to(map_object)
    note = f"""
    <div style="position:fixed;left:18px;bottom:28px;z-index:9999;background:white;
    padding:10px;border:1px solid #64748b;font-size:12px;max-width:350px">
    <b>Building-shadow sensitivity evidence</b><br>
    Scenario: {config.scenario_time_sgt}<br>
    Low/central/high height scenarios; most heights are estimated or imputed.<br>
    Mapped direct cover is kept separate.<br>
    <b>Not a validated shade fraction or Heat Score input.</b><br>
    <small>© OpenStreetMap contributors · ODbL 1.0</small></div>
    """
    map_object.get_root().html.add_child(folium.Element(note))
    folium.LayerControl(collapsed=False).add_to(map_object)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    map_object.save(output_path)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def build_solar_shade_evidence(
    config_path: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Build, export, and map the configured partial shade-evidence scenario."""

    config = load_solar_shade_config(config_path)
    built_config = load_built_environment_config(
        project_root / config.built_environment_config_path
    )
    study_area = load_study_area_config(project_root / config.study_area_config_path)
    road_path = project_root / config.roads.path
    height_path = project_root / config.building_heights.path
    raw_snapshot = project_root / config.built_environment_raw_snapshot
    raw_geopackage = raw_snapshot / "osm_built_environment_features.gpkg"
    roads = gpd.read_file(road_path, layer=config.roads.layer).to_crs(config.analysis_crs)
    height_features = gpd.read_file(
        height_path, layer=config.building_heights.layer
    ).to_crs(config.analysis_crs)
    source = load_raw_built_environment_snapshot(raw_snapshot).to_crs(config.analysis_crs)
    scenario = datetime.fromisoformat(config.scenario_time_sgt)
    elevation, azimuth = solar_position_noaa(
        scenario, study_area.latitude, study_area.longitude
    )
    shadow_scenarios = {
        scenario_name: project_building_shadows(
            height_features,
            height_field,
            elevation,
            azimuth,
        )
        for scenario_name, height_field in {
            "low": "height_low_m",
            "central": "height_central_m",
            "high": "height_high_m",
        }.items()
    }
    shadow_geometries = {
        name: frame.geometry.union_all() if not frame.empty else unary_union([])
        for name, frame in shadow_scenarios.items()
    }
    structural_geometry = build_structural_cover_geometry(
        source, built_config, config.direct_cover_match_tolerance_m
    )
    evidence = calculate_road_shade_evidence(
        roads,
        shadow_geometries["low"],
        shadow_geometries["central"],
        shadow_geometries["high"],
        structural_geometry,
        built_config.building_passage_values,
        config.scenario_time_sgt,
        elevation,
        azimuth,
    )
    summary = summarize_solar_shade(
        evidence, shadow_scenarios, height_features, config, elevation, azimuth
    )
    summary["input_sha256"] = {
        "roads": _sha256(road_path),
        "raw_built_environment": _sha256(raw_geopackage),
        "building_heights": _sha256(height_path),
    }
    processed = project_root / "data/processed/features"
    maps = project_root / "outputs/maps"
    tables = project_root / "outputs/tables"
    processed.mkdir(parents=True, exist_ok=True)
    maps.mkdir(parents=True, exist_ok=True)
    tables.mkdir(parents=True, exist_ok=True)
    road_gpkg = processed / "road_partial_solar_shade_evidence.gpkg"
    shadow_gpkg = processed / "building_shadow_height_scenarios.gpkg"
    for path in [road_gpkg, shadow_gpkg]:
        if path.exists():
            path.unlink()
    evidence.to_file(road_gpkg, layer="road_shade_evidence", driver="GPKG")
    for index, (scenario_name, shadows) in enumerate(shadow_scenarios.items()):
        if not shadows.empty:
            shadows.to_file(
                shadow_gpkg,
                layer=f"building_shadows_{scenario_name}",
                driver="GPKG",
                mode="w" if index == 0 else "a",
            )
    evidence.drop(columns="geometry").to_csv(
        processed / "road_partial_solar_shade_evidence.csv", index=False
    )
    (processed / "solar_shade_evidence_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    flat = {key: value for key, value in summary.items() if key != "input_sha256"}
    pd.DataFrame([flat]).to_csv(tables / "solar_shade_evidence_summary.csv", index=False)
    create_solar_shade_map(
        evidence,
        shadow_scenarios["central"],
        study_area.latitude,
        study_area.longitude,
        config,
        maps / "clementi_partial_solar_shade_evidence.html",
    )
    return summary


def main() -> None:
    """Command-line entry point."""

    parser = argparse.ArgumentParser(description="Build partial road solar-shade evidence.")
    parser.add_argument(
        "--config", type=Path, default=PROJECT_ROOT / "config/solar_shade.yaml"
    )
    args = parser.parse_args()
    print(json.dumps(build_solar_shade_evidence(args.config), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
