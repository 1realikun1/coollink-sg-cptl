"""Acquire and prepare open 3D inputs for one national SOLWEIG tile."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import folium
import geopandas as gpd
import numpy as np
import rasterio
import requests
import yaml
from pyproj import CRS
from rasterio.enums import Resampling
from rasterio.features import rasterize
from rasterio.transform import from_origin
from rasterio.warp import reproject, transform_bounds
from rasterio.windows import Window, from_bounds
from shapely.geometry import box

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class EnhancedTileConfig:
    """Validated sample-tile acquisition settings."""

    analysis_id: str
    tile_id: str
    snapshot_id: str
    geographic_crs: str
    analysis_crs: str
    target_resolution_m: float
    expected_buffer_m: float
    tile_index_path: str
    tile_index_layer: str
    current_building_dsm_path: str
    current_buildings_path: str
    current_buildings_layer: str
    study_area_path: str
    study_area_layer: str
    raw_snapshot_directory: str
    open_buildings_supplement_directory: str
    sources: dict[str, dict[str, Any]]
    output_directory: str
    readiness_path: str
    comparison_path: str
    map_path: str
    presence_thresholds: tuple[float, ...]
    resampling: dict[str, str]


@dataclass(frozen=True)
class TargetGrid:
    """One north-up target raster grid."""

    crs: str
    bounds: tuple[float, float, float, float]
    resolution_m: float
    width: int
    height: int
    transform: rasterio.Affine


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    try:
        return mapping[key]
    except KeyError as exc:
        raise ValueError(f"Missing required field '{section}.{key}'") from exc


def load_enhanced_tile_config(path: str | Path) -> EnhancedTileConfig:
    """Load and validate one enhanced-tile YAML configuration."""

    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Enhanced-tile configuration must be a YAML mapping")
    model = _required(payload, "enhanced_tile", "root")
    inputs = _required(payload, "inputs", "root")
    outputs = _required(payload, "outputs", "root")
    tile_index = _required(inputs, "national_tile_index", "inputs")
    buildings = _required(inputs, "current_buildings", "inputs")
    study_area = _required(inputs, "study_area", "inputs")
    sources = _required(payload, "sources", "root")
    processing = _required(payload, "processing", "root")
    geographic_crs = str(_required(model, "geographic_crs", "enhanced_tile"))
    analysis_crs = str(_required(model, "analysis_crs", "enhanced_tile"))
    if not CRS.from_user_input(geographic_crs).is_geographic:
        raise ValueError("enhanced_tile.geographic_crs must be geographic")
    if not CRS.from_user_input(analysis_crs).is_projected:
        raise ValueError("enhanced_tile.analysis_crs must be projected")
    resolution = float(_required(model, "target_resolution_m", "enhanced_tile"))
    buffer_m = float(_required(model, "expected_buffer_m", "enhanced_tile"))
    if resolution <= 0 or buffer_m < 0:
        raise ValueError("Target resolution must be positive and buffer non-negative")
    if not isinstance(sources, dict) or set(sources) != {
        "google_open_buildings_2_5d_2023",
        "meta_chmv2",
        "esa_worldcover_2021",
        "copernicus_dem_glo30",
    }:
        raise ValueError("The enhanced sample must configure all four open sources")
    thresholds = tuple(
        float(value)
        for value in _required(
            processing,
            "open_buildings_presence_threshold_sweep",
            "processing",
        )
    )
    if not thresholds or any(not 0 < value < 1 for value in thresholds):
        raise ValueError("Open Buildings thresholds must be between zero and one")
    resampling_keys = (
        "canopy_resampling",
        "open_buildings_presence_resampling",
        "open_buildings_height_resampling",
        "open_buildings_count_resampling",
        "surface_elevation_resampling",
        "land_cover_resampling",
    )
    return EnhancedTileConfig(
        analysis_id=str(_required(model, "analysis_id", "enhanced_tile")),
        tile_id=str(_required(model, "tile_id", "enhanced_tile")),
        snapshot_id=str(_required(model, "snapshot_id", "enhanced_tile")),
        geographic_crs=geographic_crs,
        analysis_crs=analysis_crs,
        target_resolution_m=resolution,
        expected_buffer_m=buffer_m,
        tile_index_path=str(_required(tile_index, "path", "inputs.national_tile_index")),
        tile_index_layer=str(_required(tile_index, "layer", "inputs.national_tile_index")),
        current_building_dsm_path=str(
            _required(inputs, "current_building_dsm", "inputs")
        ),
        current_buildings_path=str(
            _required(buildings, "path", "inputs.current_buildings")
        ),
        current_buildings_layer=str(
            _required(buildings, "layer", "inputs.current_buildings")
        ),
        study_area_path=str(_required(study_area, "path", "inputs.study_area")),
        study_area_layer=str(_required(study_area, "layer", "inputs.study_area")),
        raw_snapshot_directory=str(
            _required(payload, "raw_snapshot_directory", "root")
        ),
        open_buildings_supplement_directory=str(
            _required(payload, "open_buildings_supplement_directory", "root")
        ),
        sources={str(key): dict(value) for key, value in sources.items()},
        output_directory=str(_required(outputs, "directory", "outputs")),
        readiness_path=str(_required(outputs, "readiness", "outputs")),
        comparison_path=str(_required(outputs, "comparison", "outputs")),
        map_path=str(_required(outputs, "map", "outputs")),
        presence_thresholds=thresholds,
        resampling={
            key: str(_required(processing, key, "processing")) for key in resampling_keys
        },
    )


def load_buffered_tile_geometry(
    config: EnhancedTileConfig,
    project_root: Path = PROJECT_ROOT,
) -> gpd.GeoDataFrame:
    """Load exactly one configured tile and reconstruct its buffered bounds."""

    tiles = gpd.read_file(
        project_root / config.tile_index_path,
        layer=config.tile_index_layer,
    )
    if tiles.crs is None:
        raise ValueError("National tile index must have an explicit CRS")
    selected = tiles.loc[tiles["tile_id"].eq(config.tile_id)]
    if len(selected) != 1:
        raise ValueError(f"Expected one national tile for {config.tile_id}")
    row = selected.iloc[0]
    if float(row["buffer_m"]) != config.expected_buffer_m:
        raise ValueError("Configured buffer does not match national tile index")
    geometry = box(
        float(row["buffer_xmin_m"]),
        float(row["buffer_ymin_m"]),
        float(row["buffer_xmax_m"]),
        float(row["buffer_ymax_m"]),
    )
    return gpd.GeoDataFrame(
        {"tile_id": [config.tile_id], "geometry": [geometry]},
        crs=tiles.crs,
    ).to_crs(config.analysis_crs)


def select_meta_tiles(
    index: gpd.GeoDataFrame,
    buffered_tile: gpd.GeoDataFrame,
    geographic_crs: str,
) -> tuple[str, ...]:
    """Select unique CHMv2 quadkeys intersecting the buffered sample tile."""

    if index.crs is None or buffered_tile.crs is None:
        raise ValueError("CHMv2 index and buffered tile must have explicit CRS")
    if "tile" not in index.columns:
        raise ValueError("CHMv2 tile index must contain the 'tile' field")
    aoi = buffered_tile.to_crs(geographic_crs).geometry.union_all()
    candidates = index.to_crs(geographic_crs)
    selected = candidates.loc[candidates.geometry.intersects(aoi), "tile"].dropna()
    tile_ids = tuple(sorted({str(value) for value in selected}))
    if not tile_ids:
        raise ValueError("No CHMv2 tiles intersect the configured sample")
    return tile_ids


def make_target_grid(
    buffered_tile: gpd.GeoDataFrame,
    analysis_crs: str,
    resolution_m: float,
) -> TargetGrid:
    """Create an exact target grid from the configured buffered rectangle."""

    projected = buffered_tile.to_crs(analysis_crs)
    min_x, min_y, max_x, max_y = (float(value) for value in projected.total_bounds)
    width_float = (max_x - min_x) / resolution_m
    height_float = (max_y - min_y) / resolution_m
    width = int(round(width_float))
    height = int(round(height_float))
    if not np.isclose(width, width_float) or not np.isclose(height, height_float):
        raise ValueError("Buffered bounds are not divisible by target resolution")
    return TargetGrid(
        crs=analysis_crs,
        bounds=(min_x, min_y, max_x, max_y),
        resolution_m=resolution_m,
        width=width,
        height=height,
        transform=from_origin(min_x, max_y, resolution_m, resolution_m),
    )


def _resampling(name: str) -> Resampling:
    supported = {
        "nearest": Resampling.nearest,
        "bilinear": Resampling.bilinear,
        "average": Resampling.average,
        "max": Resampling.max,
    }
    try:
        return supported[name]
    except KeyError as exc:
        raise ValueError(f"Unsupported resampling method: {name}") from exc


def warp_source_mosaic(
    source_paths: tuple[Path, ...],
    band: int,
    grid: TargetGrid,
    resampling_name: str,
    source_nodata_override: float | None = None,
) -> np.ndarray:
    """Window-read and warp one or more source COGs into the 5 m target grid."""

    if not source_paths:
        raise ValueError("At least one source raster is required")
    destination_nodata = -9999.0
    destination = np.full((grid.height, grid.width), destination_nodata, dtype=np.float32)
    for index, path in enumerate(source_paths):
        with rasterio.open(path) as source:
            if source.crs is None:
                raise ValueError(f"Source raster has no CRS: {path}")
            source_bounds = transform_bounds(
                grid.crs,
                source.crs,
                *grid.bounds,
                densify_pts=21,
            )
            window = from_bounds(*source_bounds, transform=source.transform)
            window = window.round_offsets().round_lengths().intersection(
                Window(0, 0, source.width, source.height)
            )
            source_array = source.read(band, window=window, masked=True)
            source_nodata = (
                source_nodata_override
                if source_nodata_override is not None
                else source.nodata
            )
            if source_nodata is None:
                source_nodata = -9999.0
            source_data = source_array.astype(np.float32).filled(float(source_nodata))
            reproject(
                source=source_data,
                destination=destination,
                src_transform=source.window_transform(window),
                src_crs=source.crs,
                src_nodata=float(source_nodata),
                dst_transform=grid.transform,
                dst_crs=grid.crs,
                dst_nodata=destination_nodata,
                resampling=_resampling(resampling_name),
                init_dest_nodata=index == 0,
            )
    return np.ma.masked_equal(destination, destination_nodata)


def _write_raster(
    path: Path,
    data: np.ndarray,
    grid: TargetGrid,
    dtype: str,
    nodata: float | int,
    tags: dict[str, Any],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    array = np.ma.asarray(data)
    profile = {
        "driver": "GTiff",
        "width": grid.width,
        "height": grid.height,
        "count": 1,
        "crs": grid.crs,
        "transform": grid.transform,
        "dtype": dtype,
        "nodata": nodata,
        "compress": "deflate",
        "predictor": 2,
        "tiled": True,
        "blockxsize": 256,
        "blockysize": 256,
    }
    with rasterio.open(path, "w", **profile) as target:
        target.write(array.filled(nodata).astype(dtype), 1)
        target.update_tags(**{str(key): str(value) for key, value in tags.items()})


def _valid_values(array: np.ndarray) -> np.ndarray:
    return np.ma.asarray(array).compressed().astype(float)


def _continuous_summary(array: np.ndarray) -> dict[str, Any]:
    values = _valid_values(array)
    if not len(values):
        raise ValueError("Cannot summarize an empty raster")
    return {
        "valid_cell_count": int(len(values)),
        "valid_fraction": float(len(values) / np.ma.asarray(array).size),
        "minimum": float(values.min()),
        "median": float(np.median(values)),
        "p95": float(np.quantile(values, 0.95)),
        "maximum": float(values.max()),
        "mean": float(values.mean()),
    }


def binary_overlap_metrics(
    reference: np.ndarray,
    candidate: np.ndarray,
    valid_mask: np.ndarray,
) -> dict[str, Any]:
    """Compare two binary masks without calling either one ground truth."""

    reference_bool = np.asarray(reference, dtype=bool) & valid_mask
    candidate_bool = np.asarray(candidate, dtype=bool) & valid_mask
    tp = int(np.sum(reference_bool & candidate_bool))
    fp = int(np.sum(~reference_bool & candidate_bool & valid_mask))
    fn = int(np.sum(reference_bool & ~candidate_bool & valid_mask))
    tn = int(np.sum(~reference_bool & ~candidate_bool & valid_mask))
    precision = tp / (tp + fp) if tp + fp else None
    recall = tp / (tp + fn) if tp + fn else None
    iou = tp / (tp + fp + fn) if tp + fp + fn else None
    return {
        "overlap_cell_count": tp,
        "candidate_only_cell_count": fp,
        "reference_only_cell_count": fn,
        "neither_cell_count": tn,
        "precision_against_osm_proxy": precision,
        "recall_against_osm_proxy": recall,
        "intersection_over_union_against_osm_proxy": iou,
    }


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def _download_with_resume(url: str, target: Path, timeout_seconds: float = 120) -> None:
    """Download to a staging path, resuming only when the server supports ranges."""

    target.parent.mkdir(parents=True, exist_ok=True)
    head = requests.head(url, timeout=timeout_seconds, allow_redirects=True)
    head.raise_for_status()
    expected = int(head.headers["Content-Length"])
    existing = target.stat().st_size if target.exists() else 0
    if existing == expected:
        print(f"ready {target.name}: {existing:,} bytes", flush=True)
        return
    headers: dict[str, str] = {}
    mode = "wb"
    if 0 < existing < expected:
        headers["Range"] = f"bytes={existing}-"
        mode = "ab"
    response = requests.get(url, headers=headers, stream=True, timeout=timeout_seconds)
    response.raise_for_status()
    if mode == "ab" and response.status_code != 206:
        mode = "wb"
        existing = 0
    downloaded = existing
    next_report = downloaded + 64 * 1024 * 1024
    with target.open(mode) as stream:
        for chunk in response.iter_content(chunk_size=4 * 1024 * 1024):
            if not chunk:
                continue
            stream.write(chunk)
            downloaded += len(chunk)
            if downloaded >= next_report:
                print(
                    f"downloading {target.name}: {downloaded / 1024**2:.0f} MiB "
                    f"of {expected / 1024**2:.0f} MiB",
                    flush=True,
                )
                next_report += 64 * 1024 * 1024
    if target.stat().st_size != expected:
        raise OSError(
            f"Incomplete download for {target.name}: {target.stat().st_size} != {expected}"
        )


def acquire_enhanced_tile_sources(
    config: EnhancedTileConfig,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Acquire all source files atomically into one immutable raw snapshot."""

    raw_directory = project_root / config.raw_snapshot_directory
    if raw_directory.exists():
        raise FileExistsError(f"Raw snapshot already exists and is immutable: {raw_directory}")
    staging = project_root / "work" / "enhanced_tile_acquisition" / config.snapshot_id
    staging.mkdir(parents=True, exist_ok=True)
    buffered_tile = load_buffered_tile_geometry(config, project_root)
    records: list[dict[str, Any]] = []

    for source_id in (
        "google_open_buildings_2_5d_2023",
        "esa_worldcover_2021",
        "copernicus_dem_glo30",
    ):
        source = config.sources[source_id]
        relative = Path(source_id) / str(source["filename"])
        target = staging / relative
        _download_with_resume(str(source["url"]), target)
        records.append(
            {
                "source_id": source_id,
                "relative_path": relative.as_posix(),
                "url": source["url"],
                "size_bytes": target.stat().st_size,
                "sha256": _sha256(target),
            }
        )

    meta = config.sources["meta_chmv2"]
    index_relative = Path("meta_chmv2") / str(meta["index_filename"])
    index_path = staging / index_relative
    _download_with_resume(str(meta["index_url"]), index_path)
    records.append(
        {
            "source_id": "meta_chmv2_index",
            "relative_path": index_relative.as_posix(),
            "url": meta["index_url"],
            "size_bytes": index_path.stat().st_size,
            "sha256": _sha256(index_path),
        }
    )
    meta_index = gpd.read_file(index_path)
    meta_tiles = select_meta_tiles(meta_index, buffered_tile, config.geographic_crs)
    for tile_id in meta_tiles:
        url = str(meta["tile_url_template"]).format(tile=tile_id)
        relative = Path("meta_chmv2") / "chm" / f"{tile_id}.tif"
        target = staging / relative
        _download_with_resume(url, target)
        records.append(
            {
                "source_id": "meta_chmv2",
                "tile_id": tile_id,
                "relative_path": relative.as_posix(),
                "url": url,
                "size_bytes": target.stat().st_size,
                "sha256": _sha256(target),
            }
        )

    bounds = buffered_tile.to_crs(config.geographic_crs).total_bounds.tolist()
    manifest = {
        "analysis_id": config.analysis_id,
        "snapshot_id": config.snapshot_id,
        "retrieval_date": "2026-08-19",
        "tile_id": config.tile_id,
        "buffered_bounds_wgs84": bounds,
        "source_records": records,
        "source_metadata": config.sources,
        "meta_chmv2_tile_ids": list(meta_tiles),
    }
    staging.joinpath("manifest.json").write_text(
        json.dumps(manifest, indent=2, default=str), encoding="utf-8"
    )
    raw_directory.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(staging), str(raw_directory))
    return manifest


def acquire_open_buildings_supplement(
    config: EnhancedTileConfig,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Acquire the second Open Buildings COG intersecting the buffered tile."""

    raw_directory = project_root / config.open_buildings_supplement_directory
    if raw_directory.exists():
        raise FileExistsError(f"Raw supplement already exists and is immutable: {raw_directory}")
    staging = (
        project_root
        / "work"
        / "enhanced_tile_acquisition"
        / f"{config.snapshot_id}_open_buildings_east"
    )
    staging.mkdir(parents=True, exist_ok=True)
    source = config.sources["google_open_buildings_2_5d_2023"]
    downloads = (
        (str(source["manifest_url"]), str(source["manifest_filename"])),
        (str(source["supplemental_url"]), str(source["supplemental_filename"])),
    )
    records: list[dict[str, Any]] = []
    for url, filename in downloads:
        target = staging / filename
        _download_with_resume(url, target)
        records.append(
            {
                "filename": filename,
                "url": url,
                "size_bytes": target.stat().st_size,
                "sha256": _sha256(target),
            }
        )
    manifest = {
        "analysis_id": config.analysis_id,
        "snapshot_id": f"{config.snapshot_id}_open_buildings_east",
        "retrieval_date": "2026-08-19",
        "tile_id": config.tile_id,
        "reason": (
            "The buffered sample intersects two official Open Buildings manifest "
            "sources; this immutable supplement preserves the eastern source COG."
        ),
        "source_records": records,
    }
    staging.joinpath("manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )
    raw_directory.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(staging), str(raw_directory))
    return manifest


def _render_input_map(
    canopy: np.ndarray,
    building_presence: np.ndarray,
    buffered_tile: gpd.GeoDataFrame,
    output_path: Path,
) -> None:
    """Render two continuous input overlays for visual QA only."""

    wgs84 = buffered_tile.to_crs("EPSG:4326")
    min_x, min_y, max_x, max_y = (float(value) for value in wgs84.total_bounds)
    center = wgs84.geometry.union_all().centroid
    map_object = folium.Map(
        location=[center.y, center.x],
        zoom_start=14,
        tiles="CartoDB positron",
        control_scale=True,
    )
    canopy_image = np.clip(np.ma.asarray(canopy).filled(0) / 50.0, 0, 1)
    presence_image = np.clip(np.ma.asarray(building_presence).filled(0), 0, 1)
    folium.raster_layers.ImageOverlay(
        image=canopy_image,
        bounds=[[min_y, min_x], [max_y, max_x]],
        origin="upper",
        colormap=lambda value: (0.05, 0.25 + 0.65 * value, 0.15, 0.72 * value),
        opacity=0.8,
        name="Meta CHMv2 canopy height (0–50 m display scale)",
    ).add_to(map_object)
    folium.raster_layers.ImageOverlay(
        image=presence_image,
        bounds=[[min_y, min_x], [max_y, max_x]],
        origin="upper",
        colormap=lambda value: (0.8, 0.08, 0.04, 0.68 * value),
        opacity=0.7,
        name="Open Buildings presence (unthresholded)",
    ).add_to(map_object)
    folium.GeoJson(
        wgs84,
        name="Buffered sample tile",
        style_function=lambda _feature: {
            "fillOpacity": 0,
            "color": "#222222",
            "weight": 2,
        },
        tooltip="SG3414_E020000_N032000 buffered input extent",
    ).add_to(map_object)
    folium.LayerControl(collapsed=False).add_to(map_object)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    map_object.save(output_path)


def process_enhanced_tile_inputs(
    config: EnhancedTileConfig,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Clip, warp, compare, and document all acquired sample-tile sources."""

    raw_directory = project_root / config.raw_snapshot_directory
    supplement = project_root / config.open_buildings_supplement_directory
    if not raw_directory.exists() or not supplement.exists():
        raise FileNotFoundError("Acquire both immutable raw snapshots before processing")
    buffered_tile = load_buffered_tile_geometry(config, project_root)
    grid = make_target_grid(buffered_tile, config.analysis_crs, config.target_resolution_m)
    output_directory = project_root / config.output_directory
    output_directory.mkdir(parents=True, exist_ok=True)

    primary_ob = (
        raw_directory
        / "google_open_buildings_2_5d_2023"
        / str(config.sources["google_open_buildings_2_5d_2023"]["filename"])
    )
    eastern_ob = supplement / str(
        config.sources["google_open_buildings_2_5d_2023"]["supplemental_filename"]
    )
    open_buildings_paths = (primary_ob, eastern_ob)
    with rasterio.open(primary_ob) as source:
        descriptions = {str(name): index + 1 for index, name in enumerate(source.descriptions)}
    expected_bands = {
        "building_fractional_count",
        "building_height",
        "building_presence",
    }
    if set(descriptions) != expected_bands:
        raise ValueError(f"Unexpected Open Buildings bands: {descriptions}")

    presence = warp_source_mosaic(
        open_buildings_paths,
        descriptions["building_presence"],
        grid,
        config.resampling["open_buildings_presence_resampling"],
    )
    predicted_height = warp_source_mosaic(
        open_buildings_paths,
        descriptions["building_height"],
        grid,
        config.resampling["open_buildings_height_resampling"],
    )
    fractional_count = warp_source_mosaic(
        open_buildings_paths,
        descriptions["building_fractional_count"],
        grid,
        config.resampling["open_buildings_count_resampling"],
    )
    meta_paths = tuple(sorted(raw_directory.glob("meta_chmv2/chm/*.tif")))
    canopy = warp_source_mosaic(
        meta_paths,
        1,
        grid,
        config.resampling["canopy_resampling"],
        source_nodata_override=float(config.sources["meta_chmv2"]["nodata"]),
    )
    worldcover_path = (
        raw_directory
        / "esa_worldcover_2021"
        / str(config.sources["esa_worldcover_2021"]["filename"])
    )
    land_cover = warp_source_mosaic(
        (worldcover_path,),
        1,
        grid,
        config.resampling["land_cover_resampling"],
    )
    copernicus_path = (
        raw_directory
        / "copernicus_dem_glo30"
        / str(config.sources["copernicus_dem_glo30"]["filename"])
    )
    surface_elevation = warp_source_mosaic(
        (copernicus_path,),
        1,
        grid,
        config.resampling["surface_elevation_resampling"],
    )

    raster_outputs = {
        "open_buildings_presence": output_directory / "open_buildings_presence_5m.tif",
        "open_buildings_height": output_directory / "open_buildings_height_max_5m.tif",
        "open_buildings_fractional_count": (
            output_directory / "open_buildings_fractional_count_5m.tif"
        ),
        "meta_chmv2_canopy_height": output_directory / "meta_chmv2_canopy_height_max_5m.tif",
        "esa_worldcover": output_directory / "esa_worldcover_2021_5m.tif",
        "copernicus_surface_elevation": (
            output_directory / "copernicus_glo30_surface_elevation_5m.tif"
        ),
    }
    common_tags = {
        "analysis_id": config.analysis_id,
        "tile_id": config.tile_id,
        "target_crs": grid.crs,
        "target_resolution_m": grid.resolution_m,
        "validation_status": "source_product_not_singapore_field_validated",
    }
    _write_raster(
        raster_outputs["open_buildings_presence"],
        presence,
        grid,
        "float32",
        -9999.0,
        common_tags | {"quantity": "unthresholded building presence"},
    )
    _write_raster(
        raster_outputs["open_buildings_height"],
        predicted_height,
        grid,
        "float32",
        -9999.0,
        common_tags | {"quantity": "predicted relative building height", "unit": "m"},
    )
    _write_raster(
        raster_outputs["open_buildings_fractional_count"],
        fractional_count,
        grid,
        "float32",
        -9999.0,
        common_tags | {"quantity": "fractional building count"},
    )
    _write_raster(
        raster_outputs["meta_chmv2_canopy_height"],
        canopy,
        grid,
        "float32",
        -9999.0,
        common_tags | {"quantity": "predicted top-of-canopy height", "unit": "m"},
    )
    _write_raster(
        raster_outputs["esa_worldcover"],
        land_cover,
        grid,
        "uint8",
        0,
        common_tags | {"quantity": "categorical land-cover class"},
    )
    _write_raster(
        raster_outputs["copernicus_surface_elevation"],
        surface_elevation,
        grid,
        "float32",
        -9999.0,
        common_tags
        | {
            "quantity": "surface elevation, not bare-earth terrain",
            "unit": "m",
            "vertical_reference": "EGM2008 geoid",
        },
    )

    study_area = gpd.read_file(
        project_root / config.study_area_path,
        layer=config.study_area_layer,
    ).to_crs(grid.crs)
    study_mask = rasterize(
        ((geometry, 1) for geometry in study_area.geometry),
        out_shape=(grid.height, grid.width),
        transform=grid.transform,
        fill=0,
        dtype="uint8",
    ).astype(bool)
    buildings = gpd.read_file(
        project_root / config.current_buildings_path,
        layer=config.current_buildings_layer,
    ).to_crs(grid.crs)
    current_height = rasterize(
        (
            (geometry, float(height))
            for geometry, height in zip(
                buildings.geometry,
                buildings["height_central_m"],
                strict=True,
            )
        ),
        out_shape=(grid.height, grid.width),
        transform=grid.transform,
        fill=0,
        dtype="float32",
    )
    current_mask = current_height > 0
    valid = (
        study_mask
        & ~np.ma.getmaskarray(presence)
        & ~np.ma.getmaskarray(predicted_height)
    )
    threshold_results: list[dict[str, Any]] = []
    for threshold in config.presence_thresholds:
        candidate_mask = np.ma.asarray(presence).filled(-1) >= threshold
        overlap = binary_overlap_metrics(current_mask, candidate_mask, valid)
        shared_height = valid & current_mask & candidate_mask
        differences = (
            np.ma.asarray(predicted_height).filled(np.nan)[shared_height]
            - current_height[shared_height]
        )
        overlap.update(
            {
                "presence_threshold": threshold,
                "shared_height_cell_count": int(len(differences)),
                "height_mean_absolute_difference_m": (
                    float(np.mean(np.abs(differences))) if len(differences) else None
                ),
                "height_median_difference_open_minus_current_m": (
                    float(np.median(differences)) if len(differences) else None
                ),
            }
        )
        threshold_results.append(overlap)

    canopy_values = np.ma.asarray(canopy)[study_mask].compressed().astype(float)
    land_values = np.ma.asarray(land_cover)[study_mask].compressed().astype(int)
    class_labels = {
        10: "tree_cover",
        20: "shrubland",
        30: "grassland",
        40: "cropland",
        50: "built_up",
        60: "bare_sparse_vegetation",
        70: "snow_ice",
        80: "permanent_water",
        90: "herbaceous_wetland",
        95: "mangroves",
        100: "moss_lichen",
    }
    class_counts = {
        class_labels.get(int(value), f"class_{int(value)}"): int(count)
        for value, count in zip(*np.unique(land_values, return_counts=True), strict=True)
    }
    class_fractions = {
        key: float(value / len(land_values)) for key, value in class_counts.items()
    }
    comparison = {
        "analysis_id": config.analysis_id,
        "tile_id": config.tile_id,
        "comparison_scope": "intersection with the existing Clementi 2 km study area",
        "comparison_warning": (
            "OSM footprints and completed current heights are references, not ground truth. "
            "No presence threshold is selected as preferred."
        ),
        "target_grid": {
            "crs": grid.crs,
            "bounds": list(grid.bounds),
            "resolution_m": grid.resolution_m,
            "width": grid.width,
            "height": grid.height,
        },
        "source_summaries": {
            "open_buildings_presence": _continuous_summary(presence),
            "open_buildings_height_m": _continuous_summary(predicted_height),
            "open_buildings_fractional_count": _continuous_summary(fractional_count),
            "meta_chmv2_canopy_height_m": _continuous_summary(canopy),
            "copernicus_surface_elevation_m": _continuous_summary(surface_elevation),
        },
        "canopy_in_existing_study_area": {
            "valid_cell_count": int(len(canopy_values)),
            "positive_canopy_fraction": float(np.mean(canopy_values > 0)),
            "canopy_above_2m_fraction": float(np.mean(canopy_values > 2)),
            "positive_median_height_m": (
                float(np.median(canopy_values[canopy_values > 0]))
                if np.any(canopy_values > 0)
                else None
            ),
            "positive_p95_height_m": (
                float(np.quantile(canopy_values[canopy_values > 0], 0.95))
                if np.any(canopy_values > 0)
                else None
            ),
        },
        "worldcover_class_cell_counts_in_existing_study_area": class_counts,
        "worldcover_class_fractions_in_existing_study_area": class_fractions,
        "current_osm_building_proxy_cell_count_in_existing_study_area": int(
            np.sum(current_mask & study_mask)
        ),
        "open_buildings_threshold_sweep_against_osm_footprint_proxy": threshold_results,
    }
    comparison_path = project_root / config.comparison_path
    comparison_path.parent.mkdir(parents=True, exist_ok=True)
    comparison_path.write_text(json.dumps(comparison, indent=2), encoding="utf-8")
    readiness = {
        "analysis_id": config.analysis_id,
        "tile_id": config.tile_id,
        "status": "enhanced_open_inputs_ready_canopy_solweig_rerun_pending",
        "raw_snapshot_directories": [
            config.raw_snapshot_directory,
            config.open_buildings_supplement_directory,
        ],
        "grid": comparison["target_grid"],
        "output_rasters": {
            key: path.relative_to(project_root).as_posix()
            for key, path in raster_outputs.items()
        },
        "building_decision": (
            "Keep the current provenance-labelled footprint/height model as primary; "
            "retain Open Buildings as unvalidated threshold-sweep comparison and gap fill."
        ),
        "canopy_decision": (
            "CHMv2 is ready as a predicted CDSM candidate, subject to sensitivity and "
            "field validation."
        ),
        "land_cover_decision": "WorldCover is ready as categorical context.",
        "terrain_decision": (
            "Do not add Copernicus DEM to building height: it is a DSM containing surface "
            "objects, not a bare-earth DTM."
        ),
        "next_model_run": (
            "Run a flat-ground building-plus-CHMv2-canopy SOLWEIG sensitivity scenario "
            "before any national batch."
        ),
        "comparison_path": config.comparison_path,
        "visual_qa_map": config.map_path,
    }
    readiness_path = project_root / config.readiness_path
    readiness_path.parent.mkdir(parents=True, exist_ok=True)
    readiness_path.write_text(json.dumps(readiness, indent=2), encoding="utf-8")
    _render_input_map(canopy, presence, buffered_tile, project_root / config.map_path)
    return readiness


def main() -> None:
    """Acquire sample-tile sources; processing is enabled after band audit."""

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        default="config/clementi_enhanced_tile.yaml",
        help="Configuration relative to the project root",
    )
    parser.add_argument("--acquire", action="store_true", help="Acquire raw source snapshot")
    parser.add_argument(
        "--acquire-open-buildings-supplement",
        action="store_true",
        help="Acquire the eastern Open Buildings source and official manifest",
    )
    parser.add_argument("--process", action="store_true", help="Build 5 m sample inputs")
    args = parser.parse_args()
    if not args.acquire and not args.acquire_open_buildings_supplement and not args.process:
        parser.error("Select an acquisition or processing mode")
    config = load_enhanced_tile_config(PROJECT_ROOT / args.config)
    if sum((args.acquire, args.acquire_open_buildings_supplement, args.process)) != 1:
        parser.error("Select exactly one mode at a time")
    if args.acquire:
        result = acquire_enhanced_tile_sources(config)
    elif args.acquire_open_buildings_supplement:
        result = acquire_open_buildings_supplement(config)
    else:
        result = process_enhanced_tile_inputs(config)
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
