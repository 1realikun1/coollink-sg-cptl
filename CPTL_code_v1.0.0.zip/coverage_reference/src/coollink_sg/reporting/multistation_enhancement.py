"""Compare the old single-station routes with the enhanced multi-station run."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import pandas as pd
import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[3]
KEYS = ["region_id", "od_id", "departure_time_sgt", "detour_limit_fraction"]


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    if key not in mapping:
        raise ValueError(f"Missing required field '{section}.{key}'")
    return mapping[key]


def match_routes(old: pd.DataFrame, new: pd.DataFrame) -> pd.DataFrame:
    required = set(KEYS) | {
        "route_id",
        "route_length_m",
        "cptl_above_26_deg_c_min",
        "primary_cptl_reduction_vs_shortest_percent",
    }
    for label, frame in (("old", old), ("new", new)):
        missing = required.difference(frame.columns)
        if missing:
            raise ValueError(f"{label} routes are missing fields: {sorted(missing)}")
        if frame.duplicated(KEYS).any():
            raise ValueError(f"{label} routes contain duplicate comparison keys")
    fields = list(required.difference(KEYS))
    matched = old[KEYS + fields].merge(
        new[KEYS + fields],
        on=KEYS,
        how="inner",
        validate="one_to_one",
        suffixes=("_old", "_new"),
    )
    if len(matched) != len(old) or len(matched) != len(new):
        raise ValueError("Single-station and multi-station route panels do not match")
    matched["exact_route_agreement"] = matched["route_id_old"].eq(
        matched["route_id_new"]
    )
    matched["old_positive_benefit"] = matched[
        "primary_cptl_reduction_vs_shortest_percent_old"
    ].gt(1e-9)
    matched["new_positive_benefit"] = matched[
        "primary_cptl_reduction_vs_shortest_percent_new"
    ].gt(1e-9)
    matched["benefit_direction_agreement"] = matched["old_positive_benefit"].eq(
        matched["new_positive_benefit"]
    )
    matched["reduction_change_percentage_points"] = (
        matched["primary_cptl_reduction_vs_shortest_percent_new"]
        - matched["primary_cptl_reduction_vs_shortest_percent_old"]
    )
    matched["cptl_change_percent"] = 100 * (
        matched["cptl_above_26_deg_c_min_new"]
        - matched["cptl_above_26_deg_c_min_old"]
    ) / matched["cptl_above_26_deg_c_min_old"]
    return matched


def summarize_primary(matched: pd.DataFrame, primary_cap: float) -> pd.DataFrame:
    primary = matched.loc[matched["detour_limit_fraction"].eq(primary_cap)]
    rows = []
    for region_id, frame in primary.groupby("region_id", sort=True):
        old_reduction = frame[
            "primary_cptl_reduction_vs_shortest_percent_old"
        ].astype(float)
        new_reduction = frame[
            "primary_cptl_reduction_vs_shortest_percent_new"
        ].astype(float)
        rows.append(
            {
                "region_id": region_id,
                "case_count": len(frame),
                "old_median_reduction_percent": float(old_reduction.median()),
                "new_median_reduction_percent": float(new_reduction.median()),
                "median_reduction_change_percentage_points": float(
                    (new_reduction - old_reduction).median()
                ),
                "old_positive_case_share_percent": float(100 * old_reduction.gt(1e-9).mean()),
                "new_positive_case_share_percent": float(100 * new_reduction.gt(1e-9).mean()),
                "exact_route_agreement_percent": float(
                    100 * frame["exact_route_agreement"].mean()
                ),
                "benefit_direction_agreement_percent": float(
                    100 * frame["benefit_direction_agreement"].mean()
                ),
                "median_absolute_reduction_change_percentage_points": float(
                    frame["reduction_change_percentage_points"].abs().median()
                ),
                "median_cptl_change_percent": float(frame["cptl_change_percent"].median()),
            }
        )
    return pd.DataFrame(rows)


def _plot(primary: pd.DataFrame, png_path: Path, svg_path: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(8.4, 3.5), constrained_layout=True)
    old = primary["primary_cptl_reduction_vs_shortest_percent_old"]
    new = primary["primary_cptl_reduction_vs_shortest_percent_new"]
    bounds = [float(min(old.min(), new.min())), float(max(old.max(), new.max()))]
    axes[0].scatter(old, new, s=15, alpha=0.55, edgecolors="none")
    axes[0].plot(bounds, bounds, color="#334155", linestyle="--", linewidth=1)
    axes[0].set_xlabel("Old S50 reduction (%)")
    axes[0].set_ylabel("Multi-station reduction (%)")
    axes[0].set_title("Matched 5% route benefits")

    order = sorted(primary["region_id"].unique())
    data = [
        primary.loc[
            primary["region_id"].eq(region),
            "reduction_change_percentage_points",
        ]
        for region in order
    ]
    axes[1].boxplot(data, tick_labels=order, showfliers=False)
    axes[1].axhline(0, color="#334155", linestyle="--", linewidth=1)
    axes[1].tick_params(axis="x", rotation=25)
    axes[1].set_ylabel("Change in reduction (percentage points)")
    axes[1].set_title("Effect of meteorological replacement")
    for path in (png_path, svg_path):
        path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def build_report(
    summary: pd.DataFrame,
    weather_cv: pd.DataFrame,
    remote: pd.Series,
) -> str:
    route_rows = "\n".join(
        (
            f"| {row.region_id} | {row.old_median_reduction_percent:.3f} | "
            f"{row.new_median_reduction_percent:.3f} | "
            f"{row.exact_route_agreement_percent:.1f} | "
            f"{row.benefit_direction_agreement_percent:.1f} |"
        )
        for row in summary.itertuples(index=False)
    )
    cv_rows = "\n".join(
        f"| {row.metric} | {row.mae:.3f} | {row.rmse:.3f} | {row.pearson_correlation:.3f} |"
        for row in weather_cv.itertuples(index=False)
    )
    return f"""# Multi-station meteorology and remote-sensing enhancement

## Design

The original SOLWEIG-CPTL logic, urban geometry, CHMv2 canopy, OD pairs, departure
times, walking speed, threshold and distance caps were retained. The repeated S50
snapshot was replaced by quarter-hour region-level backgrounds estimated from the
four nearest valid NEA stations for each metric using inverse-distance weights in
EPSG:3414. Clear-sky radiation remained modeled and is not an observed-day
reconstruction.

## Station interpolation diagnostic

| Metric | Leave-one-station-out MAE | RMSE | Pearson correlation |
|---|---:|---:|---:|
{cv_rows}

Wind speed is substantially less spatially predictable than temperature or humidity
and remains a mesoscale context input rather than a pedestrian-height canyon wind
estimate.

## Matched route results at the 5% cap

| Region | Old median (%) | Multi-station median (%) | Exact route (%) | Direction (%) |
|---|---:|---:|---:|---:|
{route_rows}

## Remote-sensing consistency

CHMv2 canopy height remains a direct SOLWEIG input. In Clementi, the independent
multi-date Sentinel-2 NDVI composite was positively associated with the CHMv2 canopy
fraction (Spearman {float(remote['spearman_rank_correlation']):.3f}); the AUC for NDVI
distinguishing the configured CHMv2 canopy-presence class was
{float(remote['ndvi_auc_for_chmv2_canopy_presence']):.3f}. Median NDVI was
{float(remote['median_ndvi_difference']):.3f} higher in the canopy-present class.
This is cross-product consistency, not field validation of canopy height, shade,
MRT, UTCI or cooling.
"""


def run_enhancement_report(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    payload = yaml.safe_load(Path(config_path).read_text(encoding="utf-8"))
    model = _required(payload, "multistation_enhancement", "root")
    inputs = _required(payload, "inputs", "root")
    outputs = _required(payload, "outputs", "root")
    old = pd.read_csv(project_root / str(_required(inputs, "old_single_station_routes", "inputs")))
    new = pd.read_csv(project_root / str(_required(inputs, "multistation_routes", "inputs")))
    expected = int(_required(model, "expected_route_count", "model"))
    if len(old) != expected or len(new) != expected:
        raise ValueError(f"Expected {expected} routes in each comparison panel")
    matched = match_routes(old, new)
    primary_cap = float(_required(model, "primary_detour_limit", "model"))
    summary = summarize_primary(matched, primary_cap)
    if len(summary) != int(_required(model, "expected_region_count", "model")):
        raise ValueError("Route comparison region count is incomplete")
    weather_cv = pd.read_csv(project_root / str(_required(inputs, "weather_cv", "inputs")))
    remote = pd.read_csv(
        project_root / str(_required(inputs, "remote_sensing_summary", "inputs"))
    ).iloc[0]
    paths = {key: project_root / str(value) for key, value in outputs.items()}
    for path in paths.values():
        path.parent.mkdir(parents=True, exist_ok=True)
    matched.to_csv(paths["matched_routes"], index=False)
    summary.to_csv(paths["route_summary"], index=False)
    primary = matched.loc[matched["detour_limit_fraction"].eq(primary_cap)]
    _plot(primary, paths["figure_png"], paths["figure_svg"])
    report = build_report(summary, weather_cv, remote)
    paths["report"].write_text(report, encoding="utf-8")
    machine = {
        "analysis_id": str(_required(model, "analysis_id", "model")),
        "matched_route_count": len(matched),
        "primary_case_count": len(primary),
        "primary_detour_limit": primary_cap,
        "exact_route_agreement_percent": float(100 * primary["exact_route_agreement"].mean()),
        "benefit_direction_agreement_percent": float(
            100 * primary["benefit_direction_agreement"].mean()
        ),
        "remote_sensing_spearman": float(remote["spearman_rank_correlation"]),
        "remote_sensing_auc": float(remote["ndvi_auc_for_chmv2_canopy_presence"]),
    }
    paths["machine_summary"].write_text(
        json.dumps(machine, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return machine


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/multistation_enhancement.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(run_enhancement_report(args.config), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
