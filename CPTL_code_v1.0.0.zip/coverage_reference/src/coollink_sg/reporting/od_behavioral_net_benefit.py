"""Post-hoc behavioral net benefit for fixed-cap OD routing results."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import yaml


PROJECT_ROOT = Path(__file__).resolve().parents[3]
CASE_KEYS = ["region_id", "od_id", "departure_time_sgt"]


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    if key not in mapping:
        raise ValueError(f"Missing required field '{section}.{key}'")
    return mapping[key]


def build_case_behavioral_net_benefit(
    fixed_cap_cases: pd.DataFrame,
    behavior_candidates: pd.DataFrame,
    sun_cost_factor_beta: float,
    positive_tolerance_m: float = 1.0e-9,
) -> pd.DataFrame:
    """Compare shade-equivalent benefit with added-distance cost for each case.

    Generalized route cost is ``beta * sun_distance + shade_distance``. Positive
    net benefit means the shorter route's generalized cost exceeds that of the
    fixed-cap heat-optimized route.
    """

    if not np.isfinite(sun_cost_factor_beta) or sun_cost_factor_beta <= 0:
        raise ValueError("sun_cost_factor_beta must be finite and positive")
    if not np.isfinite(positive_tolerance_m) or positive_tolerance_m < 0:
        raise ValueError("positive_tolerance_m must be finite and non-negative")

    fixed_required = {
        *CASE_KEYS,
        "route_id",
        "baseline_route_id",
        "region_label",
        "distance_band_rank",
        "route_changed_from_shortest",
    }
    candidate_required = {
        *CASE_KEYS,
        "route_id",
        "departure_snapshot_sun_distance_m",
        "departure_snapshot_shade_distance_m",
        "mean_acceptance_probability",
    }
    fixed_missing = fixed_required.difference(fixed_cap_cases.columns)
    candidate_missing = candidate_required.difference(behavior_candidates.columns)
    if fixed_missing:
        raise ValueError(f"Fixed-cap cases are missing fields: {sorted(fixed_missing)}")
    if candidate_missing:
        raise ValueError(
            f"Behavior candidates are missing fields: {sorted(candidate_missing)}"
        )

    route_columns = [
        *CASE_KEYS,
        "route_id",
        "departure_snapshot_sun_distance_m",
        "departure_snapshot_shade_distance_m",
        "mean_acceptance_probability",
    ]
    routes = behavior_candidates[route_columns].copy()
    if routes.duplicated([*CASE_KEYS, "route_id"]).any():
        raise ValueError("Behavior candidate route keys must be unique")

    alternative = routes.rename(
        columns={
            "departure_snapshot_sun_distance_m": "alternative_sun_distance_m",
            "departure_snapshot_shade_distance_m": "alternative_shade_distance_m",
            "mean_acceptance_probability": "predicted_acceptance_probability",
        }
    )
    baseline = routes.drop(columns="mean_acceptance_probability").rename(
        columns={
            "route_id": "baseline_route_id",
            "departure_snapshot_sun_distance_m": "baseline_sun_distance_m",
            "departure_snapshot_shade_distance_m": "baseline_shade_distance_m",
        }
    )
    result = fixed_cap_cases.merge(
        alternative,
        on=[*CASE_KEYS, "route_id"],
        how="left",
        validate="one_to_one",
    ).merge(
        baseline,
        on=[*CASE_KEYS, "baseline_route_id"],
        how="left",
        validate="one_to_one",
    )
    distance_fields = [
        "alternative_sun_distance_m",
        "alternative_shade_distance_m",
        "baseline_sun_distance_m",
        "baseline_shade_distance_m",
    ]
    if result[distance_fields].isna().any().any():
        raise ValueError("Every fixed-cap and baseline route must match a behavior candidate")

    alternative_cost = (
        sun_cost_factor_beta * result["alternative_sun_distance_m"]
        + result["alternative_shade_distance_m"]
    )
    baseline_cost = (
        sun_cost_factor_beta * result["baseline_sun_distance_m"]
        + result["baseline_shade_distance_m"]
    )
    result["behavioral_net_benefit_m"] = baseline_cost - alternative_cost
    result["positive_behavioral_net_benefit"] = result[
        "behavioral_net_benefit_m"
    ].gt(positive_tolerance_m)
    result["sun_cost_factor_beta"] = sun_cost_factor_beta
    return result


def summarize_od_positive_net_benefit(case_results: pd.DataFrame) -> pd.DataFrame:
    """Summarize the share of five departures with positive behavioral net benefit."""

    required = {
        "region_id",
        "region_label",
        "od_id",
        "distance_band_rank",
        "positive_behavioral_net_benefit",
        "behavioral_net_benefit_m",
        "route_changed_from_shortest",
    }
    missing = required.difference(case_results.columns)
    if missing:
        raise ValueError(f"Case results are missing fields: {sorted(missing)}")
    grouped = (
        case_results.groupby(
            ["region_id", "region_label", "od_id", "distance_band_rank"],
            sort=True,
            as_index=False,
        )
        .agg(
            departure_count=("positive_behavioral_net_benefit", "size"),
            positive_net_benefit_departures=("positive_behavioral_net_benefit", "sum"),
            route_changed_departures=("route_changed_from_shortest", "sum"),
            mean_behavioral_net_benefit_m=("behavioral_net_benefit_m", "mean"),
            median_behavioral_net_benefit_m=("behavioral_net_benefit_m", "median"),
        )
        .sort_values(["region_id", "od_id"])
        .reset_index(drop=True)
    )
    grouped["positive_behavioral_net_benefit_share_percent"] = (
        100
        * grouped["positive_net_benefit_departures"]
        / grouped["departure_count"]
    )
    return grouped


def run(config_path: str | Path, project_root: Path = PROJECT_ROOT) -> dict[str, Any]:
    payload = yaml.safe_load(Path(config_path).read_text(encoding="utf-8"))
    cfg = _required(payload, "od_behavioral_net_benefit", "root")
    outputs = _required(payload, "outputs", "root")

    model = pd.read_csv(project_root / str(_required(cfg, "behavior_model_summary", "analysis")))
    if len(model) != 1:
        raise ValueError("Behavior model summary must contain exactly one row")
    beta = float(model.iloc[0]["sun_cost_factor_beta"])
    fixed = pd.read_csv(project_root / str(_required(cfg, "fixed_cap_case_table", "analysis")))
    candidates = pd.read_csv(
        project_root / str(_required(cfg, "behavior_candidate_table", "analysis"))
    )
    cases = build_case_behavioral_net_benefit(
        fixed,
        candidates,
        beta,
        float(_required(cfg, "positive_tolerance_m", "analysis")),
    )
    od_summary = summarize_od_positive_net_benefit(cases)

    paths = {key: project_root / str(value) for key, value in outputs.items()}
    for path in paths.values():
        path.parent.mkdir(parents=True, exist_ok=True)
    cases.to_csv(paths["case_table"], index=False)
    od_summary.to_csv(paths["od_table"], index=False)

    offered = cases["route_changed_from_shortest"].astype(bool)
    positive = cases["positive_behavioral_net_benefit"].astype(bool)
    summary = {
        "analysis_id": str(_required(cfg, "analysis_id", "analysis")),
        "fixed_distance_cap_percent": float(
            _required(cfg, "fixed_distance_cap_percent", "analysis")
        ),
        "case_count": int(len(cases)),
        "od_count": int(len(od_summary)),
        "sun_cost_factor_beta": beta,
        "positive_behavioral_net_benefit_cases": int(positive.sum()),
        "positive_behavioral_net_benefit_share_percent": float(100 * positive.mean()),
        "route_changed_case_count": int(offered.sum()),
        "positive_share_among_changed_routes_percent": float(
            100 * positive[offered].mean()
        ),
        "regional_positive_share_percent": {
            str(region): float(100 * group["positive_behavioral_net_benefit"].mean())
            for region, group in cases.groupby("region_id", sort=True)
        },
        "interpretation": str(_required(cfg, "interpretation", "analysis")),
    }
    paths["summary_json"].write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/od_behavioral_net_benefit.yaml",
    )
    args = parser.parse_args()
    print(json.dumps(run(args.config), indent=2))


if __name__ == "__main__":
    main()
