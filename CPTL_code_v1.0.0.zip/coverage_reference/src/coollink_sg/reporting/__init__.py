"""Publication-facing synthesis and reporting utilities."""
