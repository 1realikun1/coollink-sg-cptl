# ruff: noqa: E501
"""Build the final four-region dynamic-CPTL synthesis."""

from __future__ import annotations

import argparse
import html
import json
from pathlib import Path
from typing import Any

import pandas as pd
import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[3]
PRIMARY_CPTL_FIELD = "cptl_above_26_deg_c_min"
REDUCTION_FIELD = "primary_cptl_reduction_vs_shortest_percent"


def _read_config(config_path: Path) -> dict[str, Any]:
    with config_path.open(encoding="utf-8") as stream:
        return yaml.safe_load(stream)


def _filter_frame(frame: pd.DataFrame, filters: dict[str, Any] | None) -> pd.DataFrame:
    selected = frame
    for field, value in (filters or {}).items():
        if field not in selected:
            raise ValueError(f"Filter field {field!r} is absent")
        selected = selected.loc[selected[field].astype(str).eq(str(value))]
    if selected.empty:
        raise ValueError(f"Filters selected no rows: {filters}")
    return selected.copy()


def combine_route_tables(project_root: Path, region_specs: list[dict[str, Any]]) -> pd.DataFrame:
    """Load and standardise the comparable building-plus-canopy route panel."""

    frames: list[pd.DataFrame] = []
    for order, spec in enumerate(region_specs):
        route_spec = spec["routes"]
        frame = pd.read_csv(project_root / route_spec["path"])
        frame = _filter_frame(frame, route_spec.get("filter"))
        frame["region_id"] = spec["region_id"]
        frame["region_label"] = spec["label"]
        frame["region_order"] = order
        frames.append(frame)
    return pd.concat(frames, ignore_index=True, sort=False)


def validate_route_panel(routes: pd.DataFrame, settings: dict[str, Any]) -> dict[str, int]:
    """Enforce the matched four-region scenario grid and routing invariants."""

    required = {
        "region_id",
        "region_label",
        "od_id",
        "departure_time_sgt",
        "detour_limit_fraction",
        "distance_ratio_to_shortest",
        "route_id",
        "thermal_source_status",
        PRIMARY_CPTL_FIELD,
        REDUCTION_FIELD,
    }
    missing = required.difference(routes.columns)
    if missing:
        raise ValueError(f"Route panel is missing fields: {sorted(missing)}")

    expected_regions = len(routes["region_id"].drop_duplicates())
    expected_od = int(settings["expected_od_count"])
    expected_departures = int(settings["expected_departure_count"])
    expected_caps = [float(value) for value in settings["expected_detour_limits"]]
    expected_rows = expected_regions * expected_od * expected_departures * len(expected_caps)
    key = ["region_id", "od_id", "departure_time_sgt", "detour_limit_fraction"]
    duplicate_route_keys = int(routes.duplicated(key).sum())
    incomplete_regions = 0
    for _, frame in routes.groupby("region_id", sort=False):
        complete = (
            frame["od_id"].nunique() == expected_od
            and frame["departure_time_sgt"].nunique() == expected_departures
            and sorted(frame["detour_limit_fraction"].unique()) == expected_caps
            and len(frame) == expected_od * expected_departures * len(expected_caps)
        )
        incomplete_regions += int(not complete)
    cap_tolerance = float(settings["distance_cap_tolerance"])
    cap_violations = int(
        (
            routes["distance_ratio_to_shortest"]
            > 1 + routes["detour_limit_fraction"] + cap_tolerance
        ).sum()
    )
    quality = {
        "route_rows": int(len(routes)),
        "expected_route_rows": expected_rows,
        "duplicate_route_keys": duplicate_route_keys,
        "incomplete_regions": incomplete_regions,
        "negative_cptl": int(routes[PRIMARY_CPTL_FIELD].lt(-1e-9).sum()),
        "negative_reduction": int(routes[REDUCTION_FIELD].lt(-1e-7).sum()),
        "distance_cap_violations": cap_violations,
        "field_validated_status_rows": int(
            (~routes["thermal_source_status"].str.contains("not_field_validated")).sum()
        ),
    }
    failures = {key: value for key, value in quality.items() if key not in {"route_rows", "expected_route_rows"} and value}
    if len(routes) != expected_rows:
        failures["route_row_mismatch"] = len(routes) - expected_rows
    if failures:
        raise ValueError(f"Four-region route-panel quality gates failed: {failures}")
    return quality


def summarize_route_panel(
    routes: pd.DataFrame,
    settings: dict[str, Any],
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Create cap-response, primary-cap, and departure-time summaries."""

    tolerance = float(settings["positive_tolerance"])
    work = routes.copy()
    work["actual_detour_percent"] = 100 * (work["distance_ratio_to_shortest"] - 1)
    grouped_rows: list[dict[str, Any]] = []
    for (order, region_id, label, cap), frame in work.groupby(
        ["region_order", "region_id", "region_label", "detour_limit_fraction"],
        sort=True,
    ):
        reductions = frame[REDUCTION_FIELD]
        grouped_rows.append(
            {
                "region_order": int(order),
                "region_id": region_id,
                "region_label": label,
                "detour_limit_fraction": float(cap),
                "detour_limit_percent": 100 * float(cap),
                "case_count": int(len(frame)),
                "od_count": int(frame["od_id"].nunique()),
                "departure_count": int(frame["departure_time_sgt"].nunique()),
                "median_route_cptl_deg_c_min": float(frame[PRIMARY_CPTL_FIELD].median()),
                "median_cptl_reduction_percent": float(reductions.median()),
                "q25_cptl_reduction_percent": float(reductions.quantile(0.25)),
                "q75_cptl_reduction_percent": float(reductions.quantile(0.75)),
                "positive_reduction_share_percent": float(100 * reductions.gt(tolerance).mean()),
                "median_actual_detour_percent": float(frame["actual_detour_percent"].median()),
            }
        )
    detour = pd.DataFrame(grouped_rows).sort_values(
        ["region_order", "detour_limit_fraction"]
    )

    previous_change: dict[tuple[str, float], float] = {}
    for region_id, frame in work.groupby("region_id", sort=False):
        pivot = frame.pivot(
            index=["od_id", "departure_time_sgt"],
            columns="detour_limit_fraction",
            values="route_id",
        )
        ordered_caps = sorted(pivot.columns)
        for prior, current in zip(ordered_caps, ordered_caps[1:], strict=False):
            previous_change[(region_id, float(current))] = float(
                100 * pivot[current].ne(pivot[prior]).mean()
            )
    detour["route_changed_vs_previous_cap_percent"] = [
        previous_change.get((row.region_id, float(row.detour_limit_fraction)), 0.0)
        for row in detour.itertuples()
    ]

    primary_cap = float(settings["primary_detour_limit"])
    main = detour.loc[detour["detour_limit_fraction"].eq(primary_cap)].copy()
    main = main.drop(columns=["region_order", "detour_limit_fraction"]).reset_index(drop=True)

    departure_rows: list[dict[str, Any]] = []
    five = work.loc[work["detour_limit_fraction"].eq(primary_cap)].copy()
    five["departure_hour_sgt"] = pd.to_datetime(
        five["departure_time_sgt"], format="mixed"
    ).dt.strftime("%H:%M")
    for (order, region_id, label, hour), frame in five.groupby(
        ["region_order", "region_id", "region_label", "departure_hour_sgt"], sort=True
    ):
        reductions = frame[REDUCTION_FIELD]
        departure_rows.append(
            {
                "region_order": int(order),
                "region_id": region_id,
                "region_label": label,
                "departure_hour_sgt": hour,
                "case_count": int(len(frame)),
                "median_cptl_reduction_percent": float(reductions.median()),
                "q25_cptl_reduction_percent": float(reductions.quantile(0.25)),
                "q75_cptl_reduction_percent": float(reductions.quantile(0.75)),
                "positive_reduction_share_percent": float(100 * reductions.gt(tolerance).mean()),
                "median_actual_detour_percent": float(frame["actual_detour_percent"].median()),
            }
        )
    departures = pd.DataFrame(departure_rows).drop(columns="region_order")
    return detour.drop(columns="region_order"), main, departures


def _read_record(project_root: Path, spec: dict[str, Any]) -> dict[str, Any]:
    path = project_root / spec["path"]
    if path.suffix.lower() == ".json":
        with path.open(encoding="utf-8") as stream:
            return json.load(stream)
    frame = _filter_frame(pd.read_csv(path), spec.get("filter"))
    if len(frame) != 1:
        raise ValueError(f"Metadata source must select one row: {spec['path']}")
    return frame.iloc[0].to_dict()


def build_input_table(project_root: Path, region_specs: list[dict[str, Any]]) -> pd.DataFrame:
    """Compile model-input and coverage metadata with explicit provenance fields."""

    rows: list[dict[str, Any]] = []
    for order, spec in enumerate(region_specs):
        metadata = spec["metadata"]
        network = _read_record(project_root, metadata["network"])
        buildings = _read_record(project_root, metadata["buildings"])
        thermal = _read_record(project_root, metadata["thermal"])
        if spec["region_id"] == "clementi_mrt":
            thermal_sampling = thermal["sampling"]
            grid = thermal["dsm"]
            canopy = thermal["canopy_dsm"]
            thermal_values = {
                "solweig_version": thermal["solweig_version"],
                "grid_width": grid["width"],
                "grid_height": grid["height"],
                "resolution_m": grid["resolution_m"],
                "canopy_positive_pixel_count": canopy["positive_pixel_count"],
                "road_time_row_count": thermal_sampling["row_count"],
                "timestamp_count": thermal_sampling["timestamp_count"],
                "paper_validation_ready": thermal["readiness"]["paper_validation_ready"],
                "thermal_source_status": thermal["thermal_source_status"],
            }
        else:
            thermal_values = {
                "solweig_version": thermal["solweig_version"],
                "grid_width": thermal["width"],
                "grid_height": thermal["height"],
                "resolution_m": thermal["resolution_m"],
                "canopy_positive_pixel_count": thermal["canopy_positive_pixel_count"],
                "road_time_row_count": thermal["row_count"],
                "timestamp_count": thermal["timestamp_count"],
                "paper_validation_ready": thermal["paper_validation_ready"],
                "thermal_source_status": thermal["thermal_source_status"],
            }
        building_count = int(buildings["building_count"])
        direct_count = int(buildings["direct_osm_height_count"])
        rows.append(
            {
                "region_order": order,
                "region_id": spec["region_id"],
                "region_label": spec["label"],
                "urban_context": spec["urban_context"],
                "crs": str(buildings["analysis_crs"]),
                "node_count": int(network["node_count"]),
                "directed_edge_count": int(network["directed_edge_count"]),
                "building_count": building_count,
                "direct_osm_height_count": direct_count,
                "direct_osm_height_share_percent": 100 * direct_count / building_count,
                **thermal_values,
            }
        )
    return pd.DataFrame(rows).sort_values("region_order").drop(columns="region_order")


def build_weather_table(project_root: Path, weather_spec: dict[str, Any]) -> pd.DataFrame:
    """Return a compact, non-comparative Raffles Place weather robustness table."""

    with (project_root / weather_spec["path"]).open(encoding="utf-8") as stream:
        summary = json.load(stream)
    five = summary["five_percent_cap"]
    return pd.DataFrame(
        [
            {
                "region_id": "raffles_place_mrt",
                "design": summary["design"],
                "scenario_count": summary["variant_count"],
                "median_reduction_min_percent": five["median_reduction_range_percent"][0],
                "median_reduction_max_percent": five["median_reduction_range_percent"][1],
                "positive_share_min_percent": five["positive_share_range_percent"][0],
                "positive_share_max_percent": five["positive_share_range_percent"][1],
                "exact_route_share_min_percent": five[
                    "exact_route_share_vs_baseline_range_percent"
                ][0],
                "exact_route_share_max_percent": five[
                    "exact_route_share_vs_baseline_range_percent"
                ][1],
                "benefit_direction_agreement_min_percent": five[
                    "benefit_direction_agreement_range_percent"
                ][0],
                "benefit_direction_agreement_max_percent": five[
                    "benefit_direction_agreement_range_percent"
                ][1],
                "interpretation_limit": summary["interpretation_limit"],
            }
        ]
    )


def _svg_header(width: int, height: int) -> list[str]:
    return [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="#FFFFFF"/>',
        "<style>text{font-family:Arial,sans-serif;fill:#1E293B}.title{font-size:23px;font-weight:700}.subtitle{font-size:13px;fill:#475569}.panel{font-size:17px;font-weight:700}.label{font-size:14px}.tick{font-size:12px;fill:#475569}.note{font-size:11px;fill:#64748B}.grid{stroke:#E2E8F0;stroke-width:1}.axis{stroke:#64748B;stroke-width:1.2}</style>",
    ]


def render_primary_figure(main: pd.DataFrame, output_path: Path) -> None:
    """Render the four-region 5% cap result as a two-panel vector figure."""

    width, height = 1400, 650
    colors = ["#0072B2", "#E69F00", "#009E73", "#CC79A7"]
    rows = main.reset_index(drop=True)
    svg = _svg_header(width, height)
    svg += [
        '<text x="60" y="42" class="title">Four-region heat-aware routing response at the 5% distance cap</text>',
        '<text x="60" y="66" class="subtitle">Median and interquartile range across 60 matched OD-departure cases per region</text>',
        '<text x="60" y="112" class="panel">A  Modeled CPTL reduction (%)</text>',
        '<text x="755" y="112" class="panel">B  Positive cases and actual detour</text>',
    ]
    left_x0, left_x1 = 250, 680
    y_positions = [180, 275, 370, 465]
    max_reduction = max(8.0, float(rows["q75_cptl_reduction_percent"].max()) * 1.12)
    for tick in range(0, int(max_reduction) + 1, 2):
        x = left_x0 + tick / max_reduction * (left_x1 - left_x0)
        svg += [
            f'<line x1="{x:.1f}" y1="145" x2="{x:.1f}" y2="500" class="grid"/>',
            f'<text x="{x:.1f}" y="525" text-anchor="middle" class="tick">{tick}</text>',
        ]
    for index, row in rows.iterrows():
        y = y_positions[index]
        q25 = left_x0 + row.q25_cptl_reduction_percent / max_reduction * (left_x1 - left_x0)
        median = left_x0 + row.median_cptl_reduction_percent / max_reduction * (left_x1 - left_x0)
        q75 = left_x0 + row.q75_cptl_reduction_percent / max_reduction * (left_x1 - left_x0)
        label = html.escape(str(row.region_label))
        svg += [
            f'<text x="230" y="{y + 5}" text-anchor="end" class="label">{label}</text>',
            f'<line x1="{q25:.1f}" y1="{y}" x2="{q75:.1f}" y2="{y}" stroke="{colors[index]}" stroke-width="8" stroke-linecap="round"/>',
            f'<circle cx="{median:.1f}" cy="{y}" r="8" fill="#FFFFFF" stroke="{colors[index]}" stroke-width="4"/>',
            f'<text x="{median + 13:.1f}" y="{y - 13}" class="tick">{row.median_cptl_reduction_percent:.2f}</text>',
        ]
    right_x0, right_x1 = 930, 1320
    for tick in [0, 20, 40, 60, 80, 100]:
        x = right_x0 + tick / 100 * (right_x1 - right_x0)
        svg += [
            f'<line x1="{x:.1f}" y1="145" x2="{x:.1f}" y2="500" class="grid"/>',
            f'<text x="{x:.1f}" y="525" text-anchor="middle" class="tick">{tick}</text>',
        ]
    for index, row in rows.iterrows():
        y = y_positions[index]
        bar_end = right_x0 + row.positive_reduction_share_percent / 100 * (right_x1 - right_x0)
        svg += [
            f'<text x="910" y="{y + 5}" text-anchor="end" class="label">{html.escape(str(row.region_label))}</text>',
            f'<rect x="{right_x0}" y="{y - 15}" width="{bar_end - right_x0:.1f}" height="30" rx="3" fill="{colors[index]}" opacity="0.78"/>',
            f'<text x="{bar_end - 7:.1f}" y="{y + 5}" text-anchor="end" fill="#FFFFFF" style="font:700 12px Arial">{row.positive_reduction_share_percent:.1f}%</text>',
            f'<text x="{right_x0:.1f}" y="{y + 34}" class="tick">median actual detour: {row.median_actual_detour_percent:.2f}%</text>',
        ]
    svg += [
        '<text x="465" y="558" text-anchor="middle" class="label">CPTL reduction relative to shortest-distance route (%)</text>',
        '<text x="1125" y="558" text-anchor="middle" class="label">Cases with positive reduction (%)</text>',
        '<text x="60" y="610" class="note">CPTL = cumulative positive thermal load above 26°C. Thick line = IQR; open circle = median.</text>',
        '<text x="60" y="630" class="note">Deterministic network-coverage sample; not travel demand, population exposure, or field validation.</text>',
        "</svg>",
    ]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(svg), encoding="utf-8")


def render_detour_figure(detour: pd.DataFrame, output_path: Path) -> None:
    """Render median benefit and actual-distance response across distance caps."""

    width, height = 1400, 650
    colors = {
        "Clementi": "#0072B2",
        "Jurong East": "#E69F00",
        "Toa Payoh": "#009E73",
        "Raffles Place": "#CC79A7",
    }
    svg = _svg_header(width, height)
    svg += [
        '<text x="60" y="42" class="title">Distance-cap response across four Singapore study areas</text>',
        '<text x="60" y="66" class="subtitle">Matched 12-OD × 5-departure design; points are regional medians</text>',
        '<text x="60" y="112" class="panel">A  CPTL reduction</text>',
        '<text x="755" y="112" class="panel">B  Actual distance increase</text>',
    ]
    panels = [(110, 145, 550, 355, 5.0), (805, 145, 550, 355, 3.0)]
    for x0, y0, panel_width, panel_height, y_max in panels:
        for tick in range(5):
            value = y_max * tick / 4
            y = y0 + panel_height - value / y_max * panel_height
            svg += [
                f'<line x1="{x0}" y1="{y:.1f}" x2="{x0 + panel_width}" y2="{y:.1f}" class="grid"/>',
                f'<text x="{x0 - 12}" y="{y + 4:.1f}" text-anchor="end" class="tick">{value:.1f}</text>',
            ]
        for cap in [0, 5, 10, 15]:
            x = x0 + cap / 15 * panel_width
            svg += [
                f'<line x1="{x:.1f}" y1="{y0}" x2="{x:.1f}" y2="{y0 + panel_height}" class="grid"/>',
                f'<text x="{x:.1f}" y="{y0 + panel_height + 27}" text-anchor="middle" class="tick">{cap}%</text>',
            ]
    for label, frame in detour.groupby("region_label", sort=False):
        color = colors[label]
        frame = frame.sort_values("detour_limit_percent")
        for panel, field in zip(
            panels,
            ["median_cptl_reduction_percent", "median_actual_detour_percent"],
            strict=True,
        ):
            x0, y0, panel_width, panel_height, y_max = panel
            points = []
            for row in frame.itertuples():
                x = x0 + row.detour_limit_percent / 15 * panel_width
                y = y0 + panel_height - getattr(row, field) / y_max * panel_height
                points.append(f"{x:.1f},{y:.1f}")
                svg.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="6" fill="{color}"/>')
            svg.append(
                f'<polyline points="{" ".join(points)}" fill="none" stroke="{color}" stroke-width="3"/>'
            )
    svg += [
        '<text x="385" y="555" text-anchor="middle" class="label">Allowed distance increase</text>',
        '<text x="1080" y="555" text-anchor="middle" class="label">Allowed distance increase</text>',
    ]
    legend_x = [265, 480, 705, 925]
    for x, (label, color) in zip(legend_x, colors.items(), strict=True):
        svg += [
            f'<line x1="{x}" y1="596" x2="{x + 28}" y2="596" stroke="{color}" stroke-width="4"/>',
            f'<circle cx="{x + 14}" cy="596" r="5" fill="{color}"/>',
            f'<text x="{x + 38}" y="601" class="label">{html.escape(label)}</text>',
        ]
    svg += [
        '<text x="60" y="635" class="note">Curves describe the configured OD-departure panel. Plateaus show little additional median gain, not proof of a universal optimal cap.</text>',
        "</svg>",
    ]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(svg), encoding="utf-8")


def _latex_table(frame: pd.DataFrame, columns: list[tuple[str, str]], caption: str, label: str) -> str:
    align = "l" + "r" * (len(columns) - 1)
    header = " & ".join(title for _, title in columns) + r" \\"
    rows = []
    for record in frame.to_dict("records"):
        values = []
        for field, _ in columns:
            value = record[field]
            if isinstance(value, float):
                values.append(f"{value:.2f}")
            else:
                values.append(str(value).replace("%", r"\%"))
        rows.append(" & ".join(values) + r" \\")
    return "\n".join(
        [
            r"\begin{table}[htbp]",
            r"\centering",
            f"\\caption{{{caption}}}",
            f"\\label{{{label}}}",
            f"\\begin{{tabular}}{{{align}}}",
            r"\toprule",
            header,
            r"\midrule",
            *rows,
            r"\bottomrule",
            r"\end{tabular}",
            r"\end{table}",
            "",
        ]
    )


def _markdown_table(frame: pd.DataFrame, columns: list[tuple[str, str, str]]) -> str:
    headings = [title for _, title, _ in columns]
    lines = ["| " + " | ".join(headings) + " |", "|" + "|".join(["---"] * len(columns)) + "|"]
    for record in frame.to_dict("records"):
        values = []
        for field, _, format_spec in columns:
            value = record[field]
            values.append(format(value, format_spec) if format_spec else str(value))
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines)


def _write_reports(
    paths: dict[str, Path],
    inputs: pd.DataFrame,
    main: pd.DataFrame,
    detour: pd.DataFrame,
    weather: pd.DataFrame,
    pooled: dict[str, float],
) -> None:
    main_md = _markdown_table(
        main,
        [
            ("region_label", "Region", ""),
            ("median_cptl_reduction_percent", "Median reduction (%)", ".3f"),
            ("q25_cptl_reduction_percent", "Q1 (%)", ".3f"),
            ("q75_cptl_reduction_percent", "Q3 (%)", ".3f"),
            ("positive_reduction_share_percent", "Positive cases (%)", ".1f"),
            ("median_actual_detour_percent", "Median actual detour (%)", ".3f"),
        ],
    )
    input_md = _markdown_table(
        inputs,
        [
            ("region_label", "Region", ""),
            ("directed_edge_count", "Directed edges", ",d"),
            ("building_count", "Buildings", ",d"),
            ("direct_osm_height_share_percent", "Direct OSM heights (%)", ".1f"),
            ("canopy_positive_pixel_count", "Canopy cells", ",d"),
            ("road_time_row_count", "Road-time rows", ",d"),
        ],
    )
    weather_row = weather.iloc[0]
    cap_pivot = detour.pivot(
        index="region_id",
        columns="detour_limit_percent",
        values="median_cptl_reduction_percent",
    )
    max_5_to_15_gain = float((cap_pivot[15.0] - cap_pivot[5.0]).max())
    en = f"""# Final four-region synthesis: dynamic pedestrian heat exposure and routing

## Scope and comparability

This synthesis compares Clementi, Jurong East, Toa Payoh, and Raffles Place under the matched building-plus-CHMv2-canopy design. Every region uses EPSG:3414, 5 m thermal inputs, 37 quarter-hour SOLWEIG timestamps from 09:00–18:00 SGT, a repeated S50 station context, modeled clear-sky radiation, 1.2 m/s walking speed, a 60 s arrival-time dominance bin, and CPTL above 26 °C as the primary objective. Each regional routing panel contains 12 deterministic network-coverage OD pairs, five departures, and 0/5/10/15% distance caps. The sample is not travel demand.

## Methods suitable for a manuscript

Building central heights were rasterized with CHMv2 predicted canopy height after removing building–canopy overlap. SOLWEIG 0.1.0b92 produced time-varying mean radiant temperature and UTCI fields; road segments were sampled at 5 m intervals with stable directed `segment_id` keys. For each departure, the time-dependent search propagated arrival time at 1.2 m/s and minimized the exact positive-part integral of linearly interpolated UTCI above 26 °C, subject to a hard distance cap relative to the shortest-distance route. The comparison is descriptive: medians, interquartile ranges, positive-benefit shares, and actual detours are reported across 60 matched cases per region. No inferential confidence interval is used because OD pairs are a deterministic coverage sample rather than a probability sample.

## Model-input audit

{input_md}

All four thermal panels contain 37 timestamps and have complete road-time keys. Direct OSM height coverage varies substantially, so completed building heights should be interpreted as provenance-labelled model inputs rather than measured truth. CHMv2 is a predicted canopy product.

## Primary results at the 5% cap

{main_md}

All four regional medians are positive. The regional median reduction range is {main['median_cptl_reduction_percent'].min():.3f}–{main['median_cptl_reduction_percent'].max():.3f}%, and {main['positive_reduction_share_percent'].min():.1f}–{main['positive_reduction_share_percent'].max():.1f}% of cases improve. Across the pooled 240-case descriptive panel, the median reduction is {pooled['median_reduction_percent']:.3f}% and {pooled['positive_share_percent']:.1f}% of cases improve. These differences must not be interpreted as a ranking of neighborhood safety or population exposure.

![Four-region primary results](../outputs/figures/four_region_primary_results.svg)

## Distance-cap response and robustness

The response curves generally flatten after 5–10%, indicating limited additional median benefit in this configured sample; the largest within-region increase from the 5% to 15% cap is {max_5_to_15_gain:.3f} percentage points and is descriptive rather than a universal optimum. Raffles Place weather stress tests retain positive 5% median reductions across all nine scenarios ({weather_row.median_reduction_min_percent:.3f}–{weather_row.median_reduction_max_percent:.3f}%). Benefit-direction agreement with baseline is {weather_row.benefit_direction_agreement_min_percent:.1f}–{weather_row.benefit_direction_agreement_max_percent:.1f}%, while exact-route agreement is lower ({weather_row.exact_route_share_min_percent:.1f}–{weather_row.exact_route_share_max_percent:.1f}%). Thus, directional benefit is more stable than the exact road sequence.

![Four-region distance-cap response](../outputs/figures/four_region_detour_response.svg)

## Conclusions

1. A small distance allowance consistently enables lower modeled dynamic heat burden across all four configured networks: the 5% cap yields positive regional median CPTL reductions and positive benefits in at least {main['positive_reduction_share_percent'].min():.1f}% of matched cases.
2. Most median gain is realized by 5–10% allowed distance, so a modest cap is a defensible design setting for subsequent validation rather than evidence of a universal pedestrian preference.
3. Raffles Place weather perturbations preserve the direction of the conclusion even when some exact routes change, supporting algorithmic robustness but not meteorological validation.
4. Results are scenario evidence, not observed exposure, causal canopy effects, safety recommendations, or population-weighted impacts. Field MRT/UTCI observations, local meteorology and radiation, terrain/material inputs, demand-representative OD sampling, and interaction sensitivity remain necessary before policy deployment.
"""
    zh = f"""# 四区域最终综合：动态步行热暴露与路径

## 范围与可比口径

本综合统一比较 Clementi、Jurong East、Toa Payoh 和 Raffles Place 的“建筑＋CHMv2 树冠”情景。四区均使用 EPSG:3414、5 m 热环境输入、09:00–18:00 SGT 共 37 个 15 分钟时刻、重复的 S50 站点背景、晴空模型辐射、1.2 m/s 步速、60 秒到达时间分箱，并以 26 °C 以上 CPTL 为主目标。每区均为 12 个确定性路网覆盖 OD、5 个出发时刻及 0/5/10/15% 距离上限；该样本不是实际出行需求。

## 可直接写入论文的方法

研究将建筑中心高度栅格化，并在移除建筑—树冠重叠后加入 CHMv2 预测树冠高度。SOLWEIG 0.1.0b92 生成分时平均辐射温度与 UTCI；道路按 5 m 间隔采样，并以稳定的有向 `segment_id` 连接热场和路网。动态搜索以 1.2 m/s 推进到达时间，对线性插值 UTCI 超过 26 °C 的正部积分进行最小化，同时严格满足相对最短距离路线的绕行上限。每区 60 个匹配案例报告中位数、四分位距、正收益比例和实际绕行。由于 OD 是确定性覆盖样本而非概率样本，不使用可能误导的推断性置信区间。

## 模型输入审计

{input_md.replace('Region', '区域').replace('Directed edges', '有向道路').replace('Buildings', '建筑').replace('Direct OSM heights (%)', '直接 OSM 高度 (%)').replace('Canopy cells', '树冠像元').replace('Road-time rows', '道路—时刻行数')}

四区热场均包含 37 个时刻且道路—时刻键完整。直接 OSM 高度覆盖比例差异明显，因此补齐后的建筑高度应视为保留来源标记的模型输入，而不是测量真值；CHMv2 同样是预测树冠产品。

## 5% 绕行上限主结果

{main_md.replace('Region', '区域').replace('Median reduction (%)', 'CPTL 降幅中位数 (%)').replace('Q1 (%)', 'Q1 (%)').replace('Q3 (%)', 'Q3 (%)').replace('Positive cases (%)', '正收益案例 (%)').replace('Median actual detour (%)', '实际绕行中位数 (%)')}

四区中位数均为正，区域中位降幅范围为 {main['median_cptl_reduction_percent'].min():.3f}–{main['median_cptl_reduction_percent'].max():.3f}%，正收益案例占 {main['positive_reduction_share_percent'].min():.1f}–{main['positive_reduction_share_percent'].max():.1f}%。合并 240 个案例作描述性统计时，中位降幅为 {pooled['median_reduction_percent']:.3f}%，正收益比例为 {pooled['positive_share_percent']:.1f}%。这些差异不能解释为区域安全等级或人口暴露排名。

![四区域主结果](../../outputs/figures/four_region_primary_results.svg)

## 距离上限响应与稳健性

响应曲线总体在 5–10% 后趋于平台，说明本配置样本中继续放宽距离的额外中位收益有限；各区内部从 5% 放宽到 15% 的最大中位增益为 {max_5_to_15_gain:.3f} 个百分点，不能视为普适最优值。Raffles Place 的 9 个天气压力情景均保留正的 5% 中位降幅（{weather_row.median_reduction_min_percent:.3f}–{weather_row.median_reduction_max_percent:.3f}%）。收益方向与基线的一致率为 {weather_row.benefit_direction_agreement_min_percent:.1f}–{weather_row.benefit_direction_agreement_max_percent:.1f}%，而精确路线一致率为 {weather_row.exact_route_share_min_percent:.1f}–{weather_row.exact_route_share_max_percent:.1f}%；因此“有无收益”的方向比具体道路序列更稳定。

![四区域距离上限响应](../../outputs/figures/four_region_detour_response.svg)

## 结论

1. 四个已配置路网均表明，小幅距离余量可以降低模型动态热负荷：5% 上限下各区 CPTL 中位降幅均为正，且至少 {main['positive_reduction_share_percent'].min():.1f}% 的匹配案例获得正收益。
2. 中位收益大部分在 5–10% 距离余量内实现，因此小幅上限可作为后续验证的合理设计值，但不能解释为普适的行人偏好。
3. Raffles Place 天气扰动下，部分精确路线会改变，但总体收益方向保持稳定；这支持算法稳健性，不等于气象验证。
4. 结果属于模型情景证据，不是实测暴露、树冠因果效应、安全建议或人口加权影响。政策应用前仍需道路尺度 MRT/UTCI 实测、本地气象和辐射、地形与材料、需求代表性 OD，以及多参数交互敏感性。
"""
    paths["report_en"].write_text(en, encoding="utf-8")
    paths["report_zh"].write_text(zh, encoding="utf-8")


def build_four_region_synthesis(
    project_root: Path = PROJECT_ROOT,
    config_path: Path | None = None,
) -> dict[str, Any]:
    """Build all standardised data, tables, figures, and manuscript-ready text."""

    config_path = config_path or project_root / "config/four_region_synthesis.yaml"
    config = _read_config(config_path)
    settings = config["four_region_synthesis"]
    routes = combine_route_tables(project_root, config["regions"])
    quality = validate_route_panel(routes, settings)
    detour, main, departures = summarize_route_panel(routes, settings)
    inputs = build_input_table(project_root, config["regions"])
    weather = build_weather_table(project_root, config["weather_robustness"])
    outputs = {key: project_root / value for key, value in config["outputs"].items()}
    for path in outputs.values():
        path.parent.mkdir(parents=True, exist_ok=True)

    routes.to_csv(outputs["standardized_routes"], index=False)
    inputs.to_csv(outputs["input_table"], index=False)
    main.to_csv(outputs["main_table"], index=False)
    detour.to_csv(outputs["detour_table"], index=False)
    departures.to_csv(outputs["departure_table"], index=False)
    weather.to_csv(outputs["weather_table"], index=False)
    outputs["main_table_latex"].write_text(
        _latex_table(
            main,
            [
                ("region_label", "Region"),
                ("median_cptl_reduction_percent", "Median reduction (\\%)"),
                ("q25_cptl_reduction_percent", "Q1 (\\%)"),
                ("q75_cptl_reduction_percent", "Q3 (\\%)"),
                ("positive_reduction_share_percent", "Positive cases (\\%)"),
                ("median_actual_detour_percent", "Median detour (\\%)"),
            ],
            "Dynamic CPTL routing results at the 5\\% distance cap.",
            "tab:four_region_primary",
        ),
        encoding="utf-8",
    )
    outputs["detour_table_latex"].write_text(
        _latex_table(
            detour,
            [
                ("region_label", "Region"),
                ("detour_limit_percent", "Cap (\\%)"),
                ("median_cptl_reduction_percent", "Median reduction (\\%)"),
                ("positive_reduction_share_percent", "Positive cases (\\%)"),
                ("median_actual_detour_percent", "Median actual detour (\\%)"),
            ],
            "Distance-cap response in the matched four-region panel.",
            "tab:four_region_caps",
        ),
        encoding="utf-8",
    )
    render_primary_figure(main, outputs["primary_figure"])
    render_detour_figure(detour, outputs["detour_figure"])

    primary_cap = float(settings["primary_detour_limit"])
    primary_routes = routes.loc[routes["detour_limit_fraction"].eq(primary_cap)]
    tolerance = float(settings["positive_tolerance"])
    pooled = {
        "case_count": int(len(primary_routes)),
        "median_reduction_percent": float(primary_routes[REDUCTION_FIELD].median()),
        "positive_share_percent": float(100 * primary_routes[REDUCTION_FIELD].gt(tolerance).mean()),
    }
    _write_reports(outputs, inputs, main, detour, weather, pooled)
    machine_summary = {
        "analysis_id": settings["analysis_id"],
        "comparison_scenario": settings["comparison_scenario"],
        "sample_type": settings["sample_type"],
        "quality_gates": quality,
        "pooled_five_percent_descriptive": pooled,
        "regional_median_reduction_range_percent": [
            float(main["median_cptl_reduction_percent"].min()),
            float(main["median_cptl_reduction_percent"].max()),
        ],
        "regional_positive_share_range_percent": [
            float(main["positive_reduction_share_percent"].min()),
            float(main["positive_reduction_share_percent"].max()),
        ],
        "paper_validation_ready": False,
        "claim_boundary": (
            "Matched clear-sky design-scenario comparison; not observed exposure, "
            "travel demand, causal canopy effect, area safety ranking, or field validation."
        ),
        "outputs": {key: str(path.relative_to(project_root)) for key, path in outputs.items()},
    }
    outputs["machine_summary"].write_text(
        json.dumps(machine_summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return machine_summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=None)
    args = parser.parse_args()
    result = build_four_region_synthesis(config_path=args.config)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
