"""Tests for deterministic network-coverage multi-OD sampling."""

from pathlib import Path

import geopandas as gpd
from shapely.geometry import LineString, Point

from coollink_sg.config import MultiODCPTLConfig, load_multi_od_cptl_config
from coollink_sg.routing.multi_od_cptl import select_network_coverage_od_pairs

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _config() -> MultiODCPTLConfig:
    return MultiODCPTLConfig(
        analysis_id="test_multi_od",
        output_crs="EPSG:3414",
        sample_type="network_coverage_not_travel_demand",
        sampling_method="largest_scc_farthest_origins_distance_bands",
        origin_count=2,
        distance_bands_m=((90.0, 110.0), (190.0, 210.0)),
        scenarios=(),
        output_stem="test_multi_od",
    )


def _network() -> tuple[gpd.GeoDataFrame, gpd.GeoDataFrame]:
    nodes = gpd.GeoDataFrame(
        {"osmid": [1, 2, 3, 4, 5]},
        geometry=[Point(x, 0) for x in (0, 100, 200, 300, 400)],
        crs="EPSG:3414",
    )
    rows = []
    for index, (left, right) in enumerate(zip(range(1, 5), range(2, 6), strict=True)):
        for direction, (u, v) in enumerate(((left, right), (right, left))):
            rows.append(
                {
                    "u": u,
                    "v": v,
                    "key": 0,
                    "segment_id": f"edge_{index}_{direction}",
                    "length_m": 100.0,
                    "geometry": LineString([(100 * (u - 1), 0), (100 * (v - 1), 0)]),
                }
            )
    edges = gpd.GeoDataFrame(rows, geometry="geometry", crs="EPSG:3414")
    return nodes, edges


def test_project_multi_od_config_retains_non_demand_warning() -> None:
    config = load_multi_od_cptl_config(PROJECT_ROOT / "config/multi_od_cptl.yaml")

    assert config.sample_type == "network_coverage_not_travel_demand"
    assert config.origin_count == 4
    assert config.distance_bands_m == (
        (500.0, 1000.0),
        (1000.0, 2000.0),
        (2000.0, 3000.0),
    )
    assert len(config.scenarios) == 2


def test_od_sample_is_deterministic_and_respects_distance_bands() -> None:
    nodes, edges = _network()

    first, endpoints, graph = select_network_coverage_od_pairs(
        nodes, edges, _config()
    )
    second, _, _ = select_network_coverage_od_pairs(nodes, edges, _config())

    assert first.equals(second)
    assert len(first) == 4
    assert len(endpoints) == 8
    assert graph.number_of_nodes() == 5
    assert first["shortest_path_distance_m"].tolist() == [100.0, 200.0, 100.0, 200.0]
    assert first["sample_type"].eq("network_coverage_not_travel_demand").all()
