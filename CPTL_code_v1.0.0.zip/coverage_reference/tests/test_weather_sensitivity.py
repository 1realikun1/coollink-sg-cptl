"""Tests for Raffles Place OFAT weather sensitivity."""

from pathlib import Path

import pandas as pd

from coollink_sg.heat.weather_sensitivity import (
    apply_weather_variant,
    build_weather_variants,
    compare_routes_to_baseline,
    load_weather_sensitivity_config,
    summarize_route_stability,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_project_weather_sensitivity_builds_nine_ofat_variants() -> None:
    config = load_weather_sensitivity_config(
        PROJECT_ROOT / "config/raffles_place_weather_sensitivity.yaml"
    )
    variants = build_weather_variants(config)

    assert len(variants) == 9
    assert variants[0].variant_id == "baseline"
    assert sum(v.varied_parameter == "air_temperature_delta_deg_c" for v in variants) == 2
    assert sum(
        v.varied_parameter == "relative_humidity_delta_percentage_points" for v in variants
    ) == 2
    assert sum(v.varied_parameter == "wind_speed_multiplier" for v in variants) == 2
    assert sum(v.varied_parameter == "global_radiation_multiplier" for v in variants) == 2


def test_apply_weather_variant_changes_only_configured_factor() -> None:
    config = load_weather_sensitivity_config(
        PROJECT_ROOT / "config/raffles_place_weather_sensitivity.yaml"
    )
    variant = next(
        value
        for value in build_weather_variants(config)
        if value.variant_id == "air_temperature_delta_deg_c_2"
    )
    baseline = pd.DataFrame(
        {
            "timestamp_sgt": ["2026-08-17T09:00:00+08:00"],
            "air_temperature_deg_c": [32.2],
            "relative_humidity_percent": [64.8],
            "wind_speed_m_s": [2.0],
            "clear_sky_ghi_w_m2": [500.0],
            "clear_sky_dni_w_m2": [600.0],
            "clear_sky_dhi_w_m2": [100.0],
        }
    )
    changed = apply_weather_variant(baseline, variant)

    assert changed.loc[0, "air_temperature_deg_c"] == 34.2
    assert changed.loc[0, "relative_humidity_percent"] == 64.8
    assert changed.loc[0, "wind_speed_m_s"] == 2.0
    assert changed.loc[0, "clear_sky_ghi_w_m2"] == 500.0


def test_route_comparison_reports_exact_and_directional_stability() -> None:
    routes = pd.DataFrame(
        {
            "variant_id": ["baseline", "changed"],
            "varied_parameter": ["baseline", "air_temperature_delta_deg_c"],
            "varied_value": [0.0, 2.0],
            "od_id": ["od1", "od1"],
            "departure_time_sgt": ["2026-08-17T09:00:00+08:00"] * 2,
            "detour_limit_fraction": [0.05, 0.05],
            "route_id": ["same", "same"],
            "primary_cptl_reduction_vs_shortest_percent": [2.0, 3.0],
            "distance_ratio_to_shortest": [1.01, 1.01],
        }
    )
    comparison = compare_routes_to_baseline(routes)
    summary = summarize_route_stability(comparison)
    changed = summary.loc[summary["variant_id"].eq("changed")].iloc[0]

    assert changed["exact_route_share_vs_baseline_percent"] == 100.0
    assert changed["benefit_direction_agreement_vs_baseline_percent"] == 100.0
    assert changed["median_cptl_reduction_delta_percentage_points"] == 1.0
