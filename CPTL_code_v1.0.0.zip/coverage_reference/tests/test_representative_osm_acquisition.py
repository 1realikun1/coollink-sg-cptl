from pathlib import Path

from coollink_sg.data.representative_osm_acquisition import (
    load_region_query_geometries,
    load_representative_osm_config,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_representative_osm_config_and_query_geometry_load() -> None:
    config = load_representative_osm_config(
        PROJECT_ROOT / "config/representative_osm_acquisition.yaml"
    )
    geometries = load_region_query_geometries(config)
    assert config.region_ids == ("jurong_east_mrt", "toa_payoh_mrt", "raffles_place_mrt")
    assert set(geometries) == set(config.region_ids)
    for network_area, building_area, tile_ids in geometries.values():
        assert network_area.geometry.iloc[0].area > 0
        assert building_area.geometry.iloc[0].area > network_area.geometry.iloc[0].area
        assert len(tile_ids) >= 7


def test_single_region_raffles_place_acquisition_config_loads() -> None:
    config = load_representative_osm_config(
        PROJECT_ROOT / "config/raffles_place_osm_acquisition.yaml"
    )
    geometries = load_region_query_geometries(config)
    assert config.region_ids == ("raffles_place_mrt",)
    assert geometries["raffles_place_mrt"][2] == (
        "SG3414_E028000_N026000",
        "SG3414_E028000_N028000",
        "SG3414_E028000_N030000",
        "SG3414_E030000_N026000",
        "SG3414_E030000_N028000",
        "SG3414_E030000_N030000",
        "SG3414_E032000_N028000",
    )
