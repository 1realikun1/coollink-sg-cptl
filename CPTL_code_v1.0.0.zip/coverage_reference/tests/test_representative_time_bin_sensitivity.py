from pathlib import Path

import pandas as pd

from coollink_sg.routing.representative_time_bin_sensitivity import (
    compare_time_bins_to_baseline,
    load_representative_time_bin_sensitivity_config,
    summarize_time_bin_sensitivity,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_representative_time_bin_config_is_explicit_ofat_design() -> None:
    config = load_representative_time_bin_sensitivity_config(
        PROJECT_ROOT / "config/representative_time_bin_sensitivity.yaml"
    )
    assert config.design == "one_factor_at_a_time"
    assert config.time_bins_seconds == (30, 60, 120)
    assert config.baseline_time_bin_seconds == 60
    assert config.detour_limits == (0.0, 0.05, 0.1)


def test_time_bin_comparison_and_summary_detect_route_change() -> None:
    routes = pd.DataFrame(
        {
            "region_id": ["a", "a", "a"],
            "od_id": ["od1", "od1", "od1"],
            "departure_time_sgt": ["09:00", "09:00", "09:00"],
            "detour_limit_fraction": [0.05, 0.05, 0.05],
            "time_bin_seconds": [30, 60, 120],
            "route_id": ["same", "same", "different"],
            "route_length_m": [101, 101, 102],
            "cptl_above_26_deg_c_min": [9, 9, 10],
            "primary_cptl_reduction_vs_shortest_percent": [10, 10, 0],
        }
    )
    compared = compare_time_bins_to_baseline(routes, 60)
    changed = compared.set_index("time_bin_seconds")["route_changed_vs_baseline"]
    assert changed.loc[30] == 0
    assert changed.loc[120] == 1
    runtimes = pd.DataFrame(
        {
            "region_id": ["a", "a", "a"],
            "time_bin_seconds": [30, 60, 120],
            "od_id": ["od1", "od1", "od1"],
            "runtime_seconds": [3.0, 2.0, 1.0],
        }
    )
    summary = summarize_time_bin_sensitivity(compared, runtimes).set_index(
        "time_bin_seconds"
    )
    assert summary.loc[30, "route_changed_share_vs_60s_percent"] == 0
    assert summary.loc[120, "route_changed_share_vs_60s_percent"] == 100
    assert summary.loc[120, "maximum_absolute_cptl_delta_vs_60s_deg_c_min"] == 1
