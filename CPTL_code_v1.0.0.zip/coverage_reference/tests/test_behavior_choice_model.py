import numpy as np
import pandas as pd

from coollink_sg.routing.behavior_choice_model import (
    effective_components,
    fit_population_model,
    route_choice_probability,
)


def test_route_choice_probability_is_symmetric() -> None:
    probability = route_choice_probability(np.array([0.0, 10.0]), np.array([0.0, 0.0]), 5.0)
    assert np.isclose(probability[0], 0.5)
    assert probability[1] < 0.5
    assert np.isclose(probability[1] + route_choice_probability(0.0, 10.0, 5.0), 1.0)


def test_population_fit_recovers_synthetic_parameters() -> None:
    rng = np.random.default_rng(17)
    n = 5000
    sun_diff = rng.normal(0, 35, n)
    shade_diff = rng.normal(0, 35, n)
    beta = 1.35
    scale = 22.0
    probability = route_choice_probability(beta * sun_diff + shade_diff, 0.0, scale)
    frame = pd.DataFrame(
        {
            "A_effective_sun_m": sun_diff,
            "B_effective_sun_m": np.zeros(n),
            "A_effective_shade_m": shade_diff,
            "B_effective_shade_m": np.zeros(n),
            "A_chosen": rng.binomial(1, probability),
        }
    )
    fitted = fit_population_model(frame)
    assert abs(fitted["sun_cost_factor_beta"] - beta) < 0.12
    assert abs(fitted["choice_scale_m"] - scale) < 3.0


def test_effective_components_split_tree_shade() -> None:
    frame = pd.DataFrame(
        {
            "Participant": ["p"],
            "A_sun_length": [10.0],
            "A_tree_length": [20.0],
            "A_shade_length": [30.0],
            "B_sun_length": [5.0],
            "B_tree_length": [10.0],
            "B_shade_length": [45.0],
            "B_chosen": [1],
            "Treatment": [1],
        }
    )
    result = effective_components(frame, 0.5)
    assert result.loc[0, "A_effective_sun_m"] == 20.0
    assert result.loc[0, "A_effective_shade_m"] == 40.0
    assert result.loc[0, "A_chosen"] == 0
