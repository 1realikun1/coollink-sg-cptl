"""Tests for exploratory road heat-exposure proxy sensitivity."""

from pathlib import Path

import geopandas as gpd
import pandas as pd
import pytest
from shapely.geometry import LineString

from coollink_sg.config import (
    ProcessedLayerConfig,
    RoadHeatExposureProxyConfig,
    load_road_heat_exposure_proxy_config,
)
from coollink_sg.heat.road_exposure_proxy import (
    COMPONENT_FIELDS,
    compute_exposure_proxy_sensitivity,
    create_exposure_proxy_map,
    generate_three_component_weight_scenarios,
    prepare_exposure_components,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _config() -> RoadHeatExposureProxyConfig:
    return RoadHeatExposureProxyConfig(
        analysis_id="test_exposure_proxy",
        output_crs="EPSG:3414",
        weight_step=0.1,
        diagnostic_top_fraction=0.1,
        weather_metric="wbgt",
        weather_normalization="valid_national_snapshot_minmax",
        road_features=ProcessedLayerConfig("unused.gpkg", "road_features"),
        weather_associations_path="unused_associations.csv",
        weather_observations_path="unused_observations.csv",
        shade_field="shade",
        vegetation_field="green",
        component_interpretations={
            "wbgt_station_context": "test context",
            "shade_deficit": "test shade",
            "vegetation_context_deficit": "test green",
        },
    )


def _roads() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "segment_id": ["a", "b", "c"],
            "shade": [0.0, 0.5, 1.0],
            "green": [0.2, 0.5, 0.8],
        },
        geometry=[
            LineString([(0, 0), (1, 0)]),
            LineString([(1, 0), (2, 0)]),
            LineString([(2, 0), (3, 0)]),
        ],
        crs="EPSG:3414",
    )


def _associations() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "segment_id": ["a", "b", "c"],
            "metric": ["wbgt"] * 3,
            "source_station_id": ["s1", "s2", "s1"],
            "source_station_name": ["one", "two", "one"],
            "source_value": [30.0, 32.0, 30.0],
            "source_unit": ["degC"] * 3,
            "observed_at_sgt": ["2026-08-17T12:45:00+08:00"] * 3,
            "road_midpoint_to_station_distance_m": [1000.0, 2000.0, 1500.0],
            "weather_snapshot_id": ["snapshot"] * 3,
            "association_status": ["context_only_not_road_observation"] * 3,
        }
    )


def _observations() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "metric": ["wbgt", "wbgt", "wbgt"],
            "value": [28.0, 31.0, 34.0],
            "quality_flag": ["valid", "valid", "valid"],
            "station_id": ["low", "middle", "high"],
        }
    )


def test_project_configuration_selects_no_weight_scenario() -> None:
    config = load_road_heat_exposure_proxy_config(
        PROJECT_ROOT / "config/road_heat_exposure_proxy.yaml"
    )

    assert config.weight_step == 0.1
    assert config.weather_normalization == "valid_national_snapshot_minmax"
    assert config.shade_field == "combined_shade_evidence_fraction"


def test_three_component_simplex_is_complete_and_unpreferred() -> None:
    scenarios = generate_three_component_weight_scenarios(_config())

    assert len(scenarios) == 66
    assert scenarios["weight_sum"].eq(1).all()
    assert scenarios["preferred_scenario"].eq(False).all()  # noqa: E712
    weights = scenarios.filter(like="weight_").drop(columns="weight_sum")
    assert (weights == 1).any(axis=1).sum() == 3


def test_context_and_proxy_components_are_bounded_and_directional() -> None:
    prepared, metadata = prepare_exposure_components(
        _roads(), _associations(), _observations(), _config()
    )

    assert prepared[list(COMPONENT_FIELDS)].apply(lambda s: s.between(0, 1).all()).all()
    assert prepared.loc[0, COMPONENT_FIELDS[0]] == pytest.approx(1 / 3)
    assert prepared.loc[1, COMPONENT_FIELDS[0]] == pytest.approx(2 / 3)
    assert prepared.loc[0, COMPONENT_FIELDS[1]] == pytest.approx(1)
    assert prepared.loc[2, COMPONENT_FIELDS[1]] == pytest.approx(0)
    assert metadata["valid_national_wbgt_station_count"] == 3
    assert metadata["assigned_wbgt_station_count"] == 2


def test_sensitivity_retains_all_roads_without_creating_heat_score() -> None:
    prepared, _ = prepare_exposure_components(
        _roads(), _associations(), _observations(), _config()
    )
    result, scenarios = compute_exposure_proxy_sensitivity(prepared, _config())

    assert len(result) == 3
    assert result["segment_id"].is_unique
    assert len(scenarios) == 66
    assert result["exposure_proxy_min_across_weights"].between(0, 1).all()
    assert result["exposure_proxy_max_across_weights"].between(0, 1).all()
    assert result["preferred_weight_scenario"].eq("none").all()
    assert "heat_score" not in result.columns


def test_non_context_weather_assignment_is_rejected() -> None:
    associations = _associations()
    associations.loc[0, "association_status"] = "road_observation"

    with pytest.raises(ValueError, match="context-only status"):
        prepare_exposure_components(_roads(), associations, _observations(), _config())


def test_map_states_that_result_is_not_heat_score(tmp_path: Path) -> None:
    prepared, _ = prepare_exposure_components(
        _roads(), _associations(), _observations(), _config()
    )
    result, _ = compute_exposure_proxy_sensitivity(prepared, _config())
    output = tmp_path / "exposure.html"

    create_exposure_proxy_map(result, output)

    html = output.read_text(encoding="utf-8")
    assert "not Heat Score or measured road exposure" in html
    assert "No preferred weights" in html
