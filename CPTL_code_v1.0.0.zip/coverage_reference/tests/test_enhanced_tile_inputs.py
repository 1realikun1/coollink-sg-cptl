"""Tests for enhanced sample-tile acquisition logic."""

from pathlib import Path

import geopandas as gpd
import numpy as np
from shapely.geometry import box

from coollink_sg.features.enhanced_tile_inputs import (
    binary_overlap_metrics,
    load_enhanced_tile_config,
    make_target_grid,
    select_meta_tiles,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_enhanced_tile_config_requires_all_open_sources() -> None:
    config = load_enhanced_tile_config(
        PROJECT_ROOT / "config/clementi_enhanced_tile.yaml"
    )

    assert config.tile_id == "SG3414_E020000_N032000"
    assert config.analysis_crs == "EPSG:3414"
    assert config.target_resolution_m == 5
    assert set(config.sources) == {
        "google_open_buildings_2_5d_2023",
        "meta_chmv2",
        "esa_worldcover_2021",
        "copernicus_dem_glo30",
    }


def test_meta_tile_selection_is_unique_and_spatial() -> None:
    index = gpd.GeoDataFrame(
        {"tile": ["b", "a", "a", "outside"]},
        geometry=[
            box(1, 0, 2, 1),
            box(0, 0, 1, 1),
            box(0, 0, 1, 1),
            box(4, 4, 5, 5),
        ],
        crs="EPSG:4326",
    )
    sample = gpd.GeoDataFrame(
        {"tile_id": ["sample"]},
        geometry=[box(0.5, 0.25, 1.5, 0.75)],
        crs="EPSG:4326",
    )

    selected = select_meta_tiles(index, sample, "EPSG:4326")

    assert selected == ("a", "b")


def test_target_grid_and_binary_overlap_are_explicit() -> None:
    sample = gpd.GeoDataFrame(
        {"tile_id": ["sample"]},
        geometry=[box(19_500, 31_500, 22_500, 34_500)],
        crs="EPSG:3414",
    )
    grid = make_target_grid(sample, "EPSG:3414", 5)
    metrics = binary_overlap_metrics(
        np.array([[True, True], [False, False]]),
        np.array([[True, False], [True, False]]),
        np.ones((2, 2), dtype=bool),
    )

    assert (grid.width, grid.height) == (600, 600)
    assert metrics["overlap_cell_count"] == 1
    assert metrics["candidate_only_cell_count"] == 1
    assert metrics["reference_only_cell_count"] == 1
    assert metrics["intersection_over_union_against_osm_proxy"] == 1 / 3
