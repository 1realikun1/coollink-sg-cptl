"""Tests for multi-OD robustness summary calculations."""

import pandas as pd

from coollink_sg.routing.multi_od_robustness_report import (
    summarize_multi_od_results,
)


def _routes() -> pd.DataFrame:
    rows = []
    for scenario, scale in [("building_only", 1.0), ("building_canopy_chmv2", 0.8)]:
        for od_id, band in [("od_1", 1), ("od_2", 2)]:
            for cap, reduction in [(0.0, 0.0), (0.05, 4.0), (0.10, 5.0), (0.15, 5.0)]:
                route_version = 2 if cap >= 0.10 else int(cap > 0)
                rows.append(
                    {
                        "thermal_scenario": scenario,
                        "od_id": od_id,
                        "departure_time_sgt": "2026-08-17T09:00:00+08:00",
                        "detour_limit_fraction": cap,
                        "distance_band_rank": band,
                        "distance_ratio_to_shortest": 1 + cap / 2,
                        "primary_cptl_reduction_vs_shortest_percent": reduction,
                        "cptl_above_26_deg_c_min": 100 * scale * (1 - reduction / 100),
                        "route_id": f"{scenario}_{od_id}_{route_version}",
                    }
                )
    return pd.DataFrame(rows)


def _comparison() -> pd.DataFrame:
    rows = []
    for od_id in ["od_1", "od_2"]:
        for cap in [0.0, 0.05, 0.10, 0.15]:
            rows.append(
                {
                    "od_id": od_id,
                    "departure_time_sgt": "2026-08-17T09:00:00+08:00",
                    "detour_limit_fraction": cap,
                    "alternative_minus_reference_cptl_percent": -20.0,
                    "route_changed": cap > 0,
                }
            )
    return pd.DataFrame(rows)


def test_summary_reports_complete_grid_and_cap_saturation() -> None:
    summary = summarize_multi_od_results(_routes(), _comparison())

    assert summary["od_count"] == 2
    assert summary["route_scenario_count"] == 16
    assert summary["by_scenario_and_detour_cap"]["building_only|5%"][
        "median_cptl_reduction_percent"
    ] == 4.0
    assert summary["canopy_minus_building_only"]["5%"][
        "median_cptl_change_percent"
    ] == -20.0
    assert summary["cap_saturation"]["building_only"][
        "route_changed_10_to_15_percent_share"
    ] == 0.0
