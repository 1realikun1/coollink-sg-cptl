from __future__ import annotations

import pandas as pd

from coollink_sg.reporting.multistation_enhancement import match_routes


def test_match_routes_reports_route_and_benefit_agreement() -> None:
    base = {
        "region_id": ["r"],
        "od_id": ["od"],
        "departure_time_sgt": ["t"],
        "detour_limit_fraction": [0.05],
        "route_id": ["route"],
        "route_length_m": [100.0],
        "cptl_above_26_deg_c_min": [50.0],
        "primary_cptl_reduction_vs_shortest_percent": [2.0],
    }
    matched = match_routes(pd.DataFrame(base), pd.DataFrame(base)).iloc[0]
    assert bool(matched["exact_route_agreement"])
    assert bool(matched["benefit_direction_agreement"])
    assert matched["reduction_change_percentage_points"] == 0
