"""Tests for OSM-based road vegetation proxy features."""

from datetime import UTC, datetime
from pathlib import Path

import geopandas as gpd
import pytest
from shapely.geometry import LineString, Point, box

from coollink_sg.config import load_study_area_config, load_vegetation_config
from coollink_sg.features.vegetation import (
    classify_vegetation_features,
    combined_query_tags,
    compute_road_vegetation_features,
    load_raw_vegetation_snapshot,
    save_raw_vegetation_snapshot,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _config():
    return load_vegetation_config(PROJECT_ROOT / "config/vegetation.yaml")


def _source_features() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "element": ["way", "node", "way"],
            "id": [1, 2, 3],
            "natural": [None, "tree", "tree_row"],
            "landuse": ["grass", None, None],
        },
        geometry=[
            box(-20, -20, 50, 20),
            Point(10, 0),
            LineString([(0, 5), (100, 5)]),
        ],
        crs="EPSG:3414",
    )


def _road_edges() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "segment_id": ["s1", "s2"],
            "length_m": [100.0, 100.0],
        },
        geometry=[
            LineString([(0, 0), (100, 0)]),
            LineString([(200, 0), (300, 0)]),
        ],
        crs="EPSG:3414",
    )


def test_query_tags_are_a_union_without_duplicates() -> None:
    tags = combined_query_tags(_config())

    assert "tree" in tags["natural"]
    assert "tree_row" in tags["natural"]
    assert len(tags["natural"]) == len(set(tags["natural"]))


def test_source_features_are_classified_by_tag_and_geometry() -> None:
    green, trees, rows = classify_vegetation_features(_source_features(), _config())

    assert len(green) == 1
    assert len(trees) == 1
    assert len(rows) == 1


def test_road_vegetation_metrics_are_complete_and_bounded() -> None:
    result, source_counts = compute_road_vegetation_features(
        _road_edges(),
        _source_features(),
        _config(),
    )

    first = result.set_index("segment_id").loc["s1"]
    second = result.set_index("segment_id").loc["s2"]
    assert result["green_area_proxy_ratio"].between(0, 1).all()
    assert first["green_area_proxy_ratio"] > 0
    assert first["mapped_tree_count"] == 1
    assert first["mapped_tree_row_length_m"] > 0
    assert second["green_area_proxy_ratio"] == 0
    assert second["mapped_tree_count"] == 0
    assert source_counts == {
        "mapped_green_polygon_count": 1,
        "mapped_tree_point_count": 1,
        "mapped_tree_row_count": 1,
    }


def test_duplicate_segment_ids_are_rejected() -> None:
    edges = _road_edges()
    edges.loc[1, "segment_id"] = "s1"

    with pytest.raises(ValueError, match="must be unique"):
        compute_road_vegetation_features(edges, _source_features(), _config())


def test_raw_vegetation_snapshot_is_immutable(tmp_path: Path) -> None:
    retrieved = datetime(2026, 8, 17, 6, 0, tzinfo=UTC)
    study_area = load_study_area_config(PROJECT_ROOT / "config/study_area.yaml")
    snapshot = save_raw_vegetation_snapshot(
        _source_features(),
        retrieved,
        _config(),
        study_area,
        tmp_path,
    )

    loaded = load_raw_vegetation_snapshot(snapshot)
    assert len(loaded) == 3
    assert (snapshot / "manifest.json").is_file()
    with pytest.raises(FileExistsError):
        save_raw_vegetation_snapshot(
            _source_features(),
            retrieved,
            _config(),
            study_area,
            tmp_path,
        )

