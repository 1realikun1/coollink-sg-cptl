from pathlib import Path

import pandas as pd

from coollink_sg.routing.representative_cptl import (
    load_representative_cptl_config,
    summarize_representative_routes,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_representative_cptl_config_matches_existing_method() -> None:
    config = load_representative_cptl_config(
        PROJECT_ROOT / "config/representative_cptl.yaml"
    )
    assert len(config.regions) == 2
    assert config.origin_count == 4
    assert len(config.distance_bands_m) == 3
    assert config.detour_limits == (0.0, 0.05, 0.1, 0.15)
    assert config.primary_threshold_deg_c == 26


def test_raffles_place_cptl_config_matches_regional_design() -> None:
    config = load_representative_cptl_config(
        PROJECT_ROOT / "config/raffles_place_cptl.yaml"
    )
    assert tuple(region.region_id for region in config.regions) == ("raffles_place_mrt",)
    assert config.origin_count == 4
    assert config.detour_limits == (0.0, 0.05, 0.1, 0.15)
    assert config.time_bin_seconds == 60


def test_representative_summary_keeps_regions_separate() -> None:
    routes = pd.DataFrame(
        {
            "region_id": ["a", "a", "b", "b"],
            "detour_limit_fraction": [0.05] * 4,
            "od_id": ["a1", "a2", "b1", "b2"],
            "departure_time_sgt": ["09:00", "09:00", "09:00", "09:00"],
            "cptl_above_26_deg_c_min": [10, 20, 30, 40],
            "primary_cptl_reduction_vs_shortest_percent": [1, 3, 5, 7],
            "distance_ratio_to_shortest": [1.01, 1.03, 1.02, 1.04],
        }
    )
    result = summarize_representative_routes(routes, "cptl_above_26_deg_c_min")
    assert result.set_index("region_id").loc["a", "median_cptl_reduction_percent"] == 2
    assert result.set_index("region_id").loc["b", "median_cptl_reduction_percent"] == 6
