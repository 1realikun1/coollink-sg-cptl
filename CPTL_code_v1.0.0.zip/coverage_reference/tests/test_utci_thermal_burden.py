"""Tests for radiation-driven UTCI road thermal burden."""

from pathlib import Path

import geopandas as gpd
import pandas as pd
from shapely.geometry import LineString

from coollink_sg.config import (
    ProcessedLayerConfig,
    UTCIThermalBurdenConfig,
    load_utci_thermal_burden_config,
)
from coollink_sg.heat.utci_thermal_burden import (
    calculate_clear_sky_context,
    compute_utci_thermal_burden,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _config() -> UTCIThermalBurdenConfig:
    return UTCIThermalBurdenConfig(
        analysis_id="test_utci",
        output_crs="EPSG:3414",
        scenario_time_sgt="2026-08-17T12:45:00+08:00",
        timezone="Asia/Singapore",
        walking_speed_m_s=1.2,
        heat_stress_threshold_deg_c=26.0,
        solar_position_method="pvlib_nrel_spa",
        clear_sky_model="pvlib_ineichen",
        solar_gain_model="ashrae_55_erf",
        sky_view_fraction=1.0,
        body_exposure_fraction=1.0,
        shortwave_absorptivity=0.7,
        floor_reflectance=0.6,
        posture="standing",
        minimum_utci_wind_speed_m_s=0.5,
        roads=ProcessedLayerConfig("unused.gpkg", "roads"),
        weather_associations_path="unused.csv",
        study_area_config_path="unused.yaml",
        shade_fields={
            "low": "combined_shade_evidence_fraction_low",
            "central": "combined_shade_evidence_fraction_central",
            "high": "combined_shade_evidence_fraction_high",
        },
    )


def _roads() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "segment_id": ["sun", "shade"],
            "length_m": [120.0, 120.0],
            "combined_shade_evidence_fraction_low": [0.0, 1.0],
            "combined_shade_evidence_fraction_central": [0.0, 1.0],
            "combined_shade_evidence_fraction_high": [0.0, 1.0],
        },
        geometry=[LineString([(0, 0), (120, 0)]), LineString([(0, 10), (120, 10)])],
        crs="EPSG:3414",
    )


def _weather() -> pd.DataFrame:
    rows = []
    units = {
        "air_temperature": "degC",
        "relative_humidity": "percent",
        "wind_speed": "m/s",
    }
    values = {"air_temperature": 31.0, "relative_humidity": 70.0, "wind_speed": 1.0}
    for segment_id in ["sun", "shade"]:
        for metric in units:
            rows.append(
                {
                    "segment_id": segment_id,
                    "metric": metric,
                    "source_value": values[metric],
                    "source_unit": units[metric],
                    "source_station_id": f"station_{metric}",
                    "source_station_name": metric,
                    "observed_at_sgt": "2026-08-17T12:59:00+08:00",
                    "road_midpoint_to_station_distance_m": 1000.0,
                    "association_status": "context_only_not_road_observation",
                    "weather_snapshot_id": "snapshot",
                }
            )
    return pd.DataFrame(rows)


def test_project_utci_config_has_no_component_weights() -> None:
    config = load_utci_thermal_burden_config(
        PROJECT_ROOT / "config/utci_thermal_burden.yaml"
    )

    assert config.heat_stress_threshold_deg_c == 26
    assert config.clear_sky_model == "pvlib_ineichen"
    assert config.solar_gain_model == "ashrae_55_erf"
    assert not hasattr(config, "weight")


def test_clear_sky_context_is_positive_at_clementi_midday() -> None:
    context = calculate_clear_sky_context(
        1.3141081,
        103.7656688,
        "2026-08-17T12:45:00+08:00",
        "Asia/Singapore",
    )

    assert context["solar_apparent_elevation_deg"] > 70
    assert context["clear_sky_dni_w_m2"] > 200
    assert context["clear_sky_ghi_w_m2"] > 0


def test_full_shade_reduces_modeled_utci_and_burden() -> None:
    result, metadata = compute_utci_thermal_burden(
        _roads(), _weather(), 1.3141081, 103.7656688, _config()
    )
    indexed = result.set_index("segment_id")

    assert metadata["heat_stress_threshold_deg_c"] == 26
    assert indexed.loc["sun", "modeled_utci_mean_central_deg_c"] > indexed.loc[
        "shade", "modeled_utci_mean_central_deg_c"
    ]
    assert indexed.loc["sun", "thermal_burden_central_deg_c_min"] > indexed.loc[
        "shade", "thermal_burden_central_deg_c_min"
    ]
    assert indexed["formal_heat_score_generated"].eq(False).all()  # noqa: E712
    assert "heat_score" not in indexed.columns
