"""Tests for the strict unified road-feature table assembly."""

import math
from pathlib import Path

import geopandas as gpd
import pytest
from shapely.geometry import LineString

from coollink_sg.config import (
    ProcessedLayerConfig,
    RoadFeatureTableConfig,
    load_road_feature_table_config,
)
from coollink_sg.features.road_feature_table import assemble_road_feature_table

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _config() -> RoadFeatureTableConfig:
    source = ProcessedLayerConfig(path="unused.gpkg", layer="unused")
    return RoadFeatureTableConfig(
        join_key="segment_id",
        output_crs="EPSG:3414",
        network=source,
        vegetation=source,
        built_environment=source,
        sentinel2_ndvi=source,
        solar_shade=source,
        vegetation_fields=("context_buffer_m", "context_buffer_area_m2", "green"),
        built_environment_fields=("built",),
        sentinel2_ndvi_fields=(
            "sentinel2_ndvi_mean",
            "sentinel2_ndvi_median",
            "sentinel2_ndvi_valid_pixel_count",
            "sentinel2_ndvi_buffer_pixel_count",
            "sentinel2_ndvi_valid_pixel_fraction",
            "sentinel2_ndvi_observation_count_mean",
        ),
        solar_shade_fields=(
            "scenario_time_sgt",
            "solar_elevation_deg",
            "solar_azimuth_deg",
            "building_shadow_length_low_m",
            "building_shadow_fraction_low",
            "building_shadow_length_central_m",
            "building_shadow_fraction_central",
            "building_shadow_length_high_m",
            "building_shadow_fraction_high",
            "direct_mapped_cover_length_m",
            "direct_mapped_cover_fraction",
            "combined_shade_evidence_length_m",
            "combined_shade_evidence_fraction",
            "shade_evidence_class",
            "shade_model_status",
        ),
        sentinel2_ndvi_nullable_fields=(
            "sentinel2_ndvi_mean",
            "sentinel2_ndvi_median",
            "sentinel2_ndvi_observation_count_mean",
        ),
    )


def _network() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "segment_id": ["s2", "s1"],
            "length_m": [10.0, 20.0],
            "highway": ["footway", "residential"],
        },
        geometry=[
            LineString([(0, 0), (10, 0)]),
            LineString([(20, 0), (40, 0)]),
        ],
        crs="EPSG:3414",
    )


def _vegetation() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "segment_id": ["s1", "s2"],
            "length_m": [20.0, 10.0],
            "context_buffer_m": [20.0, 20.0],
            "context_buffer_area_m2": [100.0, 80.0],
            "green": [0.4, 0.1],
        },
        geometry=[
            LineString([(20, 0), (40, 0)]),
            LineString([(0, 0), (10, 0)]),
        ],
        crs="EPSG:3414",
    )


def _built() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "segment_id": ["s1", "s2"],
            "length_m": [20.0, 10.0],
            "context_buffer_m": [20.0, 20.0],
            "context_buffer_area_m2": [100.0, 80.0],
            "built": [0.2, 0.6],
        },
        geometry=[
            LineString([(20, 0), (40, 0)]),
            LineString([(0, 0), (10, 0)]),
        ],
        crs="EPSG:3414",
    )


def _sentinel2() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "segment_id": ["s1", "s2"],
            "sentinel2_ndvi_mean": [0.6, None],
            "sentinel2_ndvi_median": [0.55, None],
            "sentinel2_ndvi_valid_pixel_count": [8, 0],
            "sentinel2_ndvi_buffer_pixel_count": [10, 10],
            "sentinel2_ndvi_valid_pixel_fraction": [0.8, 0.0],
            "sentinel2_ndvi_observation_count_mean": [3.0, None],
        },
        geometry=[
            LineString([(20, 0), (40, 0)]),
            LineString([(0, 0), (10, 0)]),
        ],
        crs="EPSG:3414",
    )


def _solar_shade() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "segment_id": ["s1", "s2"],
            "length_m": [20.0, 10.0],
            "scenario_time_sgt": [
                "2026-08-17T12:45:00+08:00",
                "2026-08-17T12:45:00+08:00",
            ],
            "solar_elevation_deg": [76.0, 76.0],
            "solar_azimuth_deg": [25.0, 25.0],
            "building_shadow_length_low_m": [1.0, 0.0],
            "building_shadow_fraction_low": [0.05, 0.0],
            "building_shadow_length_central_m": [2.0, 0.0],
            "building_shadow_fraction_central": [0.1, 0.0],
            "building_shadow_length_high_m": [3.0, 0.0],
            "building_shadow_fraction_high": [0.15, 0.0],
            "direct_mapped_cover_length_m": [4.0, 0.0],
            "direct_mapped_cover_fraction": [0.2, 0.0],
            "combined_shade_evidence_length_m": [6.0, 0.0],
            "combined_shade_evidence_fraction": [0.3, 0.0],
            "shade_evidence_class": [
                "height_tagged_shadow_and_direct_cover",
                "none_observed_in_incomplete_sources",
            ],
            "shade_model_status": [
                "estimated_building_heights_and_mapped_cover_not_validated",
                "estimated_building_heights_and_mapped_cover_not_validated",
            ],
        },
        geometry=[
            LineString([(20, 0), (40, 0)]),
            LineString([(0, 0), (10, 0)]),
        ],
        crs="EPSG:3414",
    )


def test_project_configuration_declares_strict_join_sources() -> None:
    config = load_road_feature_table_config(
        PROJECT_ROOT / "config/road_feature_table.yaml"
    )

    assert config.join_key == "segment_id"
    assert config.output_crs == "EPSG:3414"
    assert "green_area_proxy_ratio" in config.vegetation_fields
    assert "building_passage_flag" in config.built_environment_fields
    assert "sentinel2_ndvi_mean" in config.sentinel2_ndvi_fields
    assert "combined_shade_evidence_fraction" in config.solar_shade_fields


def test_join_is_one_to_one_and_preserves_network_order_and_geometry() -> None:
    result = assemble_road_feature_table(
        _network(), _vegetation(), _built(), _sentinel2(), _solar_shade(), _config()
    )

    assert result["segment_id"].tolist() == ["s2", "s1"]
    assert result.set_index("segment_id").loc["s1", "green"] == 0.4
    assert result.set_index("segment_id").loc["s2", "built"] == 0.6
    assert result.set_index("segment_id").loc["s1", "sentinel2_ndvi_mean"] == 0.6
    assert result.set_index("segment_id").loc[
        "s1", "combined_shade_evidence_fraction"
    ] == pytest.approx(0.3)
    assert math.isnan(
        result.set_index("segment_id").loc["s2", "sentinel2_ndvi_mean"]
    )
    assert result.geometry.equals(_network().geometry)
    assert result.crs.to_epsg() == 3414


def test_duplicate_source_keys_are_rejected() -> None:
    vegetation = _vegetation()
    vegetation.loc[1, "segment_id"] = "s1"

    with pytest.raises(ValueError, match="must be unique"):
        assemble_road_feature_table(
            _network(), vegetation, _built(), _sentinel2(), _solar_shade(), _config()
        )


def test_incomplete_source_key_coverage_is_rejected() -> None:
    vegetation = _vegetation().iloc[[0]].copy()

    with pytest.raises(ValueError, match="key coverage differs"):
        assemble_road_feature_table(
            _network(), vegetation, _built(), _sentinel2(), _solar_shade(), _config()
        )


def test_mismatched_context_definition_is_rejected() -> None:
    built = _built()
    built.loc[0, "context_buffer_m"] = 25.0

    with pytest.raises(ValueError, match="context_buffer_m"):
        assemble_road_feature_table(
            _network(), _vegetation(), built, _sentinel2(), _solar_shade(), _config()
        )


def test_crs_mismatch_is_rejected() -> None:
    built = _built().to_crs("EPSG:4326")

    with pytest.raises(ValueError, match="CRS must equal"):
        assemble_road_feature_table(
            _network(), _vegetation(), built, _sentinel2(), _solar_shade(), _config()
        )


def test_satellite_missing_values_must_match_zero_valid_count() -> None:
    sentinel2 = _sentinel2()
    sentinel2.loc[1, "sentinel2_ndvi_mean"] = 0.0

    with pytest.raises(ValueError, match="missing exactly"):
        assemble_road_feature_table(
            _network(), _vegetation(), _built(), sentinel2, _solar_shade(), _config()
        )


def test_incomplete_satellite_key_coverage_is_rejected() -> None:
    sentinel2 = _sentinel2().iloc[[0]].copy()

    with pytest.raises(ValueError, match="key coverage differs"):
        assemble_road_feature_table(
            _network(), _vegetation(), _built(), sentinel2, _solar_shade(), _config()
        )


def test_invalid_solar_shade_fraction_is_rejected() -> None:
    shade = _solar_shade()
    shade.loc[0, "combined_shade_evidence_fraction"] = 1.2
    with pytest.raises(ValueError, match="within 0–1"):
        assemble_road_feature_table(
            _network(), _vegetation(), _built(), _sentinel2(), shade, _config()
        )
