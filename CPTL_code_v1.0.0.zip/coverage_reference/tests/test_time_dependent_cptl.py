"""Tests for time-dependent distance-constrained CPTL routing."""

from pathlib import Path

import geopandas as gpd
import pandas as pd
import pytest
from shapely.geometry import LineString, Point

from coollink_sg.config import DynamicCPTLConfig, ProcessedLayerConfig
from coollink_sg.heat.dynamic_utci import TimeVaryingUTCI
from coollink_sg.routing.time_dependent_cptl import (
    compute_time_dependent_cptl_routes,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]
STATUS = "provisional_static_repeat_not_solweig_dynamic_output"


def _config() -> DynamicCPTLConfig:
    return DynamicCPTLConfig(
        analysis_id="test_dynamic_cptl",
        output_crs="EPSG:3414",
        timezone="Asia/Singapore",
        departure_times=("2026-08-17T12:00:00+08:00",),
        walking_speed_m_s=1.0,
        primary_threshold_deg_c=26.0,
        sensitivity_thresholds_deg_c=(26.0, 32.0, 38.0),
        detour_limits=(0.0, 0.10),
        time_bin_seconds=60,
        integration_method="piecewise_linear_threshold_crossing_exact",
        waiting_allowed=False,
        primary_height_scenario="central",
        thermal_source_status=STATUS,
        is_solweig_dynamic_result=False,
        output_stem="test_dynamic_cptl",
        validation_series_start_sgt="2026-08-17T12:00:00+08:00",
        validation_series_end_sgt="2026-08-17T12:10:00+08:00",
        validation_series_interval_seconds=300,
        network_path="unused.gpkg",
        nodes_layer="nodes",
        edges_layer="edges",
        static_thermal=ProcessedLayerConfig("unused.gpkg", "thermal"),
        dynamic_thermal_path="unused.csv",
        od_summary_path="unused.json",
        endpoints=ProcessedLayerConfig("unused.gpkg", "endpoints"),
    )


def _nodes() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {"osmid": [1, 2, 3, 4]},
        geometry=[Point(0, 0), Point(60, 0), Point(0, 66), Point(120, 0)],
        crs="EPSG:3414",
    )


def _edges() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "u": [1, 2, 1, 3],
            "v": [2, 4, 3, 4],
            "key": [0, 0, 0, 0],
            "segment_id": ["hot_1", "hot_2", "cool_1", "cool_2"],
            "length_m": [60.0, 60.0, 66.0, 66.0],
        },
        geometry=[
            LineString([(0, 0), (60, 0)]),
            LineString([(60, 0), (120, 0)]),
            LineString([(0, 0), (0, 66)]),
            LineString([(0, 66), (120, 0)]),
        ],
        crs="EPSG:3414",
    )


def _thermal() -> TimeVaryingUTCI:
    timestamps = pd.date_range("2026-08-17T12:00:00+08:00", periods=3, freq="5min")
    rows = []
    for segment_id in ["hot_1", "hot_2", "cool_1", "cool_2"]:
        value = 36.0 if segment_id.startswith("hot") else 30.0
        for timestamp in timestamps:
            rows.append(
                {
                    "segment_id": segment_id,
                    "timestamp_sgt": str(timestamp),
                    "height_scenario": "central",
                    "modeled_utci_deg_c": value,
                    "thermal_source_status": STATUS,
                }
            )
    return TimeVaryingUTCI(pd.DataFrame(rows), "central", STATUS)


def test_distance_constraint_rejects_then_accepts_lower_cptl_route() -> None:
    routes, segments, summary = compute_time_dependent_cptl_routes(
        _nodes(), _edges(), _thermal(), 1, 4, _config()
    )
    indexed = routes.set_index("detour_limit_fraction")

    assert indexed.loc[0.0, "route_length_m"] == 120.0
    assert indexed.loc[0.0, "cptl_above_26_deg_c_min"] == pytest.approx(20.0)
    assert indexed.loc[0.1, "route_length_m"] == 132.0
    assert indexed.loc[0.1, "cptl_above_26_deg_c_min"] == pytest.approx(8.8)
    assert indexed.loc[0.1, "primary_cptl_reduction_vs_shortest_percent"] == pytest.approx(
        56.0
    )
    assert summary["is_solweig_dynamic_result"] is False
    assert len(segments) == 4


def test_segment_clock_uses_accumulated_arrival_time() -> None:
    _, segments, _ = compute_time_dependent_cptl_routes(
        _nodes(), _edges(), _thermal(), 1, 4, _config()
    )
    shortest = segments.loc[segments["detour_limit_fraction"].eq(0)].sort_values(
        "route_sequence"
    )

    assert shortest.iloc[0]["entry_time_sgt"] == "2026-08-17T12:00:00+08:00"
    assert shortest.iloc[1]["entry_time_sgt"] == "2026-08-17T12:01:00+08:00"
    assert shortest.iloc[1]["exit_time_sgt"] == "2026-08-17T12:02:00+08:00"
