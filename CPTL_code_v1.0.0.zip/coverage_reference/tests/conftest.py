"""Archive-only handling of one upstream integration test requiring an unbundled raw index."""
from pathlib import Path
import pytest

def pytest_collection_modifyitems(items):
    root = Path(__file__).resolve().parents[1]
    index = root / "data/raw/national_tile_inputs/20260819T030000Z/meta_chmv2/tiles.geojson"
    if not index.exists():
        for item in items:
            if item.name == "test_jurong_canopy_supplement_selects_only_one_missing_tile":
                item.add_marker(pytest.mark.skip(reason="Requires the original global CHMv2 raw tile index, not redistributed in this processed-data archive."))
