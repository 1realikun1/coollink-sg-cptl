"""Tests for national tiling and 3D-source replacement gates."""

from pathlib import Path

import geopandas as gpd
from shapely.geometry import box

from coollink_sg.data.national_domain import (
    assess_3d_sources,
    build_tile_grid,
    load_national_domain_config,
    summarize_current_building_baseline,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_national_config_is_metric_and_blocks_unvalidated_replacement() -> None:
    config = load_national_domain_config(PROJECT_ROOT / "config/national_3d_model.yaml")
    assessment = assess_3d_sources(config)

    assert config.analysis_crs == "EPSG:3414"
    assert config.core_tile_size_m == 2000
    assert config.shadow_buffer_m == 500
    assert assessment["direct_replacement_approved"] is False
    assert assessment["sources"]["nus_voxcity"]["checks"]["is_analysis_dataset"] is False
    assert assessment["sources"]["sla_national_3d"]["checks"]["data_accessible"] is False
    assert (
        assessment["sources"]["google_open_buildings_2_5d_2023"]["checks"]
        ["singapore_validation_passed"]
        is False
    )
    assert (
        assessment["sources"]["esa_worldcover_2021"]
        ["building_replacement_gate_applicable"]
        is False
    )


def test_tile_grid_keeps_intersecting_land_and_explicit_load_estimates() -> None:
    planning_areas = gpd.GeoDataFrame(
        {"name": ["west", "east"]},
        geometry=[box(500, 500, 2500, 2500), box(2500, 500, 3500, 1500)],
        crs="EPSG:3414",
    )

    boundary, tiles = build_tile_grid(
        planning_areas,
        analysis_crs="EPSG:3414",
        tile_size_m=2000,
        shadow_buffer_m=500,
        raster_resolution_m=5,
        timestep_count=37,
    )

    assert len(boundary) == 1
    assert len(tiles) == 4
    assert tiles["tile_id"].is_unique
    assert set(tiles.geometry.area) == {4_000_000}
    assert set(tiles["core_raster_cells"]) == {160_000}
    assert set(tiles["buffered_raster_cells"]) == {360_000}
    assert set(tiles["estimated_cell_timesteps"]) == {13_320_000}
    assert abs(tiles["land_area_km2"].sum() - boundary.geometry.area.sum() / 1e6) < 1e-9


def test_current_baseline_summary_labels_open_buildings_cap_conflict() -> None:
    buildings = gpd.GeoDataFrame(
        {
            "height_central_m": [12.0, 100.0, 112.0],
            "height_method": ["direct", "estimated", "estimated"],
        },
        geometry=[box(0, 0, 1, 1), box(1, 0, 2, 1), box(2, 0, 3, 1)],
        crs="EPSG:3414",
    )

    summary = summarize_current_building_baseline(buildings)

    assert summary["building_count"] == 3
    assert summary["height_central_above_open_buildings_cap_count"] == 1
    assert summary["height_method_counts"] == {"direct": 1, "estimated": 2}
