import numpy as np
import pandas as pd

from coollink_sg.routing.behavior_probability_routing import (
    _markdown_table,
    acceptance_probability_draws,
    behavior_screening_maximum_distance,
    select_behavioral_offer,
)


def test_markdown_table_does_not_require_optional_tabulate() -> None:
    rendered = _markdown_table(pd.DataFrame({"region": ["a|b"], "value": [1.5]}))
    assert "| region | value |" in rendered
    assert "| a\\|b | 1.5 |" in rendered


def test_behavior_screening_distance_matches_probability_bound() -> None:
    distance = behavior_screening_maximum_distance(1000.0, 1.2, 25.0, 0.05)
    probability = 1 / (1 + np.exp((distance - 1.2 * 1000.0) / 25.0))
    assert np.isclose(probability, 0.05)


def test_acceptance_probability_prefers_lower_generalized_cost() -> None:
    bootstrap = pd.DataFrame(
        {"sun_cost_factor_beta": [1.2, 1.3], "choice_scale_m": [20.0, 30.0]}
    )
    probability = acceptance_probability_draws(10, 90, 100, 0, bootstrap)
    assert np.all(probability > 0.5)


def test_select_offer_maximizes_probability_weighted_reduction() -> None:
    candidates = pd.DataFrame(
        {
            "is_shortest_distance": [True, False, False],
            "cptl_reduction_deg_c_min": [0.0, 5.0, 8.0],
            "probability_weighted_cptl_reduction_deg_c_min": [0.0, 4.0, 3.0],
            "mean_acceptance_probability": [1.0, 0.8, 0.375],
            "route_length_m": [1000.0, 1030.0, 1100.0],
            "route_id": ["s", "a", "b"],
        }
    )
    assert select_behavioral_offer(candidates, 1e-9, 0.05) == 1


def test_select_offer_rejects_alternative_below_probability_floor() -> None:
    candidates = pd.DataFrame(
        {
            "is_shortest_distance": [True, False],
            "cptl_reduction_deg_c_min": [0.0, 10.0],
            "probability_weighted_cptl_reduction_deg_c_min": [0.0, 0.4],
            "mean_acceptance_probability": [1.0, 0.04],
            "route_length_m": [1000.0, 1200.0],
            "route_id": ["s", "a"],
        }
    )
    assert select_behavioral_offer(candidates, 1e-9, 0.05) == 0
