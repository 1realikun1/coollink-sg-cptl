"""Tests for provenance-labelled building-height completion."""

from pathlib import Path

import geopandas as gpd
import pytest
from shapely.geometry import box

from coollink_sg.config import BuildingHeightConfig, load_building_height_config
from coollink_sg.features.building_height import (
    complete_building_heights,
    parse_positive_levels,
)


def _config() -> BuildingHeightConfig:
    return BuildingHeightConfig(
        model_id="test",
        height_field="height",
        levels_field="building:levels",
        floor_height_quantiles=(0.25, 0.5, 0.75),
        minimum_type_level_sample=2,
        analysis_crs="EPSG:3414",
        built_environment_raw_snapshot="unused",
        hdb3d_cityjson_path="unused",
    )


def _source() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "element": ["way"] * 8,
            "id": list(range(1, 9)),
            "building": [
                "residential",
                "residential",
                "yes",
                "yes",
                "yes",
                "yes",
                "residential",
                "rare",
            ],
            "height": [12, 30, 9, None, None, None, None, None],
            "building:levels": [4, 10, 3, 2, 4, None, None, None],
        },
        geometry=[box(i * 2, 0, i * 2 + 1, 1) for i in range(8)],
        crs="EPSG:3414",
    )


def test_project_config_requires_data_derived_quantiles() -> None:
    config = load_building_height_config(Path("config/building_height.yaml"))
    assert config.floor_height_quantiles == (0.25, 0.5, 0.75)
    assert config.minimum_type_level_sample == 5
    assert "20260817T115026163523Z" in config.hdb3d_cityjson_path


@pytest.mark.parametrize(
    ("value", "expected"),
    [(3, 3.0), ("4.5", 4.5), (0, None), ("2;3", None), (None, None)],
)
def test_parse_positive_levels_rejects_ranges(value, expected) -> None:
    assert parse_positive_levels(value) == expected


def test_completion_uses_strict_source_priority_and_fills_all_buildings() -> None:
    hdb = {
        "way/1": {"height_m": 99.0, "hdb_max_floor_lvl": 30.0},
        "way/5": {"height_m": 15.3, "hdb_max_floor_lvl": 5.0},
    }
    result, diagnostics = complete_building_heights(_source(), hdb, _config())
    indexed = result.set_index("building_id")
    assert indexed.loc["way/1", "height_central_m"] == 12
    assert indexed.loc["way/1", "height_method"] == "osm_explicit_positive_height"
    assert indexed.loc["way/5", "height_method"] == "hdb3d_storey_estimate_osm_id_match"
    assert indexed.loc["way/4", "height_method"] == "osm_levels_times_local_floor_height"
    assert indexed.loc["way/6", "height_method"].startswith("building_type_level")
    assert indexed.loc["way/8", "height_method"].startswith("global_level")
    assert result["height_central_m"].notna().all()
    assert (result["height_low_m"] <= result["height_central_m"]).all()
    assert (result["height_central_m"] <= result["height_high_m"]).all()
    assert diagnostics["calibration_sample_count"] == 3
    assert diagnostics["floor_height_central_m"] == pytest.approx(3.0)


def test_completion_requires_local_height_level_calibration() -> None:
    source = _source()
    source["height"] = None
    with pytest.raises(ValueError, match="At least three"):
        complete_building_heights(source, {}, _config())
