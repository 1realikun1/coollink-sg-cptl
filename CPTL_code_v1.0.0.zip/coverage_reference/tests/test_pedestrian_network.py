"""Unit tests for pedestrian-network preparation."""

import math
from pathlib import Path

import networkx as nx
import pytest
from shapely.geometry import LineString

from coollink_sg.config import load_study_area_config
from coollink_sg.data.pedestrian_network import (
    annotate_projected_network,
    create_study_area,
    summarize_network,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _toy_walk_graph() -> nx.MultiDiGraph:
    graph = nx.MultiDiGraph(crs="EPSG:4326")
    graph.add_node(1, x=103.7650, y=1.3140)
    graph.add_node(2, x=103.7655, y=1.3145)
    graph.add_node(3, x=103.7660, y=1.3148)
    graph.add_edge(
        1,
        2,
        key=0,
        geometry=LineString([(103.7650, 1.3140), (103.7655, 1.3145)]),
        osmid=101,
    )
    graph.add_edge(
        2,
        3,
        key=0,
        geometry=LineString([(103.7655, 1.3145), (103.7660, 1.3148)]),
        osmid=102,
    )
    return graph


def test_study_area_uses_metric_radius() -> None:
    config = load_study_area_config(PROJECT_ROOT / "config/study_area.yaml")
    center, area = create_study_area(config)

    assert center.crs.to_string() == "EPSG:3414"
    assert area.crs.to_string() == "EPSG:3414"
    assert area.geometry.iloc[0].area == pytest.approx(math.pi * 2000**2, rel=0.01)


def test_projected_edges_receive_unique_ids_and_positive_lengths() -> None:
    graph, nodes, edges = annotate_projected_network(_toy_walk_graph(), "EPSG:3414")

    assert str(nodes.crs) == "EPSG:3414"
    assert str(edges.crs) == "EPSG:3414"
    assert edges["segment_id"].is_unique
    assert (edges["length_m"] > 0).all()
    assert graph.edges[1, 2, 0]["segment_id"] == "osm:1:2:0"


def test_network_summary_reports_connectivity() -> None:
    config = load_study_area_config(PROJECT_ROOT / "config/study_area.yaml")
    graph, nodes, edges = annotate_projected_network(_toy_walk_graph(), "EPSG:3414")

    summary = summarize_network(graph, nodes, edges, config)

    assert summary["node_count"] == 3
    assert summary["directed_edge_count"] == 2
    assert summary["weakly_connected_components"] == 1
    assert summary["largest_component_node_share"] == 1.0
