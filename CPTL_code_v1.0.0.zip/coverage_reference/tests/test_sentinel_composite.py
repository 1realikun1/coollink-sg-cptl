"""Tests for fixed-rule multi-date Sentinel-2 NDVI compositing."""

import json
from pathlib import Path

import geopandas as gpd
import numpy as np
import pytest
from shapely.geometry import Polygon, mapping

from coollink_sg.config import load_sentinel_composite_config
from coollink_sg.features.sentinel_composite import (
    median_ndvi_composite,
    select_composite_items,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _config():
    return load_sentinel_composite_config(
        PROJECT_ROOT / "config/sentinel_composite.yaml"
    )


def _item(identifier: str, date: str, cloud: float) -> dict:
    footprint = Polygon([(103, 1), (104, 1), (104, 2), (103, 2)])
    return {
        "id": identifier,
        "geometry": mapping(footprint),
        "properties": {
            "datetime": f"{date}T03:00:00Z",
            "eo:cloud_cover": cloud,
        },
        "assets": {name: {} for name in ("red", "nir", "scl")},
    }


def test_project_configuration_fixes_selection_and_median_rules() -> None:
    config = _config()

    assert config.scene_count == 6
    assert config.selection_rule == "lowest_scene_cloud_full_coverage_unique_dates"
    assert config.composite_statistic == "median"
    assert config.valid_scl_classes == (4, 5, 6, 7)


def test_selection_uses_cloud_order_and_unique_dates() -> None:
    items = [
        _item("duplicate-date-higher", "2026-05-01", 3),
        _item("duplicate-date-lower", "2026-05-01", 1),
        *[
            _item(f"scene-{index}", f"2026-05-{index + 1:02d}", index + 2)
            for index in range(1, 7)
        ],
    ]
    study = gpd.GeoDataFrame(
        geometry=[Polygon([(103.2, 1.2), (103.3, 1.2), (103.3, 1.3), (103.2, 1.3)])],
        crs="EPSG:4326",
    )

    selected = select_composite_items(
        json.dumps({"features": items}).encode(), study, _config()
    )

    assert len(selected) == 6
    assert selected[0]["id"] == "duplicate-date-lower"
    assert "duplicate-date-higher" not in {item["id"] for item in selected}
    assert len({item["properties"]["datetime"][:10] for item in selected}) == 6


def test_median_composite_preserves_gaps_and_counts_observations() -> None:
    first = np.array([[0.2, np.nan], [0.4, np.nan]], dtype="float32")
    second = np.array([[0.6, 0.8], [np.nan, np.nan]], dtype="float32")
    third = np.array([[0.4, 0.6], [0.2, np.nan]], dtype="float32")

    composite, count = median_ndvi_composite([first, second, third])

    assert composite[0, 0] == pytest.approx(0.4)
    assert composite[0, 1] == pytest.approx(0.7)
    assert composite[1, 0] == pytest.approx(0.3)
    assert np.isnan(composite[1, 1])
    assert count.tolist() == [[3, 2], [2, 0]]


def test_median_composite_rejects_single_or_misaligned_scenes() -> None:
    with pytest.raises(ValueError, match="at least two"):
        median_ndvi_composite([np.ones((2, 2))])
    with pytest.raises(ValueError, match="share a shape"):
        median_ndvi_composite([np.ones((2, 2)), np.ones((3, 3))])
