"""Tests for partial, evidence-labelled road solar shade modelling."""

from datetime import UTC, datetime
from pathlib import Path

import geopandas as gpd
import pytest
from shapely.geometry import LineString, box

from coollink_sg.config import load_solar_shade_config
from coollink_sg.features.solar_shade import (
    calculate_road_shade_evidence,
    parse_metric_height,
    project_building_shadows,
    shadow_offset_m,
    solar_position_noaa,
)


def test_project_config_is_conservative_and_time_explicit() -> None:
    config = load_solar_shade_config(Path("config/solar_shade.yaml"))
    assert config.scenario_time_sgt == "2026-08-17T12:45:00+08:00"
    assert config.source_weather_snapshot_id == "20260817T050515590629Z"
    assert config.use_building_levels_as_height is False
    assert config.analysis_crs == "EPSG:3414"


@pytest.mark.parametrize(
    ("value", "expected"),
    [(12, 12.0), ("4.5 m", 4.5), (" 9 metres ", 9.0), (0, None), ("3;4", None), ("12 ft", None)],
)
def test_parse_metric_height_avoids_ambiguous_conversion(value, expected) -> None:
    assert parse_metric_height(value) == expected


def test_solar_position_is_timezone_aware_and_physically_bounded() -> None:
    scenario = datetime.fromisoformat("2026-08-17T12:45:00+08:00")
    elevation, azimuth = solar_position_noaa(scenario, 1.314, 103.765)
    assert 70 < elevation < 90
    assert 0 <= azimuth < 360
    with pytest.raises(ValueError, match="timezone-aware"):
        solar_position_noaa(datetime(2026, 8, 17, 12, 45), 1.314, 103.765)


def test_shadow_offset_is_opposite_solar_azimuth() -> None:
    east, north, length = shadow_offset_m(10, 45, 90)
    assert length == pytest.approx(10)
    assert east == pytest.approx(-10)
    assert north == pytest.approx(0, abs=1e-12)


def test_only_positive_explicit_building_heights_are_projected() -> None:
    source = gpd.GeoDataFrame(
        {
            "element": ["way", "way", "way"],
            "id": [1, 2, 3],
            "building": ["yes", "yes", "yes"],
            "height": [10, "3 floors", 0],
        },
        geometry=[box(0, 0, 2, 2), box(4, 0, 6, 2), box(8, 0, 10, 2)],
        crs="EPSG:3414",
    )
    shadows = project_building_shadows(source, "height", 45, 90)
    assert len(shadows) == 1
    assert shadows.iloc[0]["height_m"] == 10
    assert shadows.iloc[0]["shadow_length_m"] == pytest.approx(10)


def test_road_evidence_keeps_shadow_and_direct_cover_separate() -> None:
    roads = gpd.GeoDataFrame(
        {
            "segment_id": ["a", "b"],
            "length_m": [10.0, 10.0],
            "tunnel": [None, "building_passage"],
        },
        geometry=[LineString([(0, 0), (10, 0)]), LineString([(0, 2), (10, 2)])],
        crs="EPSG:3414",
    )
    result = calculate_road_shade_evidence(
        roads,
        box(0, -1, 5, 1),
        box(0, -1, 5, 1),
        box(0, -1, 5, 1),
        box(8, -1, 10, 1),
        ("building_passage",),
        "2026-08-17T12:45:00+08:00",
        75,
        20,
    ).set_index("segment_id")
    assert result.loc["a", "building_shadow_fraction_central"] == pytest.approx(0.5)
    assert result.loc["a", "direct_mapped_cover_fraction"] == pytest.approx(0.2)
    assert result.loc["a", "combined_shade_evidence_fraction_low"] == pytest.approx(0.7)
    assert result.loc["a", "combined_shade_evidence_fraction_central"] == pytest.approx(0.7)
    assert result.loc["a", "combined_shade_evidence_fraction_high"] == pytest.approx(0.7)
    assert result.loc["a", "combined_shade_evidence_fraction"] == pytest.approx(0.7)
    assert result.loc["b", "direct_mapped_cover_fraction"] == pytest.approx(1)
    assert result.loc["b", "shade_model_status"] == (
        "estimated_building_heights_and_mapped_cover_not_validated"
    )


def test_utc_offset_is_used_in_solar_position() -> None:
    local = datetime.fromisoformat("2026-08-17T12:45:00+08:00")
    same_instant = local.astimezone(UTC)
    local_position = solar_position_noaa(local, 1.314, 103.765)
    utc_position = solar_position_noaa(same_instant, 1.314, 103.765)
    assert utc_position == pytest.approx(local_position, abs=1e-9)
