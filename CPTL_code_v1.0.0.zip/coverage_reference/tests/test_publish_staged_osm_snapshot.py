from pathlib import Path

from coollink_sg.data.publish_staged_osm_snapshot import load_osm_recovery_config

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_recovery_config_loads() -> None:
    config = load_osm_recovery_config(
        PROJECT_ROOT / "config/representative_osm_recovery.yaml"
    )
    assert config.completed_region_ids == ("jurong_east_mrt", "toa_payoh_mrt")
