from pathlib import Path

import numpy as np
import rasterio

from coollink_sg.heat.representative_solweig_inputs import (
    load_representative_solweig_input_config,
    prepare_canopy_mosaic,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_representative_solweig_input_config_loads() -> None:
    config = load_representative_solweig_input_config(
        PROJECT_ROOT / "config/representative_solweig_inputs.yaml"
    )
    assert config.raster_resolution_m == 5
    assert tuple(region.region_id for region in config.regions) == (
        "jurong_east_mrt",
        "toa_payoh_mrt",
    )
    assert len(config.regions[0].canopy_sources) == 2


def test_raffles_place_solweig_input_config_loads() -> None:
    config = load_representative_solweig_input_config(
        PROJECT_ROOT / "config/raffles_place_solweig_inputs.yaml"
    )
    assert len(config.regions) == 1
    assert config.regions[0].region_id == "raffles_place_mrt"
    assert config.regions[0].canopy_sources == (
        "data/raw/national_tile_inputs/20260819T030000Z/meta_chmv2/chm/1322322311.tif",
    )


def test_representative_canopy_zero_is_valid_not_nodata(tmp_path: Path) -> None:
    profile = {
        "driver": "GTiff",
        "height": 2,
        "width": 2,
        "count": 1,
        "dtype": "float32",
        "crs": "EPSG:3414",
        "transform": rasterio.transform.from_origin(0, 10, 5, 5),
    }
    building_path = tmp_path / "building.tif"
    canopy_source = tmp_path / "canopy_source.tif"
    canopy_output = tmp_path / "canopy_output.tif"
    with rasterio.open(building_path, "w", **profile) as target:
        target.write(np.array([[0, 10], [0, 0]], dtype=np.float32), 1)
    with rasterio.open(canopy_source, "w", **profile) as target:
        target.write(np.array([[0, 8], [6, 0]], dtype=np.float32), 1)

    prepare_canopy_mosaic(
        (canopy_source,),
        building_path,
        canopy_output,
        source_nodata=255,
        minimum_height_m=2,
        height_multiplier=1,
    )

    with rasterio.open(canopy_output) as source:
        canopy = source.read(1)
        assert source.nodata == -9999.0
        assert source.tags()["zero_value_semantics"] == "valid_no_canopy"
    assert np.array_equal(canopy, np.array([[0, 0], [6, 0]], dtype=np.float32))
