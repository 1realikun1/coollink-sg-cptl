from __future__ import annotations

import numpy as np
import pandas as pd

from coollink_sg.data.multistation_weather import (
    idw_estimate,
    summarize_cv,
)


def test_idw_estimate_uses_configured_nearest_stations() -> None:
    values = np.asarray([10.0, 20.0, 100.0])
    distances = np.asarray([1000.0, 2000.0, 100.0])
    estimate, order, weights = idw_estimate(values, distances, 2, 1.0, 100.0)
    assert order.tolist() == [2, 0]
    assert np.isclose(weights.sum(), 1.0)
    assert np.isclose(estimate, (100.0 * 0.9090909091) + (10.0 * 0.0909090909))


def test_summarize_cv_reports_signed_and_absolute_error() -> None:
    frame = pd.DataFrame(
        {
            "metric": ["air_temperature", "air_temperature"],
            "station_id": ["A", "B"],
            "timestamp_sgt": ["t1", "t1"],
            "observed": [10.0, 12.0],
            "predicted": [11.0, 10.0],
            "error": [1.0, -2.0],
            "absolute_error": [1.0, 2.0],
            "squared_error": [1.0, 4.0],
        }
    )
    summary = summarize_cv(frame).iloc[0]
    assert np.isclose(summary["mean_bias"], -0.5)
    assert np.isclose(summary["mae"], 1.5)
    assert np.isclose(summary["rmse"], np.sqrt(2.5))
