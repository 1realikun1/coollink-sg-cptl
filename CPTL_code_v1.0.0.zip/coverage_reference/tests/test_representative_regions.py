from pathlib import Path

import geopandas as gpd
from shapely.geometry import Point, box

from coollink_sg.data.representative_regions import (
    assign_regions_to_tiles,
    load_representative_regions_config,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_representative_region_config_loads() -> None:
    config = load_representative_regions_config(PROJECT_ROOT / "config/representative_regions.yaml")
    assert config.study_radius_m == 2000
    assert len(config.regions) == 4
    assert config.regions[0]["region_id"] == "clementi_mrt"


def test_assign_regions_to_tiles_reports_readiness(tmp_path: Path) -> None:
    regions = gpd.GeoDataFrame(
        {"region_id": ["a"], "geometry": [Point(5, 5).buffer(2)]}, crs="EPSG:3414"
    )
    tiles = gpd.GeoDataFrame(
        {"tile_id": ["tile_a", "tile_b"], "geometry": [box(0, 0, 10, 10), box(10, 0, 20, 10)]},
        crs="EPSG:3414",
    )
    (tmp_path / "tile_a").mkdir()
    (tmp_path / "tile_a" / "input_readiness.json").write_text("{}", encoding="utf-8")
    result = assign_regions_to_tiles(regions, tiles, tmp_path)
    assert result.loc[0, "required_core_tile_ids"] == "tile_a"
    assert result.loc[0, "input_readiness"] == "complete"
