"""Tests for OSM building and artificial-cover proxy features."""

from datetime import UTC, datetime
from pathlib import Path

import geopandas as gpd
import pytest
from shapely.geometry import LineString, Point, box

from coollink_sg.config import (
    load_built_environment_config,
    load_study_area_config,
)
from coollink_sg.features.built_environment import (
    QUERY_TAGS,
    classify_built_environment_features,
    compute_road_built_environment_features,
    load_raw_built_environment_snapshot,
    save_raw_built_environment_snapshot,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _config():
    return load_built_environment_config(
        PROJECT_ROOT / "config/built_environment.yaml"
    )


def _source_features() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "building": ["yes", "roof", None, None],
            "covered": [None, None, "yes", None],
            "amenity": [None, None, None, "shelter"],
            "shelter": [None, None, None, "yes"],
        },
        geometry=[
            box(0, 5, 30, 20),
            box(40, 5, 60, 15),
            LineString([(10, 2), (70, 2)]),
            Point(50, 3),
        ],
        crs="EPSG:3414",
    )


def _road_edges() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "segment_id": ["s1", "s2"],
            "length_m": [100.0, 100.0],
            "tunnel": ["building_passage", None],
        },
        geometry=[
            LineString([(0, 0), (100, 0)]),
            LineString([(200, 0), (300, 0)]),
        ],
        crs="EPSG:3414",
    )


def test_config_and_query_tags_are_explicit() -> None:
    config = _config()

    assert config.road_context_buffer_m == 20
    assert "yes" in config.accepted_covered_values
    assert QUERY_TAGS["building"] is True
    assert QUERY_TAGS["covered"] is True


def test_source_features_are_classified_separately() -> None:
    buildings, roofs, covered, shelters = classify_built_environment_features(
        _source_features(), _config()
    )

    assert len(buildings) == 1
    assert len(roofs) == 1
    assert len(covered) == 1
    assert len(shelters) == 1


def test_road_metrics_are_complete_bounded_and_separate() -> None:
    result, counts = compute_road_built_environment_features(
        _road_edges(), _source_features(), _config()
    )
    indexed = result.set_index("segment_id")
    first = indexed.loc["s1"]
    second = indexed.loc["s2"]

    assert result["building_footprint_proxy_ratio"].between(0, 1).all()
    assert first["building_footprint_proxy_ratio"] > 0
    assert first["nearest_mapped_building_distance_m"] == 5
    assert first["mapped_roof_area_m2"] > 0
    assert first["mapped_covered_way_length_m"] > 0
    assert first["mapped_shelter_count"] == 1
    assert first["building_passage_length_m"] == 100
    assert second["building_footprint_proxy_ratio"] == 0
    assert second["mapped_shelter_count"] == 0
    assert second["building_passage_flag"] == 0
    assert counts == {
        "mapped_building_polygon_count": 1,
        "mapped_roof_polygon_count": 1,
        "mapped_covered_way_count": 1,
        "mapped_shelter_feature_count": 1,
    }


def test_duplicate_segment_ids_are_rejected() -> None:
    edges = _road_edges()
    edges.loc[1, "segment_id"] = "s1"

    with pytest.raises(ValueError, match="must be unique"):
        compute_road_built_environment_features(edges, _source_features(), _config())


def test_raw_snapshot_directory_cannot_be_overwritten(tmp_path: Path) -> None:
    retrieved = datetime(2026, 8, 17, 7, 0, tzinfo=UTC)
    study_area = load_study_area_config(PROJECT_ROOT / "config/study_area.yaml")
    snapshot = save_raw_built_environment_snapshot(
        _source_features(), retrieved, _config(), study_area, tmp_path
    )

    assert len(load_raw_built_environment_snapshot(snapshot)) == 4
    assert (snapshot / "manifest.json").is_file()
    with pytest.raises(FileExistsError):
        save_raw_built_environment_snapshot(
            _source_features(), retrieved, _config(), study_area, tmp_path
        )
