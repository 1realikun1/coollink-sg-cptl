"""Tests for the documented Clementi MRT to NUS University Town scenario."""

from datetime import UTC, datetime
from pathlib import Path

import geopandas as gpd
import pytest
from shapely.geometry import LineString, Point, box

from coollink_sg.config import (
    NetworkConfig,
    ODScenarioConfig,
    ShortestPathConfig,
    StudyAreaConfig,
    load_od_scenario_config,
)
from coollink_sg.routing.od_scenario import (
    create_scenario_map,
    load_raw_geocode_snapshot,
    route_configured_scenario,
    save_raw_geocode_snapshot,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _scenario() -> ODScenarioConfig:
    return ODScenarioConfig(
        scenario_id="test_route",
        origin_label="Origin",
        origin_source="study_area_center",
        destination_label="Destination",
        destination_query="Test destination",
        geographic_crs="EPSG:4326",
        source_metadata={"provider": "test"},
    )


def _routing() -> ShortestPathConfig:
    return ShortestPathConfig(
        network_path="unused.gpkg",
        nodes_layer="nodes",
        edges_layer="edges",
        output_crs="EPSG:3414",
        cost_field="length_m",
    )


def _study_area() -> StudyAreaConfig:
    return StudyAreaConfig(
        name="test",
        display_name="Test",
        latitude=1.314,
        longitude=103.765,
        radius_m=2000,
        geographic_crs="EPSG:4326",
        analysis_crs="EPSG:3414",
        center_metadata={},
        network=NetworkConfig(
            network_type="walk",
            simplify=True,
            retain_all=True,
            truncate_by_edge=False,
        ),
        source_metadata={},
    )


def _destination() -> gpd.GeoDataFrame:
    lon, lat = 103.766, 1.314
    return gpd.GeoDataFrame(
        {
            "lat": [lat],
            "lon": [lon],
            "display_name": ["Test destination, Singapore"],
            "osm_type": ["way"],
            "osm_id": [123],
        },
        geometry=[box(lon - 0.0001, lat - 0.0001, lon + 0.0001, lat + 0.0001)],
        crs="EPSG:4326",
    )


def _network() -> tuple[gpd.GeoDataFrame, gpd.GeoDataFrame]:
    geographic = gpd.GeoSeries(
        [Point(103.765, 1.314), Point(103.7655, 1.314), Point(103.766, 1.314)],
        crs="EPSG:4326",
    )
    projected = geographic.to_crs("EPSG:3414")
    nodes = gpd.GeoDataFrame(
        {"osmid": [1, 2, 3]}, geometry=projected, crs="EPSG:3414"
    )
    edges = gpd.GeoDataFrame(
        {
            "u": [1, 2],
            "v": [2, 3],
            "key": [0, 0],
            "segment_id": ["s1", "s2"],
            "length_m": [55.0, 55.0],
        },
        geometry=[
            LineString([projected.iloc[0], projected.iloc[1]]),
            LineString([projected.iloc[1], projected.iloc[2]]),
        ],
        crs="EPSG:3414",
    )
    return nodes, edges


def test_project_scenario_names_real_documented_endpoints() -> None:
    config = load_od_scenario_config(PROJECT_ROOT / "config/od_scenario.yaml")

    assert config.scenario_id == "clementi_mrt_to_nus_utown"
    assert "University Town" in config.destination_query
    assert config.origin_source == "study_area_center"


def test_scenario_routes_snapped_endpoints_and_reports_distance() -> None:
    nodes, edges = _network()
    route, endpoints, summary = route_configured_scenario(
        nodes, edges, _destination(), _study_area(), _routing(), _scenario()
    )

    assert route.edges["segment_id"].tolist() == ["s1", "s2"]
    assert summary["route_distance_m"] == 110
    assert summary["route_segment_count"] == 2
    assert summary["origin_snap_distance_m"] == pytest.approx(0)
    assert summary["destination_snap_distance_m"] == pytest.approx(0)
    assert endpoints["role"].tolist() == [
        "origin_source",
        "origin_snapped_node",
        "destination_source",
        "destination_snapped_node",
    ]


def test_raw_geocode_snapshot_cannot_be_overwritten(tmp_path: Path) -> None:
    retrieved = datetime(2026, 8, 17, 9, 0, tzinfo=UTC)
    snapshot = save_raw_geocode_snapshot(
        _destination(), retrieved, _scenario(), tmp_path
    )

    assert len(load_raw_geocode_snapshot(snapshot)) == 1
    assert (snapshot / "manifest.json").is_file()
    with pytest.raises(FileExistsError):
        save_raw_geocode_snapshot(
            _destination(), retrieved, _scenario(), tmp_path
        )


def test_scenario_map_is_written(tmp_path: Path) -> None:
    nodes, edges = _network()
    route, endpoints, _ = route_configured_scenario(
        nodes, edges, _destination(), _study_area(), _routing(), _scenario()
    )
    output = tmp_path / "route.html"

    create_scenario_map(route, endpoints, _scenario(), output)

    assert output.is_file()
    html = output.read_text(encoding="utf-8")
    assert "Shortest-distance route" in html
    assert "No travel-time or heat cost" in html
