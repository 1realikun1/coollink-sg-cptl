from __future__ import annotations

import pandas as pd

from coollink_sg.heat.multistation_solweig import Config, validate_weather


def _config() -> Config:
    return Config(
        analysis_id="test",
        analysis_crs="EPSG:3414",
        timezone="Asia/Singapore",
        interval_minutes=15,
        max_shadow_distance_m=500,
        edge_sampling_interval_m=5,
        canopy_trunk_ratio=0.25,
        use_anisotropic_sky=True,
        thermal_source_status="solweig_multistation_not_field_validated",
        regional_weather_path="weather.csv",
        regions=(),
        solweig_root="runs",
        heat_root="heat",
        summary_path="summary.csv",
        provenance_path="summary.json",
    )


def test_validate_weather_accepts_complete_quarter_hour_clock() -> None:
    frame = pd.DataFrame(
        {
            "region_id": ["r", "r"],
            "region_latitude": [1.3, 1.3],
            "region_longitude": [103.8, 103.8],
            "timestamp_sgt": [
                "2026-08-17T09:00:00+08:00",
                "2026-08-17T09:15:00+08:00",
            ],
            "air_temperature_deg_c": [30.0, 30.1],
            "relative_humidity_percent": [70.0, 69.0],
            "wind_speed_m_s": [1.0, 1.1],
            "clear_sky_ghi_w_m2": [300.0, 400.0],
        }
    )
    result = validate_weather(frame, _config(), "r")
    assert len(result) == 2
