"""Tests for Sentinel-2 NDVI versus OSM green-context diagnostics."""

from pathlib import Path

import geopandas as gpd
import pandas as pd
import pytest
from shapely.geometry import LineString

from coollink_sg.config import load_ndvi_osm_consistency_config
from coollink_sg.features.ndvi_osm_consistency import (
    compute_ndvi_osm_consistency,
    summarize_ndvi_osm_consistency,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _config():
    return load_ndvi_osm_consistency_config(
        PROJECT_ROOT / "config/ndvi_osm_consistency.yaml"
    )


def _features() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "segment_id": ["s1", "s2", "s3", "s4"],
            "sentinel2_ndvi_mean": [0.1, 0.4, 0.8, None],
            "sentinel2_ndvi_valid_pixel_fraction": [1.0, 0.5, 1.0, 0.0],
            "green_area_proxy_ratio": [0.0, 0.2, 0.9, 0.3],
        },
        geometry=[
            LineString([(0, index), (1, index)]) for index in range(4)
        ],
        crs="EPSG:3414",
    )


def test_project_configuration_uses_pairwise_complete_policy() -> None:
    config = _config()

    assert config.missing_value_policy == "pairwise_complete_no_imputation"
    assert config.ndvi_field == "sentinel2_ndvi_mean"
    assert config.osm_green_proxy_field == "green_area_proxy_ratio"


def test_pairwise_complete_ranks_preserve_all_segments() -> None:
    result = compute_ndvi_osm_consistency(_features(), _config())

    assert len(result) == 4
    assert result["segment_id"].is_unique
    assert result["analysis_pair_complete"].tolist() == [True, True, True, False]
    assert result.loc[2, "absolute_rank_disagreement"] == pytest.approx(0)
    assert pd.isna(result.loc[3, "absolute_rank_disagreement"])


def test_summary_reports_association_without_imputation() -> None:
    config = _config()
    result = compute_ndvi_osm_consistency(_features(), config)
    summary = summarize_ndvi_osm_consistency(result, config)

    assert summary["segment_count"] == 4
    assert summary["pairwise_complete_segment_count"] == 3
    assert summary["missing_ndvi_segment_count"] == 1
    assert summary["pearson_correlation"] > 0
    assert summary["spearman_rank_correlation"] == pytest.approx(1)
    assert summary["heat_score_generated"] is False


def test_ndvi_missingness_must_match_zero_valid_fraction() -> None:
    features = _features()
    features.loc[3, "sentinel2_ndvi_mean"] = 0.2

    with pytest.raises(ValueError, match="missing exactly"):
        compute_ndvi_osm_consistency(features, _config())


def test_crs_mismatch_is_rejected() -> None:
    with pytest.raises(ValueError, match="CRS must equal"):
        compute_ndvi_osm_consistency(_features().to_crs("EPSG:4326"), _config())
