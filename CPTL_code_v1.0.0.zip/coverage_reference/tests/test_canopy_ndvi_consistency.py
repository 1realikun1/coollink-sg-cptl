from __future__ import annotations

import numpy as np

from coollink_sg.features.canopy_ndvi_consistency import summarize_pairs


def test_summarize_pairs_detects_consistent_canopy_signal() -> None:
    ndvi = np.asarray([[0.1, 0.2], [0.7, 0.8]])
    canopy = np.asarray([[0.0, 0.1], [0.8, 1.0]])
    summary = summarize_pairs(ndvi, canopy, 0.25)
    assert summary["paired_pixel_count"] == 4
    assert summary["ndvi_auc_for_chmv2_canopy_presence"] == 1.0
    assert summary["median_ndvi_difference"] > 0
