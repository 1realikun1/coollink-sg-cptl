"""Tests for exact epsilon-constrained UTCI thermal routing."""

from pathlib import Path

import geopandas as gpd
from shapely.geometry import LineString, Point

from coollink_sg.config import (
    ProcessedLayerConfig,
    ThermalRouteConfig,
    load_thermal_route_config,
)
from coollink_sg.routing.thermal_route import compute_thermal_routes

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _config() -> ThermalRouteConfig:
    return ThermalRouteConfig(
        analysis_id="test_thermal_route",
        output_crs="EPSG:3414",
        detour_limits=(0.0, 0.10),
        primary_height_scenario="central",
        network_path="unused.gpkg",
        nodes_layer="nodes",
        edges_layer="edges",
        thermal=ProcessedLayerConfig("unused.gpkg", "thermal"),
        od_summary_path="unused.json",
        endpoints=ProcessedLayerConfig("unused.gpkg", "endpoints"),
    )


def _nodes() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {"osmid": [1, 2, 3, 4]},
        geometry=[Point(0, 0), Point(1, 0), Point(0, 1), Point(2, 0)],
        crs="EPSG:3414",
    )


def _edges() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "u": [1, 2, 1, 3],
            "v": [2, 4, 3, 4],
            "key": [0, 0, 0, 0],
            "segment_id": ["hot_1", "hot_2", "cool_1", "cool_2"],
            "length_m": [1.0, 1.0, 1.1, 1.1],
        },
        geometry=[
            LineString([(0, 0), (1, 0)]),
            LineString([(1, 0), (2, 0)]),
            LineString([(0, 0), (0, 1)]),
            LineString([(0, 1), (2, 0)]),
        ],
        crs="EPSG:3414",
    )


def _thermal() -> gpd.GeoDataFrame:
    frame = _edges()[["segment_id", "geometry"]].copy()
    frame["travel_time_min"] = [1.0, 1.0, 1.1, 1.1]
    for scenario in ["low", "central", "high"]:
        frame[f"modeled_utci_mean_{scenario}_deg_c"] = [36.0, 36.0, 30.0, 30.0]
        frame[f"thermal_burden_{scenario}_deg_c_min"] = [10.0, 10.0, 1.0, 1.0]
    return frame


def test_project_thermal_route_uses_explicit_detour_caps() -> None:
    config = load_thermal_route_config(PROJECT_ROOT / "config/thermal_route.yaml")

    assert config.detour_limits == (0.0, 0.05, 0.10, 0.15)
    assert config.primary_height_scenario == "central"


def test_exact_constraint_rejects_then_accepts_cool_detour() -> None:
    routes, assignments, summary = compute_thermal_routes(
        _nodes(), _edges(), _thermal(), 1, 4, _config()
    )
    central = routes.loc[routes["height_scenario"].eq("central")].set_index(
        "detour_limit_fraction"
    )

    assert central.loc[0.0, "route_length_m"] == 2.0
    assert central.loc[0.0, "selected_scenario_thermal_burden_deg_c_min"] == 20.0
    assert central.loc[0.1, "route_length_m"] == 2.2
    assert central.loc[0.1, "selected_scenario_thermal_burden_deg_c_min"] == 2.0
    assert central.loc[0.1, "thermal_burden_reduction_vs_shortest_percent"] == 90.0
    assert summary["subjective_thermal_component_weights_used"] is False
    assert len(assignments) > 0
