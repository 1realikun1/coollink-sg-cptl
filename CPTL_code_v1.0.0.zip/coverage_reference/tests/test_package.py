"""Foundation smoke tests."""

import importlib

import coollink_sg


def test_package_version() -> None:
    assert coollink_sg.__version__ == "0.1.0"


def test_planned_subpackages_are_importable() -> None:
    names = (
        "data",
        "features",
        "heat",
        "routing",
        "planning",
        "visualization",
    )

    for name in names:
        module = importlib.import_module(f"coollink_sg.{name}")
        assert module.__doc__

