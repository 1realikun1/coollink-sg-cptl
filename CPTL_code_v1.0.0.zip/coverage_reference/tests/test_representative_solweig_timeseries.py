from pathlib import Path

import numpy as np
import pytest
import rasterio

from coollink_sg.heat.representative_solweig_timeseries import (
    load_representative_solweig_timeseries_config,
    validate_surface_pair,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_representative_solweig_timeseries_config_is_comparable() -> None:
    config = load_representative_solweig_timeseries_config(
        PROJECT_ROOT / "config/representative_solweig_timeseries.yaml"
    )
    assert len(config.regions) == 2
    assert config.interval_minutes == 15
    assert config.canopy_trunk_ratio == 0.25
    assert "not_field_validated" in config.thermal_source_status


def test_raffles_place_solweig_timeseries_matches_regional_design() -> None:
    config = load_representative_solweig_timeseries_config(
        PROJECT_ROOT / "config/raffles_place_solweig_timeseries.yaml"
    )
    assert tuple(region.region_id for region in config.regions) == ("raffles_place_mrt",)
    assert config.interval_minutes == 15
    assert config.canopy_trunk_ratio == 0.25
    assert config.weather_station_id == "S50"


def test_surface_pair_requires_valid_zero_canopy_semantics(tmp_path: Path) -> None:
    profile = {
        "driver": "GTiff",
        "height": 2,
        "width": 2,
        "count": 1,
        "dtype": "float32",
        "crs": "EPSG:3414",
        "transform": rasterio.transform.from_origin(0, 10, 5, 5),
    }
    dsm_path = tmp_path / "dsm.tif"
    cdsm_path = tmp_path / "cdsm.tif"
    with rasterio.open(dsm_path, "w", **profile) as target:
        target.write(np.array([[10, 0], [0, 0]], dtype=np.float32), 1)
    with rasterio.open(cdsm_path, "w", **{**profile, "nodata": -9999}) as target:
        target.write(np.array([[0, 0], [6, 0]], dtype=np.float32), 1)

    metadata = validate_surface_pair(dsm_path, cdsm_path, "EPSG:3414")
    assert metadata["building_positive_pixel_count"] == 1
    assert metadata["canopy_positive_pixel_count"] == 1

    with rasterio.open(cdsm_path, "w", **{**profile, "nodata": 0}) as target:
        target.write(np.array([[0, 0], [6, 0]], dtype=np.float32), 1)
    with pytest.raises(ValueError, match="Zero must be valid"):
        validate_surface_pair(dsm_path, cdsm_path, "EPSG:3414")
