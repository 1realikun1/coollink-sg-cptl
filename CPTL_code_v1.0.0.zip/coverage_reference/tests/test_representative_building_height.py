from pathlib import Path

import geopandas as gpd
import pytest
from shapely.geometry import Polygon

from coollink_sg.features.representative_building_height import (
    load_representative_building_height_config,
    prepare_unique_buildings_for_height_completion,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_representative_building_height_config_loads() -> None:
    config = load_representative_building_height_config(
        PROJECT_ROOT / "config/representative_building_height.yaml"
    )
    assert config.region_ids == ("jurong_east_mrt", "toa_payoh_mrt")
    assert config.building_config.analysis_crs == "EPSG:3414"


def test_raffles_place_building_height_config_loads() -> None:
    config = load_representative_building_height_config(
        PROJECT_ROOT / "config/raffles_place_building_height.yaml"
    )
    assert config.region_ids == ("raffles_place_mrt",)
    assert config.building_config.analysis_crs == "EPSG:3414"


def test_exact_duplicate_building_records_are_collapsed() -> None:
    source = gpd.GeoDataFrame(
        {
            "element": ["way", "way"],
            "id": [1, 1],
            "building": ["apartments", "apartments"],
            "height": [None, None],
            "building:levels": [10, 10],
            "geometry": [
                Polygon([(0, 0), (1, 0), (1, 1), (0, 1)]),
                Polygon([(0, 0), (1, 0), (1, 1), (0, 1)]),
            ],
        },
        crs="EPSG:4326",
    )
    unique, audit = prepare_unique_buildings_for_height_completion(
        source, "height", "building:levels"
    )
    assert len(unique) == 1
    assert audit["duplicate_building_rows_removed"] == 1


def test_conflicting_duplicate_building_records_are_rejected() -> None:
    source = gpd.GeoDataFrame(
        {
            "element": ["way", "way"],
            "id": [1, 1],
            "building": ["apartments", "apartments"],
            "height": [20, 30],
            "building:levels": [10, 10],
            "geometry": [
                Polygon([(0, 0), (1, 0), (1, 1), (0, 1)]),
                Polygon([(0, 0), (1, 0), (1, 1), (0, 1)]),
            ],
        },
        crs="EPSG:4326",
    )
    with pytest.raises(ValueError, match="Conflicting duplicate"):
        prepare_unique_buildings_for_height_completion(source, "height", "building:levels")
