import numpy as np
import pandas as pd

from coollink_sg.reporting.od_behavioral_net_benefit import (
    build_case_behavioral_net_benefit,
    summarize_od_positive_net_benefit,
)


def test_behavioral_net_benefit_sign_and_od_share() -> None:
    fixed = pd.DataFrame(
        {
            "region_id": ["r", "r"],
            "region_label": ["Region", "Region"],
            "od_id": ["od_1", "od_1"],
            "distance_band_rank": [1, 1],
            "departure_time_sgt": ["t1", "t2"],
            "route_id": ["a1", "a2"],
            "baseline_route_id": ["s1", "s2"],
            "route_changed_from_shortest": [True, True],
        }
    )
    candidates = pd.DataFrame(
        {
            "region_id": ["r", "r", "r", "r"],
            "od_id": ["od_1"] * 4,
            "departure_time_sgt": ["t1", "t1", "t2", "t2"],
            "route_id": ["s1", "a1", "s2", "a2"],
            "departure_snapshot_sun_distance_m": [100.0, 0.0, 100.0, 0.0],
            "departure_snapshot_shade_distance_m": [0.0, 110.0, 0.0, 130.0],
            "mean_acceptance_probability": [1.0, 0.6, 1.0, 0.4],
        }
    )
    cases = build_case_behavioral_net_benefit(fixed, candidates, 1.2)
    assert np.allclose(cases["behavioral_net_benefit_m"], [10.0, -10.0])
    assert cases["positive_behavioral_net_benefit"].tolist() == [True, False]

    summary = summarize_od_positive_net_benefit(cases)
    assert len(summary) == 1
    assert summary.iloc[0]["positive_behavioral_net_benefit_share_percent"] == 50.0
    assert summary.iloc[0]["departure_count"] == 2


def test_net_benefit_rejects_unmatched_route() -> None:
    fixed = pd.DataFrame(
        {
            "region_id": ["r"],
            "region_label": ["Region"],
            "od_id": ["od_1"],
            "distance_band_rank": [1],
            "departure_time_sgt": ["t1"],
            "route_id": ["missing"],
            "baseline_route_id": ["s1"],
            "route_changed_from_shortest": [True],
        }
    )
    candidates = pd.DataFrame(
        {
            "region_id": ["r"],
            "od_id": ["od_1"],
            "departure_time_sgt": ["t1"],
            "route_id": ["s1"],
            "departure_snapshot_sun_distance_m": [100.0],
            "departure_snapshot_shade_distance_m": [0.0],
            "mean_acceptance_probability": [1.0],
        }
    )
    try:
        build_case_behavioral_net_benefit(fixed, candidates, 1.2)
    except ValueError as error:
        assert "must match" in str(error)
    else:
        raise AssertionError("Expected unmatched route to fail")
