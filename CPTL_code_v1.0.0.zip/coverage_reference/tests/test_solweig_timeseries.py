"""Tests for the phase-two SOLWEIG input and road-sampling pipeline."""

from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
from shapely.geometry import LineString, Polygon

from coollink_sg.config import load_solweig_timeseries_config
from coollink_sg.heat.solweig_timeseries import (
    build_readiness,
    build_weather_timeseries,
    extract_station_weather,
    prepare_canopy_dsm,
    prepare_edge_sample_indices,
    rasterize_building_dsm,
    scenario_timestamps,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_project_solweig_config_declares_runnable_but_unvalidated_scenario() -> None:
    config = load_solweig_timeseries_config(PROJECT_ROOT / "config/solweig_timeseries.yaml")
    timestamps = scenario_timestamps(config)

    assert config.raster_resolution_m == 5.0
    assert config.max_shadow_distance_m == 500.0
    assert config.weather_station_id == "S50"
    assert len(timestamps) == 37
    assert "not_field_validated" in config.thermal_source_status
    assert config.canopy_source_path is None


def test_canopy_solweig_config_declares_predicted_canopy_sensitivity() -> None:
    config = load_solweig_timeseries_config(PROJECT_ROOT / "config/solweig_timeseries_canopy.yaml")

    assert config.canopy_source_path is not None
    assert config.canopy_dsm_path is not None
    assert config.canopy_height_multiplier == 1.0
    assert config.minimum_canopy_height_m == 2.0
    assert config.canopy_trunk_ratio == 0.25
    assert "chmv2_canopy" in config.thermal_source_status


def test_station_snapshot_and_clear_sky_clock_preserve_provenance() -> None:
    observations = pd.DataFrame(
        {
            "snapshot_id": ["snap"] * 3,
            "metric": ["air_temperature", "relative_humidity", "wind_speed"],
            "station_id": ["S50"] * 3,
            "station_name": ["Clementi Road"] * 3,
            "value": [32.2, 64.8, 2.0],
            "unit": ["degC", "percent", "m/s"],
            "observed_at_sgt": ["2026-08-17T12:59:00+08:00"] * 3,
            "quality_flag": ["valid"] * 3,
            "latitude": [1.3318] * 3,
            "longitude": [103.7762] * 3,
        }
    )
    station = extract_station_weather(observations, "S50", "snap")
    timestamps = pd.date_range("2026-08-17T12:00:00+08:00", periods=3, freq="15min")
    weather = build_weather_timeseries(
        timestamps, 1.3141081, 103.7656688, "Asia/Singapore", station
    )

    assert station["air_temperature_deg_c"] == 32.2
    assert weather["air_temperature_deg_c"].nunique() == 1
    assert (weather["clear_sky_ghi_w_m2"] > 0).all()
    assert weather["solar_radiation_status"].eq("pvlib_ineichen_clear_sky_model_not_observed").all()


def test_building_dsm_and_ground_cell_edge_sampling(tmp_path: Path) -> None:
    buildings = gpd.GeoDataFrame(
        {"height_central_m": [12.0]},
        geometry=[Polygon([(5, 5), (15, 5), (15, 15), (5, 15)])],
        crs="EPSG:3414",
    )
    edges = gpd.GeoDataFrame(
        {"segment_id": ["edge-1"]},
        geometry=[LineString([(0, 10), (20, 10)])],
        crs="EPSG:3414",
    )
    output = tmp_path / "dsm.tif"
    metadata = rasterize_building_dsm(
        buildings,
        edges,
        output,
        "EPSG:3414",
        "height_central_m",
        5.0,
    )
    with rasterio.open(output) as source:
        dsm = source.read(1)
        mappings, diagnostics = prepare_edge_sample_indices(
            edges,
            source.transform,
            source.width,
            source.height,
            dsm > 0,
            5.0,
        )

    assert metadata["maximum_height_m"] == 12.0
    assert metadata["ground_model"] == "flat_zero_elevation"
    assert len(mappings) == 1
    assert diagnostics["shifted_building_samples"] > 0
    assert np.all(dsm.ravel()[mappings[0]] == 0)


def test_prepare_canopy_dsm_masks_short_and_building_overlap(tmp_path: Path) -> None:
    transform = rasterio.transform.from_origin(0, 10, 5, 5)
    profile = {
        "driver": "GTiff",
        "height": 2,
        "width": 2,
        "count": 1,
        "dtype": "float32",
        "crs": "EPSG:3414",
        "transform": transform,
    }
    building_path = tmp_path / "building.tif"
    canopy_source = tmp_path / "source.tif"
    canopy_output = tmp_path / "canopy.tif"
    with rasterio.open(building_path, "w", **profile) as target:
        target.write(np.array([[0.0, 12.0], [0.0, 0.0]], dtype=np.float32), 1)
    with rasterio.open(canopy_source, "w", **profile) as target:
        target.write(np.array([[1.0, 9.0], [8.0, 255.0]], dtype=np.float32), 1)

    metadata = prepare_canopy_dsm(
        canopy_source,
        building_path,
        canopy_output,
        source_nodata=255.0,
        minimum_height_m=2.0,
    )
    with rasterio.open(canopy_output) as source:
        canopy = source.read(1)
        canopy_nodata = source.nodata

    assert np.array_equal(canopy, np.array([[0.0, 0.0], [8.0, 0.0]]))
    assert canopy_nodata == -9999.0
    assert metadata["positive_pixel_count"] == 1
    assert metadata["building_overlap_pixel_count_removed"] == 1


def test_prepare_canopy_dsm_height_multiplier_preserves_thresholded_footprint(
    tmp_path: Path,
) -> None:
    transform = rasterio.transform.from_origin(0, 5, 5, 5)
    profile = {
        "driver": "GTiff",
        "height": 1,
        "width": 2,
        "count": 1,
        "dtype": "float32",
        "crs": "EPSG:3414",
        "transform": transform,
    }
    building_path = tmp_path / "building.tif"
    canopy_source = tmp_path / "source.tif"
    canopy_output = tmp_path / "canopy.tif"
    with rasterio.open(building_path, "w", **profile) as target:
        target.write(np.zeros((1, 2), dtype=np.float32), 1)
    with rasterio.open(canopy_source, "w", **profile) as target:
        target.write(np.array([[1.5, 4.0]], dtype=np.float32), 1)

    metadata = prepare_canopy_dsm(
        canopy_source,
        building_path,
        canopy_output,
        source_nodata=None,
        minimum_height_m=2.0,
        height_multiplier=0.5,
    )
    with rasterio.open(canopy_output) as source:
        canopy = source.read(1)

    assert np.array_equal(canopy, np.array([[0.0, 2.0]], dtype=np.float32))
    assert metadata["height_multiplier"] == 0.5
    assert metadata["positive_pixel_count"] == 1


def test_readiness_separates_run_from_paper_validation() -> None:
    config = load_solweig_timeseries_config(PROJECT_ROOT / "config/solweig_timeseries.yaml")
    weather = pd.DataFrame(
        {
            "timestamp_sgt": [
                "2026-08-17 09:00:00+08:00",
                "2026-08-17 09:15:00+08:00",
            ]
        }
    )
    readiness = build_readiness(config, {"path": "dsm.tif"}, weather)

    assert readiness["minimum_model_inputs_ready"] is True
    assert readiness["paper_validation_ready"] is False
    assert readiness["optional_or_validation_inputs"]["canopy_dsm"]["available"] is False
