"""Tests for repository invariants established in Part 1."""

from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_required_directories_exist() -> None:
    required = (
        "config",
        "data/raw",
        "data/interim",
        "data/processed",
        "docs",
        "notebooks",
        "outputs/maps",
        "outputs/tables",
        "outputs/figures",
        "src/coollink_sg",
        "tests",
        "app",
    )

    for relative_path in required:
        assert (PROJECT_ROOT / relative_path).is_dir(), relative_path


def test_settings_preserve_raw_data_rule() -> None:
    settings = (PROJECT_ROOT / "config/settings.yaml").read_text(encoding="utf-8")

    assert "raw_data_is_immutable: true" in settings
    assert "require_explicit_crs: true" in settings
