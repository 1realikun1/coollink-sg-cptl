"""Tests for metric-separated road-to-weather-station associations."""

from pathlib import Path

import geopandas as gpd
import pandas as pd
import pytest
from shapely.geometry import LineString, Polygon

from coollink_sg.config import load_road_weather_association_config
from coollink_sg.features.road_weather_association import (
    associate_weather_stations_to_roads,
    summarize_road_weather_associations,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _config():
    return load_road_weather_association_config(
        PROJECT_ROOT / "config/road_weather_association.yaml"
    )


def _roads() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {"segment_id": ["west", "east"]},
        geometry=[
            LineString([(103.7500, 1.3100), (103.7510, 1.3100)]),
            LineString([(103.8490, 1.3100), (103.8500, 1.3100)]),
        ],
        crs="EPSG:4326",
    )


def _study_area() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        geometry=[
            Polygon(
                [
                    (103.70, 1.25),
                    (103.90, 1.25),
                    (103.90, 1.35),
                    (103.70, 1.35),
                ]
            )
        ],
        crs="EPSG:4326",
    )


def _observations() -> pd.DataFrame:
    rows = []
    metrics = ("air_temperature", "relative_humidity", "wind_speed", "wbgt")
    for metric_index, metric in enumerate(metrics):
        for station_id, longitude, value in (
            ("west_station", 103.75, 20 + metric_index),
            ("east_station", 103.85, 30 + metric_index),
        ):
            rows.append(
                {
                    "snapshot_id": "snapshot",
                    "retrieved_at_utc": "2026-08-17T05:05:00+00:00",
                    "metric": metric,
                    "station_id": station_id,
                    "station_name": station_id,
                    "station_context": None,
                    "latitude": 1.31,
                    "longitude": longitude,
                    "observed_at_sgt": (
                        f"2026-08-17T{12 if metric != 'wbgt' else 11}:45:00+08:00"
                    ),
                    "observed_at_utc": (
                        f"2026-08-17T{4 if metric != 'wbgt' else 3}:45:00+00:00"
                    ),
                    "value": value,
                    "unit": "test_unit",
                    "heat_stress": None,
                    "age_minutes_at_retrieval": 20,
                    "quality_flag": "valid",
                }
            )
    return pd.DataFrame(rows)


def test_project_config_preserves_metric_separation() -> None:
    config = _config()

    assert config.assignment_method == "nearest_nonmissing_station_by_metric"
    assert config.road_reference_point == "geometry_midpoint"
    assert config.required_metrics == (
        "air_temperature",
        "relative_humidity",
        "wind_speed",
        "wbgt",
    )


def test_each_road_gets_one_nearest_station_per_metric() -> None:
    result = associate_weather_stations_to_roads(
        _roads(), _observations(), _study_area(), _config()
    )

    assert len(result) == 8
    assert not result.duplicated(["segment_id", "metric"]).any()
    stations = result.set_index(["segment_id", "metric"])["source_station_id"]
    assert stations.loc[("west", "wbgt")] == "west_station"
    assert stations.loc[("east", "air_temperature")] == "east_station"
    assert (result["road_midpoint_to_station_distance_m"] >= 0).all()
    assert set(result["association_status"]) == {
        "context_only_not_road_observation"
    }


def test_missing_required_metric_is_rejected() -> None:
    observations = _observations().loc[lambda frame: frame["metric"] != "wbgt"]

    with pytest.raises(ValueError, match="Required weather metrics are absent"):
        associate_weather_stations_to_roads(
            _roads(), observations, _study_area(), _config()
        )


def test_nonaccepted_or_missing_stations_are_excluded() -> None:
    observations = _observations()
    observations.loc[
        (observations["metric"] == "wbgt")
        & (observations["station_id"] == "west_station"),
        "quality_flag",
    ] = "stale"

    result = associate_weather_stations_to_roads(
        _roads(), observations, _study_area(), _config()
    )

    west_wbgt = result.loc[
        (result["segment_id"] == "west") & (result["metric"] == "wbgt")
    ].iloc[0]
    assert west_wbgt["source_station_id"] == "east_station"


def test_summary_reports_temporal_span_and_no_interpolation() -> None:
    config = _config()
    result = associate_weather_stations_to_roads(
        _roads(), _observations(), _study_area(), config
    )
    summary, table = summarize_road_weather_associations(result, config)

    assert summary["association_row_count"] == 8
    assert summary["metric_count"] == 4
    assert summary["cross_metric_observation_time_span_minutes"] == 60
    assert summary["spatial_interpolation_performed"] is False
    assert summary["heat_model_input_generated"] is False
    assert len(table) == 4
