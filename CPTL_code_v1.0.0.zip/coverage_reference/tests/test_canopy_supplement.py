from pathlib import Path

from coollink_sg.data.canopy_supplement import (
    load_canopy_supplement_config,
    required_region_canopy_tiles,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_jurong_canopy_supplement_selects_only_one_missing_tile() -> None:
    config = load_canopy_supplement_config(
        PROJECT_ROOT / "config/jurong_east_chmv2_supplement.yaml"
    )
    assert required_region_canopy_tiles(config) == ("1322322310", "1322322311")
