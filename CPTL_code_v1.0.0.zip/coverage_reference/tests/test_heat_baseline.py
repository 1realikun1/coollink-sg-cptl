"""Tests for the gated, transparent baseline heat-score engine."""

from pathlib import Path

import geopandas as gpd
import pytest
from shapely.geometry import LineString

from coollink_sg.config import (
    HeatComponentConfig,
    HeatModelConfig,
    load_heat_model_config,
)
from coollink_sg.heat.baseline import (
    audit_heat_model_readiness,
    compute_heat_scores,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _component(
    name: str,
    field: str,
    direction: str,
    weight: float,
    minimum: float = 0,
    maximum: float = 1,
) -> HeatComponentConfig:
    return HeatComponentConfig(
        name=name,
        input_field=field,
        direction=direction,
        weight=weight,
        reference_min=minimum,
        reference_max=maximum,
        proxy_candidate_field=None,
        unavailable_reason="synthetic test input",
    )


def _configured_model() -> HeatModelConfig:
    return HeatModelConfig(
        model_id="synthetic_test_model",
        enabled=True,
        score_min=0,
        score_max=100,
        missing_value_policy="reject",
        components=(
            _component("wbgt", "wbgt", "higher_is_hotter", 0.5, 25, 35),
            _component("shade", "shade", "higher_is_cooler", 0.3),
            _component("vegetation", "vegetation", "higher_is_cooler", 0.2),
        ),
    )


def _features() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "segment_id": ["hot", "middle", "cool"],
            "wbgt": [35.0, 30.0, 25.0],
            "shade": [0.0, 0.5, 1.0],
            "vegetation": [0.0, 0.5, 1.0],
        },
        geometry=[
            LineString([(0, 0), (1, 0)]),
            LineString([(1, 0), (2, 0)]),
            LineString([(2, 0), (3, 0)]),
        ],
        crs="EPSG:3414",
    )


def test_project_heat_model_is_intentionally_unconfigured() -> None:
    config = load_heat_model_config(PROJECT_ROOT / "config/heat_model.yaml")

    assert config.enabled is False
    assert all(component.weight is None for component in config.components)
    assert {component.name for component in config.components} == {
        "wbgt",
        "shade",
        "vegetation",
    }


def test_configured_score_is_bounded_and_directionally_correct() -> None:
    result = compute_heat_scores(_features(), _configured_model()).set_index(
        "segment_id"
    )

    assert result.loc["hot", "heat_score"] == pytest.approx(100)
    assert result.loc["middle", "heat_score"] == pytest.approx(50)
    assert result.loc["cool", "heat_score"] == pytest.approx(0)
    assert result["heat_score"].between(0, 100).all()
    assert result.loc["hot", "heat_component_shade_0_1"] == 1
    assert result.loc["cool", "heat_component_shade_0_1"] == 0


def test_values_are_clipped_to_configured_reference_bounds() -> None:
    features = _features()
    features.loc[0, "wbgt"] = 50
    features.loc[2, "shade"] = 2

    result = compute_heat_scores(features, _configured_model())

    assert result["heat_score"].between(0, 100).all()


def test_missing_input_values_are_rejected() -> None:
    features = _features()
    features.loc[1, "wbgt"] = None

    with pytest.raises(ValueError, match="missing_input_values"):
        compute_heat_scores(features, _configured_model())


def test_invalid_weight_sum_is_rejected() -> None:
    config = _configured_model()
    invalid = HeatModelConfig(
        model_id=config.model_id,
        enabled=True,
        score_min=0,
        score_max=100,
        missing_value_policy="reject",
        components=(
            _component("wbgt", "wbgt", "higher_is_hotter", 0.5, 25, 35),
            _component("shade", "shade", "higher_is_cooler", 0.3),
            _component("vegetation", "vegetation", "higher_is_cooler", 0.3),
        ),
    )

    with pytest.raises(ValueError, match="invalid_weight_sum"):
        compute_heat_scores(_features(), invalid)


def test_readiness_audit_reports_candidates_without_substitution() -> None:
    config = load_heat_model_config(PROJECT_ROOT / "config/heat_model.yaml")
    features = _features().rename(
        columns={
            "shade": "combined_shade_evidence_fraction",
            "vegetation": "green_area_proxy_ratio",
        }
    )

    audit = audit_heat_model_readiness(features, config)
    components = {item["component"]: item for item in audit["components"]}

    assert audit["ready"] is False
    assert audit["status"] == "not_ready_no_score_generated"
    assert components["shade"]["proxy_candidate_available"] is True
    assert components["vegetation"]["proxy_candidate_available"] is True
    assert all(not item["proxy_substitution_performed"] for item in components.values())
