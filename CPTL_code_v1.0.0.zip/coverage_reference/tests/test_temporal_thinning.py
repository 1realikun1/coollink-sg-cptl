"""Focused tests for route-aware temporal thinning utilities."""

import numpy as np

from coollink_sg.heat.temporal_thinning import (
    anchor_indices,
    positive_linear_integral,
    reconstruct_from_anchors,
)


def test_anchor_indices_retain_final_irregular_endpoint() -> None:
    assert anchor_indices(37, 8).tolist() == [0, 8, 16, 24, 32, 36]


def test_linear_reconstruction_is_exact_for_linear_series() -> None:
    values = np.vstack([np.arange(9, dtype=float), 2 * np.arange(9, dtype=float) + 3])
    reconstructed = reconstruct_from_anchors(values, anchor_indices(9, 4))
    np.testing.assert_allclose(reconstructed, values)


def test_positive_linear_integral_handles_threshold_crossings() -> None:
    result = positive_linear_integral(
        np.array([24.0, 28.0, 28.0]),
        np.array([28.0, 24.0, 30.0]),
        np.array([2.0, 2.0, 2.0]),
        26.0,
    )
    np.testing.assert_allclose(result, np.array([1.0, 1.0, 6.0]))
