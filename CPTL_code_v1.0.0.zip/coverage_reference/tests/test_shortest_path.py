"""Tests for the directed shortest-distance routing baseline."""

from pathlib import Path

import geopandas as gpd
import pytest
from shapely.geometry import LineString, Point

from coollink_sg.config import ShortestPathConfig, load_shortest_path_config
from coollink_sg.routing.shortest_path import (
    build_routing_graph,
    nearest_network_node,
    shortest_route,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _config() -> ShortestPathConfig:
    return ShortestPathConfig(
        network_path="unused.gpkg",
        nodes_layer="nodes",
        edges_layer="edges",
        output_crs="EPSG:3414",
        cost_field="length_m",
    )


def _nodes() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {"osmid": [1, 2, 3, 4]},
        geometry=[Point(0, 0), Point(10, 0), Point(20, 0), Point(0, 10)],
        crs="EPSG:3414",
    )


def _edges() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "u": [1, 1, 2, 1, 4],
            "v": [2, 2, 3, 3, 1],
            "key": [0, 1, 0, 0, 0],
            "segment_id": ["long", "short", "next", "direct", "inbound"],
            "length_m": [10.0, 4.0, 6.0, 20.0, 10.0],
        },
        geometry=[
            LineString([(0, 0), (5, 2), (10, 0)]),
            LineString([(0, 0), (10, 0)]),
            LineString([(10, 0), (20, 0)]),
            LineString([(0, 0), (20, 0)]),
            LineString([(0, 10), (0, 0)]),
        ],
        crs="EPSG:3414",
    )


def test_project_shortest_path_configuration_is_distance_only() -> None:
    config = load_shortest_path_config(PROJECT_ROOT / "config/shortest_path.yaml")

    assert config.cost_field == "length_m"
    assert config.output_crs == "EPSG:3414"


def test_shortest_route_selects_shortest_parallel_edge() -> None:
    graph = build_routing_graph(_nodes(), _edges(), _config())
    route = shortest_route(graph, 1, 3)

    assert route.node_path == (1, 2, 3)
    assert route.edges["segment_id"].tolist() == ["short", "next"]
    assert route.edges["route_sequence"].tolist() == [0, 1]
    assert route.distance_m == pytest.approx(10)
    assert route.edges.crs.to_epsg() == 3414


def test_routing_respects_edge_direction() -> None:
    graph = build_routing_graph(_nodes(), _edges(), _config())

    with pytest.raises(ValueError, match="No directed path"):
        shortest_route(graph, 3, 1)


def test_nearest_node_returns_metric_snap_distance() -> None:
    node, distance = nearest_network_node(_nodes(), 9, 1, "EPSG:3414")

    assert node == 2
    assert distance == pytest.approx(2**0.5)


def test_duplicate_segment_ids_are_rejected() -> None:
    edges = _edges()
    edges.loc[1, "segment_id"] = "long"

    with pytest.raises(ValueError, match="must be complete and unique"):
        build_routing_graph(_nodes(), edges, _config())


def test_non_positive_edge_cost_is_rejected() -> None:
    edges = _edges()
    edges.loc[0, "length_m"] = 0

    with pytest.raises(ValueError, match="must be positive"):
        build_routing_graph(_nodes(), edges, _config())


def test_unknown_endpoint_is_rejected() -> None:
    graph = build_routing_graph(_nodes(), _edges(), _config())

    with pytest.raises(ValueError, match="Destination node is not in the network"):
        shortest_route(graph, 1, 999)
