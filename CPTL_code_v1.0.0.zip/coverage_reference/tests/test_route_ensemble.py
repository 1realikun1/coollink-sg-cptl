"""Tests for distance–exposure route sensitivity analysis."""

from pathlib import Path

import geopandas as gpd
import pandas as pd
from shapely.geometry import LineString, Point

from coollink_sg.config import (
    ProcessedLayerConfig,
    RouteEnsembleConfig,
    load_route_ensemble_config,
)
from coollink_sg.heat.road_exposure_proxy import COMPONENT_FIELDS
from coollink_sg.routing.route_ensemble import (
    compute_route_ensemble,
    create_route_ensemble_map,
    generate_tradeoff_scenarios,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _config() -> RouteEnsembleConfig:
    return RouteEnsembleConfig(
        analysis_id="test_route_ensemble",
        output_crs="EPSG:3414",
        tradeoff_step=0.5,
        cost_method="length_times_convex_distance_exposure_proxy",
        network_path="unused.gpkg",
        nodes_layer="nodes",
        edges_layer="edges",
        exposure=ProcessedLayerConfig("unused_exposure.gpkg", "exposure"),
        weight_scenarios_path="unused_weights.csv",
        od_summary_path="unused_summary.json",
        endpoints=ProcessedLayerConfig("unused_endpoints.gpkg", "endpoints"),
    )


def _nodes() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {"osmid": [1, 2, 3, 4]},
        geometry=[Point(0, 0), Point(1, 0), Point(0, 1), Point(2, 0)],
        crs="EPSG:3414",
    )


def _edges() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "u": [1, 2, 1, 3],
            "v": [2, 4, 3, 4],
            "key": [0, 0, 0, 0],
            "segment_id": ["hot_1", "hot_2", "cool_1", "cool_2"],
            "length_m": [1.0, 1.0, 2.0, 2.0],
        },
        geometry=[
            LineString([(0, 0), (1, 0)]),
            LineString([(1, 0), (2, 0)]),
            LineString([(0, 0), (0, 1)]),
            LineString([(0, 1), (2, 0)]),
        ],
        crs="EPSG:3414",
    )


def _exposure() -> gpd.GeoDataFrame:
    values = {
        "segment_id": ["hot_1", "hot_2", "cool_1", "cool_2"],
        COMPONENT_FIELDS[0]: [1.0, 1.0, 0.1, 0.1],
        COMPONENT_FIELDS[1]: [1.0, 1.0, 0.1, 0.1],
        COMPONENT_FIELDS[2]: [1.0, 1.0, 0.1, 0.1],
    }
    return gpd.GeoDataFrame(values, geometry=_edges().geometry, crs="EPSG:3414")


def _weights() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "scenario_id": ["wbgt", "shade", "green"],
            "weight_wbgt_station_context": [1.0, 0.0, 0.0],
            "weight_shade_deficit": [0.0, 1.0, 0.0],
            "weight_vegetation_context_deficit": [0.0, 0.0, 1.0],
            "weight_sum": [1.0, 1.0, 1.0],
            "preferred_scenario": [False, False, False],
        }
    )


def _endpoints() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "role": ["origin_source", "destination_source"],
            "label": ["Origin", "Destination"],
        },
        geometry=[Point(0, 0), Point(2, 0)],
        crs="EPSG:3414",
    )


def test_project_route_ensemble_has_no_preferred_tradeoff() -> None:
    config = load_route_ensemble_config(PROJECT_ROOT / "config/route_ensemble.yaml")
    tradeoffs = generate_tradeoff_scenarios(config)

    assert len(tradeoffs) == 6
    assert tradeoffs["preferred_tradeoff"].eq(False).all()  # noqa: E712
    assert tradeoffs.iloc[0]["exposure_tradeoff"] == 0
    assert tradeoffs.iloc[-1]["exposure_tradeoff"] == 1


def test_ensemble_retains_shortest_and_exposure_avoiding_routes() -> None:
    routes, assignments, catalogue, summary = compute_route_ensemble(
        _nodes(), _edges(), _exposure(), _weights(), 1, 4, _config()
    )

    assert len(assignments) == 9
    assert len(routes) == 2
    assert len(catalogue) == 2
    assert summary["unique_route_count"] == 2
    assert summary["preferred_route"] is None
    shortest = routes.loc[routes["route_role"].eq("shortest_distance")].iloc[0]
    alternative = routes.loc[
        routes["route_role"].eq("most_supported_nonshortest_sensitivity_route")
    ].iloc[0]
    assert shortest["route_length_m"] == 2
    assert alternative["route_length_m"] == 4
    assert assignments["preferred_scenario"].eq(False).all()  # noqa: E712
    assert "heat_score" not in assignments.columns


def test_route_ensemble_map_states_no_preferred_route(tmp_path: Path) -> None:
    routes, _, _, _ = compute_route_ensemble(
        _nodes(), _edges(), _exposure(), _weights(), 1, 4, _config()
    )
    output = tmp_path / "routes.html"

    create_route_ensemble_map(routes, _endpoints(), output)

    html = output.read_text(encoding="utf-8")
    assert "No preferred route" in html
    assert "no validated Heat Score" in html
