"""Tests for exploratory intervention candidate screening."""

from pathlib import Path

import geopandas as gpd
from shapely.geometry import LineString

from coollink_sg.config import (
    InterventionScreeningConfig,
    ProcessedLayerConfig,
    load_intervention_screening_config,
)
from coollink_sg.heat.intervention_screening import (
    compute_intervention_screening,
    create_intervention_screening_map,
)
from coollink_sg.heat.road_exposure_proxy import COMPONENT_FIELDS

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _config() -> InterventionScreeningConfig:
    return InterventionScreeningConfig(
        analysis_id="test_screening",
        output_crs="EPSG:3414",
        ranking_method="percentile_of_symmetric_weight_sweep_mean",
        diagnostic_top_fraction=0.1,
        exposure=ProcessedLayerConfig("unused.gpkg", "exposure"),
        screening_field="mean",
        sensitivity_field="sensitivity",
        scenario_frequency_field="frequency",
    )


def _exposure() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "segment_id": ["low", "middle", "high"],
            "mean": [0.1, 0.5, 0.9],
            "sensitivity": [0.2, 0.3, 0.4],
            "frequency": [0.0, 0.2, 0.5],
            COMPONENT_FIELDS[0]: [0.1, 0.5, 0.9],
            COMPONENT_FIELDS[1]: [0.1, 0.5, 0.9],
            COMPONENT_FIELDS[2]: [0.1, 0.5, 0.9],
        },
        geometry=[
            LineString([(0, 0), (1, 0)]),
            LineString([(1, 0), (2, 0)]),
            LineString([(2, 0), (3, 0)]),
        ],
        crs="EPSG:3414",
    )


def test_project_screening_is_explicitly_exploratory() -> None:
    config = load_intervention_screening_config(
        PROJECT_ROOT / "config/intervention_screening.yaml"
    )

    assert config.ranking_method == "percentile_of_symmetric_weight_sweep_mean"
    assert config.diagnostic_top_fraction == 0.1


def test_screening_preserves_order_without_creating_priority_score() -> None:
    result = compute_intervention_screening(_exposure(), _config()).set_index(
        "segment_id"
    )

    assert result.loc["high", "screening_percentile"] == 1
    assert result.loc["high", "exploratory_screening_rank"] == 1
    assert result.loc["high", "top_screening_fraction_flag"] == 1
    assert result["preferred_intervention_priority"].eq("none").all()
    assert "priority_score" not in result.columns
    assert "heat_score" not in result.columns


def test_screening_map_states_that_it_is_not_validated(tmp_path: Path) -> None:
    result = compute_intervention_screening(_exposure(), _config())
    output = tmp_path / "screening.html"

    create_intervention_screening_map(result, _config(), output)

    html = output.read_text(encoding="utf-8")
    assert "not validated intervention priority" in html
    assert "cost-effectiveness" in html
