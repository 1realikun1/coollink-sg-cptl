from pathlib import Path

import pytest

from coollink_sg.data.regional_input_audit import (
    coverage_fraction,
    load_regional_input_audit_config,
    source_coverage_fraction,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_jurong_east_input_audit_config_loads() -> None:
    config = load_regional_input_audit_config(
        PROJECT_ROOT / "config/jurong_east_regional_input_audit.yaml"
    )
    assert config.region_id == "jurong_east_mrt"
    assert len(config.sources) == 4


def test_coverage_fraction_is_bounded_and_explicit() -> None:
    assert coverage_fraction((0, 0, 10, 10), (-1, -1, 11, 11)) == 1.0
    assert coverage_fraction((0, 0, 10, 10), (5, 0, 15, 10)) == 0.5
    assert coverage_fraction((0, 0, 10, 10), (20, 20, 30, 30)) == 0.0
    with pytest.raises(ValueError, match="positive-area"):
        coverage_fraction((0, 0, 0, 10), (0, 0, 10, 10))
    assert source_coverage_fraction(
        (0, 0, 10, 10), ((0, 0, 5, 10), (5, 0, 10, 10))
    ) == 1.0
