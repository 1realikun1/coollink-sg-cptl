"""Tests for time-indexed UTCI interpolation and CPTL integration."""

from pathlib import Path

import pandas as pd
import pytest

from coollink_sg.config import load_dynamic_cptl_config
from coollink_sg.heat.dynamic_utci import (
    TimeVaryingUTCI,
    repeat_static_utci_for_algorithm_validation,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]
STATUS = "provisional_static_repeat_not_solweig_dynamic_output"


def _series(values: list[float]) -> pd.DataFrame:
    timestamps = pd.date_range("2026-08-17T12:00:00+08:00", periods=2, freq="10min")
    return pd.DataFrame(
        {
            "segment_id": ["edge", "edge"],
            "timestamp_sgt": timestamps.astype(str),
            "height_scenario": ["central", "central"],
            "modeled_utci_deg_c": values,
            "thermal_source_status": [STATUS, STATUS],
        }
    )


def test_project_dynamic_cptl_config_locks_main_idea_contract() -> None:
    config = load_dynamic_cptl_config(PROJECT_ROOT / "config/dynamic_cptl.yaml")

    assert config.primary_threshold_deg_c == 26
    assert config.sensitivity_thresholds_deg_c == (26.0, 32.0, 38.0)
    assert config.detour_limits == (0.0, 0.05, 0.10, 0.15)
    assert config.time_bin_seconds == 60
    assert config.integration_method == "piecewise_linear_threshold_crossing_exact"
    assert config.waiting_allowed is False
    assert "not_solweig" in config.thermal_source_status
    assert config.is_solweig_dynamic_result is False


def test_solweig_dynamic_cptl_config_uses_real_time_series_contract() -> None:
    config = load_dynamic_cptl_config(PROJECT_ROOT / "config/dynamic_cptl_solweig.yaml")

    assert config.is_solweig_dynamic_result is True
    assert config.output_stem == "clementi_time_dependent_cptl_solweig"
    assert len(config.departure_times) == 5
    assert "solweig" in config.thermal_source_status


def test_canopy_solweig_dynamic_cptl_config_preserves_canopy_provenance() -> None:
    config = load_dynamic_cptl_config(
        PROJECT_ROOT / "config/dynamic_cptl_solweig_canopy.yaml"
    )

    assert config.is_solweig_dynamic_result is True
    assert config.output_stem == "clementi_time_dependent_cptl_solweig_canopy"
    assert "chmv2_canopy" in config.thermal_source_status


def test_threshold_crossing_integral_is_exact_for_linear_utci() -> None:
    field = TimeVaryingUTCI(_series([25.0, 29.0]), "central", STATUS)

    exposure = field.integrate_exposure(
        "edge", "2026-08-17T12:00:00+08:00", 10.0, (26.0,)
    )

    assert exposure.entry_utci_deg_c == 25.0
    assert exposure.exit_utci_deg_c == 29.0
    assert exposure.mean_utci_deg_c == 27.0
    assert exposure.exceedance_deg_c_min[26.0] == pytest.approx(11.25)


def test_constant_series_degrades_to_duration_times_utci_excess() -> None:
    field = TimeVaryingUTCI(_series([36.0, 36.0]), "central", STATUS)

    exposure = field.integrate_exposure(
        "edge", "2026-08-17T12:02:00+08:00", 3.0, (26.0, 32.0, 38.0)
    )

    assert exposure.exceedance_deg_c_min == {26.0: 30.0, 32.0: 12.0, 38.0: 0.0}


def test_validation_series_is_explicitly_static_and_complete() -> None:
    static = pd.DataFrame(
        {
            "segment_id": ["a", "b"],
            "modeled_utci_mean_central_deg_c": [34.0, 36.0],
        }
    )
    timestamps = pd.date_range("2026-08-17T12:00:00+08:00", periods=3, freq="5min")

    result = repeat_static_utci_for_algorithm_validation(
        static, timestamps, "central", STATUS
    )

    assert len(result) == 6
    assert result.groupby("segment_id")["modeled_utci_deg_c"].nunique().eq(1).all()
    assert result["thermal_source_status"].eq(STATUS).all()


def test_lookup_rejects_extrapolation() -> None:
    field = TimeVaryingUTCI(_series([30.0, 31.0]), "central", STATUS)

    with pytest.raises(ValueError, match="outside the modeled time window"):
        field.utci_at("edge", "2026-08-17T11:59:00+08:00")
