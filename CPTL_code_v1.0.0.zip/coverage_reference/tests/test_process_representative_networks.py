from pathlib import Path

from coollink_sg.data.process_representative_networks import (
    load_representative_network_processing_config,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_representative_network_processing_config_loads() -> None:
    config = load_representative_network_processing_config(
        PROJECT_ROOT / "config/representative_network_processing.yaml"
    )
    assert config.analysis_crs == "EPSG:3414"
    assert config.region_ids == ("jurong_east_mrt", "toa_payoh_mrt")


def test_raffles_place_network_processing_config_loads() -> None:
    config = load_representative_network_processing_config(
        PROJECT_ROOT / "config/raffles_place_network_processing.yaml"
    )
    assert config.analysis_crs == "EPSG:3414"
    assert config.region_ids == ("raffles_place_mrt",)
