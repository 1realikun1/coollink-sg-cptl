from pathlib import Path

import numpy as np
import pytest
import rasterio

from coollink_sg.data.raffles_place_input_audit import (
    audit_raster_pair,
    load_raffles_place_input_audit_config,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _write_raster(path: Path, values: np.ndarray, nodata: float | None, canopy: bool) -> None:
    profile = {
        "driver": "GTiff",
        "height": values.shape[0],
        "width": values.shape[1],
        "count": 1,
        "dtype": "float32",
        "crs": "EPSG:3414",
        "transform": rasterio.transform.from_origin(0, 10, 5, 5),
        "nodata": nodata,
    }
    with rasterio.open(path, "w", **profile) as target:
        target.write(values.astype(np.float32), 1)
        if canopy:
            target.update_tags(zero_value_semantics="valid_no_canopy")


def test_raffles_place_input_audit_config_loads() -> None:
    config = load_raffles_place_input_audit_config(
        PROJECT_ROOT / "config/raffles_place_input_audit.yaml"
    )
    assert config.region_id == "raffles_place_mrt"
    assert config.analysis_crs == "EPSG:3414"
    assert config.required_core_tile_count == 7


def test_raster_pair_accepts_valid_zero_canopy_semantics(tmp_path: Path) -> None:
    building = tmp_path / "building.tif"
    canopy = tmp_path / "canopy.tif"
    _write_raster(building, np.array([[10, 0], [0, 0]]), None, False)
    _write_raster(canopy, np.array([[0, 0], [5, 0]]), -9999, True)
    result = audit_raster_pair(building, canopy, "EPSG:3414", 5)
    assert result["positive_overlap_pixel_count"] == 0
    assert result["canopy_positive_pixel_count"] == 1


def test_raster_pair_rejects_building_canopy_overlap(tmp_path: Path) -> None:
    building = tmp_path / "building.tif"
    canopy = tmp_path / "canopy.tif"
    _write_raster(building, np.array([[10, 0], [0, 0]]), None, False)
    _write_raster(canopy, np.array([[5, 0], [0, 0]]), -9999, True)
    with pytest.raises(ValueError, match="overlap"):
        audit_raster_pair(building, canopy, "EPSG:3414", 5)
