"""Tests for exploratory cooling-support proxy sensitivity analysis."""

from pathlib import Path

import geopandas as gpd
import pytest
from shapely.geometry import LineString

from coollink_sg.config import (
    CoolingProxyComponentConfig,
    CoolingProxySensitivityConfig,
    load_cooling_proxy_sensitivity_config,
)
from coollink_sg.heat.cooling_proxy import (
    compute_cooling_proxy_sensitivity,
    create_cooling_proxy_sensitivity_map,
    generate_weight_scenarios,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _config() -> CoolingProxySensitivityConfig:
    return CoolingProxySensitivityConfig(
        analysis_id="test_proxy",
        input_path="unused.gpkg",
        input_layer="road_features",
        output_crs="EPSG:3414",
        weight_step=0.05,
        diagnostic_top_fraction=0.1,
        components=(
            CoolingProxyComponentConfig(
                name="green",
                input_field="green_area_proxy_ratio",
                interpretation="test green proxy",
            ),
            CoolingProxyComponentConfig(
                name="passage",
                input_field="building_passage_flag",
                interpretation="test passage proxy",
            ),
        ),
    )


def _features() -> gpd.GeoDataFrame:
    return gpd.GeoDataFrame(
        {
            "segment_id": ["green", "passage", "agreement"],
            "green_area_proxy_ratio": [0.8, 0.0, 0.5],
            "building_passage_flag": [0, 1, 0.5],
        },
        geometry=[
            LineString([(0, 0), (1, 0)]),
            LineString([(1, 0), (2, 0)]),
            LineString([(2, 0), (3, 0)]),
        ],
        crs="EPSG:3414",
    )


def test_project_configuration_declares_no_preferred_weights() -> None:
    config = load_cooling_proxy_sensitivity_config(
        PROJECT_ROOT / "config/cooling_proxy_sensitivity.yaml"
    )

    assert config.weight_step == 0.05
    assert [component.input_field for component in config.components] == [
        "green_area_proxy_ratio",
        "building_passage_flag",
    ]


def test_weight_sweep_covers_full_simplex_without_preference() -> None:
    scenarios = generate_weight_scenarios(_config())

    assert len(scenarios) == 21
    assert scenarios["weight_sum"].eq(1).all()
    assert scenarios["preferred_scenario"].eq(False).all()  # noqa: E712
    assert scenarios.iloc[0]["weight_green"] == 0
    assert scenarios.iloc[-1]["weight_green"] == 1


def test_sensitivity_statistics_are_bounded_and_retain_disagreement() -> None:
    result, _ = compute_cooling_proxy_sensitivity(_features(), _config())
    indexed = result.set_index("segment_id")

    assert indexed.loc["green", "cooling_support_proxy_min"] == pytest.approx(0)
    assert indexed.loc["green", "cooling_support_proxy_max"] == pytest.approx(0.8)
    assert indexed.loc["green", "cooling_support_proxy_range_across_weights"] == pytest.approx(0.8)
    assert indexed.loc["passage", "cooling_support_proxy_range_across_weights"] == pytest.approx(1)
    assert indexed.loc[
        "agreement", "cooling_support_proxy_range_across_weights"
    ] == pytest.approx(0)
    assert result["top_fraction_scenario_frequency"].between(0, 1).all()
    assert result["preferred_weight_scenario"].eq("none").all()
    assert "heat_score" not in result.columns


def test_duplicate_segment_ids_are_rejected() -> None:
    features = _features()
    features.loc[1, "segment_id"] = "green"

    with pytest.raises(ValueError, match="complete and unique"):
        compute_cooling_proxy_sensitivity(features, _config())


def test_out_of_bounds_proxy_input_is_rejected() -> None:
    features = _features()
    features.loc[0, "green_area_proxy_ratio"] = 1.2

    with pytest.raises(ValueError, match="between 0 and 1"):
        compute_cooling_proxy_sensitivity(features, _config())


def test_sensitivity_map_states_that_it_is_not_heat_score(tmp_path: Path) -> None:
    result, _ = compute_cooling_proxy_sensitivity(_features(), _config())
    output = tmp_path / "sensitivity.html"

    create_cooling_proxy_sensitivity_map(result, output)

    html = output.read_text(encoding="utf-8")
    assert "No preferred weight; not Heat Score" in html
