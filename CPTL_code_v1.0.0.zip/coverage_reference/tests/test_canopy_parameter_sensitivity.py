"""Tests for OFAT CHMv2 canopy-parameter sensitivity."""

from pathlib import Path

import numpy as np
import pandas as pd

from coollink_sg.heat.canopy_parameter_sensitivity import (
    _thermal_summary,
    build_canopy_variants,
    load_canopy_sensitivity_config,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_project_canopy_sensitivity_builds_seven_ofat_variants() -> None:
    config = load_canopy_sensitivity_config(
        PROJECT_ROOT / "config/canopy_parameter_sensitivity.yaml"
    )
    variants = build_canopy_variants(config)

    assert len(variants) == 7
    assert variants[0].variant_id == "baseline"
    assert sum(variant.varied_parameter == "height_multiplier" for variant in variants) == 2
    assert sum(variant.varied_parameter == "minimum_canopy_height_m" for variant in variants) == 2
    assert sum(variant.varied_parameter == "trunk_ratio" for variant in variants) == 2


def test_thermal_summary_requires_paired_keys_and_reports_delta() -> None:
    config = load_canopy_sensitivity_config(
        PROJECT_ROOT / "config/canopy_parameter_sensitivity.yaml"
    )
    variant = build_canopy_variants(config)[1]
    baseline = pd.DataFrame(
        {
            "segment_id": ["a", "b"],
            "timestamp_sgt": ["t", "t"],
            "road_mean_tmrt_deg_c": [40.0, 42.0],
            "modeled_utci_deg_c": [34.0, 36.0],
            "road_mean_sun_fraction": [0.5, 0.7],
        }
    )
    changed = baseline.copy()
    changed["modeled_utci_deg_c"] -= 1.0

    summary = _thermal_summary(baseline, changed, variant)

    assert summary["mean_delta_modeled_utci_deg_c"] == -1.0
    assert np.isclose(summary["median_delta_road_mean_tmrt_deg_c"], 0.0)
