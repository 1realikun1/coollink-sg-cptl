from types import SimpleNamespace

import numpy as np
import solweig.api

from coollink_sg.heat.solweig_ground_export import route_ground_state_to_writer


def test_ground_state_is_routed_as_exact_copy_and_patch_is_restored(monkeypatch):
    original = solweig.api._calculate_single
    ground = np.array([[30.0, 31.5]], dtype=np.float32)
    result = SimpleNamespace(
        state=SimpleNamespace(tgout1=ground),
        tmrt=np.array([[42.0, 43.0]], dtype=np.float32),
        kup=None,
    )

    def fake(*args, **kwargs):
        return result

    monkeypatch.setattr(solweig.api, "_calculate_single", fake)
    fake_before_context = solweig.api._calculate_single
    with route_ground_state_to_writer():
        captured = solweig.api._calculate_single()
        assert np.array_equal(captured.kup, ground)
        assert captured.kup is not ground
    assert solweig.api._calculate_single is fake_before_context
    monkeypatch.setattr(solweig.api, "_calculate_single", original)
