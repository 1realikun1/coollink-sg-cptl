"""Tests for paired canopy sensitivity summaries."""

import numpy as np
import pandas as pd

from coollink_sg.heat.canopy_sensitivity import (
    build_summary,
    compare_road_timeseries,
    compare_routes,
    summarize_road_deltas,
)


def test_paired_road_and_route_summaries_preserve_scenario_contract() -> None:
    road_base = pd.DataFrame(
        {
            "segment_id": ["a", "b"],
            "timestamp_sgt": ["2026-08-17T09:00:00+08:00"] * 2,
            "road_mean_tmrt_deg_c": [50.0, 40.0],
            "modeled_utci_deg_c": [38.0, 36.0],
            "road_mean_sun_fraction": [1.0, 0.0],
            "sample_cell_count": [2, 3],
        }
    )
    road_canopy = road_base.copy()
    road_canopy["road_mean_tmrt_deg_c"] = [45.0, 41.0]
    road_canopy["modeled_utci_deg_c"] = [37.0, 36.2]
    road_canopy["road_mean_sun_fraction"] = [0.5, 0.0]
    road_comparison = compare_road_timeseries(road_base, road_canopy)
    time_summary = summarize_road_deltas(road_comparison)

    route_base = pd.DataFrame(
        {
            "departure_time_sgt": ["2026-08-17T09:00:00+08:00"] * 2,
            "detour_limit_fraction": [0.0, 0.05],
            "route_id": ["short", "base-cool"],
            "route_length_m": [1000.0, 1040.0],
            "route_mean_utci_deg_c": [37.0, 36.5],
            "cptl_above_26_deg_c_min": [200.0, 190.0],
            "primary_cptl_reduction_vs_shortest_percent": [0.0, 5.0],
        }
    )
    route_canopy = route_base.copy()
    route_canopy["route_id"] = ["short", "canopy-cool"]
    route_canopy["cptl_above_26_deg_c_min"] = [180.0, 162.0]
    route_canopy["primary_cptl_reduction_vs_shortest_percent"] = [0.0, 10.0]
    route_comparison = compare_routes(route_base, route_canopy)
    summary = build_summary(road_comparison, route_comparison)

    assert len(time_summary) == 1
    assert np.isclose(
        time_summary.iloc[0][
            "mean_delta_modeled_utci_deg_c_canopy_minus_building_only"
        ],
        -0.4,
    )
    assert route_comparison["route_changed"].tolist() == [False, True]
    assert summary["road_time_record_count"] == 2
    assert summary["flexible_route_changed_count"] == 1
