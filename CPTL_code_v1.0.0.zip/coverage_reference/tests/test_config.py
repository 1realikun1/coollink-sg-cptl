"""Tests for study-area configuration."""

from pathlib import Path

import pytest

from coollink_sg.config import (
    load_study_area_config,
    load_vegetation_config,
    load_weather_config,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_clementi_study_area_config_is_valid() -> None:
    config = load_study_area_config(PROJECT_ROOT / "config/study_area.yaml")

    assert config.name == "clementi_mrt_2km"
    assert config.radius_m == 2000
    assert config.geographic_crs == "EPSG:4326"
    assert config.analysis_crs == "EPSG:3414"
    assert config.network.network_type == "walk"


def test_non_positive_radius_is_rejected(tmp_path: Path) -> None:
    config_path = tmp_path / "invalid.yaml"
    config_path.write_text(
        """
study_area:
  name: test
  display_name: Test
  center:
    latitude: 1.3
    longitude: 103.8
  radius_m: 0
  geographic_crs: EPSG:4326
  analysis_crs: EPSG:3414
network:
  network_type: walk
  simplify: true
  retain_all: true
  truncate_by_edge: false
source: {}
""".strip(),
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match="radius_m must be positive"):
        load_study_area_config(config_path)


def test_weather_config_declares_all_required_metrics() -> None:
    config = load_weather_config(PROJECT_ROOT / "config/weather.yaml")

    assert {endpoint.metric for endpoint in config.endpoints} == {
        "air_temperature",
        "relative_humidity",
        "wind_speed",
        "wbgt",
    }
    assert config.timezone == "Asia/Singapore"
    assert config.output_crs == "EPSG:4326"


def test_vegetation_config_uses_metric_context_buffer() -> None:
    config = load_vegetation_config(PROJECT_ROOT / "config/vegetation.yaml")

    assert config.road_context_buffer_m == 20
    assert config.boundary_query_margin_m >= config.road_context_buffer_m
    assert config.analysis_crs == "EPSG:3414"
    assert config.output_metric_name == "green_area_proxy_ratio"

