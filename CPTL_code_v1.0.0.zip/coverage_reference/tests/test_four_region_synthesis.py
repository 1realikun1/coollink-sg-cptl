"""Tests for the four-region final synthesis."""

from pathlib import Path

import pandas as pd
import pytest

from coollink_sg.reporting.four_region_synthesis import (
    combine_route_tables,
    render_primary_figure,
    summarize_route_panel,
    validate_route_panel,
)


def _settings() -> dict[str, object]:
    return {
        "expected_od_count": 2,
        "expected_departure_count": 2,
        "expected_detour_limits": [0, 0.05],
        "primary_detour_limit": 0.05,
        "positive_tolerance": 1e-9,
        "distance_cap_tolerance": 1e-7,
    }


def _route_panel() -> pd.DataFrame:
    rows = []
    for region_order, (region_id, label, multiplier) in enumerate(
        [("a", "Area A", 1.0), ("b", "Area B", 2.0)]
    ):
        for od in ["od_1", "od_2"]:
            for departure in ["09:00", "11:00"]:
                for cap in [0.0, 0.05]:
                    reduction = cap * 100 * multiplier
                    rows.append(
                        {
                            "region_order": region_order,
                            "region_id": region_id,
                            "region_label": label,
                            "od_id": od,
                            "departure_time_sgt": departure,
                            "detour_limit_fraction": cap,
                            "distance_ratio_to_shortest": 1 + cap / 2,
                            "route_id": f"{region_id}_{od}_{departure}_{cap}",
                            "thermal_source_status": "scenario_not_field_validated",
                            "cptl_above_26_deg_c_min": 100 - reduction,
                            "primary_cptl_reduction_vs_shortest_percent": reduction,
                        }
                    )
    return pd.DataFrame(rows)


def test_validate_and_summarize_matched_panel() -> None:
    routes = _route_panel()
    quality = validate_route_panel(routes, _settings())
    detour, main, departures = summarize_route_panel(routes, _settings())

    assert quality["route_rows"] == 16
    assert len(detour) == 4
    assert len(main) == 2
    assert len(departures) == 4
    assert main.loc[main["region_id"].eq("a"), "median_cptl_reduction_percent"].iat[0] == 5
    assert main["positive_reduction_share_percent"].eq(100).all()
    assert main["median_actual_detour_percent"].tolist() == pytest.approx([2.5, 2.5])


def test_validate_rejects_duplicate_route_key() -> None:
    routes = pd.concat([_route_panel(), _route_panel().iloc[[0]]], ignore_index=True)
    with pytest.raises(ValueError, match="quality gates failed"):
        validate_route_panel(routes, _settings())


def test_combine_filters_clementi_scenario(tmp_path: Path) -> None:
    route_path = tmp_path / "routes.csv"
    pd.DataFrame(
        [
            {"thermal_scenario": "building_only", "value": 1},
            {"thermal_scenario": "building_canopy_chmv2", "value": 2},
        ]
    ).to_csv(route_path, index=False)
    result = combine_route_tables(
        tmp_path,
        [
            {
                "region_id": "clementi_mrt",
                "label": "Clementi",
                "routes": {
                    "path": "routes.csv",
                    "filter": {"thermal_scenario": "building_canopy_chmv2"},
                },
            }
        ],
    )
    assert result["value"].tolist() == [2]
    assert result["region_id"].tolist() == ["clementi_mrt"]


def test_primary_svg_contains_accessible_labels(tmp_path: Path) -> None:
    _, main, _ = summarize_route_panel(_route_panel(), _settings())
    output = tmp_path / "figure.svg"
    render_primary_figure(main, output)
    svg = output.read_text(encoding="utf-8")
    assert "Four-region heat-aware routing response" in svg
    assert "Area A" in svg
    assert svg.endswith("</svg>")
