"""Tests for OFAT dynamic CPTL algorithm sensitivity."""

from pathlib import Path

import pandas as pd
import pytest

from coollink_sg.routing.algorithm_sensitivity import (
    build_algorithm_variants,
    load_algorithm_sensitivity_config,
    summarize_algorithm_sensitivity,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_project_config_builds_seven_unique_ofat_variants() -> None:
    config = load_algorithm_sensitivity_config(
        PROJECT_ROOT / "config/routing_algorithm_sensitivity.yaml"
    )
    variants = build_algorithm_variants(config)

    assert len(variants) == 7
    assert variants[0].variant_id == "baseline"
    assert len({variant.variant_id for variant in variants}) == 7
    assert sum(variant.varied_parameter == "time_bin_seconds" for variant in variants) == 2
    assert sum(variant.varied_parameter == "walking_speed_m_s" for variant in variants) == 2
    assert sum(variant.varied_parameter == "primary_threshold_deg_c" for variant in variants) == 2


def test_summary_reports_median_reduction_and_actual_distance() -> None:
    routes = pd.DataFrame(
        {
            "variant_id": ["baseline", "baseline"],
            "varied_parameter": ["baseline", "baseline"],
            "varied_value": [0.0, 0.0],
            "time_bin_seconds": [60, 60],
            "walking_speed_m_s": [1.2, 1.2],
            "primary_threshold_deg_c": [26.0, 26.0],
            "detour_limit_fraction": [0.05, 0.05],
            "primary_cptl_reduction_vs_shortest_percent": [2.0, 4.0],
            "distance_ratio_to_shortest": [1.01, 1.03],
        }
    )

    summary = summarize_algorithm_sensitivity(routes).iloc[0]

    assert summary["median_cptl_reduction_percent"] == 3.0
    assert summary["positive_reduction_share_percent"] == 100.0
    assert summary["median_distance_increase_percent"] == pytest.approx(2.0)
