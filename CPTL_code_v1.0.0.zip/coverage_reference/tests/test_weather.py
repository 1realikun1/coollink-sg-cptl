"""Tests for official weather-response normalization."""

from datetime import UTC, datetime
from pathlib import Path

import pandas as pd
import pytest

from coollink_sg.config import load_study_area_config, load_weather_config
from coollink_sg.data.weather import (
    KNOTS_TO_METRES_PER_SECOND,
    nearest_observations_to_study_area,
    normalize_station_readings,
    normalize_wbgt_records,
    save_raw_snapshot,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _endpoint(metric: str):
    config = load_weather_config(PROJECT_ROOT / "config/weather.yaml")
    return next(endpoint for endpoint in config.endpoints if endpoint.metric == metric)


def _station_payload(unit: str, value: float) -> dict:
    return {
        "code": 0,
        "data": {
            "stations": [
                {
                    "id": "S50",
                    "name": "Clementi Road",
                    "location": {"latitude": 1.3318, "longitude": 103.7762},
                }
            ],
            "readings": [
                {
                    "timestamp": "2026-08-17T12:50:00+08:00",
                    "data": [{"stationId": "S50", "value": value}],
                }
            ],
            "readingType": "test",
            "readingUnit": unit,
        },
        "errorMsg": "",
    }


def test_wind_speed_is_converted_from_knots_to_metres_per_second() -> None:
    frame = normalize_station_readings(
        _station_payload("knots", 10),
        _endpoint("wind_speed"),
        datetime(2026, 8, 17, 5, 0, tzinfo=UTC),
        "snapshot",
        "Asia/Singapore",
    )

    assert frame.loc[0, "source_value"] == "10"
    assert frame.loc[0, "source_unit"] == "knots"
    assert frame.loc[0, "unit"] == "m/s"
    assert frame.loc[0, "value"] == pytest.approx(10 * KNOTS_TO_METRES_PER_SECOND)
    assert frame.loc[0, "quality_flag"] == "valid"


def test_unexpected_station_unit_is_rejected() -> None:
    with pytest.raises(ValueError, match="Unexpected source unit"):
        normalize_station_readings(
            _station_payload("km/h", 10),
            _endpoint("wind_speed"),
            datetime(2026, 8, 17, 5, 0, tzinfo=UTC),
            "snapshot",
            "Asia/Singapore",
        )


def test_wbgt_na_is_preserved_as_missing() -> None:
    payload = {
        "code": 0,
        "data": {
            "records": [
                {
                    "datetime": "2026-08-17T12:30:00+08:00",
                    "item": {
                        "updatedTimestamp": "2026-08-17T12:40:00+08:00",
                        "readings": [
                            {
                                "station": {"id": "S127", "name": "Stadium Road"},
                                "location": {
                                    "latitude": "1.305738",
                                    "longitude": "103.878174",
                                },
                                "wbgt": "NA",
                                "heatStress": "NA",
                            }
                        ],
                    },
                }
            ]
        },
        "errorMsg": "",
    }

    frame = normalize_wbgt_records(
        payload,
        _endpoint("wbgt"),
        datetime(2026, 8, 17, 5, 0, tzinfo=UTC),
        "snapshot",
        "Asia/Singapore",
    )

    assert pd.isna(frame.loc[0, "value"])
    assert frame.loc[0, "source_value"] == "NA"
    assert "missing_value" in frame.loc[0, "quality_flag"]


def test_nearest_station_distance_is_computed_in_metric_crs() -> None:
    study_area = load_study_area_config(PROJECT_ROOT / "config/study_area.yaml")
    observations = pd.DataFrame(
        [
            {
                "metric": "air_temperature",
                "station_id": "near",
                "station_name": "Near",
                "station_context": None,
                "latitude": 1.3142,
                "longitude": 103.7657,
                "observed_at_utc": "2026-08-17T04:50:00+00:00",
                "observed_at_sgt": "2026-08-17T12:50:00+08:00",
                "value": 31.0,
                "unit": "degC",
                "heat_stress": None,
                "quality_flag": "valid",
            },
            {
                "metric": "air_temperature",
                "station_id": "far",
                "station_name": "Far",
                "station_context": None,
                "latitude": 1.40,
                "longitude": 103.90,
                "observed_at_utc": "2026-08-17T04:50:00+00:00",
                "observed_at_sgt": "2026-08-17T12:50:00+08:00",
                "value": 32.0,
                "unit": "degC",
                "heat_stress": None,
                "quality_flag": "valid",
            },
        ]
    )

    nearest = nearest_observations_to_study_area(observations, study_area)

    assert nearest.loc[0, "station_id"] == "near"
    assert nearest.loc[0, "distance_to_study_center_m"] < 20
    assert bool(nearest.loc[0, "inside_study_area"])


def test_raw_snapshot_is_created_once(tmp_path: Path) -> None:
    config = load_weather_config(PROJECT_ROOT / "config/weather.yaml")
    retrieved = datetime(2026, 8, 17, 5, 0, tzinfo=UTC)
    fetched = {
        endpoint.metric: {
            "raw_bytes": b'{"code":0}',
            "request_url": endpoint.url,
        }
        for endpoint in config.endpoints
    }

    snapshot = save_raw_snapshot(fetched, retrieved, config, tmp_path)

    assert (snapshot / "manifest.json").is_file()
    assert (snapshot / "air_temperature.json").read_bytes() == b'{"code":0}'
    with pytest.raises(FileExistsError):
        save_raw_snapshot(fetched, retrieved, config, tmp_path)

