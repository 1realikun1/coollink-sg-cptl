import pandas as pd

from coollink_sg.routing.behavior_informed_od import classify_building, weighted_quantile


def test_building_categories_exclude_generic_geometry_tags():
    assert classify_building("residential") == "residential"
    assert classify_building("office") == "employment"
    assert classify_building("school") == "education"
    assert classify_building("yes") is None
    assert classify_building("roof") is None


def test_weighted_quantile_responds_to_probability_mass():
    values = pd.Series([1.0, 2.0, 20.0])
    assert weighted_quantile(values, pd.Series([0.45, 0.45, 0.10]), 0.5) == 2.0
    assert weighted_quantile(values, pd.Series([0.10, 0.10, 0.80]), 0.5) == 20.0

