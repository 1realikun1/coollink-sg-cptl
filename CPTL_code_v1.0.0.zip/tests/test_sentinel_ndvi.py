"""Tests for Sentinel-2 L2A NDVI processing and road aggregation."""

import json
from datetime import UTC, datetime
from pathlib import Path

import geopandas as gpd
import numpy as np
import pytest
import rasterio
from rasterio.transform import from_origin
from shapely.geometry import LineString

from coollink_sg.config import load_sentinel_ndvi_config
from coollink_sg.features.sentinel_ndvi import (
    calculate_masked_ndvi,
    create_ndvi_map,
    road_ndvi_statistics,
    save_raw_sentinel_snapshot,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _config():
    return load_sentinel_ndvi_config(PROJECT_ROOT / "config/sentinel_ndvi.yaml")


def test_project_config_uses_l2a_assets_and_explicit_scl_classes() -> None:
    config = _config()

    assert config.collection == "sentinel-2-c1-l2a"
    assert (config.asset_red, config.asset_nir, config.asset_scl) == (
        "red",
        "nir",
        "scl",
    )
    assert config.valid_scl_classes == (4, 5, 6, 7)
    assert config.road_context_buffer_m == 20


def test_ndvi_applies_scale_offset_and_scl_mask() -> None:
    red = np.array([[2000, 2000], [0, 2000]], dtype="uint16")
    nir = np.array([[6000, 6000], [6000, 6000]], dtype="uint16")
    scl = np.array([[4, 3], [4, 7]], dtype="uint8")

    ndvi, valid = calculate_masked_ndvi(
        red, nir, scl, 0.0001, -0.1, 0.0001, -0.1, (4, 5, 6, 7)
    )

    assert ndvi[0, 0] == pytest.approx(2 / 3)
    assert np.isnan(ndvi[0, 1])
    assert np.isnan(ndvi[1, 0])
    assert ndvi[1, 1] == pytest.approx(2 / 3)
    assert valid.tolist() == [[True, False], [False, True]]


def test_road_statistics_report_valid_fraction_and_missing_outside() -> None:
    ndvi = np.full((10, 10), 0.5, dtype="float32")
    ndvi[4:6, 4:6] = np.nan
    transform = from_origin(0, 100, 10, 10)
    edges = gpd.GeoDataFrame(
        {"segment_id": ["inside", "outside"]},
        geometry=[
            LineString([(10, 50), (90, 50)]),
            LineString([(200, 200), (220, 200)]),
        ],
        crs="EPSG:3414",
    )

    observation_count = np.where(np.isfinite(ndvi), 3, 0).astype("uint8")
    result = road_ndvi_statistics(
        edges,
        ndvi,
        transform,
        "EPSG:3414",
        10,
        observation_count=observation_count,
    )
    indexed = result.set_index("segment_id")

    assert indexed.loc["inside", "sentinel2_ndvi_mean"] == pytest.approx(0.5)
    assert 0 < indexed.loc["inside", "sentinel2_ndvi_valid_pixel_fraction"] < 1
    assert np.isnan(indexed.loc["outside", "sentinel2_ndvi_mean"])
    assert indexed.loc["outside", "sentinel2_ndvi_valid_pixel_count"] == 0
    assert indexed.loc["inside", "sentinel2_ndvi_observation_count_mean"] == 3
    assert np.isnan(
        indexed.loc["outside", "sentinel2_ndvi_observation_count_mean"]
    )


def test_duplicate_segments_are_rejected() -> None:
    edges = gpd.GeoDataFrame(
        {"segment_id": ["s1", "s1"]},
        geometry=[LineString([(0, 0), (1, 0)]), LineString([(1, 0), (2, 0)])],
        crs="EPSG:3414",
    )

    with pytest.raises(ValueError, match="complete and unique"):
        road_ndvi_statistics(
            edges,
            np.ones((2, 2), dtype="float32"),
            from_origin(0, 2, 1, 1),
            "EPSG:3414",
            1,
        )


def test_raw_snapshot_is_immutable_and_records_native_windows(tmp_path: Path) -> None:
    profile = {
        "driver": "GTiff",
        "height": 2,
        "width": 2,
        "count": 1,
        "dtype": "uint16",
        "crs": "EPSG:32648",
        "transform": from_origin(300000, 200000, 10, 10),
        "nodata": 0,
    }
    scl_profile = {**profile, "dtype": "uint8"}
    windows = {
        "red": (np.ones((2, 2), dtype="uint16"), profile),
        "nir": (np.ones((2, 2), dtype="uint16") * 2, profile),
        "scl": (np.ones((2, 2), dtype="uint8") * 4, scl_profile),
    }
    item = {
        "id": "test-item",
        "properties": {"datetime": "2026-01-01T00:00:00Z", "eo:cloud_cover": 1},
    }
    retrieved = datetime(2026, 8, 17, 10, 0, tzinfo=UTC)
    response = json.dumps({"features": [item]}).encode()
    snapshot = save_raw_sentinel_snapshot(
        response, item, {"bbox": [0, 0, 1, 1]}, windows, retrieved, _config(), tmp_path
    )

    assert (snapshot / "manifest.json").is_file()
    with rasterio.open(snapshot / "red_native_window.tif") as source:
        assert source.read(1).tolist() == [[1, 1], [1, 1]]
    with pytest.raises(FileExistsError):
        save_raw_sentinel_snapshot(
            response,
            item,
            {"bbox": [0, 0, 1, 1]},
            windows,
            retrieved,
            _config(),
            tmp_path,
        )


def test_map_embeds_source_and_coverage_traceability(tmp_path: Path) -> None:
    roads = gpd.GeoDataFrame(
        {
            "segment_id": ["s1"],
            "sentinel2_ndvi_mean": [0.4],
            "sentinel2_ndvi_valid_pixel_fraction": [0.75],
        },
        geometry=[LineString([(103.76, 1.31), (103.77, 1.31)])],
        crs="EPSG:4326",
    )
    output = tmp_path / "ndvi.html"

    create_ndvi_map(
        roads,
        output,
        {
            "item_id": "sentinel-test-item",
            "acquired_at": "2026-06-13T03:37:46Z",
            "study_area_valid_pixel_fraction": 0.608,
        },
    )

    html = output.read_text(encoding="utf-8")
    assert "sentinel-test-item" in html
    assert "60.8%" in html
    assert "NDVI is not canopy cover" in html
