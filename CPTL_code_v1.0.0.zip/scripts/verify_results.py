"""Read-only numerical checks of the archived CPTL result tables."""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd


def weighted_median(values, weights):
    frame = pd.DataFrame({"value": values, "weight": weights}).dropna()
    frame = frame.loc[frame.weight.gt(0)].sort_values("value")
    assert not frame.empty
    return float(frame.loc[frame.weight.cumsum().ge(0.5 * frame.weight.sum()), "value"].iloc[0])


def verify(root):
    routing = root / "data/processed/routing"
    rec = pd.read_csv(routing / "behavior_informed_probability_recommendations.csv")
    candidates = pd.read_csv(routing / "behavior_informed_probability_candidates.csv")
    od = pd.read_csv(routing / "behavior_informed_od_sample.csv")
    key = ["region_id", "od_id", "departure_time_sgt"]
    assert len(rec) == 760 and len(candidates) == 12122 and len(od) == 152
    assert not rec.duplicated(key).any()
    assert not candidates.duplicated(key + ["route_id"]).any()
    assert len(candidates[key].drop_duplicates()) == 760
    assert rec.groupby("region_id").size().to_dict() == {
        "clementi_mrt": 200, "jurong_east_mrt": 160,
        "raffles_place_mrt": 200, "toa_payoh_mrt": 200,
    }
    assert rec.merge(candidates[key + ["route_id"]], on=key + ["route_id"], validate="one_to_one").shape[0] == 760
    alternatives = rec.loc[~rec.is_shortest_distance]
    assert alternatives.mean_acceptance_probability.ge(0.05).all()
    assert alternatives.cptl_reduction_deg_c_min.gt(1e-9).all()
    for suffix in ["deg_c_min", "percent"]:
        np.testing.assert_allclose(rec["probability_weighted_cptl_reduction_" + suffix],
                                   rec.mean_acceptance_probability * rec["cptl_reduction_" + suffix], rtol=1e-9, atol=1e-9)
    eligible = candidates.loc[(~candidates.is_shortest_distance) & candidates.mean_acceptance_probability.ge(0.05) & candidates.cptl_reduction_deg_c_min.gt(1e-9)]
    maxima = eligible.groupby(key).probability_weighted_cptl_reduction_deg_c_min.max()
    offered = alternatives.set_index(key).probability_weighted_cptl_reduction_deg_c_min
    assert set(maxima.index) == set(offered.index)
    np.testing.assert_allclose(offered.sort_index(), maxima.sort_index(), rtol=1e-9, atol=1e-9)
    expected = pd.read_csv(root / "outputs/tables/behavior_informed_probability_summary.csv").set_index("region_id")
    rows = []
    for district, frame in rec.groupby("region_id"):
        w = frame.od_probability
        offer = ~frame.is_shortest_distance
        row = {
            "region_id": district, "case_count": len(frame),
            "weighted_offered_alternative_share_percent": 100 * np.average(offer, weights=w),
            "weighted_median_acceptance_probability_percent": 100 * weighted_median(frame.loc[offer, "mean_acceptance_probability"], w[offer]),
            "weighted_median_physical_detour_percent": weighted_median(frame.physical_detour_percent, w),
            "weighted_median_offered_cptl_reduction_percent": weighted_median(frame.cptl_reduction_percent, w),
            "weighted_median_probability_weighted_cptl_reduction_percent": weighted_median(frame.probability_weighted_cptl_reduction_percent, w),
        }
        for column, value in row.items():
            if column != "region_id": np.testing.assert_allclose(value, expected.loc[district, column], rtol=1e-10, atol=1e-10)
        rows.append(row)
    control = pd.read_csv(routing / "four_region_behavior_probability_recommendations.csv")
    assert len(control) == 240
    summary = json.loads((root / "data/processed/behavior/melnikov2022_choice_model_summary.json").read_text())
    bootstrap = pd.read_csv(root / "data/processed/behavior/melnikov2022_choice_bootstrap.csv")
    assert summary["observation_count"] == 408 and summary["participant_count"] == 46
    assert len(bootstrap) == 500
    thin = pd.read_csv(root / "outputs/tables/temporal_thinning_summary.csv").set_index("interval_minutes")
    assert thin.loc[30, "retained_timestamp_count"] == 19 and thin.loc[30, "full_timestamp_count"] == 37
    np.testing.assert_allclose(thin.loc[30, "solweig_run_reduction_percent"], 100 * (1 - 19/37))
    np.testing.assert_allclose(thin.loc[30, "exact_route_agreement_percent"], 92.5)
    return {"status": "passed", "primary_cases": len(rec), "candidate_routes": len(candidates),
            "synthetic_od_pairs": len(od), "coverage_cases": len(control),
            "bootstrap_replicates": len(bootstrap), "district_summaries": rows,
            "scope": "Integrity, candidate-pool optimality, eligibility, weighted summary reproduction and archived temporal-thinning summary; no full SOLWEIG/routing rerun."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    result = verify(args.data_root)
    text = json.dumps(result, indent=2)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(text + "\n", encoding="utf8")
    print(text)
