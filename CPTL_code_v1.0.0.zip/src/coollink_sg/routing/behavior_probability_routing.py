"""Behavior-calibrated probabilistic route offers without fixed detour caps."""

from __future__ import annotations

import argparse
from dataclasses import replace
import json
from pathlib import Path
from typing import Any

import geopandas as gpd
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import yaml
from scipy.special import expit
from shapely.geometry import MultiLineString

from coollink_sg.config import ShortestPathConfig
from coollink_sg.heat.dynamic_utci import TimeVaryingUTCI
from coollink_sg.routing.representative_cptl import (
    _dynamic_config,
    load_representative_cptl_config,
)
from coollink_sg.routing.shortest_path import build_routing_graph, shortest_route
from coollink_sg.routing.time_dependent_cptl import (
    LENGTH_FIELD,
    _dynamic_destination_labels,
    _evaluate_route,
    _recover_edge_keys,
    _route_id,
    _threshold_slug,
)
from coollink_sg.routing.behavior_informed_od import weighted_quantile

PROJECT_ROOT = Path(__file__).resolve().parents[3]


def _required(mapping: dict[str, Any], key: str, section: str) -> Any:
    if key not in mapping:
        raise ValueError(f"Missing required field '{section}.{key}'")
    return mapping[key]


def behavior_screening_maximum_distance(
    shortest_distance_m: float,
    beta: float,
    scale_m: float,
    minimum_acceptance_probability: float,
) -> float:
    """Upper distance bound implied by a best-case shade acceptance probability."""

    if shortest_distance_m <= 0 or beta <= 0 or scale_m <= 0:
        raise ValueError("Distance and behavior parameters must be positive")
    if not 0 < minimum_acceptance_probability < 0.5:
        raise ValueError("minimum_acceptance_probability must be between zero and 0.5")
    log_odds = np.log((1 - minimum_acceptance_probability) / minimum_acceptance_probability)
    return float(beta * shortest_distance_m + scale_m * log_odds)


class TimeVaryingSunFraction:
    """Validated linear lookup of the SOLWEIG road sun fraction."""

    def __init__(self, frame: pd.DataFrame) -> None:
        required = {"segment_id", "timestamp_sgt", "road_mean_sun_fraction"}
        missing = required.difference(frame.columns)
        if missing:
            raise ValueError(f"Road thermal table is missing sun fields: {sorted(missing)}")
        selected = frame[list(required)].copy()
        selected["_timestamp_utc"] = pd.to_datetime(
            selected["timestamp_sgt"], utc=True, errors="raise"
        )
        selected["road_mean_sun_fraction"] = pd.to_numeric(
            selected["road_mean_sun_fraction"], errors="raise"
        )
        values = selected["road_mean_sun_fraction"].to_numpy(dtype=float)
        if not np.isfinite(values).all() or np.any((values < 0) | (values > 1)):
            raise ValueError("Road sun fractions must be finite and between zero and one")
        if selected.duplicated(["segment_id", "_timestamp_utc"]).any():
            raise ValueError("Road sun segment-time keys must be unique")
        pivot = selected.pivot(
            index="segment_id",
            columns="_timestamp_utc",
            values="road_mean_sun_fraction",
        ).sort_index(axis=1)
        if pivot.isna().any().any():
            raise ValueError("Every road segment must have the complete sun time grid")
        self.segment_ids = frozenset(pivot.index.astype(str))
        self._rows = {
            str(segment_id): row for row, segment_id in enumerate(pivot.index.astype(str))
        }
        self._timestamps = pd.DatetimeIndex(pivot.columns)
        self._seconds = (
            self._timestamps - self._timestamps[0]
        ).total_seconds().to_numpy(dtype=float)
        self._values = pivot.to_numpy(dtype=float)

    def at(self, segment_id: str, timestamp: pd.Timestamp) -> float:
        parsed = pd.Timestamp(timestamp)
        if parsed.tzinfo is None:
            raise ValueError("Sun lookup timestamp must be timezone-aware")
        parsed = parsed.tz_convert("UTC")
        if parsed < self._timestamps[0] or parsed > self._timestamps[-1]:
            raise ValueError("Sun lookup timestamp lies outside the modeled series")
        try:
            row = self._rows[str(segment_id)]
        except KeyError as exc:
            raise ValueError(f"Unknown road sun segment_id: {segment_id}") from exc
        second = float((parsed - self._timestamps[0]).total_seconds())
        return float(np.interp(second, self._seconds, self._values[row]))


def _sun_shade_distance(
    graph: Any,
    edge_keys: list[tuple[int, int, int]],
    sun: TimeVaryingSunFraction,
    departure: pd.Timestamp,
) -> tuple[float, float]:
    sun_distance = 0.0
    total_distance = 0.0
    for u, v, key in edge_keys:
        attributes = graph[u][v][key]
        length = float(attributes[LENGTH_FIELD])
        total_distance += length
        sun_distance += length * sun.at(str(attributes["segment_id"]), departure)
    return sun_distance, total_distance - sun_distance


def acceptance_probability_draws(
    alternative_sun_m: float,
    alternative_shade_m: float,
    shortest_sun_m: float,
    shortest_shade_m: float,
    bootstrap: pd.DataFrame,
) -> np.ndarray:
    """Probability of accepting an alternative over the shortest route."""

    beta = bootstrap["sun_cost_factor_beta"].to_numpy(dtype=float)
    scale = bootstrap["choice_scale_m"].to_numpy(dtype=float)
    alt_cost = beta * alternative_sun_m + alternative_shade_m
    shortest_cost = beta * shortest_sun_m + shortest_shade_m
    return expit(-(alt_cost - shortest_cost) / scale)


def select_behavioral_offer(
    candidates: pd.DataFrame,
    minimum_improvement: float,
    minimum_acceptance_probability: float,
) -> int:
    """Select the route maximizing probability-weighted CPTL reduction."""

    alternatives = candidates.loc[
        candidates["cptl_reduction_deg_c_min"].gt(minimum_improvement)
        & candidates["mean_acceptance_probability"].ge(minimum_acceptance_probability)
        & ~candidates["is_shortest_distance"]
    ]
    if alternatives.empty:
        return int(candidates.loc[candidates["is_shortest_distance"]].index[0])
    return int(
        alternatives.sort_values(
            [
                "probability_weighted_cptl_reduction_deg_c_min",
                "mean_acceptance_probability",
                "route_length_m",
                "route_id",
            ],
            ascending=[False, False, True, True],
        ).index[0]
    )


def _build_candidate(
    graph: Any,
    edge_keys: list[tuple[int, int, int]],
    thermal: TimeVaryingUTCI,
    sun: TimeVaryingSunFraction,
    departure: pd.Timestamp,
    thresholds: tuple[float, ...],
    walking_speed: float,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    metrics, segments, geometries = _evaluate_route(
        graph, edge_keys, thermal, departure, thresholds, walking_speed
    )
    segment_ids = str(metrics.pop("segment_ids")).split("|")
    sun_distance, shade_distance = _sun_shade_distance(graph, edge_keys, sun, departure)
    route_id = _route_id(departure, segment_ids)
    return (
        {
            "route_id": route_id,
            **metrics,
            "departure_snapshot_sun_distance_m": sun_distance,
            "departure_snapshot_shade_distance_m": shade_distance,
            "geometry": MultiLineString(geometries),
        },
        [{"route_id": route_id, **segment} for segment in segments],
    )


def _summarize(recommendations: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for region_id, frame in recommendations.groupby("region_id", sort=True):
        weights = frame["od_probability"].astype(float)
        offered = ~frame["is_shortest_distance"]
        offered_weights = weights.loc[offered]
        rows.append(
            {
                "region_id": region_id,
                "case_count": len(frame),
                "weighted_offered_alternative_share_percent": float(100 * np.average(offered, weights=weights)),
                "weighted_median_acceptance_probability_percent": 100 * weighted_quantile(
                    frame.loc[offered, "mean_acceptance_probability"], offered_weights, 0.5
                ),
                "weighted_median_physical_detour_percent": weighted_quantile(
                    frame["physical_detour_percent"], weights, 0.5
                ),
                "weighted_median_offered_cptl_reduction_percent": weighted_quantile(
                    frame["cptl_reduction_percent"], weights, 0.5
                ),
                "weighted_median_probability_weighted_cptl_reduction_percent": weighted_quantile(
                    frame["probability_weighted_cptl_reduction_percent"], weights, 0.5
                ),
            }
        )
    return pd.DataFrame(rows)


def _markdown_table(frame: pd.DataFrame) -> str:
    """Render a compact Markdown table without pandas' optional tabulate dependency."""
    columns = [str(column) for column in frame.columns]
    rows = [[str(value) for value in row] for row in frame.itertuples(index=False, name=None)]

    def escape(value: str) -> str:
        return value.replace("|", "\\|").replace("\n", " ")

    lines = [
        "| " + " | ".join(escape(value) for value in columns) + " |",
        "| " + " | ".join("---" for _ in columns) + " |",
    ]
    lines.extend("| " + " | ".join(escape(value) for value in row) + " |" for row in rows)
    return "\n".join(lines)


def _write_reports(
    paths: dict[str, Path],
    summary: pd.DataFrame,
    model: dict[str, Any],
    payload: dict[str, Any],
) -> None:
    rows_en = [
        "# Behavior-calibrated probability routing",
        "",
        "The fixed 5/10/15% caps are retained only as a legacy comparison. The new route offer",
        "is selected by maximizing acceptance-probability-weighted CPTL reduction.",
        "",
        f"The transferred Singapore behavior model used {model['observation_count']} choices from",
        f"{model['participant_count']} participants. Its sun cost factor was",
        f"{model['sun_cost_factor_beta']:.3f} and leave-one-participant-out accuracy was",
        f"{100 * model['loocv_accuracy']:.1f}%.",
        "",
        _markdown_table(summary),
        "",
        "This is external behavior calibration, not observed route choice in the four districts.",
        str(payload["interpretation"]),
    ]
    rows_zh = [
        "# 数据驱动的行为概率路由",
        "",
        "固定的 5%/10%/15% 绕行上限只保留为旧模型对照。新模型在候选路线中选择",
        "“接受概率 × CPTL 实际降幅”最大的路线，不再把百分比当作人的行为阈值。",
        "",
        f"外部行为模型来自新加坡 {model['participant_count']} 名参与者的",
        f"{model['observation_count']} 次有效选择；日照感知成本系数为",
        f"{model['sun_cost_factor_beta']:.3f}，留一参与者预测准确率为",
        f"{100 * model['loocv_accuracy']:.1f}%。",
        "",
        _markdown_table(summary),
        "",
        "注意：这是外部行为数据迁移，不是四个研究区内的真实路径选择验证。",
        str(payload["interpretation"]),
    ]
    paths["report_en"].parent.mkdir(parents=True, exist_ok=True)
    paths["report_zh"].parent.mkdir(parents=True, exist_ok=True)
    paths["report_en"].write_text("\n".join(rows_en) + "\n", encoding="utf-8")
    paths["report_zh"].write_text("\n".join(rows_zh) + "\n", encoding="utf-8")


def _plot(summary: pd.DataFrame, png_path: Path, svg_path: Path) -> None:
    labels = summary["region_id"].str.replace("_mrt", "").str.replace("_", " ")
    fig, axes = plt.subplots(1, 2, figsize=(8.4, 3.5), constrained_layout=True)
    axes[0].bar(labels, summary["weighted_median_acceptance_probability_percent"], color="#2563eb")
    axes[0].set_ylabel("Median acceptance probability (%)")
    axes[0].tick_params(axis="x", rotation=25)
    axes[1].bar(
        labels,
        summary["weighted_median_probability_weighted_cptl_reduction_percent"],
        color="#059669",
    )
    axes[1].set_ylabel("Median probability-weighted CPTL reduction (%)")
    axes[1].tick_params(axis="x", rotation=25)
    for path in (png_path, svg_path):
        path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def build_behavior_probability_routes(
    config_path: str | Path,
    project_root: Path = PROJECT_ROOT,
    region_id: str | None = None,
    output_root: Path | None = None,
) -> dict[str, Any]:
    config_payload = yaml.safe_load(Path(config_path).read_text(encoding="utf-8"))
    model_cfg = _required(config_payload, "behavior_probability_routing", "root")
    outputs = _required(config_payload, "outputs", "root")
    rep_path = project_root / str(
        _required(model_cfg, "representative_config", "behavior_probability_routing")
    )
    representative = load_representative_cptl_config(rep_path)
    if region_id is not None:
        selected_regions = tuple(
            region for region in representative.regions if region.region_id == region_id
        )
        if len(selected_regions) != 1:
            raise ValueError(f"Unknown or duplicated region_id: {region_id}")
        representative = replace(representative, regions=selected_regions)
    behavior_path = project_root / str(
        _required(model_cfg, "behavior_summary", "behavior_probability_routing")
    )
    behavior = json.loads(behavior_path.read_text(encoding="utf-8"))
    bootstrap_path = project_root / str(
        _required(model_cfg, "behavior_bootstrap", "behavior_probability_routing")
    )
    bootstrap = pd.read_csv(bootstrap_path)
    sample = pd.read_csv(
        project_root / str(_required(model_cfg, "od_sample", "behavior_probability_routing"))
    )
    if region_id is not None:
        sample = sample.loc[sample["region_id"].eq(region_id)].copy()
    minimum_probability = float(
        _required(
            model_cfg,
            "minimum_screening_acceptance_probability",
            "behavior_probability_routing",
        )
    )
    interval = tuple(
        map(
            float,
            _required(model_cfg, "probability_interval", "behavior_probability_routing"),
        )
    )
    if len(interval) != 2 or not 0 < interval[0] < interval[1] < 1:
        raise ValueError("probability_interval must contain two increasing probabilities")
    primary_field = _threshold_slug(representative.primary_threshold_deg_c)
    route_frames: list[gpd.GeoDataFrame] = []
    segment_frames: list[pd.DataFrame] = []
    recommendation_rows: list[pd.Series] = []
    for region_index, region in enumerate(representative.regions, start=1):
        region_sample = sample.loc[sample["region_id"].eq(region.region_id)].copy()
        network_path = project_root / region.network_path
        thermal_path = project_root / region.dynamic_thermal_path
        nodes = gpd.read_file(network_path, layer="nodes").to_crs(representative.output_crs)
        edges = gpd.read_file(network_path, layer="edges").to_crs(representative.output_crs)
        routing_config = ShortestPathConfig(
            network_path=region.network_path,
            nodes_layer="nodes",
            edges_layer="edges",
            output_crs=representative.output_crs,
            cost_field=LENGTH_FIELD,
        )
        graph = build_routing_graph(nodes, edges, routing_config)
        thermal_frame = pd.read_csv(thermal_path)
        thermal = TimeVaryingUTCI(
            thermal_frame,
            "central",
            representative.thermal_source_status,
        )
        sun = TimeVaryingSunFraction(thermal_frame)
        run_config = _dynamic_config(representative, region)
        for od_index, od in enumerate(region_sample.itertuples(index=False), start=1):
            print(
                f"[{region_index}/{len(representative.regions)} {region.region_id}] "
                f"OD {od_index}/{len(region_sample)} {od.od_id}",
                flush=True,
            )
            shortest = shortest_route(
                graph, int(od.origin_node), int(od.destination_node), LENGTH_FIELD
            )
            shortest_keys = [
                (int(row.u), int(row.v), int(row.key))
                for row in shortest.edges.itertuples(index=False)
            ]
            maximum_distance = behavior_screening_maximum_distance(
                shortest.distance_m,
                float(behavior["sun_cost_factor_beta"]),
                float(behavior["choice_scale_m"]),
                minimum_probability,
            )
            for departure_text in representative.departure_times:
                departure = pd.Timestamp(departure_text)
                labels, destination_ids, _ = _dynamic_destination_labels(
                    graph,
                    thermal,
                    int(od.origin_node),
                    int(od.destination_node),
                    departure,
                    maximum_distance,
                    run_config,
                )
                candidate_keys = [shortest_keys]
                candidate_keys.extend(
                    _recover_edge_keys(labels, label_id) for label_id in destination_ids
                )
                unique: dict[tuple[tuple[int, int, int], ...], list[tuple[int, int, int]]] = {}
                for keys in candidate_keys:
                    unique.setdefault(tuple(keys), keys)
                rows: list[dict[str, Any]] = []
                segments: list[dict[str, Any]] = []
                for keys in unique.values():
                    row, route_segments = _build_candidate(
                        graph,
                        keys,
                        thermal,
                        sun,
                        departure,
                        representative.sensitivity_thresholds_deg_c,
                        representative.walking_speed_m_s,
                    )
                    rows.append(row)
                    segments.extend(route_segments)
                candidates = gpd.GeoDataFrame(rows, geometry="geometry", crs=edges.crs)
                shortest_route_id = _route_id(
                    departure,
                    [str(graph[u][v][key]["segment_id"]) for u, v, key in shortest_keys],
                )
                candidates["is_shortest_distance"] = candidates["route_id"].eq(shortest_route_id)
                if candidates["is_shortest_distance"].sum() != 1:
                    raise RuntimeError("Candidate set must contain exactly one shortest route")
                baseline = candidates.loc[candidates["is_shortest_distance"]].iloc[0]
                probabilities = []
                lows = []
                highs = []
                for candidate in candidates.itertuples(index=False):
                    if candidate.is_shortest_distance:
                        draws = np.ones(len(bootstrap), dtype=float)
                    else:
                        draws = acceptance_probability_draws(
                            candidate.departure_snapshot_sun_distance_m,
                            candidate.departure_snapshot_shade_distance_m,
                            baseline.departure_snapshot_sun_distance_m,
                            baseline.departure_snapshot_shade_distance_m,
                            bootstrap,
                        )
                    probabilities.append(float(draws.mean()))
                    lows.append(float(np.quantile(draws, interval[0])))
                    highs.append(float(np.quantile(draws, interval[1])))
                candidates["mean_acceptance_probability"] = probabilities
                candidates["acceptance_probability_low"] = lows
                candidates["acceptance_probability_high"] = highs
                candidates["physical_detour_percent"] = 100 * (
                    candidates["route_length_m"] / float(baseline.route_length_m) - 1
                )
                candidates["cptl_reduction_deg_c_min"] = (
                    float(baseline[primary_field]) - candidates[primary_field]
                )
                candidates["cptl_reduction_percent"] = np.where(
                    float(baseline[primary_field]) > 0,
                    100
                    * candidates["cptl_reduction_deg_c_min"]
                    / float(baseline[primary_field]),
                    0.0,
                )
                candidates["probability_weighted_cptl_reduction_deg_c_min"] = (
                    candidates["mean_acceptance_probability"]
                    * candidates["cptl_reduction_deg_c_min"]
                )
                candidates["probability_weighted_cptl_reduction_percent"] = (
                    candidates["mean_acceptance_probability"]
                    * candidates["cptl_reduction_percent"]
                )
                candidates.insert(0, "region_id", region.region_id)
                candidates.insert(1, "od_id", od.od_id)
                candidates.insert(2, "origin_node", int(od.origin_node))
                candidates.insert(3, "destination_node", int(od.destination_node))
                candidates.insert(4, "departure_time_sgt", departure.isoformat())
                candidates.insert(
                    5,
                    "od_probability",
                    float(getattr(od, f"od_probability_{departure.strftime('%H')}")),
                )
                candidates["behavior_screening_maximum_distance_m"] = maximum_distance
                candidates["behavior_screening_maximum_detour_percent"] = 100 * (
                    maximum_distance / shortest.distance_m - 1
                )
                selected_index = select_behavioral_offer(
                    candidates,
                    float(
                        _required(
                            model_cfg,
                            "minimum_thermal_improvement_deg_c_min",
                            "behavior_probability_routing",
                        )
                    ),
                    minimum_probability,
                )
                candidates["selected_behavioral_offer"] = False
                candidates.loc[selected_index, "selected_behavioral_offer"] = True
                recommendation_rows.append(candidates.loc[selected_index].copy())
                route_frames.append(candidates)
                segment_frame = pd.DataFrame(segments)
                segment_frame.insert(0, "region_id", region.region_id)
                segment_frame.insert(1, "od_id", od.od_id)
                segment_frame.insert(2, "departure_time_sgt", departure.isoformat())
                segment_frames.append(segment_frame)
    routes = gpd.GeoDataFrame(
        pd.concat(route_frames, ignore_index=True),
        geometry="geometry",
        crs=representative.output_crs,
    )
    recommendations = gpd.GeoDataFrame(
        recommendation_rows,
        geometry="geometry",
        crs=representative.output_crs,
    ).reset_index(drop=True)
    segments = pd.concat(segment_frames, ignore_index=True)
    expected = len(sample) * len(representative.departure_times)
    if len(recommendations) != expected:
        raise RuntimeError("Behavioral recommendation panel is incomplete")
    summary_table = _summarize(recommendations)
    paths = {key: project_root / str(value) for key, value in outputs.items()}
    if output_root is not None:
        paths = {key: output_root / path.name for key, path in paths.items()}
    for path in paths.values():
        path.parent.mkdir(parents=True, exist_ok=True)
    routes.drop(columns="geometry").to_csv(paths["candidate_routes"], index=False)
    recommendations.drop(columns="geometry").to_csv(paths["recommended_routes"], index=False)
    segments.to_csv(paths["candidate_segments"], index=False)
    if paths["geopackage"].exists():
        paths["geopackage"].unlink()
    routes.to_file(paths["geopackage"], layer="candidate_routes", driver="GPKG")
    recommendations.to_file(
        paths["geopackage"], layer="recommended_routes", driver="GPKG", mode="a"
    )
    summary_table.to_csv(paths["summary_table"], index=False)
    summary = {
        "analysis_id": str(_required(model_cfg, "analysis_id", "behavior_probability_routing")),
        "case_count": len(recommendations),
        "candidate_route_count": len(routes),
        "behavior_model": behavior,
        "minimum_screening_acceptance_probability": minimum_probability,
        "probability_role": str(
            _required(model_cfg, "probability_role", "behavior_probability_routing")
        ),
        "interpretation": str(
            _required(model_cfg, "interpretation", "behavior_probability_routing")
        ),
        "summary": summary_table.to_dict(orient="records"),
    }
    paths["summary_json"].write_text(json.dumps(summary, indent=2), encoding="utf-8")
    _plot(summary_table, paths["figure_png"], paths["figure_svg"])
    _write_reports(paths, summary_table, behavior, model_cfg)
    return summary


def merge_behavior_probability_checkpoints(
    config_path: str | Path,
    checkpoint_root: Path,
    project_root: Path = PROJECT_ROOT,
) -> dict[str, Any]:
    """Merge completed per-region runs into the configured final outputs."""
    config_payload = yaml.safe_load(Path(config_path).read_text(encoding="utf-8"))
    model_cfg = _required(config_payload, "behavior_probability_routing", "root")
    outputs = _required(config_payload, "outputs", "root")
    behavior = json.loads(
        (project_root / str(_required(model_cfg, "behavior_summary", "behavior_probability_routing"))).read_text(encoding="utf-8")
    )
    configured_names = {key: Path(str(value)).name for key, value in outputs.items()}
    regions = ("clementi_mrt", "jurong_east_mrt", "toa_payoh_mrt", "raffles_place_mrt")
    candidate_frames = []
    recommendation_frames = []
    segment_frames = []
    candidate_geometries = []
    recommendation_geometries = []
    for region_id in regions:
        root = checkpoint_root / region_id
        required_paths = [
            root / configured_names["candidate_routes"],
            root / configured_names["recommended_routes"],
            root / configured_names["candidate_segments"],
            root / configured_names["geopackage"],
        ]
        missing = [str(path) for path in required_paths if not path.exists()]
        if missing:
            raise FileNotFoundError(f"Incomplete checkpoint {region_id}: {missing}")
        candidate_frames.append(pd.read_csv(required_paths[0]))
        recommendation_frames.append(pd.read_csv(required_paths[1]))
        segment_frames.append(pd.read_csv(required_paths[2]))
        candidate_geometries.append(gpd.read_file(required_paths[3], layer="candidate_routes"))
        recommendation_geometries.append(gpd.read_file(required_paths[3], layer="recommended_routes"))

    candidates = pd.concat(candidate_frames, ignore_index=True)
    recommendations = pd.concat(recommendation_frames, ignore_index=True)
    segments = pd.concat(segment_frames, ignore_index=True)
    summary_table = _summarize(recommendations)
    paths = {key: project_root / str(value) for key, value in outputs.items()}
    for path in paths.values():
        path.parent.mkdir(parents=True, exist_ok=True)
    candidates.to_csv(paths["candidate_routes"], index=False)
    recommendations.to_csv(paths["recommended_routes"], index=False)
    segments.to_csv(paths["candidate_segments"], index=False)
    summary_table.to_csv(paths["summary_table"], index=False)
    if paths["geopackage"].exists():
        paths["geopackage"].unlink()
    candidate_gdf = gpd.GeoDataFrame(pd.concat(candidate_geometries, ignore_index=True), geometry="geometry", crs=candidate_geometries[0].crs)
    recommendation_gdf = gpd.GeoDataFrame(pd.concat(recommendation_geometries, ignore_index=True), geometry="geometry", crs=recommendation_geometries[0].crs)
    candidate_gdf.to_file(paths["geopackage"], layer="candidate_routes", driver="GPKG")
    recommendation_gdf.to_file(paths["geopackage"], layer="recommended_routes", driver="GPKG", mode="a")
    summary = {
        "analysis_id": str(_required(model_cfg, "analysis_id", "behavior_probability_routing")),
        "case_count": len(recommendations),
        "candidate_route_count": len(candidates),
        "behavior_model": behavior,
        "od_sample_type": "behavior_informed_synthetic_od_not_observed_demand",
        "minimum_screening_acceptance_probability": float(model_cfg["minimum_screening_acceptance_probability"]),
        "probability_role": str(model_cfg["probability_role"]),
        "interpretation": str(model_cfg["interpretation"]),
        "summary": summary_table.to_dict(orient="records"),
    }
    paths["summary_json"].write_text(json.dumps(summary, indent=2), encoding="utf-8")
    _plot(summary_table, paths["figure_png"], paths["figure_svg"])
    _write_reports(paths, summary_table, behavior, model_cfg)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "config/behavior_probability_routing.yaml",
    )
    parser.add_argument("--region")
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("--merge-checkpoints", type=Path)
    args = parser.parse_args()
    if args.merge_checkpoints is not None:
        print(json.dumps(merge_behavior_probability_checkpoints(args.config, args.merge_checkpoints), indent=2))
        return
    print(
        json.dumps(
            build_behavior_probability_routes(
                args.config,
                region_id=args.region,
                output_root=args.output_root,
            ),
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
