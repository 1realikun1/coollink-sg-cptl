"""Behavior-informed synthetic OD sampling and four-region CPTL experiment.

This module deliberately separates trip plausibility from observed demand. MRT
exits are official LTA points; activity anchors and capacity are OSM-derived
building proxies; temporal preferences and distance deterrence are declared
priors. No row is represented as an observed pedestrian trip.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Any

import geopandas as gpd
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
import yaml

from coollink_sg.config import DynamicCPTLConfig, ProcessedLayerConfig, ShortestPathConfig
from coollink_sg.heat.dynamic_utci import TimeVaryingUTCI
from coollink_sg.routing.shortest_path import build_routing_graph
from coollink_sg.routing.time_dependent_cptl import compute_time_dependent_cptl_routes

PROJECT_ROOT = Path(__file__).resolve().parents[3]
LENGTH_FIELD = "length_m"

CATEGORY_TAGS = {
    "residential": {"residential", "apartments", "house", "terrace", "semidetached_house", "detached", "bungalow", "dormitory"},
    "employment": {"office", "commercial", "industrial", "warehouse", "hotel"},
    "education": {"school", "university", "college", "kindergarten"},
    "retail": {"retail", "supermarket", "mall"},
    "community": {"hospital", "clinic", "civic", "public", "community_centre", "government"},
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def classify_building(value: Any) -> str | None:
    """Map an explicit OSM building tag to one activity category."""
    tag = str(value).strip().lower()
    for category, tags in CATEGORY_TAGS.items():
        if tag in tags:
            return category
    return None


def weighted_quantile(values: pd.Series, weights: pd.Series, quantile: float) -> float:
    """Return a deterministic weighted quantile for non-negative weights."""
    frame = pd.DataFrame({"value": values.astype(float), "weight": weights.astype(float)}).dropna()
    frame = frame.loc[frame["weight"].gt(0)].sort_values("value")
    if frame.empty:
        return float("nan")
    cutoff = quantile * frame["weight"].sum()
    return float(frame.loc[frame["weight"].cumsum().ge(cutoff), "value"].iloc[0])


def _routing_graph(nodes: gpd.GeoDataFrame, edges: gpd.GeoDataFrame, crs: str) -> nx.MultiDiGraph:
    return build_routing_graph(
        nodes,
        edges,
        ShortestPathConfig(
            network_path="in_memory", nodes_layer="nodes", edges_layer="edges",
            output_crs=crs, cost_field=LENGTH_FIELD,
        ),
    )


def _nearest_nodes(points: gpd.GeoDataFrame, nodes: gpd.GeoDataFrame) -> pd.Series:
    joined = gpd.sjoin_nearest(
        points[["geometry"]], nodes[["osmid", "geometry"]], how="left", distance_col="snap_distance_m"
    )
    joined = joined.loc[~joined.index.duplicated(keep="first")]
    return joined["osmid"].astype("int64")


def _candidate_buildings(
    path: Path, nodes: gpd.GeoDataFrame, maximum_per_category: int, crs: str
) -> gpd.GeoDataFrame:
    buildings = gpd.read_file(path, layer="building_heights").to_crs(crs)
    buildings["activity_category"] = buildings["building"].map(classify_building)
    buildings = buildings.loc[buildings["activity_category"].notna()].copy()
    network_hull = nodes.geometry.union_all().convex_hull.buffer(100)
    buildings = buildings.loc[buildings.geometry.intersects(network_hull)].copy()
    buildings["footprint_area_m2"] = buildings.geometry.area
    levels = pd.to_numeric(buildings["levels_used"], errors="coerce").fillna(1).clip(lower=1)
    buildings["floor_area_proxy_m2"] = buildings["footprint_area_m2"] * levels
    buildings["capacity_score"] = np.log1p(buildings["floor_area_proxy_m2"])
    buildings = (
        buildings.sort_values(["activity_category", "capacity_score", "building_id"], ascending=[True, False, True])
        .groupby("activity_category", group_keys=False)
        .head(maximum_per_category)
        .copy()
    )
    buildings["geometry"] = buildings.geometry.representative_point()
    buildings["node_id"] = _nearest_nodes(buildings, nodes).reindex(buildings.index)
    buildings = buildings.dropna(subset=["node_id"]).copy()
    buildings["node_id"] = buildings["node_id"].astype("int64")
    totals = buildings.groupby("activity_category")["capacity_score"].transform("sum")
    buildings["capacity_share_within_category"] = buildings["capacity_score"] / totals
    return buildings


def build_region_sample(
    cfg: dict[str, Any], region: dict[str, Any], exits_all: gpd.GeoDataFrame, project_root: Path
) -> tuple[pd.DataFrame, gpd.GeoDataFrame, gpd.GeoDataFrame, nx.MultiDiGraph]:
    """Create a deterministic union of high-weight exit--activity OD pairs."""
    crs = str(cfg["output_crs"])
    network_path = project_root / region["network"]
    nodes = gpd.read_file(network_path, layer="nodes").to_crs(crs)
    edges = gpd.read_file(network_path, layer="edges").to_crs(crs)
    graph = _routing_graph(nodes, edges, crs)
    largest = max(nx.strongly_connected_components(graph), key=len)
    valid_nodes = nodes.loc[nodes["osmid"].astype(int).isin(largest)].copy()

    exits = exits_all.loc[exits_all["STATION_NA"].eq(region["station_name"])].to_crs(crs).copy()
    if exits.empty:
        raise ValueError(f"No official MRT exits found for {region['station_name']}")
    exits["node_id"] = _nearest_nodes(exits, valid_nodes).reindex(exits.index)
    exits = exits.dropna(subset=["node_id"]).copy()
    exits["node_id"] = exits["node_id"].astype("int64")
    exits["exit_prior"] = 1.0 / len(exits)

    buildings = _candidate_buildings(
        project_root / region["buildings"], valid_nodes,
        int(cfg["maximum_buildings_per_category"]), crs,
    )
    if buildings.empty:
        raise ValueError(f"No explicit activity buildings found for {region['region_id']}")

    min_d = float(cfg["minimum_network_distance_m"])
    max_d = float(cfg["maximum_network_distance_m"])
    beta = math.log(2) / float(cfg["distance_half_life_m"])
    candidates: list[dict[str, Any]] = []
    for exit_row in exits.itertuples():
        lengths = nx.single_source_dijkstra_path_length(graph, int(exit_row.node_id), cutoff=max_d, weight=LENGTH_FIELD)
        reverse_lengths = nx.single_source_dijkstra_path_length(graph.reverse(copy=False), int(exit_row.node_id), cutoff=max_d, weight=LENGTH_FIELD)
        for building in buildings.itertuples():
            node_id = int(building.node_id)
            directions = (
                ("station_to_activity", int(exit_row.node_id), node_id, lengths.get(node_id)),
                ("activity_to_station", node_id, int(exit_row.node_id), reverse_lengths.get(node_id)),
            )
            for direction, origin, destination, distance in directions:
                if distance is None or not min_d <= float(distance) <= max_d:
                    continue
                row = {
                    "region_id": region["region_id"], "region_label": region["region_label"],
                    "station_name": region["station_name"], "exit_code": exit_row.EXIT_CODE,
                    "exit_objectid": int(exit_row.OBJECTID), "activity_building_id": building.building_id,
                    "activity_building_tag": building.building, "activity_category": building.activity_category,
                    "direction": direction, "origin_node": origin, "destination_node": destination,
                    "shortest_path_distance_m": float(distance),
                    "floor_area_proxy_m2": float(building.floor_area_proxy_m2),
                    "capacity_share_within_category": float(building.capacity_share_within_category),
                    "exit_prior": float(exit_row.exit_prior),
                }
                for departure in cfg["departure_times_sgt"]:
                    hour = pd.Timestamp(departure).strftime("%H")
                    activity_weight = float(cfg["activity_weights"][hour][direction][building.activity_category])
                    row[f"raw_weight_{hour}"] = (
                        row["exit_prior"] * row["capacity_share_within_category"] * activity_weight
                        * math.exp(-beta * row["shortest_path_distance_m"])
                    )
                candidates.append(row)
    candidate_frame = pd.DataFrame(candidates)
    if candidate_frame.empty:
        raise ValueError(f"No routable behavior candidates for {region['region_id']}")

    selected: set[int] = set()
    k = int(cfg["selected_pairs_per_category_direction_and_time"])
    for departure in cfg["departure_times_sgt"]:
        hour = pd.Timestamp(departure).strftime("%H")
        for direction in ("station_to_activity", "activity_to_station"):
            subset = candidate_frame.loc[candidate_frame["direction"].eq(direction)]
            for _, category_subset in subset.groupby("activity_category"):
                selected.update(category_subset.nlargest(k, f"raw_weight_{hour}").index.tolist())
    sample = candidate_frame.loc[sorted(selected)].copy().reset_index(drop=True)
    sample.insert(2, "od_id", [f"{region['region_id']}_bod_{i:03d}" for i in range(1, len(sample) + 1)])
    for departure in cfg["departure_times_sgt"]:
        hour = pd.Timestamp(departure).strftime("%H")
        total = sample[f"raw_weight_{hour}"].sum()
        sample[f"od_probability_{hour}"] = sample[f"raw_weight_{hour}"] / total
        sample[f"selection_rank_{hour}"] = sample[f"raw_weight_{hour}"].rank(method="first", ascending=False).astype(int)
    sample["sample_type"] = cfg["sample_type"]
    sample["station_flow_status"] = cfg["station_flow_status"]
    return sample, nodes, edges, graph


def _dynamic_config(cfg: dict[str, Any], region: dict[str, Any]) -> DynamicCPTLConfig:
    placeholder = ProcessedLayerConfig(path="not_used", layer="not_used")
    return DynamicCPTLConfig(
        analysis_id=f"{cfg['analysis_id']}|{region['region_id']}", output_crs=str(cfg["output_crs"]),
        timezone=str(cfg["timezone"]), departure_times=tuple(cfg["departure_times_sgt"]),
        walking_speed_m_s=float(cfg["walking_speed_m_s"]), primary_threshold_deg_c=float(cfg["primary_threshold_deg_c"]),
        sensitivity_thresholds_deg_c=tuple(float(x) for x in cfg["sensitivity_thresholds_deg_c"]),
        detour_limits=tuple(float(x) for x in cfg["detour_limits"]), time_bin_seconds=int(cfg["time_bin_seconds"]),
        integration_method="piecewise_linear_threshold_crossing_exact", waiting_allowed=False,
        primary_height_scenario="central", thermal_source_status=str(cfg["thermal_source_status"]),
        is_solweig_dynamic_result=True, output_stem="behavior_informed_od", validation_series_start_sgt="2026-08-17T09:00:00+08:00",
        validation_series_end_sgt="2026-08-17T18:00:00+08:00", validation_series_interval_seconds=900,
        network_path=region["network"], nodes_layer="nodes", edges_layer="edges", static_thermal=placeholder,
        dynamic_thermal_path=region["thermal"], od_summary_path="not_used", endpoints=placeholder,
    )


def summarize_weighted(routes: pd.DataFrame, cap: float = 0.05) -> pd.DataFrame:
    selected = routes.loc[np.isclose(routes["detour_limit_fraction"], cap)].copy()
    rows = []
    for (region_id, label), frame in selected.groupby(["region_id", "region_label"], sort=False):
        w = frame["od_probability"].astype(float)
        reduction = frame["primary_cptl_reduction_vs_shortest_percent"].astype(float)
        detour = 100 * (frame["distance_ratio_to_shortest"].astype(float) - 1)
        rows.append({
            "region_id": region_id, "region_label": label, "detour_limit_percent": 100 * cap,
            "case_count": len(frame), "od_count": int(frame["od_id"].nunique()),
            "weighted_median_cptl_reduction_percent": weighted_quantile(reduction, w, 0.5),
            "weighted_q25_cptl_reduction_percent": weighted_quantile(reduction, w, 0.25),
            "weighted_q75_cptl_reduction_percent": weighted_quantile(reduction, w, 0.75),
            "weighted_positive_reduction_share_percent": float(100 * np.average(reduction.gt(1e-9), weights=w)),
            "weighted_median_actual_detour_percent": weighted_quantile(detour, w, 0.5),
            "unweighted_median_cptl_reduction_percent": float(reduction.median()),
            "unweighted_positive_reduction_share_percent": float(100 * reduction.gt(1e-9).mean()),
        })
    return pd.DataFrame(rows)


def _convergence(routes: pd.DataFrame, cap: float) -> pd.DataFrame:
    frame = routes.loc[np.isclose(routes["detour_limit_fraction"], cap)].copy()
    rows = []
    for region, group in frame.groupby("region_id"):
        for k in (10, 20, 30, 40):
            subset = group.loc[group["selection_rank"].le(k)].copy()
            if subset.empty:
                continue
            subset["w"] = subset.groupby("departure_time_sgt")["od_probability"].transform(lambda x: x / x.sum())
            reduction = subset["primary_cptl_reduction_vs_shortest_percent"].astype(float)
            rows.append({"region_id": region, "top_k_per_departure": k, "case_count": len(subset),
                         "weighted_median_cptl_reduction_percent": weighted_quantile(reduction, subset["w"], 0.5),
                         "weighted_positive_reduction_share_percent": float(100 * np.average(reduction.gt(1e-9), weights=subset["w"]))})
    return pd.DataFrame(rows)


def _plot(summary: pd.DataFrame, coverage: pd.DataFrame, output: Path) -> None:
    merged = summary.merge(coverage[["region_id", "median_cptl_reduction_percent", "positive_reduction_share_percent"]], on="region_id")
    labels = merged["region_label"].tolist(); x = np.arange(len(labels)); width = 0.36
    fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.5), constrained_layout=True)
    bars00 = axes[0].bar(x - width/2, merged["weighted_median_cptl_reduction_percent"], width, label="Behavior-informed")
    bars01 = axes[0].bar(x + width/2, merged["median_cptl_reduction_percent"], width, label="Coverage control")
    axes[0].set_ylabel("Median CPTL reduction (%)"); axes[0].set_xticks(x, labels, rotation=20, ha="right"); axes[0].margins(y=0.14)
    bars10 = axes[1].bar(x - width/2, merged["weighted_positive_reduction_share_percent"], width, label="Behavior-informed")
    bars11 = axes[1].bar(x + width/2, merged["positive_reduction_share_percent"], width, label="Coverage control")
    axes[1].set_ylabel("Positive-benefit share (%)"); axes[1].set_xticks(x, labels, rotation=20, ha="right"); axes[1].set_ylim(0, 108)
    for axis, bars in ((axes[0], bars00), (axes[0], bars01), (axes[1], bars10), (axes[1], bars11)):
        axis.bar_label(bars, fmt="%.1f", padding=2, fontsize=7)
    axes[0].legend(frameon=False, fontsize=8)
    fig.savefig(output, format=output.suffix.lstrip(".") or "svg")
    plt.close(fig)


def _primary_coverage_control(frame: pd.DataFrame, cap: float) -> pd.DataFrame:
    """Normalize the multistation network-coverage control for comparison."""
    coverage = frame.copy()
    if "detour_limit_fraction" in coverage:
        coverage = coverage.loc[np.isclose(coverage["detour_limit_fraction"], cap)].copy()
    labels = {
        "clementi_mrt": "Clementi", "jurong_east_mrt": "Jurong East",
        "toa_payoh_mrt": "Toa Payoh", "raffles_place_mrt": "Raffles Place",
    }
    coverage["region_label"] = coverage["region_id"].map(labels)
    coverage["detour_limit_percent"] = 100 * cap
    return coverage


def run_experiment(config_path: Path, project_root: Path = PROJECT_ROOT) -> dict[str, Any]:
    payload = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    cfg = dict(payload["behavior_informed_od"])
    cfg["activity_weights"] = payload["activity_weights"]
    inputs, outputs = payload["inputs"], payload["outputs"]
    snapshots = sorted(project_root.glob(inputs["mrt_exit_snapshot_glob"]))
    if not snapshots:
        raise FileNotFoundError("No archived official MRT-exit snapshot")
    exit_path = snapshots[-1]
    exits_all = gpd.read_file(exit_path)
    samples, route_frames = [], []
    source_records = []
    for region_index, region in enumerate(inputs["regions"], 1):
        sample, nodes, edges, graph = build_region_sample(cfg, region, exits_all, project_root)
        samples.append(sample)
        thermal_path = project_root / region["thermal"]
        thermal = TimeVaryingUTCI(pd.read_csv(thermal_path), "central", cfg["thermal_source_status"])
        run_cfg = _dynamic_config(cfg, region)
        for od_index, od in enumerate(sample.itertuples(index=False), 1):
            print(f"[{region_index}/4 {region['region_id']}] OD {od_index}/{len(sample)} {od.od_id}", flush=True)
            routes, _, _ = compute_time_dependent_cptl_routes(nodes, edges, thermal, int(od.origin_node), int(od.destination_node), run_cfg, routing_graph=graph)
            routes.insert(0, "region_id", region["region_id"]); routes.insert(1, "region_label", region["region_label"]); routes.insert(2, "od_id", od.od_id)
            hour = pd.to_datetime(routes["departure_time_sgt"]).dt.strftime("%H")
            probabilities = {h: getattr(od, f"od_probability_{h}") for h in hour.unique()}
            ranks = {h: getattr(od, f"selection_rank_{h}") for h in hour.unique()}
            routes.insert(3, "od_probability", hour.map(probabilities).astype(float)); routes.insert(4, "selection_rank", hour.map(ranks).astype(int))
            routes.insert(5, "direction", od.direction); routes.insert(6, "activity_category", od.activity_category)
            route_frames.append(routes)
        source_records.append({"region_id": region["region_id"], "network_sha256": _sha256(project_root / region["network"]),
                               "building_sha256": _sha256(project_root / region["buildings"]), "thermal_sha256": _sha256(thermal_path)})
    sample_frame = pd.concat(samples, ignore_index=True)
    routes = gpd.GeoDataFrame(pd.concat(route_frames, ignore_index=True), geometry="geometry", crs=cfg["output_crs"])
    for departure, frame in routes.groupby(["region_id", "departure_time_sgt"]):
        if not np.isclose(frame.drop_duplicates("od_id")["od_probability"].sum(), 1.0):
            raise AssertionError(f"OD probabilities do not sum to one: {departure}")
    summary = summarize_weighted(routes, float(cfg["primary_detour_limit"]))
    coverage = _primary_coverage_control(
        pd.read_csv(project_root / inputs["coverage_results"]),
        float(cfg["primary_detour_limit"]),
    )
    comparison = summary.merge(coverage, on=["region_id", "region_label", "detour_limit_percent"], how="left", suffixes=("_behavior", "_coverage"))
    convergence = _convergence(routes, float(cfg["primary_detour_limit"]))
    for key in ("sample", "routes", "routes_gpkg", "summary", "comparison", "convergence", "figure", "report"):
        (project_root / outputs[key]).parent.mkdir(parents=True, exist_ok=True)
    sample_frame.to_csv(project_root / outputs["sample"], index=False)
    routes.drop(columns="geometry").to_csv(project_root / outputs["routes"], index=False)
    routes.to_file(project_root / outputs["routes_gpkg"], layer="routes", driver="GPKG")
    summary.to_csv(project_root / outputs["summary"], index=False)
    comparison.to_csv(project_root / outputs["comparison"], index=False)
    convergence.to_csv(project_root / outputs["convergence"], index=False)
    _plot(summary, coverage, project_root / outputs["figure"])
    metadata = {"analysis_id": cfg["analysis_id"], "sample_type": cfg["sample_type"], "station_flow_status": cfg["station_flow_status"],
                "mrt_exit_snapshot": str(exit_path.relative_to(project_root)), "mrt_exit_snapshot_sha256": _sha256(exit_path),
                "sample_rows": len(sample_frame), "route_rows": len(routes), "sources": source_records}
    (project_root / outputs["report"]).write_text(
        "# 行为信息驱动合成 OD 实验记录\n\n" +
        "本实验以 LTA 官方 MRT 出口为交通锚点，以 OSM 明确用途建筑的面积×楼层代理活动容量，并用分时活动先验和 500 m 距离半衰期构造 OD 权重。它不是观测行人需求。LTA DataMall 客流接口需要 AccountKey，本次未获得密钥，因此各出口使用等先验；没有编造客流。\n\n" +
        "## 可复现状态\n\n```json\n" + json.dumps(metadata, ensure_ascii=False, indent=2) + "\n```\n\n" +
        "## 5% 绕行约束结果\n\n" + summary.to_markdown(index=False, floatfmt=".3f") + "\n\n" +
        "## 解释边界\n\n主分析回答的是‘在比覆盖路网更贴近日常交通节点与活动目的地的合成 OD 分布下，结论是否仍成立’，不能用于报告真实客流量或个体选择概率。旧的 12 OD/区网络覆盖样本保留为对照。\n",
        encoding="utf-8",
    )
    return metadata


def main() -> None:
    parser = argparse.ArgumentParser(); parser.add_argument("--config", type=Path, default=PROJECT_ROOT / "config/behavior_informed_od.yaml")
    args = parser.parse_args(); print(json.dumps(run_experiment(args.config), indent=2))


if __name__ == "__main__":
    main()
