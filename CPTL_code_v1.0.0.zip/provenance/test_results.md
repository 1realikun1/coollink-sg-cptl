# Archive verification — 2026-09-08

Python 3.11.15, Windows; see environment-tested.txt for package versions.

| Check | Outcome |
|---|---|
| Primary package: `python -m pytest -q` | 181 passed, 1 explicitly skipped; 14 upstream pyproj/NumPy deprecation warnings |
| Historical control package: `python -m pytest -q` | 200 passed, 1 explicitly skipped; 14 upstream pyproj/NumPy deprecation warnings |
| `scripts/verify_results.py` | Passed all result integrity, eligibility, candidate-pool optimality and district summary checks |
| Full SOLWEIG/routing recomputation | Not run during packaging; processed inputs and original algorithms preserved |

The same upstream integration test is skipped in each snapshot because it requires the original global CHMv2 raw tile index, which is not redistributed. The remaining tests use original synthetic fixtures and the two deposited domain registry GeoPackages. No scientific result was changed to satisfy a test. Original project raw data were not modified.

An initial attempt in a minimal Python 3.12 environment failed because upstream dependencies were absent; the final suite used the complete Python 3.11 research environment. The initial portable-copy run also exposed a missing temporary-directory parent and two missing registry fixtures; packaging configuration/fixtures were corrected before the successful runs above.
